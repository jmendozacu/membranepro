<!DOCTYPE html>
<html <?php language_attributes(); ?>>

<head>

<meta charset="<?php bloginfo('charset'); ?>" />

<title><?php pk_title(); ?></title>

<?php pk_specific_js_vars(); ?>
<?php if (pk_get_options('pk_general_options', 'general_favicon') != '') : ?>

<link rel="shortcut icon" href="<?php echo stripslashes(pk_get_options('pk_general_options', 'general_favicon')); ?>" />
<?php endif; ?>

<!--[if lt IE 9]><script src="<?php echo PK_THEME_DIR.'/parkerandkent2011/js/theme/'; ?>html5.js"></script><![endif]-->
<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
<?php
	if (is_singular() && comments_open() && (get_option('thread_comments') == 1)) {
		
		wp_enqueue_script('comment-reply');
		
	}
?>
<?php pk_enqueue_theme_styles(); ?>
<?php wp_head(); ?>

<noscript>
	
	<link rel="stylesheet" href="<?php echo PK_THEME_DIR.'/parkerandkent2011/css/theme/pk/'; ?>pk_no_script.css" type="text/css" />
	
</noscript>

<?php
	pk_get_logo();
	
	if (pk_get_options('pk_general_options', 'general_custom_css') != '') : 
?>

<style type="text/css">

<?php echo stripslashes(pk_get_options('pk_general_options', 'general_custom_css')); ?>


</style>
<?php
	endif;
?>

</head>

<body <?php body_class(); ?>>

<!-- pk start wrapper -->
<div id="wrapper">
<?php pk_header(); ?>