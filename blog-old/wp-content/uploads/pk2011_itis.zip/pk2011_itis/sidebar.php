<?php
	if (function_exists('dynamic_sidebar')) :
		
		if (is_singular(array('page', 'post', 'works')) && dynamic_sidebar('sidebar_'.$post -> ID.'')) : $pk_custom_sidebars = get_option('pk_custom_sidebars'); endif;
		if (is_singular(array('page', 'post', 'works')) && isset($pk_custom_sidebars) && $pk_custom_sidebars[$post -> ID]['show_default_sidebar'] == 'false') :
		
		else :
			
			if (dynamic_sidebar('sidebar_all')) : endif;
			
			if (is_404() && dynamic_sidebar('sidebar_404')) : return; endif;
			if (is_front_page() && is_home() && dynamic_sidebar('sidebar_front_page') && dynamic_sidebar('sidebar_blog')) : return; endif;
			if (is_front_page() && dynamic_sidebar('sidebar_front_page')) : return; endif;
			if (is_home() && dynamic_sidebar('sidebar_blog')) : return; endif;
			if (is_page_template('flickr-grid-gallery-page.php') && dynamic_sidebar('sidebar_flickr_grid_gallery_pages')) : return; endif;
			if ((is_page_template('workspage_1.php') || is_page_template('workspage_2.php') || is_page_template('workspage_3.php') || is_page_template('workspage_4.php') || is_page_template('workspage_5.php') || is_page_template('workspage_6.php')) && dynamic_sidebar('sidebar_works')) : return; endif;
			if (is_singular('works') && dynamic_sidebar('sidebar_works')) : return; endif;
			if (is_singular('page') && dynamic_sidebar('sidebar_pages')) : return; endif;
			if (is_singular('post') && dynamic_sidebar('sidebar_blog')) : return; endif;
			if (is_archive() && !is_tax('taxonomy_works') && dynamic_sidebar('sidebar_blog_archive')) : return; endif;
			if ((is_tax('taxonomy_works') || (function_exists('is_post_type_archive') && is_post_type_archive('works'))) && dynamic_sidebar('sidebar_works_archive')) : return; endif;
			if (is_search() && dynamic_sidebar('sidebar_search')) : return; endif;
		
		endif;
		
	endif;
?>