<?php
/*
Template Name: Flickr Grid Gallery Page
*/
?>
<?php get_header(); ?>
<?php require_once(PK_THEME_INCLUDES.'/pk_settings.php'); ?>
<?php require_once(PK_THEME_INCLUDES.'/pk_flickr_grid_gallery_page_template.php'); ?>