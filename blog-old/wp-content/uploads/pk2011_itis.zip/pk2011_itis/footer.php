</div>
<!-- pk end page -->

<!-- pk start footer -->
<footer>

<!-- pk start footer center box-->
<div class="pk_center_box">
<?php pk_footer_widgets_area(); ?>

<!-- pk start footer navigation -->
<?php pk_footer_navigation(); ?>

<!-- pk end footer navigation -->

<!-- pk start footer copyright -->
<?php pk_footer_copyright(); ?>
<!-- pk end footer copyright -->

<!-- pk start footer social networks -->
<?php pk_footer_social_networks(); ?>
<!-- pk end footer social networks -->

</div>
<!-- pk end footer center box-->

</footer>
<!-- pk end footer -->

</div>
<!-- pk end wrapper -->

<?php wp_footer(); ?>
</body>
</html>