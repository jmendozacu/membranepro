<?php
/*
Template Name: Works - 4 Columns
*/
?>
<?php require_once(PK_THEME_INCLUDES.'/pk_works_page_template.php'); ?>