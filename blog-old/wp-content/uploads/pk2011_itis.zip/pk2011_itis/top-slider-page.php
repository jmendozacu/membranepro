<?php
/*
Template Name: Top Slider Page
*/
?>
<?php get_header(); ?>
<?php require_once(PK_THEME_INCLUDES.'/pk_settings.php'); ?>
<?php require_once(PK_THEME_INCLUDES.'/pk_top_slider_page_template.php'); ?>