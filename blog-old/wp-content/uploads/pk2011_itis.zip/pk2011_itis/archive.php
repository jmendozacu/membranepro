<?php get_header(); ?>
<?php require_once(PK_THEME_INCLUDES.'/pk_settings.php'); ?>
<?php require_once(PK_THEME_INCLUDES.'/pk_blog_template.php'); ?>