<?php
if (!empty($_SERVER['SCRIPT_FILENAME']) && 'comments.php' == basename($_SERVER['SCRIPT_FILENAME'])) die('Please do not load this page directly. Thanks!');

if (post_password_required()) : 
?>
<p class="nocomments"><?php _e('This post is password protected. Enter the password to view and post comments.', 'pk_text_domain_front'); ?></p>
<?php
	return;

endif;

if (comments_open()) : 

	global $pk_sidebar;
	global $pk_show_comments_sidebar;

	if ($pk_sidebar == 'none' && $pk_show_comments_sidebar == 'true') : 
?>

<!-- pk start comments main -->
<div id="pk_comments_main">

<?php
	endif;
?>
<!-- pk start comments -->
<div id="comments">
<div id="pk_comments">

<!-- pk start comments title -->
<h4><?php printf(_n('One Comment', '%1$s Comments', get_comments_number(), 'pk_text_domain_front'), number_format_i18n( get_comments_number())); ?></h4>
<!-- pk end comments title -->

<!-- pk start comments rss link -->
<a class="pk_comments_rss pk_alignright" href="<?php echo get_post_comments_feed_link(); ?>" title="<?php _e('Subscribe to Comments via RSS', 'pk_text_domain_front'); ?>"><?php _e('Comments RSS', 'pk_text_domain_front'); ?></a>
<!-- pk end comments rss link -->

<!-- pk start comments list -->
<ol class="comment_list">
<?php
	wp_list_comments(array('callback' => 'pk_comments_list'));
?>

</ol>
<!-- pk end comments list -->
<?php
	pk_comments_navigation(paginate_comments_links('prev_next=0&show_all=1&echo=0&type=array'));
?>

</div>
</div>
<!-- pk end comments -->

<?php
endif;

if (comments_open()) : 
?>
<!-- pk start comments form -->
<div id="respond">
<div id="pk_comments_form" class="pk_contact_form">
<h4><?php _e('Leave a comment', 'pk_text_domain_front'); ?></h4>
<?php
	if (get_option('comment_registration') && !is_user_logged_in()) : 
?>
<p><?php _e('Please login to comment.', 'pk_text_domain_front'); ?>	</p>
<?php
	else : 
?>
<form method="post" action="<?php echo get_option('siteurl'); ?>/wp-comments-post.php">
<?php
		if (is_user_logged_in()) : 

		else: 
?>
<input type="text" name="author" id="author" tabindex="101" /><label for="author"><?php _e('Name', 'pk_text_domain_front'); ?></label>
<input type="text" name="email" id="email" tabindex="102" /><label for="email"><?php _e('Email', 'pk_text_domain_front'); ?></label>
<input type="text" name="url" id="url" tabindex="103" /><label for="url"><?php _e('Site', 'pk_text_domain_front'); ?></label>
<?php
		endif;
?>
<div class="pk_contact_form_textarea_wrapper"><textarea name="comment" id="comment" rows="6" cols="10" tabindex="104"></textarea></div>
<p class="pk_comments_allowed_tags"><?php _e('Allowed tags:', 'pk_text_domain_front'); ?> <?php echo allowed_tags(); ?></p>
<input type="submit" name="submit" id="submit" value="<?php _e('Post a comment', 'pk_text_domain_front'); ?>" tabindex="105" />
<?php
		cancel_comment_reply_link(__('Cancel reply', 'pk_text_domain_front'));
		comment_id_fields();
		do_action('comment_form', $post->ID);
?>

</form>
<?php
	endif;
?>
</div>
</div>
<!-- pk end comments form -->
<?php
	if (comments_open()) : 
		
		global $pk_sidebar;
		global $pk_show_comments_sidebar;
		
		if ($pk_sidebar == 'none' && $pk_show_comments_sidebar == 'true') : 
?>

</div>
<!-- pk end comments main -->

<!-- pk start comments sidebar -->
<aside id="pk_comments_sidebar">
<div id="pk_comments_sidebar_content">

<?php
			if (function_exists('dynamic_sidebar') && dynamic_sidebar('sidebar_comments')) : endif;
?>
</div>
</aside>
<!-- pk end comments sidebar -->
<?php
		endif;
		
	endif;
	
endif;

?>