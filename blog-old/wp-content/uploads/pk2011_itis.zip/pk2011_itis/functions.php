<?php

define('PK_THEME_DIR', get_template_directory_uri());
define('PK_FRAMEWORK', get_template_directory().'/parkerandkent2011');
define('PK_FUNCTIONS', PK_FRAMEWORK.'/functions');

/*
 * PK2011 FRAMEWORK INIT
 * 
 * Another work by parker&kent
 * Author: Nicola Francesco Elia aka Parker
 * Contact: nicola@parkerandkent.com
 *
 * Follow us on ThemeForest.net: http://themeforest.net/user/ParkerAndKent
*/

require_once(PK_FUNCTIONS.'/pk_theme.php');

/*
 * THEME / ADMIN LOCALIZATION
*/

add_action('init', 'pk_load_theme_translation');

function pk_load_theme_translation() {

	load_theme_textdomain('pk_text_domain_front', PK_THEME_DIR.'/translate/theme');

}

add_action('init', 'pk_load_admin_translation');

function pk_load_admin_translation() {

	load_theme_textdomain('pk_text_domain', PK_THEME_DIR.'/translate/admin');

}

/*
 * ADMIN LOGIN / ADMIN LOGOS
*/

//add_action('login_head', 'pk_custom_login_logo');			
//add_action('admin_head', 'pk_custom_logo');

function pk_custom_login_logo() {
	
	echo '
	<style type="text/css">
		h1 a { background-image:url('.PK_THEME_DIR.'/parkerandkent2011/images/admin/login_logo.png) !important; }
	</style>';
	
}

function pk_custom_logo() {
	
	echo '
	<style type="text/css">
		#header-logo { background-image: url('.PK_THEME_DIR.'/parkerandkent2011/images/admin/admin_logo.png) !important; width:32px; height:32px; }
	</style>
	';

}

/*
 * ADMIN FOOTER
*/

//add_filter('admin_footer_text', 'pk_admin_footer');

function pk_admin_footer() {
	
	echo '2011 by <a href="http://themeforest.net/user/ParkerAndKent" target="_blank">parker&amp;kent</a>';
	
}

/*
 * CODING SUGGESTIONS
*/

/*
 * In order to easily update your theme whenever a new version is released (for bug fixes and new features)
 * we suggest you to use the following action hooks to add new functionalities and replace the existing ones.
 * 
 * Put your custom functions and all the other functions that you want to use in alternative to the theme ones
 * in this file or in any case try to keep your functions and scripts outside of the parkerandkent2011 folder.
 * At the same time, feel free to edit any of the php files contained in the main folder of the theme (the one that contains this file).
 * 
 * We will provide with every new version of the theme a changelog.txt file, just in case you want to keep track
 * of the updated scripts.
 * 
 * The theme updates will require in most of the cases the replacement of the "only" parkerandkent2011 folder.
 * Following the previous suggestions the updates will not affect your code changes.
*/

/*
 * CSS STYLING SUGGESTIONS
*/

/*
 * The theme main style CSS file and all the skins CSS files are located inside the parkerandkent2011/CSS/theme/pk/ folder.
 * The main style.CSS of the theme (located in the main theme folder, where this file is) is empty and left there for your use.
 * 
 * Add all your additional styles (new ones or overrides) in this file and, as well for the code changes, whenever a new
 * version of the theme will be released your new styles won't be overwritten.
 * 
 * We will provide with every new version of the theme a changelog.txt file, just in case you want to keep track
 * of the CSS updates.
*/

/*
 * NEW ASSETS SUGGESTIONS
*/

/*
 * As well for coding and styling, we suggest you to keep your custom assets (images, styles, libraries, etc.) outside of the parkerandkent2011 folder.
 * 
 * There is an empty "custom" folder in the main theme folder, we've created this folder just for you.
 * If you can, put all your custom assets over there.
*/

/*
 * INTRO ACTION HOOKS
*/

# pk_ah_intro

add_action('pk_ah_intro', 'pk_intro');

/*
 * TOP SLIDER PAGE ACTION HOOKS
*/

# pk_ah_top_slider_page_slider
# pk_ah_pre_top_slider_page_contents
# pk_ah_after_top_slider_page_contents
# pk_ah_pre_top_slider_page_comments
# pk_ah_after_top_slider_page_comments

add_action('pk_ah_top_slider_page_print_slider', 'pk_top_slider_page_print_slider');

function pk_top_slider_page_print_slider() {
	//echo '<p>pk_ah_top_slider_page_print_slider</p>';
	
	pk_top_slider_page_slider();
	
}

add_action('pk_ah_pre_top_slider_page_contents', 'pk_pre_top_slider_page_contents');

function pk_pre_top_slider_page_contents() {
	//echo '<p>pk_ah_pre_top_slider_page_contents</p>';
}

add_action('pk_ah_after_top_slider_page_contents', 'pk_after_top_slider_page_contents');

function pk_after_top_slider_page_contents() {
	//echo '<p>pk_ah_after_top_slider_page_contents</p>';
	
	pk_get_lightbox_gallery();
	
}

add_action('pk_ah_pre_top_slider_page_comments', 'pk_pre_top_slider_page_comments');

function pk_pre_top_slider_page_comments() {
	//echo '<span class="pk_clear_both"></span><p>pk_ah_pre_top_slider_page_comments</p>';
}

add_action('pk_ah_after_top_slider_page_comments', 'pk_after_top_slider_page_comments');

function pk_after_top_slider_page_comments() {
	//echo '<span class="pk_clear_both"></span><p>pk_ah_after_top_slider_page_comments</p>';
}

/*
 * BLOG ACTION HOOKS
*/

# pk_ah_pre_blog_loop
# pk_ah_pre_blog_list_item
# pk_ah_blog_print_list_item_standard
# pk_ah_blog_print_list_item_alternative
# pk_ah_after_blog_list_item
# pk_ah_after_blog_loop
# pk_ah_pre_blog_pagination
# pk_ah_blog_pagination
# pk_ah_after_blog_pagination
# pk_ah_blog_no_posts_available

add_action('pk_ah_pre_blog_loop', 'pk_pre_blog_loop');

function pk_pre_blog_loop() {
	//echo '<p>pk_ah_pre_blog_loop</p>';
}

add_action('pk_ah_pre_blog_list_item', 'pk_pre_blog_list_item');

function pk_pre_blog_list_item() {
	//echo '<p>pk_ah_pre_blog_list_item</p>';
}

add_action('pk_ah_blog_print_list_item_standard', 'pk_blog_list_item_standard');

add_action('pk_ah_blog_print_list_item_alternative', 'pk_blog_list_item_alternative');

add_action('pk_ah_after_blog_list_item', 'pk_after_blog_list_item');

function pk_after_blog_list_item() {
	//echo '<p>pk_ah_after_blog_list_item</p>';
}

add_action('pk_ah_after_blog_loop', 'pk_after_blog_loop');

function pk_after_blog_loop() {
	//echo '<p>pk_ah_after_blog_loop</p>';
}

add_action('pk_ah_pre_blog_pagination', 'pk_pre_blog_pagination');

function pk_pre_blog_pagination() {
	//echo '<p>pk_ah_pre_blog_pagination</p>';
}

add_action('pk_ah_blog_pagination', 'pk_blog_pagination');

add_action('pk_ah_after_blog_pagination', 'pk_after_blog_pagination');

function pk_after_blog_pagination() {
	//echo '<p>pk_ah_after_blog_pagination</p>';
}

add_action('pk_ah_blog_no_posts_available', 'pk_blog_no_posts_available');

function pk_blog_no_posts_available() {
	//echo '<p>pk_ah_blog_no_posts_available</p>';
}

/*
 * BLOG ARCHIVE ACTION HOOKS
*/

# pk_ah_pre_blog_archive_loop
# pk_ah_pre_blog_archive_list_item
# pk_ah_blog_archive_print_list_item_standard
# pk_ah_blog_archive_print_list_item_alternative
# pk_ah_after_blog_archive_list_item
# pk_ah_after_blog_archive_loop
# pk_ah_pre_blog_archive_pagination
# pk_ah_blog_archive_pagination
# pk_ah_after_blog_archive_pagination
# pk_ah_blog_archive_no_posts_available

add_action('pk_ah_pre_blog_archive_loop', 'pk_pre_blog_archive_loop');

function pk_pre_blog_archive_loop() {
	//echo '<p>pk_ah_pre_blog_archive_loop</p>';
}

add_action('pk_ah_pre_blog_archive_list_item', 'pk_pre_blog_archive_list_item');

function pk_pre_blog_archive_list_item() {
	//echo '<p>pk_ah_pre_blog_archive_list_item</p>';
}

add_action('pk_ah_blog_archive_print_list_item_standard', 'pk_blog_list_item_standard');

add_action('pk_ah_blog_archive_print_list_item_alternative', 'pk_blog_list_item_alternative');

add_action('pk_ah_after_blog_archive_list_item', 'pk_after_blog_archive_list_item');

function pk_after_blog_archive_list_item() {
	//echo '<p>pk_ah_after_blog_archive_list_item</p>';
}

add_action('pk_ah_after_blog_archive_loop', 'pk_after_blog_archive_loop');

function pk_after_blog_archive_loop() {
	//echo '<p>pk_ah_after_blog_archive_loop</p>';
}

add_action('pk_ah_pre_blog_archive_pagination', 'pk_pre_blog_archive_pagination');

function pk_pre_blog_archive_pagination() {
	//echo '<p>pk_ah_pre_blog_archive_pagination</p>';
}

add_action('pk_ah_blog_archive_pagination', 'pk_blog_pagination');

add_action('pk_ah_after_blog_archive_pagination', 'pk_after_blog_archive_pagination');

function pk_after_blog_archive_pagination() {
	//echo '<p>pk_ah_after_blog_archive_pagination</p>';
}

add_action('pk_ah_blog_archive_no_posts_available', 'pk_blog_archive_no_posts_available');

function pk_blog_archive_no_posts_available() {
	//echo '<p>pk_ah_blog_archive_no_posts_available</p>';
}

/*
 * SEARCH ACTION HOOKS
*/

# pk_ah_pre_search_loop
# pk_ah_pre_search_list_item
# pk_ah_search_print_list_item_standard
# pk_ah_search_print_list_item_alternative
# pk_ah_after_search_list_item
# pk_ah_after_search_loop
# pk_ah_pre_search_pagination
# pk_ah_search_archive_pagination
# pk_ah_after_search_pagination
# pk_ah_search_no_posts_available

add_action('pk_ah_pre_search_loop', 'pk_pre_search_loop');

function pk_pre_search_loop() {
	//echo '<p>pk_ah_pre_search_loop</p>';
}

add_action('pk_ah_pre_search_list_item', 'pk_pre_search_list_item');

function pk_pre_search_list_item() {
	//echo '<p>pk_ah_pre_search_list_item</p>';
}

add_action('pk_ah_search_print_list_item_standard', 'pk_blog_list_item_standard');

add_action('pk_ah_search_print_list_item_alternative', 'pk_blog_list_item_alternative');

add_action('pk_ah_after_search_list_item', 'pk_after_search_list_item');

function pk_after_search_list_item() {
	//echo '<p>pk_ah_after_search_list_item</p>';
}

add_action('pk_ah_after_search_loop', 'pk_after_search_loop');

function pk_after_search_loop() {
	//echo '<p>pk_ah_after_search_loop</p>';
}

add_action('pk_ah_pre_search_pagination', 'pk_pre_search_pagination');

function pk_pre_search_pagination() {
	//echo '<p>pk_ah_pre_search_pagination</p>';
}

add_action('pk_ah_search_pagination', 'pk_blog_pagination');

add_action('pk_ah_after_search_pagination', 'pk_after_search_pagination');

function pk_after_search_pagination() {
	//echo '<p>pk_ah_after_search_pagination</p>';
}

add_action('pk_ah_search_no_posts_available', 'pk_search_no_posts_available');

function pk_search_no_posts_available() {
	//echo '<p>pk_ah_search_no_posts_available</p>';
}

/*
 * SINGLE POST ACTION HOOKS
*/

# pk_ah_pre_single_post_contents
# pk_ah_after_single_post_contents
# pk_ah_pre_single_post_comments
# pk_ah_after_single_post_comments

add_action('pk_ah_pre_single_post_contents', 'pk_pre_single_post_contents');

function pk_pre_single_post_contents() {
	//echo '<p>pk_ah_pre_single_post_contents</p>';
}

add_action('pk_ah_after_single_post_contents', 'pk_after_single_post_contents');

function pk_after_single_post_contents() {
	//echo '<p>pk_ah_after_single_post_contents</p>';
	
	pk_add_link_pages();
	
	pk_add_add_this();
	
	pk_author();
	
	pk_get_lightbox_gallery();
	
}

add_action('pk_ah_pre_single_post_comments', 'pk_pre_single_post_comments');

function pk_pre_single_post_comments() {
	//echo '<span class="pk_clear_both"></span><p>pk_ah_pre_single_post_comments</p>';
}

add_action('pk_ah_after_single_post_comments', 'pk_after_single_post_comments');

function pk_after_single_post_comments() {
	//echo '<span class="pk_clear_both"></span><p>pk_ah_after_single_post_comments</p>';
}

/*
 * WORKS GRID ACTION HOOKS
*/

# pk_ah_pre_works_grid_categories_filter
# pk_ah_works_print_grid_categories_filter
# pk_ah_pre_works_grid_loop
# pk_ah_pre_works_grid_item
# pk_ah_works_print_grid_item
# pk_ah_after_works_grid_item
# pk_ah_after_works_grid_loop
# pk_ah_pre_works_grid_pagination
# pk_ah_works_grid_pagination
# pk_ah_after_works_grid_pagination
# pk_ah_pre_grid_comments
# pk_ah_after_grid_comments

add_action('pk_ah_pre_works_grid_categories_filter', 'pk_pre_works_grid_categories_filter');

function pk_pre_works_grid_categories_filter() {
	//echo '<p>pk_ah_pre_works_grid_categories_filter</p>';
}

add_action('pk_ah_works_print_grid_categories_filter', 'pk_works_grid_categories_filter');

add_action('pk_ah_pre_works_grid_loop', 'pk_pre_works_grid_loop');

function pk_pre_works_grid_loop() {
	//echo '<p>pk_ah_pre_works_grid_loop</p>';
}

add_action('pk_ah_pre_works_grid_item', 'pk_pre_works_grid_item');

function pk_pre_works_grid_item() {
	//echo '<p>pk_ah_pre_works_grid_item</p>';
}

add_action('pk_ah_works_print_grid_item', 'pk_works_grid_item');

add_action('pk_ah_after_works_grid_item', 'pk_after_works_grid_item');

function pk_after_works_grid_item() {
	//echo '<p>pk_ah_after_works_grid_item</p>';
}

add_action('pk_ah_after_works_grid_loop', 'pk_after_works_grid_loop');

function pk_after_works_grid_loop() {
	//echo '<p>pk_ah_after_works_grid_loop</p>';
}

add_action('pk_ah_pre_works_grid_pagination', 'pk_pre_works_grid_pagination');

function pk_pre_works_grid_pagination() {
	//echo '<p>pk_ah_pre_works_grid_pagination</p>';
}

add_action('pk_ah_works_grid_pagination', 'pk_works_grid_pagination');

add_action('pk_ah_after_works_grid_pagination', 'pk_after_works_grid_pagination');

function pk_after_works_grid_pagination() {
	//echo '<p>pk_ah_after_works_grid_pagination</p>';
}

add_action('pk_ah_pre_grid_comments', 'pk_pre_grid_comments');

function pk_pre_grid_comments() {
	//echo '<span class="pk_clear_both"></span><p>pk_ah_pre_grid_comments</p>';
}

add_action('pk_ah_after_grid_comments', 'pk_after_grid_comments');

function pk_after_grid_comments() {
	//echo '<span class="pk_clear_both"></span><p>pk_ah_after_grid_comments</p>';
}

/*
 * WORKS TAXONOMY (CATEGORY) GRID ACTION HOOKS
*/

# pk_ah_pre_works_taxonomy_grid_categories_filter
# pk_ah_works_taxonomy_print_grid_categories_filter
# pk_ah_pre_works_taxonomy_grid_loop
# pk_ah_pre_works_taxonomy_grid_item
# pk_ah_works_taxonomy_print_grid_item
# pk_ah_after_works_taxonomy_grid_item
# pk_ah_after_works_taxonomy_grid_loop
# pk_ah_pre_works_taxonomy_grid_pagination
# pk_ah_works_taxonomy_grid_pagination
# pk_ah_after_works_taxonomy_grid_pagination

add_action('pk_ah_pre_works_taxonomy_grid_categories_filter', 'pk_pre_works_taxonomy_grid_categories_filter');

function pk_pre_works_taxonomy_grid_categories_filter() {
	//echo '<p>pk_ah_pre_works_taxonomy_grid_categories_filter</p>';
}

add_action('pk_ah_works_taxonomy_print_grid_categories_filter', 'pk_works_grid_categories_filter');

add_action('pk_ah_pre_works_taxonomy_grid_loop', 'pk_pre_works_taxonomy_grid_loop');

function pk_pre_works_taxonomy_grid_loop() {
	//echo '<p>pk_ah_pre_works_taxonomy_grid_loop</p>';
}

add_action('pk_ah_pre_works_taxonomy_grid_item', 'pk_pre_works_taxonomy_grid_item');

function pk_pre_works_taxonomy_grid_item() {
	//echo '<p>pk_ah_pre_works_taxonomy_grid_item</p>';
}

add_action('pk_ah_works_taxonomy_print_grid_item', 'pk_works_grid_item');

add_action('pk_ah_after_works_taxonomy_grid_item', 'pk_after_works_taxonomy_grid_item');

function pk_after_works_taxonomy_grid_item() {
	//echo '<p>pk_ah_after_works_taxonomy_grid_item</p>';
}


add_action('pk_ah_after_works_taxonomy_grid_loop', 'pk_after_works_taxonomy_grid_loop');

function pk_after_works_taxonomy_grid_loop() {
	//echo '<p>pk_ah_after_works_taxonomy_grid_loop</p>';
}

add_action('pk_ah_pre_works_taxonomy_grid_pagination', 'pk_pre_works_taxonomy_grid_pagination');

function pk_pre_works_taxonomy_grid_pagination() {
	//echo '<p>pk_ah_pre_works_taxonomy_grid_pagination</p>';
}

add_action('pk_ah_works_taxonomy_grid_pagination', 'pk_works_grid_pagination');

add_action('pk_ah_after_works_taxonomy_grid_pagination', 'pk_after_works_taxonomy_grid_pagination');

function pk_after_works_taxonomy_grid_pagination() {
	//echo '<p>pk_ah_after_works_taxonomy_grid_pagination</p>';
}
/*
 * SINGLE WORKS ACTION HOOKS
*/

# pk_ah_pre_single_works_contents
# pk_ah_after_single_works_contents
# pk_ah_pre_single_works_comments
# pk_ah_after_single_works_comments

add_action('pk_ah_pre_single_works_contents', 'pk_pre_single_works_contents');

function pk_pre_single_works_contents() {
	//echo '<p>pk_ah_pre_single_works_contents</p>';
}

add_action('pk_ah_after_single_works_contents', 'pk_after_single_works_contents');

function pk_after_single_works_contents() {
	//echo '<p>pk_ah_after_single_works_contents</p>';
	
	pk_add_link_pages();
	
	pk_add_add_this();
	
	pk_author();
	
	pk_get_lightbox_gallery();
	
}

add_action('pk_ah_pre_single_works_comments', 'pk_pre_single_works_comments');

function pk_pre_single_works_comments() {
	//echo '<span class="pk_clear_both"></span><p>pk_ah_pre_single_works_comments</p>';
}

add_action('pk_ah_after_single_works_comments', 'pk_after_single_works_comments');

function pk_after_single_works_comments() {
	//echo '<span class="pk_clear_both"></span><p>pk_ah_after_single_works_comments</p>';
}

/*
 * FLICKR GRID ACTION HOOKS
*/

# pk_ah_pre_flickr_grid_loop
# pk_ah_pre_flickr_grid_item
# pk_ah_flickr_print_grid_items
# pk_ah_after_flickr_grid_item
# pk_ah_after_flickr_grid_loop
# pk_ah_pre_flickr_grid_pagination
# pk_ah_flickr_grid_pagination
# pk_ah_after_flickr_grid_pagination
# pk_ah_pre_flickr_grid_comments
# pk_ah_after_flickr_grid_comments

add_action('pk_ah_pre_flickr_grid_loop', 'pk_pre_flickr_grid_loop');

function pk_pre_flickr_grid_loop() {
	//echo '<p>pk_ah_pre_flickr_grid_loop</p>';
}

add_action('pk_ah_pre_flickr_grid_item', 'pk_pre_flickr_grid_item');

function pk_pre_flickr_grid_item() {
	//echo '<p>pk_ah_pre_flickr_grid_item</p>';
}

add_action('pk_ah_flickr_print_grid_items', 'pk_flickr_grid_items');

add_action('pk_ah_after_flickr_grid_item', 'pk_after_flickr_grid_item');

function pk_after_flickr_grid_item() {
	//echo '<p>pk_ah_after_flickr_grid_item</p>';
}

add_action('pk_ah_after_flickr_grid_loop', 'pk_after_flickr_grid_loop');

function pk_after_flickr_grid_loop() {
	//echo '<p>pk_ah_after_flickr_grid_loop</p>';
}

add_action('pk_ah_pre_flickr_grid_pagination', 'pk_pre_flickr_grid_pagination');

function pk_pre_flickr_grid_pagination() {
	//echo '<p>pk_ah_pre_flickr_grid_pagination</p>';
}

add_action('pk_ah_flickr_grid_pagination', 'pk_flickr_grid_pagination');

add_action('pk_ah_after_flickr_grid_pagination', 'pk_after_flickr_grid_pagination');

function pk_after_flickr_grid_pagination() {
	//echo '<p>pk_ah_after_flickr_grid_pagination</p>';
}

add_action('pk_ah_pre_flickr_grid_comments', 'pk_pre_flickr_grid_comments');

function pk_pre_flickr_grid_comments() {
	//echo '<span class="pk_clear_both"></span><p>pk_ah_pre_flickr_grid_comments</p>';
}

add_action('pk_ah_after_flickr_grid_comments', 'pk_after_flickr_grid_comments');

function pk_after_flickr_grid_comments() {
	//echo '<span class="pk_clear_both"></span><p>pk_ah_after_flickr_grid_comments</p>';
}

/*
 * PAGES ACTION HOOKS
*/

# pk_ah_pre_page_contents
# pk_ah_after_page_contents
# pk_ah_pre_page_comments
# pk_ah_after_page_comments

add_action('pk_ah_pre_page_contents', 'pk_pre_page_contents');

function pk_pre_page_contents() {
	//echo '<p>pk_ah_pre_page_contents</p>';
}

add_action('pk_ah_after_page_contents', 'pk_after_page_contents');

function pk_after_page_contents() {
	//echo '<p>pk_ah_after_page_contents</p>';
	
	pk_add_link_pages();
	
	pk_get_lightbox_gallery();
	
}

add_action('pk_ah_pre_page_comments', 'pk_pre_page_comments');

function pk_pre_page_comments() {
	//echo '<span class="pk_clear_both"></span><p>pk_ah_pre_page_comments</p>';
}

add_action('pk_ah_after_page_comments', 'pk_after_page_comments');

function pk_after_page_comments() {
	//echo '<span class="pk_clear_both"></span><p>pk_ah_after_page_comments</p>';
}

/*
 * FOOTER ACTION HOOKS
*/

# pk_ah_pre_footer_widgets_area
# pk_ah_after_page_comments

add_action('pk_ah_pre_footer_widgets_area', 'pk_pre_footer_widgets_area');

function pk_pre_footer_widgets_area() {
	//echo '<span class="pk_clear_both"><p>pk_ah_pre_footer_widgets_area</p>';
}

add_action('pk_ah_after_footer_widgets_area', 'pk_after_footer_widgets_area');

function pk_after_footer_widgets_area() {
	//echo '<span class="pk_clear_both"><p>pk_ah_after_footer_widgets_area</p>';
}

/*
 * 
 * Enjoy it! :)
 * 
*/

?>