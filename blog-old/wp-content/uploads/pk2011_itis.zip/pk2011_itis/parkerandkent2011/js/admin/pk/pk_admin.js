var $pk_aj = jQuery.noConflict();
$pk_aj(document).ready(function() {
	
	$pk_aj('.pk_admin_delete_profile_button').click(function(event) {
		
		return confirm($pk_aj(this).attr('data-message'));
		
	});
	
	$pk_aj('.pk_admin_restore_options_button').click(function(event) {
		
		return confirm($pk_aj(this).attr('data-message'));
		
	});
	
	$pk_aj('.pk_admin_clickable_head').click(function(event) {
		
		$pk_aj($pk_aj(this).next('.pk_admin_tggleable_body')).toggle();
		
		return false;
		
	});
	
	$pk_aj('.pk_admin_input_text_area_select_all').click(function(){
		
		$pk_aj(this).select();
		
		return false;
		
	});
	
	$pk_aj('.pk_admin_input_slider').rangeinput();
	$pk_aj('.pk_admin_input_slider').change(function(event) {
		
		$pk_aj(this).data("rangeinput").setValue($pk_aj(this).val());
		
	});
	
	$pk_aj('.pk_admin_input_select_box').change(function(event) {
		
		var count = 0;
		
		$pk_aj(this).find('option').each(function() {
			
			if (count > 0) {
				
				$pk_aj('.' + $pk_aj(this).val().split(',')[0]).hide();
				$pk_aj('#' + $pk_aj(this).val().split(',')[0]).hide();
				$pk_aj('#' + $pk_aj(this).val().split(',')[0] + '_save_button').hide();
				
			}
			
			count++;
			
		});
		
		$pk_aj('.' + $pk_aj(this).val().split(',')[0]).show();
		$pk_aj('#' + $pk_aj(this).val().split(',')[0]).show();
		$pk_aj('#' + $pk_aj(this).val().split(',')[0] + '_save_button').show();
		
	});
	
	$pk_aj('.pk_admin_input_select_box').change();
	
	$pk_aj('.pk_admin_multiple_checkbox').change(function(event) {
		
		pkCheckMultipleFields();
		
	});
	
	$pk_aj('.pk_admin_input_select_multiple').change(function(event) {
		
		pkCheckMultipleFields();
		
	});
	
	function pkCheckMultipleFields() {
	
		$pk_aj('.pk_admin_multiple_field').each(function() {
				
			var main = $pk_aj(this).attr('name');
			var result = '';
			
			$pk_aj('.pk_admin_multiple_checkbox[data-main="' + main + '"]').each(function() {
				
				if ($pk_aj(this).is(':checked')) {
					
					(result == '') ? result += $pk_aj(this).attr('value') : result += ',' + $pk_aj(this).attr('value');
					
				}
				
			});
			
			$pk_aj('.pk_admin_input_select_multiple[data-main="' + main + '"]').find('option').each(function() {
				
				if ($pk_aj(this).is(':selected')) {
					
					(result == '') ? result += $pk_aj(this).val() : result += ',' + $pk_aj(this).val();
					
				}
				
			});
			
			$pk_aj(this).val(result);
				
		});
	
	}
	
	var selected_footer_column_width = 0;
	
	var columns_values = [];
	var columns_classes = [];
	
	columns_values['1_1'] = 1;
	columns_values['1_2'] = 1 / 2;
	columns_values['1_3'] = 1 / 3;
	columns_values['1_4'] = 1 / 4;
	columns_values['1_5'] = 1 / 5;
	columns_values['1_6'] = 1 / 6;
	columns_values['2_3'] = 2 / 3;
	columns_values['3_4'] = 3 / 4;
	columns_values['2_5'] = 2 / 5;
	columns_values['3_5'] = 3 / 5;
	columns_values['4_5'] = 4 / 5;
	columns_values['5_6'] = 5 / 6;
	
	columns_classes['1_1'] = 'pk_full_width';
	columns_classes['1_2'] = 'pk_one_half';
	columns_classes['1_3'] = 'pk_one_third';
	columns_classes['1_4'] = 'pk_one_fourth';
	columns_classes['1_5'] = 'pk_one_fifth';
	columns_classes['1_6'] = 'pk_one_sixth';
	columns_classes['2_3'] = 'pk_two_third';
	columns_classes['3_4'] = 'pk_three_fourth';
	columns_classes['2_5'] = 'pk_two_fifth';
	columns_classes['3_5'] = 'pk_three_fifth';
	columns_classes['4_5'] = 'pk_four_fifth';
	columns_classes['5_6'] = 'pk_five_sixth';
	
	$pk_aj('.pk_admin_footer_layout_columns_list').sortable({
		
		placeholder:"pk_admin_footer_column_placeholder",
		scrollSensitivity:"pointer",
		start:function() {
			
			$pk_aj('.pk_admin_footer_column_placeholder').width(selected_footer_column_width);
			
		},
		update:function() {
			
			pkSaveColumns($pk_aj(this).parent().parent().find('.pk_admin_add_footer_layout_column_button'), false);
			
		}
		
	});
	
	$pk_aj('.pk_admin_footer_layout_columns_list').disableSelection();
	
	$pk_aj('.pk_admin_add_footer_layout_column_button').click(function(event) {
		
		if (pkSaveColumns($pk_aj(this), true) == false) {
			
			return;	
			
		}
		
		var list = $pk_aj(this).parent().parent().find('.pk_admin_footer_layout_columns_list');
		
		list.append('<li class="pk_admin_footer_column_' + $pk_aj(this).parent().find('.pk_admin_input_footer_layout_select').val() + '"><input class="pk_admin_delete_footer_column button" type="button" value="x" /></li>');
		
		pkAddActionsToColumns();
		
	});
	
	$pk_aj('.pk_admin_footer_layout_value').each(function() {
		
		if ($pk_aj(this).val() != '') {
		
			var columns = $pk_aj(this).val().split('[pk_data_sep]')[1].split(',');
			
			var list = $pk_aj(this).parent().parent().find('.pk_admin_footer_layout_columns_list');
			
			for (var i = 0; i < columns.length; i++) {
				
				list.append('<li class="pk_admin_footer_column_' + columns[i] + '"><input class="pk_admin_delete_footer_column button" type="button" value="x" /></li>');
				
			}
			
			pkAddActionsToColumns();
		
		}
		
	});
	
	function pkAddActionsToColumns() {
		
		$pk_aj('.pk_admin_footer_layout_columns li').each(function() {
			
			$pk_aj(this).find('.pk_admin_delete_footer_column').click(function() {
				
				var buttonClicked = $pk_aj(this).parent().parent().parent().parent().find('.pk_admin_add_footer_layout_column_button');
				
				$pk_aj(this).parent().remove();
				
				pkSaveColumns(buttonClicked, false);
			
			});
			
			$pk_aj(this).mousedown(function() {
			
				selected_footer_column_width = $pk_aj(this).width();
			
			});
			
		});
		
	}
	
	function pkSaveColumns(buttonClicked, add_item) {
		
		var columns_count = 0;
		var columns_data = '';
		var columns_string = '';
		
		var selected_value = buttonClicked.parent().find('.pk_admin_input_footer_layout_select').val();
		
		buttonClicked.parent().parent().find('.pk_admin_footer_layout_columns_list li').each(function() {
			
			columns_count += columns_values[$pk_aj(this).attr('class').split('pk_admin_footer_column_')[1]];
			columns_data += ((columns_data != '') ? ',' : '') + $pk_aj(this).attr('class').split('pk_admin_footer_column_')[1];
			columns_string += ((columns_string != '') ? ',' : '') + columns_classes[$pk_aj(this).attr('class').split('pk_admin_footer_column_')[1]];
			
		});
		
		if (selected_value != '0' && add_item == true) {
		
			columns_count += columns_values[selected_value];
			columns_data += ((columns_data != '') ? ',' : '') + selected_value;
			columns_string += ((columns_string != '') ? ',' : '') + columns_classes[selected_value];
		
		} else {
			
			if (add_item == true) {
				
				return false;
				
			}
			
		}
		
		if (columns_count > 1) {
			
			alert(buttonClicked.attr('data-error'));
			return false;
			
		}
		
		buttonClicked.parent().find('.pk_admin_footer_layout_value').val((columns_string != '' && columns_data != '') ? columns_string + '[pk_data_sep]' + columns_data : '');
		
		return true;
		
	}
	
	$pk_aj('.pk_admin_footer_social_networks_list').sortable({
		
		placeholder:"pk_admin_footer_social_networks_placeholder",
		scrollSensitivity:"pointer",
		update:function() {
			
			pkSaveSocialNetworks();
			
		}
		
	});
	
	$pk_aj('.pk_admin_add_footer_social_network_button').click(function(event) {
		
		var networks_list = $pk_aj(this).parent().parent().find('.pk_admin_footer_social_networks_list');
		var networks_select = $pk_aj(this).parent().find('.pk_admin_footer_social_networks_select');
		
		if (networks_select.val() == 'select') {
			
			return;
			
		}
		
		networks_list.append('<li class="pk_admin_footer_social_networks_list_item"><img class="' + networks_select.find('option:selected').text() + '" src="' + networks_select.val() + '" /><input class="pk_admin_input_social_networks_url_text_field" type="text" value="" /><input class="pk_admin_delete_social_networks_list_item button" type="button" value="x" /></li>');
		
		pkAddActionsToSocialNetworksItems();
		
		pkSaveSocialNetworks();
		
	});
	
	function pkAddActionsToSocialNetworksItems() {
		
		$pk_aj('.pk_admin_footer_social_networks_list_item').each(function() {
			
			$pk_aj(this).find('.pk_admin_delete_social_networks_list_item').click(function() {
				
				$pk_aj(this).parent().remove();
				
				pkSaveSocialNetworks();
			
			});
			
			$pk_aj(this).find('.pk_admin_input_social_networks_url_text_field').change(function() {
		
				pkSaveSocialNetworks();
			
			});
			
		});
		
	}
	
	function pkSaveSocialNetworks() {
		
		var value = '';
		
		$pk_aj('.pk_admin_footer_social_networks_manager').each(function() {
			
			$pk_aj(this).find('.pk_admin_footer_social_networks_list_item').each(function() {
				
				var network_name = $pk_aj(this).find('img').attr('class');
				var network_icon_url = $pk_aj(this).find('img').attr('src');
				var network_url = $pk_aj(this).find('.pk_admin_input_social_networks_url_text_field').val();
				
				value += (value != '') ? '[pk_data_sep]' : '';
				value += network_name + ',' + network_icon_url + ',' + network_url;
				
			});
			
			$pk_aj(this).find('.pk_admin_footer_social_networks_value').val(value);
			
		});
		
	}
	
	$pk_aj('.pk_admin_footer_social_networks_manager').each(function() {
		
		var value = $pk_aj(this).find('.pk_admin_footer_social_networks_value').val();
		var networks_list =  $pk_aj(this).find('.pk_admin_footer_social_networks_list');
		
		if (value == '') {
			
			return;
			
		}
			
		var networks = value.split('[pk_data_sep]');
		
		for (var i = 0; i < networks.length; i++) {
			
			var network_data = networks[i].split(',');
			
			networks_list.append('<li class="pk_admin_footer_social_networks_list_item"><img class="' + network_data[0] + '" src="' + network_data[1] + '" /><input class="pk_admin_input_social_networks_url_text_field" type="text" value="' + network_data[2] + '" /><input class="pk_admin_delete_social_networks_list_item button" type="button" value="x" /></li>');
			
			pkAddActionsToSocialNetworksItems();
			
		}
			
	});
	
	$pk_aj('.pk_admin_lightbox_gallery_list').sortable({
		
		placeholder:"pk_admin_lightbox_gallery_placeholder",
		scrollSensitivity:"pointer",
		update:function() {
			
			pkSaveLightboxGallery();
			
		}
		
	});
	
	$pk_aj('.pk_admin_add_lightbox_gallery_item_button').click(function(event) {
		
		var gallery_lightbox_list = $pk_aj(this).parent().parent().find('.pk_admin_lightbox_gallery_list');
		
		var title = gallery_lightbox_list.attr('data-title-label');
		var url = gallery_lightbox_list.attr('data-url-label');
		
		gallery_lightbox_list.append('<li class="pk_admin_lightbox_gallery_list_item"><input class="pk_admin_delete_lightbox_gallery_list_item button" type="button" value="x" /><p><input class="pk_admin_input_lightbox_gallery_title_text_field" type="text" value="' + title + '" onfocus="if (this.value == \'' + title + '\') this.value = \'\';" onblur="if (this.value == \'\') this.value = \'' + title + '\'" /></p><p><input class="pk_admin_input_lightbox_gallery_url_text_field" type="text" value="' + url + '"  onfocus="if (this.value == \'' + url + '\') this.value = \'\';" onblur="if (this.value == \'\') this.value = \'' + url + '\'" /><p></li>');
		
		pkAddActionsToLightboxGalleryItems();
		
		pkSaveLightboxGallery();
		
	});
	
	function pkAddActionsToLightboxGalleryItems() {
		
		$pk_aj('.pk_admin_lightbox_gallery_list_item').each(function() {
			
			$pk_aj(this).find('.pk_admin_delete_lightbox_gallery_list_item').click(function() {
				
				$pk_aj(this).parent().remove();
				
				pkSaveLightboxGallery();
				
			});
			
			$pk_aj('.pk_admin_input_lightbox_gallery_title_text_field').change(function() {
				
				pkSaveLightboxGallery();
				
			});
			
			$pk_aj(this).find('.pk_admin_input_lightbox_gallery_url_text_field').change(function() {
				
				pkSaveLightboxGallery();
				
			});
			
		});
		
	}
	
	$pk_aj('.pk_admin_lightbox_gallery_manager').each(function() {
		
		var name = $pk_aj(this).find('.pk_admin_lightbox_gallery_value').attr('name');
		
		var items_width_field = $pk_aj(this).find('#pk_admin_lightbox_gallery_items_width_' + name);
		var items_height_field = $pk_aj(this).find('#pk_admin_lightbox_gallery_items_height_' + name);
		var slideshow = $pk_aj(this).find('.pk_admin_radio_checkbox[name=pk_admin_lightbox_gallery_slideshow_' + name + ']');
		var interval = $pk_aj(this).find('#pk_admin_lightbox_gallery_slideshow_interval_' + name);
		var gallery_id = $pk_aj(this).find('#pk_admin_lightbox_gallery_id_' + name);
		
		items_width_field.change(function() {
			
			pkSaveLightboxGallery();
			
		});
		
		items_height_field.change(function() {
			
			pkSaveLightboxGallery();
			
		});
		
		slideshow.change(function() {
			
			pkSaveLightboxGallery();
			
		});
		
		interval.change(function() {
			
			pkSaveLightboxGallery();
			
		});
		
		gallery_id.change(function() {
			
			pkSaveLightboxGallery();
			
		});
		
	});
		
	$pk_aj('.pk_admin_lightbox_gallery_manager').each(function() {
		
		var value = $pk_aj(this).find('.pk_admin_lightbox_gallery_value').val();
		
		if (value == '') {
			
			return;
			
		}
		
		var data = value.split('[pk_data_sep]')[0];
		var items = value.split('[pk_data_sep]')[1];
		
		var name = $pk_aj(this).find('.pk_admin_lightbox_gallery_value').attr('name');
		
		var items_width_field = $pk_aj(this).find('#pk_admin_lightbox_gallery_items_width_' + name);
		var items_height_field = $pk_aj(this).find('#pk_admin_lightbox_gallery_items_height_' + name);
		var slideshow = $pk_aj(this).find('.pk_admin_radio_checkbox[name=pk_admin_lightbox_gallery_slideshow_' + name + ']');
		var interval = $pk_aj(this).find('#pk_admin_lightbox_gallery_slideshow_interval_' + name);
		var gallery_id = $pk_aj(this).find('#pk_admin_lightbox_gallery_id_' + name);
		var gallery_lightbox_list = $pk_aj(this).find('#pk_admin_lightbox_gallery_list_' + name);
		
		data = data.split('[pk_sep]');
		
		items_width_field.val(data[0]);
		items_height_field.val(data[1]);
		(data[2] == 'true') ? $pk_aj(this).find('.pk_admin_radio_checkbox[id=pk_admin_lightbox_gallery_yes_pk_lightbox_gallery]').attr('checked', true) : $pk_aj(this).find('.pk_admin_radio_checkbox[id=pk_admin_lightbox_gallery_no_pk_lightbox_gallery]').attr('checked', true);
		interval.val(data[3]);
		gallery_id.val(data[4]);
		
		if (items == '') {
			
			return;
			
		}
		
		var def_title = gallery_lightbox_list.attr('data-title-label');
		var def_url = gallery_lightbox_list.attr('data-url-label');
		
		items = items.split('[pk_items_sep]');
		
		for (var i = 0; i < items.length; i++) {
			
			var item_data = items[i].split('[pk_sep]');
			
			var title = item_data[0];
			var url = item_data[1];
			
			gallery_lightbox_list.append('<li class="pk_admin_lightbox_gallery_list_item"><input class="pk_admin_delete_lightbox_gallery_list_item button" type="button" value="x" /><p><input class="pk_admin_input_lightbox_gallery_title_text_field" type="text" value="' + title + '" onfocus="if (this.value == \'' + def_title + '\') this.value = \'\';" onblur="if (this.value == \'\') this.value = \'' + title + '\'" /></p><p><input class="pk_admin_input_lightbox_gallery_url_text_field" type="text" value="' + url + '"  onfocus="if (this.value == \'' + def_url + '\') this.value = \'\';" onblur="if (this.value == \'\') this.value = \'' + url + '\'" /><p></li>');
			
		}
		
		pkAddActionsToLightboxGalleryItems();
		
		pkSaveLightboxGallery();
		
	});
	
	function pkSaveLightboxGallery() {
		
		$pk_aj('.pk_admin_lightbox_gallery_manager').each(function() {
			
			var data = '';
			
			var value = $pk_aj(this).find('.pk_admin_lightbox_gallery_value');
			var name = $pk_aj(this).find('.pk_admin_lightbox_gallery_value').attr('name');
			
			var items_width_field = $pk_aj(this).find('#pk_admin_lightbox_gallery_items_width_' + name);
			var items_height_field = $pk_aj(this).find('#pk_admin_lightbox_gallery_items_height_' + name);
			var slideshow = $pk_aj(this).find('.pk_admin_radio_checkbox[name=pk_admin_lightbox_gallery_slideshow_' + name + ']:checked');
			var interval = $pk_aj(this).find('#pk_admin_lightbox_gallery_slideshow_interval_' + name);
			var gallery_id = $pk_aj(this).find('#pk_admin_lightbox_gallery_id_' + name);
			var gallery_lightbox_list = $pk_aj(this).find('#pk_admin_lightbox_gallery_list_' + name);
			
			data = items_width_field.val() + '[pk_sep]' + items_height_field.val() + '[pk_sep]' + ((slideshow.attr('id') == 'pk_admin_lightbox_gallery_yes_pk_lightbox_gallery') ? 'true' : 'false') + '[pk_sep]' + interval.val() + '[pk_sep]' + gallery_id.val() + '[pk_data_sep]';
			
			var items = '';
			
			gallery_lightbox_list.find('.pk_admin_lightbox_gallery_list_item').each(function() {
				
				var item_title = $pk_aj(this).find('.pk_admin_input_lightbox_gallery_title_text_field').val();
				var item_url = $pk_aj(this).find('.pk_admin_input_lightbox_gallery_url_text_field').val();
				
				items += (items == '') ? '' : '[pk_items_sep]';
				items += item_title + '[pk_sep]' + item_url;
				
			});
			
			value.val(data + items);
			
		});
		
	}
	
	$pk_aj('#page_template').change(function(event) {
		
		pkHideAllTemplatesOptions();
		
		var template = $pk_aj(this).val();
		
		switch (template) {
			
			case 'default' :
			
				$pk_aj('#pk_metabox_div_0').show();
				$pk_aj('#pk_metabox_div_4').show();
				break;
				
			case 'top-slider-page.php' :
				
				$pk_aj('#pk_metabox_div_0').show();
				$pk_aj('#pk_metabox_div_3').show();
				$pk_aj('#pk_metabox_div_4').show();
				
				$pk_aj('.pk_admin_input_text_field[name=pk_fgg_flickr_user_id]').change();
				
				break;
				
			case 'flickr-grid-gallery-page.php' :
				
				$pk_aj('#pk_metabox_div_0').show();
				$pk_aj('#pk_metabox_div_2').show();
				
				$pk_aj('.pk_admin_input_text_field[name=pk_fgg_flickr_user_id]').change();
				
				break;
			
			case 'workspage_1.php' :
			case 'workspage_2.php' :
			case 'workspage_3.php' :
			case 'workspage_4.php' :
			case 'workspage_5.php' :	
			case 'workspage_6.php' :
			
				$pk_aj('#pk_metabox_div_0').show();
				$pk_aj('#pk_metabox_div_1').show();
				break;
			
		}
		
	});
	
	$pk_aj('#page_template').change();
	
	function pkHideAllTemplatesOptions() {
		
		$pk_aj('#pk_metabox_div_0').hide();
		$pk_aj('#pk_metabox_div_1').hide();
		$pk_aj('#pk_metabox_div_2').hide();
		$pk_aj('#pk_metabox_div_3').hide();
		$pk_aj('#pk_metabox_div_4').hide();
		$pk_aj('#pk_options').show();
		
	}
	
	$pk_aj('.pk_admin_upload_file_button').click(function(event) {
		
		var id = $pk_aj(this).attr('id');
		var post_id =  $pk_aj(this).attr('data-post_id');
		var media = $pk_aj(this).attr('data-media');
		var main_media = $pk_aj(this).attr('data-main-media');
		var main = ($pk_aj(this).attr('data-main')) ? $pk_aj(this).attr('data-main') : $pk_aj(this).attr('name');
		var the_url = '';
		
		if (media != 'image' && media != 'video' && media != 'audio') media = '';
		
		tb_show('', 'media-upload.php?' + ((media != '') ? 'type=' + media : '') + ((post_id != '') ? '&amp;post_id=' + post_id : '&amp;post_id=0') + '&amp;tab=library&amp;TB_iframe=true');
		
		var old_function = window.send_to_editor;
		
		window.send_to_editor = function(html) {
			
			if (media == 'image') {
				
				the_url = $pk_aj('img', html).attr('src');
				$pk_aj('#' + id + '_field').val(the_url);
				
			} else {
					
				the_url = $pk_aj(html).attr('href');
				$pk_aj('#' + id + '_field').val(the_url);
				
			}
			
			window.send_to_editor = old_function;
			
			tb_remove();
			
			pkSaveUploadedFile(main, (main_media == undefined) ? media : main_media);
			
		}
		
		return false;
		
	});
	
	$pk_aj('.pk_admin_upload_cover_field, .pk_admin_upload_file_field').change(function(event) {
		
		var main = ($pk_aj(this).attr('data-main')) ? $pk_aj(this).attr('data-main') : $pk_aj(this).attr('name');
		var media = $pk_aj(this).attr('data-media');
		
		pkSaveUploadedFile(main, media);
		
	});
	
	function pkSaveUploadedFile(main, media) {
		
		var result = '';
		
		if (media == 'video') {
		
			result = $pk_aj('#' + main + '_select_video').val();
			
			if (result == '1') {
			
				result += ',' + $pk_aj('#' + main + '_cover_field').val();
				result += ',' + $pk_aj('#' + main + '_mp4_field').val();
				result += ',' + $pk_aj('#' + main + '_webm_field').val();
				result += ',' + $pk_aj('#' + main + '_ogg_field').val();
				
			} else {
				
				if (result != '0') {
					
					result += ',' + $pk_aj('#' + main + '_cover_field').val();
					result += ',' + $pk_aj('#' + main + '_file_field').val();
					
				}
				
			}
		
		} else {
			
			if (media == 'audio') {
				
				result = $pk_aj('#' + main + '_cover_field').val();
				result += ',' + $pk_aj('#' + main + '_file_field').val();
				
			} else {
				
				result = $pk_aj('#' + main + '_file_field').val();
				
			}
			
		}
		
		$pk_aj('#' + main).val(result);
		
	}
	
	$pk_aj('.pk_admin_input_select_video').each(function() {
		
		var main = $pk_aj(this).attr('data-main');
			
		$pk_aj(this).find('option').each(function() {
			
			$pk_aj('.' + main + '_vt_' + $pk_aj(this).val()).hide();
			
		});
		
		$pk_aj('.' + main + '_vt_' + $pk_aj(this).val()).show();
			
	});
	
	$pk_aj('.pk_admin_input_select_video').change(function(event) {
		
		var main = $pk_aj(this).attr('data-main');
		var media = $pk_aj(this).attr('data-media');
		
		$pk_aj(this).find('option').each(function() {
			
			$pk_aj('.' + main + '_vt_' + $pk_aj(this).val()).hide();
			
		});
		
		$pk_aj('.' + main + '_vt_' + $pk_aj(this).val()).show();
		
		pkSaveUploadedFile(main, media);
		
	});
	
	$pk_aj('.pk_admin_input_text_field[name=pk_sfg_flickr_user_id]').change(function(event) {
		
		if ($pk_aj(this).val() == '') {
			
			return;
			
		}
		
		$pk_aj('body').css('cursor', 'progress');
		
		$pk_aj.ajax({
			url:ajaxurl,
			type:'POST',
			cache:false,
			data:{
					
					action:'load_flickr_user_photos',
					suffix:'sfg',
					post_id:$pk_aj('#pk_post_id').val(),
					flickr_user_id:$pk_aj(this).val()
					
			},
			success:function(output) {
				
				$pk_aj('body').css('cursor', 'auto');
				
				if (output.split('[pk_data_sep]')[0] == 'success') {
					
					var photosets_values = output.split('[pk_data_sep]')[1].split('[pk_sep]');
					var photosets_labels = output.split('[pk_data_sep]')[2].split('[pk_sep]');
					
					var galleries_values = output.split('[pk_data_sep]')[3].split('[pk_sep]');
					var galleries_labels = output.split('[pk_data_sep]')[4].split('[pk_sep]');
					
					$pk_aj('.pk_admin_input_select[name=pk_sfg_select_set]').empty();
					$pk_aj('.pk_admin_input_select[name=pk_sfg_select_galleries]').empty();
					
					for (var i = 0; i < photosets_values.length; i++) {
						
						$pk_aj('.pk_admin_input_select[name=pk_sfg_select_set]').append('<option value="' + photosets_values[i] + '"' + ((output.split('[pk_data_sep]')[5] == photosets_values[i]) ? ' selected="selected"' : '') + '>' + photosets_labels[i] + '</option>');
						
					}
					
					for (var i = 0; i < galleries_values.length; i++) {
						
						$pk_aj('.pk_admin_input_select[name=pk_sfg_select_galleries]').append('<option value="' + galleries_values[i] + '"' + ((output.split('[pk_data_sep]')[6] == galleries_values[i]) ? ' selected="selected"' : '') + '>' + galleries_labels[i] + '</option>');
						
					}
					
					return;
				
				}
				
				if (output == 'error') {
					
					$pk_aj('.pk_admin_input_select[name=pk_sfg_select_set]').empty();
					$pk_aj('.pk_admin_input_select[name=pk_sfg_select_galleries]').empty();
					
					$pk_aj('.pk_admin_input_select[name=pk_sfg_select_set]').append('<option value="">No photoset available</option>');
					$pk_aj('.pk_admin_input_select[name=pk_sfg_select_galleries]').append('<option value="">No galleries available</option>');
					
				}
				
			}

		});

		return false;
		
	});
	
	$pk_aj('.pk_admin_input_text_field[name=pk_sfg_flickr_user_id]').change();
	
	$pk_aj('.pk_admin_input_text_field[name=pk_fgg_flickr_user_id]').change(function(event) {
		
		if ($pk_aj(this).val() == '') {
			
			return;
			
		}
		
		$pk_aj('body').css('cursor', 'progress');
		
		$pk_aj.ajax({
			url:ajaxurl,
			type:'POST',
			cache:false,
			data:{
					
					action:'load_flickr_user_photos',
					suffix:'fgg',
					post_id:$pk_aj('#pk_post_id').val(),
					flickr_user_id:$pk_aj(this).val()
					
			},
			success:function(output) {
				
				$pk_aj('body').css('cursor', 'auto');
				
				if (output.split('[pk_data_sep]')[0] == 'success') {
					
					var photosets_values = output.split('[pk_data_sep]')[1].split('[pk_sep]');
					var photosets_labels = output.split('[pk_data_sep]')[2].split('[pk_sep]');
					
					var galleries_values = output.split('[pk_data_sep]')[3].split('[pk_sep]');
					var galleries_labels = output.split('[pk_data_sep]')[4].split('[pk_sep]');
					
					$pk_aj('.pk_admin_input_select[name=pk_fgg_select_set]').empty();
					$pk_aj('.pk_admin_input_select[name=pk_fgg_select_galleries]').empty();
					
					for (var i = 0; i < photosets_values.length; i++) {
						
						$pk_aj('.pk_admin_input_select[name=pk_fgg_select_set]').append('<option value="' + photosets_values[i] + '"' + ((output.split('[pk_data_sep]')[5] == photosets_values[i]) ? ' selected="selected"' : '') + '>' + photosets_labels[i] + '</option>');
						
					}
					
					for (var i = 0; i < galleries_values.length; i++) {
						
						$pk_aj('.pk_admin_input_select[name=pk_fgg_select_galleries]').append('<option value="' + galleries_values[i] + '"' + ((output.split('[pk_data_sep]')[6] == galleries_values[i]) ? ' selected="selected"' : '') + '>' + galleries_labels[i] + '</option>');
						
					}
					
					return;
				
				}
				
				if (output == 'error') {
					
					$pk_aj('.pk_admin_input_select[name=pk_fgg_select_set]').empty();
					$pk_aj('.pk_admin_input_select[name=pk_fgg_select_galleries]').empty();
					
					$pk_aj('.pk_admin_input_select[name=pk_fgg_select_set]').append('<option value="">No photoset available</option>');
					$pk_aj('.pk_admin_input_select[name=pk_fgg_select_galleries]').append('<option value="">No galleries available</option>');
					
				}
				
			}

		});

		return false;
		
	});
	
	$pk_aj('.pk_admin_input_text_field[name=pk_fgg_flickr_user_id]').change();
	
	$pk_aj('.pk_admin_input_select[name=pk_main_theme_skin]').change(function(event) {
	
		$pk_aj(this).find('option').each(function(event) {
			
			$pk_aj('.' + $pk_aj(this).val().split('.').join('_')).hide();
			
		});
		
		$pk_aj('.' + $pk_aj(this).find('option:selected').val().split('.').join('_')).show();
		
	});
	
	$pk_aj('.pk_admin_input_select[name=pk_main_theme_skin]').change();
	
});