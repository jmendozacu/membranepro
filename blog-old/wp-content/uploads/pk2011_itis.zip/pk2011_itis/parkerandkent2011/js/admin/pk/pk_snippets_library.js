var $pk_aj = jQuery.noConflict();
$pk_aj(document).ready(function() {
	
	$pk_aj('.pk_admin_send_snippet_button').remove().appendTo($pk_aj('.pk_sl_snippets_library select').parent());
	
	$pk_aj('.pk_admin_send_snippet_button').click(function(event) {
		
		if ($pk_aj('.pk_admin_snippet_content').val() == '') {
			
			return;
			
		} else {
			
			window.send_to_editor('\n' + $pk_aj('.pk_admin_snippet_content').val() + '\n');
		
			return false;
			
		}
		
	});
	
	$pk_aj('.pk_sl_snippets_library select').bind('change', function(event) {
		
		if ($pk_aj(this).val() == '') {
			
			$pk_aj('.pk_admin_messages').hide();
			$pk_aj('.pk_admin_snippet_title').val('');
			$pk_aj('.pk_admin_snippet_content').val('');
			return;
			
		}
		
		$pk_aj('body').css('cursor', 'progress');
		$pk_aj('.pk_admin_messages').hide();
		$pk_aj('#pk_admin_loading_snippet').show();
		
		$pk_aj.ajax({
			url:ajaxurl,
			type:'POST',
			cache:false,
			data:{
					
					action:'load_snippet',
					snippet_id:$pk_aj(this).val()
					
			},
			success:function(output) {
				
				$pk_aj('body').css('cursor', 'auto');
				
				if (output.split(',')[0] == 'success') {
					
					var title = decodeURIComponent(output.split(',')[1].replace(/\+/g, '%20'));
					var content = decodeURIComponent(output.split(',')[2].replace(/\+/g, '%20'));
					
					$pk_aj('.pk_admin_snippet_title').val(title);
					$pk_aj('.pk_admin_snippet_content').val(content);
					
					$pk_aj('#pk_admin_success_loading_snippet').show();
					$pk_aj('#pk_admin_loading_snippet').hide();
					
					return;
				
				}
				
				if (output == 'error') {
					
					$pk_aj('#pk_admin_error_loading_snippet').show();
					$pk_aj('#pk_admin_loading_snippet').hide();
					
				}
				
			}

		});

		return false;
		
	});
	
	$pk_aj('.pk_admin_save_snippet_button').click(function(event) {
		
		$pk_aj('body').css('cursor', 'progress');
		$pk_aj('.pk_admin_messages').hide();
		$pk_aj('#pk_admin_saving_snippet').show();
		
		$pk_aj.ajax({
			url:ajaxurl,
			type:'POST',
			cache:false,
			data:{
					
					action:'save_snippet',
					snippet_title:$pk_aj('.pk_admin_snippet_title').val(),
					snippet_content:$pk_aj('.pk_admin_snippet_content').val()
					
			},
			success:function(output) {
				
				$pk_aj('body').css('cursor', 'auto');
				
				if (output.split(',')[0] == 'success') {
					
					$pk_aj('.pk_sl_snippets_library select').append('<option value="' + output.split(',')[1] + '" selected="selected">' + $pk_aj('.pk_admin_snippet_title').val() + '</option>');
					
					$pk_aj('#pk_admin_success_saving_snippet').show();
					$pk_aj('#pk_admin_saving_snippet').hide();
					
					return;
				
				}
				
				if (output == 'error') {
					
					$pk_aj('#pk_admin_error_saving_snippet').show();
					$pk_aj('#pk_admin_saving_snippet').hide();
					
				}
				
			}

		});

		return false;
				
	});
	
	$pk_aj('.pk_admin_update_snippet_button').click(function(event) {
		
		$pk_aj('body').css('cursor', 'progress');
		$pk_aj('.pk_admin_messages').hide();
		$pk_aj('#pk_admin_updating_snippet').show();
		
		$pk_aj.ajax({
			url:ajaxurl,
			type:'POST',
			cache:false,
			data:{
					
					action:'update_snippet',
					snippet_id:$pk_aj('.pk_sl_snippets_library select').val(),
					snippet_title:$pk_aj('.pk_admin_snippet_title').val(),
					snippet_content:$pk_aj('.pk_admin_snippet_content').val()
					
			},
			success:function(output) {
				
				$pk_aj('body').css('cursor', 'auto');
				
				if (output.split(',')[0] == 'success') {
					
					var title = decodeURIComponent(output.split(',')[2].replace(/\+/g, '%20'));
					var content = decodeURIComponent(output.split(',')[3].replace(/\+/g, '%20'));
					
					$pk_aj('.pk_sl_snippets_library select option[value="' + output.split(',')[1] + '"]').text(title);
					
					$pk_aj('#pk_admin_success_updating_snippet').show();
					$pk_aj('#pk_admin_updating_snippet').hide();
					
					return;
				
				}
				
				if (output == 'error') {
					
					$pk_aj('#pk_admin_error_updating_snippet').show();
					$pk_aj('#pk_admin_updating_snippet').hide();
					
				}
				
			}

		});

		return false;
				
	});
	
	$pk_aj('.pk_admin_delete_snippet_button').click(function(event) {
		
		if ($pk_aj('.pk_sl_snippets_library select').val() == '' || confirm($pk_aj(this).attr('data-message')) == false) {
			
			return;
			
		}
		
		$pk_aj('body').css('cursor', 'progress');
		$pk_aj('.pk_admin_messages').hide();
		$pk_aj('#pk_admin_deleting_snippet').show();
		
		$pk_aj.ajax({
			url:ajaxurl,
			type:'POST',
			cache:false,
			data:{
					
					action:'delete_snippet',
					snippet_id:$pk_aj('.pk_sl_snippets_library select').val()
					
			},
			success:function(output) {
				
				$pk_aj('body').css('cursor', 'auto');
				
				if (output == 'success') {
					
					$pk_aj('.pk_sl_snippets_library select option[value="' + $pk_aj('.pk_sl_snippets_library select').val() + '"]').remove();
					
					$pk_aj('.pk_admin_snippet_title').val('');
					$pk_aj('.pk_admin_snippet_content').val('');
					
					$pk_aj('#pk_admin_success_deleting_snippet').show();
					$pk_aj('#pk_admin_deleting_snippet').hide();
					
					return;
				
				}
				
				if (output == 'error') {
					
					$pk_aj('#pk_admin_error_deleting_snippet').show();
					$pk_aj('#pk_admin_deleting_snippet').hide();
					
				}
				
			}

		});

		return false;
				
	});
	
});