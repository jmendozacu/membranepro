var $pk_aj = jQuery.noConflict();
$pk_aj(document).ready(function() {
	
	var saved_shortcode = new Array();
	var saved_shortcode_type = '';
	var saved_shortcode_fields = new Array();
	var saved_shortcode_values = new Array();
	var update_shortcode = false;
	
	$pk_aj('.pk_sc_shortcodes_manager table').click(function(event) {
		
		if ($pk_aj(this).attr('id') == 'pk_sc_table_save_shortcode') {
			
			return false;
			
		}
		
		$pk_aj('.pk_sc_save_shortcode').hide();
		
	});
	
	$pk_aj('.pk_admin_load_shortcodes_list').bind('click', function(event) {
		
		if ($pk_aj(this).val() == 'select') {
			
			return;
			
		}
		
		var data_array = $pk_aj.parseJSON(decodeURIComponent($pk_aj(this).val().replace(/\+/g, '%20')));
		var type = data_array['type'];
		var fields = data_array['fields'];
		var values = data_array['values'];
		
		for (var i = 0; i < fields.length; i++) {
			
			var field = $pk_aj('.pk_sc_' + type).find('[name="' + fields[i] + '"]');
			
			if (field.attr('type') == 'hidden') {
				
				field.val(values[i]);
				
				if (field.attr('class') == 'pk_audio_field') {
					
					$pk_aj('#' + fields[i] + '_cover_field').val(values[i].split(',')[0]);
					$pk_aj('#' + fields[i] + '_file_field').val(values[i].split(',')[1]);
					
				}
				
				if (field.attr('class') == 'pk_video_field') {
					
					$pk_aj('#' + fields[i] + '_select_video').val(values[i].split(',')[0]);
					$pk_aj('#' + fields[i] + '_select_video').change();
					
					$pk_aj('#' + fields[i] + '_cover_field').val(values[i].split(',')[1]);
					
					if (values[i].split(',')[0] == '1') {
						
						$pk_aj('#' + fields[i] + '_mp4_field').val(values[i].split(',')[2]);
						$pk_aj('#' + fields[i] + '_webm_field').val(values[i].split(',')[3]);
						$pk_aj('#' + fields[i] + '_ogg_field').val(values[i].split(',')[4]);
						
					} else {
						
						$pk_aj('#' + fields[i] + '_file_field').val(values[i].split(',')[2]);
						
					}
					
				}
				
				if (field.attr('class') == 'pk_admin_multiple_field') {
					
					var options_array = values[i].split(',');
					
					if (field.parent().find('.pk_admin_multiple_checkbox_div_wrapper').attr('class') != undefined) {
						
						field.parent().find('.pk_admin_multiple_checkbox').each(function() {
							
							if ($pk_aj.inArray($pk_aj(this).val(), options_array) != -1) {
								
								$pk_aj(this).attr('checked', true);
								
							} else {
								
								$pk_aj(this).attr('checked', false);
								
							}
							
						});
						
					}
					
					if (field.parent().find('.pk_admin_input_select_multiple').attr('class') != undefined) {
						
						field.parent().find('.pk_admin_input_select_multiple').val(options_array);
						
					}
					
				}
				
			}
			
			field.val(values[i]);
			field.change();
		
		}
		
	});
	
	$pk_aj('#pk_sc_close_save_shortcode_button').click(function(event) {
		
		pk_reset_save_shortcode_form();
		$pk_aj('.pk_sc_save_shortcode').hide();
		
		return false;
		
	});
	
	$pk_aj('#pk_sc_save_shortcode_button').click(function(event) {
		
		saved_shortcode_name = $pk_aj('.pk_sc_save_shortcode').find('[name="pk_sc_save_shortcode_name"]').val();
		
		if (saved_shortcode_name == '') {
			
			alert($pk_aj(this).attr('data-message'));
			return false;
			
		}
		
		
		$pk_aj('.pk_admin_messages').hide();
		$pk_aj('#pk_admin_saving_shortcode').show();
		
		$pk_aj('body').css('cursor', 'progress');
		
		saved_shortcode = new Array();
		
		saved_shortcode[0] = saved_shortcode_type;
		saved_shortcode[1] = saved_shortcode_name;
		saved_shortcode[2] = saved_shortcode_fields;
		saved_shortcode[3] = saved_shortcode_values;
		
		$pk_aj.ajax({
			url:ajaxurl,
			type:'POST',
			cache:false,
			data:{
					
					action:'save_shortcode',
					saved_shortcodes_data:saved_shortcode,
					update:update_shortcode
					
			},
			success:function(output) {
				
				$pk_aj('body').css('cursor', 'auto');
				
				if (output.split(',')[0] == 'success') {
					
					if (update_shortcode) {
						
						$pk_aj('#pk_admin_delete_shortcodes_list_' + saved_shortcode_type + ' option:contains("' + saved_shortcode_name + '")').val(output.split(',')[1]);
						$pk_aj('#pk_admin_load_shortcodes_list_' + saved_shortcode_type + ' option:contains("' + saved_shortcode_name + '")').val(output.split(',')[1]);
					
					} else {
					
						$pk_aj('#pk_admin_delete_shortcodes_list_' + saved_shortcode_type).append('<option value="' + output.split(',')[1] + '" selected="selected">' + saved_shortcode_name + '</option>');
						$pk_aj('#pk_admin_load_shortcodes_list_' + saved_shortcode_type).append('<option value="' + output.split(',')[1] + '" selected="selected">' + saved_shortcode_name + '</option>');
						
					}
					
					$pk_aj('#pk_admin_tr_load_shortcode_' + saved_shortcode_type).show();
					$pk_aj('#pk_admin_tr_delete_shortcode_' + saved_shortcode_type).show();
					$pk_aj('#pk_sc_table_' + saved_shortcode_type + '_open_shortcodes_library_button').hide();
					$pk_aj('#pk_sc_table_' + saved_shortcode_type + '_close_shortcodes_library_button').show();
					
					$pk_aj('.pk_sc_save_shortcode').hide();
					pk_reset_save_shortcode_form();
					
					$pk_aj('#pk_admin_success_saving_shortcode').show();
					$pk_aj('#pk_admin_saving_shortcode').hide();
					
					return;
				
				} else if (output == 'error') {
					
					$pk_aj('.pk_sc_save_shortcode').show();
					
					$pk_aj('#pk_admin_error_saving_shortcode').show();
					$pk_aj('#pk_admin_saving_shortcode').hide();
					
				} else {
					
					if (confirm(output)) {
						 
						 update_shortcode = true;
						 $pk_aj('#pk_sc_save_shortcode_button').click();
						 return;
						 
					}
					
					$pk_aj('.pk_sc_save_shortcode').show();
					
				}
				
			}

		});

		return false;
				
	});
	
	$pk_aj('.pk_sc_delete_shortcode_button').click(function(event) {
		
		var type = $pk_aj(this).attr('data-type');
		var deleted_shortcode = $pk_aj('#pk_admin_delete_shortcodes_list_' + type).val();
		
		if ($pk_aj('#pk_admin_delete_shortcodes_list_' + type).val() == 'select' || confirm($pk_aj(this).attr('data-message')) == false) {
			
			 return false;
						 
		}
		
		$pk_aj('.pk_admin_messages').hide();
		$pk_aj('#pk_admin_deleting_shortcode').show();
		
		$pk_aj('body').css('cursor', 'progress');
		
		$pk_aj.ajax({
			url:ajaxurl,
			type:'POST',
			cache:false,
			data:{
					
					action:'delete_shortcode',
					deleted_shortcode_data:deleted_shortcode
					
			},
			success:function(output) {
				
				$pk_aj('body').css('cursor', 'auto');
				
				if (output == 'success') {
					
					$pk_aj('#pk_admin_delete_shortcodes_list_' + type + ' option[value="' + deleted_shortcode + '"]').remove();
					$pk_aj('#pk_admin_load_shortcodes_list_' + type + ' option[value="' + deleted_shortcode + '"]').remove();
					
					$pk_aj('#pk_admin_success_deleting_shortcode').show();
					$pk_aj('#pk_admin_deleting_shortcode').hide();
					
					if ($pk_aj('#pk_admin_load_shortcodes_list_' + type + ' option').length == 1) {
						
						$pk_aj('#pk_admin_tr_load_shortcode_' + type).hide();
						$pk_aj('#pk_admin_tr_delete_shortcode_' + type).hide();
						$pk_aj('#pk_sc_table_' + type + '_open_shortcodes_library_button').show();
						$pk_aj('#pk_sc_table_' + type + '_close_shortcodes_library_button').hide();
						
					}
					
					return;
				
				}
				
				if (output == 'error') {
					
					$pk_aj('#pk_admin_error_deleting_shortcode').show();
					$pk_aj('#pk_admin_deleting_shortcode').hide();
					
				}
				
			}

		});

		return false;
				
	});
	
	$pk_aj('.pk_admin_open_shortcodes_library_button').click(function(event) {
		
		var type = $pk_aj(this).attr('data-type');
		
		if ($pk_aj('#pk_admin_load_shortcodes_list_' + type + ' option').length == 1) {
			
			alert($pk_aj(this).attr('data-message'));
			return false;
			
		}
		
		$pk_aj('#pk_admin_tr_load_shortcode_' + type).show();
		$pk_aj('#pk_admin_tr_delete_shortcode_' + type).show();
		$pk_aj('#pk_sc_table_' + type + '_open_shortcodes_library_button').hide();
		$pk_aj('#pk_sc_table_' + type + '_close_shortcodes_library_button').show();
		
		return false;
		
	});
	
	$pk_aj('.pk_admin_close_shortcodes_library_button').click(function(event) {
		
		var type = $pk_aj(this).attr('data-type');
		
		$pk_aj('#pk_admin_tr_load_shortcode_' + type).hide();
		$pk_aj('#pk_admin_tr_delete_shortcode_' + type).hide();
		$pk_aj('#pk_sc_table_' + type + '_open_shortcodes_library_button').show();
		$pk_aj('#pk_sc_table_' + type + '_close_shortcodes_library_button').hide();
		
		return false;
		
	});
	
	$pk_aj('.pk_sc_selector').find('[name="pk_sc_shortcode_type"]').change(function(event) {
		
		pk_reset_save_shortcode_form();
		$pk_aj('.pk_sc_save_shortcode').hide();
		
	});
	
	function pk_reset_save_shortcode_form() {
		
		saved_shortcode_type = '';
		saved_shortcode_fields = new Array();
		saved_shortcode_values = new Array();
		update_shortcode = false;
		
		$pk_aj('.pk_sc_save_shortcode').find('[name="pk_sc_save_shortcode_name"]').val('');
		
		$pk_aj('.pk_admin_messages').hide();
		
	}
	
	function pk_sc_create_library_actions() {
		
		$pk_aj('.pk_admin_sc_div').each(function() {
			
			var shortcode_type = $pk_aj(this).attr('class').split(' ')[2].split('pk_sc_')[1];
			
			$pk_aj('#pk_sc_table_' + shortcode_type + '_generate_shortcode_button').click(function(event) {
				
				pk_reset_save_shortcode_form();
				
				var counter = 0;
				
				saved_shortcode_type = shortcode_type;
				
				$pk_aj('#pk_sc_table_' + shortcode_type).find('[name]').each(function() {
					
					saved_shortcode_fields[counter] = $pk_aj(this).attr('name');
					saved_shortcode_values[counter] = $pk_aj(this).val();
						
					counter++;
					
				});
				
				$pk_aj('.pk_sc_save_shortcode').show();
				
				pk_sc_send_to_editor(shortcode_type);
				
				return false;
				
			});
			
		 });
		 
	}
	
	pk_sc_create_library_actions();
	
	function pk_sc_send_to_editor(type) {
		
		switch (type) {
			
			case 'blog':
				
				window.send_to_editor('\n[pk_' + $pk_aj('.pk_sc_blog').find('[name="pk_sc_blog_query_type"]').val() + '_posts title="' + $pk_aj('.pk_sc_blog').find('[name="pk_sc_blog_title"]').val() + '" posts="' + $pk_aj('.pk_sc_blog').find('[name="pk_sc_blog_posts"]').val() + '" order_by="' + $pk_aj('.pk_sc_blog').find('[name="pk_sc_blog_order_by"]').val() + '" number="' + $pk_aj('.pk_sc_blog').find('[name="pk_sc_blog_number"]').val() + '" display_excerpt="' + $pk_aj('.pk_sc_blog').find('[name="pk_sc_blog_display_excerpt"]').val() + '" display_thumb="' + $pk_aj('.pk_sc_blog').find('[name="pk_sc_blog_display_thumb"]').val() + '" list_icon="' + $pk_aj('.pk_sc_blog').find('[name="pk_sc_blog_list_icon"]').val() + '" thumb_icon="' + $pk_aj('.pk_sc_blog').find('[name="pk_sc_blog_thumb_icon"]').val() + '" thumb_width="' + $pk_aj('.pk_sc_blog').find('[name="pk_sc_blog_thumb_width"]').val() + '" thumb_height="' + $pk_aj('.pk_sc_blog').find('[name="pk_sc_blog_thumb_height"]').val() + '"]\n');
				break;
			
			case 'normal_box':
				
				window.send_to_editor('\n[pk_box width="' + $pk_aj('.pk_sc_normal_box').find('[name="pk_sc_normal_box_width"]').val() + '" align="' + $pk_aj('.pk_sc_normal_box').find('[name="pk_sc_normal_box_align"]').val() + '" text_align="' + $pk_aj('.pk_sc_normal_box').find('[name="pk_sc_normal_box_text_align"]').val() + '"]\n' + $pk_aj('.pk_sc_normal_box').find('[name="pk_sc_normal_box_content"]').val() + '\n[/pk_box]\n');
				break;
			
			case 'titled_box':
				
				window.send_to_editor('\n[pk_titled_box width="' + $pk_aj('.pk_sc_titled_box').find('[name="pk_sc_titled_box_width"]').val() + '" align="' + $pk_aj('.pk_sc_titled_box').find('[name="pk_sc_titled_box_align"]').val() + '"]\n[pk_box_title text_align="' + $pk_aj('.pk_sc_titled_box').find('[name="pk_sc_titled_box_title_text_align"]').val() + '"]\n' + $pk_aj('.pk_sc_titled_box').find('[name="pk_sc_titled_box_title"]').val() + '\n[/pk_box_title]\n[pk_box_content text_align="' + $pk_aj('.pk_sc_titled_box').find('[name="pk_sc_titled_box_content_text_align"]').val() + '"]\n' + $pk_aj('.pk_sc_titled_box').find('[name="pk_sc_titled_box_content"]').val() + '\n[/pk_box_content]\n[/pk_titled_box]\n');
				break;
			
			case 'message_box':
				
				window.send_to_editor('\n[pk_' + $pk_aj('.pk_sc_message_box').find('[name="pk_sc_message_box_type"]').val() + '_box width="' + $pk_aj('.pk_sc_message_box').find('[name="pk_sc_message_box_width"]').val() + '"]\n' + $pk_aj('.pk_sc_message_box').find('[name="pk_sc_message_box_content"]').val() + '\n[/pk_' + $pk_aj('.pk_sc_message_box').find('[name="pk_sc_message_box_type"]').val() + '_box]\n');
				break;
			
			case 'normal_buttons':
				
				window.send_to_editor('\n[pk_button size="' + $pk_aj('.pk_sc_normal_buttons').find('[name="pk_sc_normal_buttons_size"]').val() + '" align="' + $pk_aj('.pk_sc_normal_buttons').find('[name="pk_sc_normal_buttons_align"]').val() + '" color="' + $pk_aj('.pk_sc_normal_buttons').find('[name="pk_sc_normal_buttons_color"]').val() + '" icon="' + $pk_aj('.pk_sc_normal_buttons').find('[name="pk_sc_normal_buttons_icon"]').val() + '" action="' + $pk_aj('.pk_sc_normal_buttons').find('[name="pk_sc_normal_buttons_action"]').val() + '" link="' + $pk_aj('.pk_sc_normal_buttons').find('[name="pk_sc_normal_buttons_link"]').val() + '" link_target="' + $pk_aj('.pk_sc_normal_buttons').find('[name="pk_sc_normal_buttons_link_target"]').val() + '" title="' + $pk_aj('.pk_sc_normal_buttons').find('[name="pk_sc_normal_buttons_title"]').val() + '" lightbox_gallery_id="' + $pk_aj('.pk_sc_normal_buttons').find('[name="pk_sc_normal_buttons_lightbox_gallery_id"]').val() + '"]' + $pk_aj('.pk_sc_normal_buttons').find('[name="pk_sc_normal_buttons_label"]').val() + '[/pk_button]\n');
				break;
			
			case 'columns':
				
				window.send_to_editor('\n[' + $pk_aj('.pk_sc_columns').find('[name="pk_sc_columns_size"]').val() + ']\n' + $pk_aj('.pk_sc_columns').find('[name="pk_sc_columns_content"]').val() + '\n[/' + $pk_aj('.pk_sc_columns').find('[name="pk_sc_columns_size"]').val() + ']\n');
				break;
			
			case 'recent_comments':
				
				window.send_to_editor('\n[pk_recent_comments title="' + $pk_aj('.pk_sc_recent_comments').find('[name="pk_sc_recent_comments_title"]').val() + '" number="' + $pk_aj('.pk_sc_recent_comments').find('[name="pk_sc_recent_comments_number"]').val() + '"]\n');
				break;
			
			case 'dividers':
				
				var dividers_height = '';
		
				if ($pk_aj('.pk_sc_dividers').find('[name="pk_sc_dividers_type"]').val() == 'pk_empty_space') {
			
					dividers_height = ' height="' + $pk_aj('.pk_sc_dividers').find('[name="pk_sc_dividers_height"]').val() + '"';
			
				}
		
				window.send_to_editor('\n[' + saved_shortcode_values[0] + dividers_height + ']\n');
				break;
			
			case 'dribbble':
				
				window.send_to_editor('\n[pk_dribbble_feed title="' + $pk_aj('.pk_sc_dribbble').find('[name="pk_sc_dribbble_title"]').val() + '" username="' + $pk_aj('.pk_sc_dribbble').find('[name="pk_sc_dribbble_username"]').val() + '" number="' + $pk_aj('.pk_sc_dribbble').find('[name="pk_sc_dribbble_number"]').val() + '"]\n');
				break;
			
			case 'flickr':
				
				window.send_to_editor('\n[pk_flickr_feed title="' + $pk_aj('.pk_sc_flickr').find('[name="pk_sc_flickr_title"]').val() + '" feed="' + $pk_aj('.pk_sc_flickr').find('[name="pk_sc_flickr_feed"]').val() + '" number="' + $pk_aj('.pk_sc_flickr').find('[name="pk_sc_flickr_number"]').val() + '" thumb_icon="' + $pk_aj('.pk_sc_flickr').find('[name="pk_sc_flickr_thumb_icon"]').val() + '" open_with_lightbox="' + $pk_aj('.pk_sc_flickr').find('[name="pk_sc_flickr_open_with_lightbox"]').val() + '" slideshow_autostart="' + $pk_aj('.pk_sc_flickr').find('[name="pk_sc_flickr_slideshow_autostart"]').val() + '" slideshow_interval="' + $pk_aj('.pk_sc_flickr').find('[name="pk_sc_flickr_slideshow_interval"]').val() + '"]\n');
				break;
			
			case 'contact_form':
				
				window.send_to_editor('\n[pk_contact_form send_to="' + $pk_aj('.pk_sc_contact_form').find('[name="pk_sc_contact_form_send_to"]').val() + '" name_label="' + $pk_aj('.pk_sc_contact_form').find('[name="pk_sc_contact_form_name_label"]').val() + '" email_label="' + $pk_aj('.pk_sc_contact_form').find('[name="pk_sc_contact_form_email_label"]').val() + '" message_label="' + $pk_aj('.pk_sc_contact_form').find('[name="pk_sc_contact_form_message_label"]').val() + '" subject="' + $pk_aj('.pk_sc_contact_form').find('[name="pk_sc_contact_form_subject"]').val() + '"]\n');
				break;
			
			case 'search_form':
				
				window.send_to_editor('\n[pk_search_form title="' + $pk_aj('.pk_sc_search_form').find('[name="pk_sc_search_form_title"]').val() + '"]\n');
				break;
			
			case 'google_maps':
				
				window.send_to_editor('\n[pk_google_maps title="' + $pk_aj('.pk_sc_google_maps').find('[name="pk_sc_google_maps_title"]').val() + '" map_height="' + $pk_aj('.pk_sc_google_maps').find('[name="pk_sc_google_maps_map_height"]').val() + '" map_url="' + $pk_aj('.pk_sc_google_maps').find('[name="pk_sc_google_maps_map_url"]').val() + '"]\n');
				break;
			
			case 'images':
				
				window.send_to_editor('\n[pk_image image="' + $pk_aj('.pk_sc_images').find('[name="pk_sc_images_image"]').val() + '" title="' + $pk_aj('.pk_sc_images').find('[name="pk_sc_images_title"]').val() + '" w="' + $pk_aj('.pk_sc_images').find('[name="pk_sc_images_w"]').val() + '" image_style="' + $pk_aj('.pk_sc_images').find('[name="pk_sc_images_image_style"]').val() + '" h="' + $pk_aj('.pk_sc_images').find('[name="pk_sc_images_h"]').val() + '" align="' + $pk_aj('.pk_sc_images').find('[name="pk_sc_images_align"]').val() + '" icon="' + $pk_aj('.pk_sc_images').find('[name="pk_sc_images_icon"]').val() + '" action="' + $pk_aj('.pk_sc_images').find('[name="pk_sc_images_action"]').val() + '" link="' + $pk_aj('.pk_sc_images').find('[name="pk_sc_images_link"]').val() + '" link_target="' + $pk_aj('.pk_sc_images').find('[name="pk_sc_images_link_target"]').val() + '" lightbox_gallery_id="' + $pk_aj('.pk_sc_images').find('[name="pk_sc_images_lightbox_gallery_id"]').val() + '"]\n');
				break;
			
			case 'media_video':
				
				var video_type = $pk_aj('.pk_sc_media_video').find('[name="pk_sc_media_video_file"]').val().split(',')[0];
				var video_cover = $pk_aj('.pk_sc_media_video').find('[name="pk_sc_media_video_file"]').val().split(',')[1];
				var use_custom_player = $pk_aj('.pk_sc_media_video').find('[name="pk_sc_media_video_use_custom_player"]').val();
				
				if (video_type == '0') {
					
					pk_reset_save_shortcode_form();
					$pk_aj('.pk_sc_save_shortcode').hide();
					
				}
				
				if (video_type == '1') {
				
					window.send_to_editor('\n[pk_html5_player width="' + $pk_aj('.pk_sc_media_video').find('[name="pk_sc_media_video_width"]').val() + '" height="' + $pk_aj('.pk_sc_media_video').find('[name="pk_sc_media_video_height"]').val() + '" align="' + $pk_aj('.pk_sc_media_video').find('[name="pk_sc_media_video_align"]').val() + '" autoplay="' + $pk_aj('.pk_sc_media_video').find('[name="pk_sc_media_video_autoplay"]').val() + '" cover="' + $pk_aj('.pk_sc_media_video').find('[name="pk_sc_media_video_file"]').val().split(',')[1] + '" mp4="' + $pk_aj('.pk_sc_media_video').find('[name="pk_sc_media_video_file"]').val().split(',')[2] + '" webm="' + $pk_aj('.pk_sc_media_video').find('[name="pk_sc_media_video_file"]').val().split(',')[3] + '" ogg="' + $pk_aj('.pk_sc_media_video').find('[name="pk_sc_media_video_file"]').val().split(',')[4] + '"]\n');
					
				}
				
				if (video_type == '2') {
				
					window.send_to_editor('\n[pk_video_player width="' + $pk_aj('.pk_sc_media_video').find('[name="pk_sc_media_video_width"]').val() + '" height="' + $pk_aj('.pk_sc_media_video').find('[name="pk_sc_media_video_height"]').val() + '" align="' + $pk_aj('.pk_sc_media_video').find('[name="pk_sc_media_video_align"]').val() + '" autoplay="' + $pk_aj('.pk_sc_media_video').find('[name="pk_sc_media_video_autoplay"]').val() + '" cover="' + $pk_aj('.pk_sc_media_video').find('[name="pk_sc_media_video_file"]').val().split(',')[1] + '" video_url="' + $pk_aj('.pk_sc_media_video').find('[name="pk_sc_media_video_file"]').val().split(',')[2] + '"]\n');
					
				}
				
				if (video_type == '3') {
					
					if (use_custom_player == 'true') {
						
						video_type = 'youtube_custom';
						
					} else {
						
						video_type = 'youtube';
						
					}
				
					window.send_to_editor('\n[pk_' + video_type + '_player width="' + $pk_aj('.pk_sc_media_video').find('[name="pk_sc_media_video_width"]').val() + '" height="' + $pk_aj('.pk_sc_media_video').find('[name="pk_sc_media_video_height"]').val() + '" align="' + $pk_aj('.pk_sc_media_video').find('[name="pk_sc_media_video_align"]').val() + '" autoplay="' + $pk_aj('.pk_sc_media_video').find('[name="pk_sc_media_video_autoplay"]').val() + '" cover="' + $pk_aj('.pk_sc_media_video').find('[name="pk_sc_media_video_file"]').val().split(',')[1] + '" video_id="' + $pk_aj('.pk_sc_media_video').find('[name="pk_sc_media_video_file"]').val().split(',')[2] + '"]\n');
					
				}
				
				if (video_type == '4') {
				
					window.send_to_editor('\n[pk_vimeo_player width="' + $pk_aj('.pk_sc_media_video').find('[name="pk_sc_media_video_width"]').val() + '" height="' + $pk_aj('.pk_sc_media_video').find('[name="pk_sc_media_video_height"]').val() + '" align="' + $pk_aj('.pk_sc_media_video').find('[name="pk_sc_media_video_align"]').val() + '" autoplay="' + $pk_aj('.pk_sc_media_video').find('[name="pk_sc_media_video_autoplay"]').val() + '" cover="' + $pk_aj('.pk_sc_media_video').find('[name="pk_sc_media_video_file"]').val().split(',')[1] + '" video_id="' + $pk_aj('.pk_sc_media_video').find('[name="pk_sc_media_video_file"]').val().split(',')[2] + '"]\n');
					
				}
				break;
			
			case 'media_audio':
				
				window.send_to_editor('\n[pk_audio_player width="' + $pk_aj('.pk_sc_media_audio').find('[name="pk_sc_media_audio_width"]').val() + '" height="' + $pk_aj('.pk_sc_media_audio').find('[name="pk_sc_media_audio_height"]').val() + '" align="' + $pk_aj('.pk_sc_media_audio').find('[name="pk_sc_media_audio_align"]').val() + '" autoplay="' + $pk_aj('.pk_sc_media_audio').find('[name="pk_sc_media_audio_autoplay"]').val() + '" cover="' + $pk_aj('.pk_sc_media_audio').find('[name="pk_sc_media_audio_file"]').val().split(',')[0] + '" audio_url="' + $pk_aj('.pk_sc_media_audio').find('[name="pk_sc_media_audio_file"]').val().split(',')[1] + '"]\n');
				break;
			
			case 'media_swf':
				
				window.send_to_editor('\n[pk_swf_object width="' + $pk_aj('.pk_sc_media_swf').find('[name="pk_sc_media_swf_width"]').val() + '" height="' + $pk_aj('.pk_sc_media_swf').find('[name="pk_sc_media_swf_height"]').val() + '" align="' + $pk_aj('.pk_sc_media_swf').find('[name="pk_sc_media_swf_align"]').val() + '" swf_url="' + $pk_aj('.pk_sc_media_swf').find('[name="pk_sc_media_swf_file"]').val() + '" flashvars=\'' + $pk_aj('.pk_sc_media_swf').find('[name="pk_sc_media_swf_flashvars"]').val() + '\' params=\'' + $pk_aj('.pk_sc_media_swf').find('[name="pk_sc_media_swf_params"]').val() + '\' fp_version="' + $pk_aj('.pk_sc_media_swf').find('[name="pk_sc_media_swf_fp_version"]').val() + '"]\n');
				break;
			
			case 'slides_slider':
				
				window.send_to_editor('\n[pk_standard_slider width="' + $pk_aj('.pk_sc_slides_slider').find('[name="pk_sc_slides_slider_width"]').val() + '" height="' + $pk_aj('.pk_sc_slides_slider').find('[name="pk_sc_slides_slider_height"]').val() + '" slides_categories="' + $pk_aj('.pk_sc_slides_slider').find('[name="pk_sc_slides_slider_slides_categories"]').val() + '" slides_ids="' + $pk_aj('.pk_sc_slides_slider').find('[name="pk_sc_slides_slider_slides_ids"]').val() + '" info_text_align="' + $pk_aj('.pk_sc_slides_slider').find('[name="pk_sc_slides_slider_info_text_align"]').val() + '" info_back_ground_alpha="' + $pk_aj('.pk_sc_slides_slider').find('[name="pk_sc_slides_slider_info_back_ground_alpha"]').val() + '" slideshow="' + $pk_aj('.pk_sc_slides_slider').find('[name="pk_sc_slides_slider_slideshow"]').val() + '" slideshow_auto_start="' + $pk_aj('.pk_sc_slides_slider').find('[name="pk_sc_slides_slider_slideshow_auto_start"]').val() + '" slideshow_interval="' + $pk_aj('.pk_sc_slides_slider').find('[name="pk_sc_slides_slider_slideshow_interval"]').val() + '" open_info_label="' + $pk_aj('.pk_sc_slides_slider').find('[name="pk_sc_slides_slider_open_info_label"]').val() + '" close_info_label="' + $pk_aj('.pk_sc_slides_slider').find('[name="pk_sc_slides_slider_close_info_label"]').val() + '"]\n');
				break;
			
			case 'tables':
				
				window.send_to_editor('\n[pk_table width="' + $pk_aj('.pk_sc_tables').find('[name="pk_sc_tables_width"]').val() + '" align="' + $pk_aj('.pk_sc_tables').find('[name="pk_sc_tables_align"]').val() + '" hover="' + $pk_aj('.pk_sc_tables').find('[name="pk_sc_tables_hover"]').val() + '"]\n' + $pk_aj('.pk_sc_tables').find('[name="pk_sc_tables_html"]').val() + '\n[/pk_table]\n');
				break;
			
			case 'tabs':
				
				var total_tabs = Number($pk_aj('.pk_sc_tabs').find('[name="pk_sc_tabs_number"]').val())
				
				var tabs_output = '\n[pk_' + $pk_aj('.pk_sc_tabs').find('[name="pk_sc_tabs_style"]').val() + '_tabs title="' + $pk_aj('.pk_sc_tabs').find('[name="pk_sc_tabs_title"]').val() + '" width="' + $pk_aj('.pk_sc_tabs').find('[name="pk_sc_tabs_width"]').val() + '" align="' + $pk_aj('.pk_sc_tabs').find('[name="pk_sc_tabs_align"]').val() + '"]\n';
				
				for (var i = 0; i < total_tabs; i++) {
					
					tabs_output += '\n[pk_tab title="Tab title ' + i + '"]\n<p>Tab ' + i + ' content here...</p>\n[/pk_tab]\n';
					
				}
				
				tabs_output += '\n[/pk_' + $pk_aj('.pk_sc_tabs').find('[name="pk_sc_tabs_style"]').val() + '_tabs]\n';
				
				window.send_to_editor(tabs_output);
				break;
			
			case 'toggles':
				
				var total_toggles = Number($pk_aj('.pk_sc_toggles').find('[name="pk_sc_toggles_number"]').val())
				
				var toggles_output = '\n[pk_' + $pk_aj('.pk_sc_toggles').find('[name="pk_sc_toggles_style"]').val() + '_toggles width="' + $pk_aj('.pk_sc_toggles').find('[name="pk_sc_toggles_width"]').val() + '" align="' + $pk_aj('.pk_sc_toggles').find('[name="pk_sc_toggles_align"]').val() + '"]\n';
				
				for (var i = 0; i < total_toggles; i++) {
					
					toggles_output += '\n[pk_' + $pk_aj('.pk_sc_toggles').find('[name="pk_sc_toggles_style"]').val() + '_toggle title="Toggle title ' + i + '"]\n<p>Toggle ' + i + ' content here...</p>\n[/pk_' + $pk_aj('.pk_sc_toggles').find('[name="pk_sc_toggles_style"]').val() + '_toggle]\n';
					
				}
				
				toggles_output += '\n[/pk_' + $pk_aj('.pk_sc_toggles').find('[name="pk_sc_toggles_style"]').val() + '_toggles]\n';
				
				window.send_to_editor(toggles_output);
				break;
			
			case 'twitter':
				
				window.send_to_editor('\n[pk_twitter_feed title="' + $pk_aj('.pk_sc_twitter').find('[name="pk_sc_twitter_title"]').val() + '" username="' + $pk_aj('.pk_sc_twitter').find('[name="pk_sc_twitter_username"]').val() + '" number="' + $pk_aj('.pk_sc_twitter').find('[name="pk_sc_twitter_number"]').val() + '" show_follow_link="' + $pk_aj('.pk_sc_twitter').find('[name="pk_sc_twitter_show_follow_link"]').val() + '"]\n');
				break;
			
			case 'typography_hu':
				
				window.send_to_editor('\n[pk_heading_underline color="' + $pk_aj('.pk_sc_typography_hu').find('[name="pk_sc_typography_hu_color"]').val() + '"]' + $pk_aj('.pk_sc_typography_hu').find('[name="pk_sc_typography_hu_heading"]').val() + '[/pk_heading_underline]\n');
				break;
			
			case 'typography_hb':
				
				window.send_to_editor('\n[pk_heading_background color="' + $pk_aj('.pk_sc_typography_hb').find('[name="pk_sc_typography_hb_color"]').val() + '" background_color="' + $pk_aj('.pk_sc_typography_hb').find('[name="pk_sc_typography_hb_background_color"]').val() + '" rounded="' + $pk_aj('.pk_sc_typography_hb').find('[name="pk_sc_typography_hb_rounded"]').val() + '"]' + $pk_aj('.pk_sc_typography_hb').find('[name="pk_sc_typography_hb_heading"]').val() + '[/pk_heading_background]\n');
				break;
			
			case 'typography_pre':
				
				window.send_to_editor('\n[pk_pre]\n' + $pk_aj('.pk_sc_typography_pre').find('[name="pk_sc_typography_pre_content"]').val() + '\n[/pk_pre]\n');
				break;
			
			case 'typography_code':
				
				window.send_to_editor('\n[pk_code]\n' + $pk_aj('.pk_sc_typography_code').find('[name="pk_sc_typography_code_content"]').val() + '\n[/pk_code]\n');
				break;
			
			case 'typography_quote':
				
				window.send_to_editor('\n[pk_quote width="' + $pk_aj('.pk_sc_typography_quote').find('[name="pk_sc_typography_quote_width"]').val() + '" align="' + $pk_aj('.pk_sc_typography_quote').find('[name="pk_sc_typography_quote_align"]').val() + '" cite="' + $pk_aj('.pk_sc_typography_quote').find('[name="pk_sc_typography_quote_cite"]').val() + '"]\n' + $pk_aj('.pk_sc_typography_quote').find('[name="pk_sc_typography_quote_quote"]').val() + '\n[/pk_quote]\n');
				break;
			
			case 'typography_lists':
				
				window.send_to_editor('\n[' + $pk_aj('.pk_sc_typography_lists').find('[name="pk_sc_typography_lists_style"]').val() + ' underline="' + $pk_aj('.pk_sc_typography_lists').find('[name="pk_sc_typography_lists_underline"]').val() + '"]\n' + $pk_aj('.pk_sc_typography_lists').find('[name="pk_sc_typography_lists_list"]').val() + '\n[/' + $pk_aj('.pk_sc_typography_lists').find('[name="pk_sc_typography_lists_style"]').val() + ']\n');
				break;
			
			case 'typography_hl':
				
				window.send_to_editor('\n[pk_highlight color="' + $pk_aj('.pk_sc_typography_hl').find('[name="pk_sc_typography_hl_color"]').val() + '" background_color="' + $pk_aj('.pk_sc_typography_hl').find('[name="pk_sc_typography_hl_background_color"]').val() + '" rounded="' + $pk_aj('.pk_sc_typography_hl').find('[name="pk_sc_typography_hl_rounded"]').val() + '"]' + $pk_aj('.pk_sc_typography_hl').find('[name="pk_sc_typography_hl_content"]').val() + '[/pk_highlight]\n');
				break;
			
			case 'typography_dc':
				
				window.send_to_editor('\n[pk_drop_caps type="' + $pk_aj('.pk_sc_typography_dc').find('[name="pk_sc_typography_dc_type"]').val() + '" color="' + $pk_aj('.pk_sc_typography_dc').find('[name="pk_sc_typography_dc_color"]').val() + '"]' + $pk_aj('.pk_sc_typography_dc').find('[name="pk_sc_typography_dc_text"]').val() + '[/pk_drop_caps]\n');
				break;
			
			case 'typography_il':
				
				window.send_to_editor('\n[pk_icon_link icon="' + $pk_aj('.pk_sc_typography_il').find('[name="pk_sc_typography_il_icon"]').val() + '" icon_type="' + $pk_aj('.pk_sc_typography_il').find('[name="pk_sc_typography_il_icon_type"]').val() + '"]' + $pk_aj('.pk_sc_typography_il').find('[name="pk_sc_typography_il_link"]').val() + '[/pk_icon_link]\n');
				break;
			
			case 'typography_it':
				
				window.send_to_editor('\n[pk_icon_text icon="' + $pk_aj('.pk_sc_typography_it').find('[name="pk_sc_typography_it_icon"]').val() + '" icon_type="' + $pk_aj('.pk_sc_typography_it').find('[name="pk_sc_typography_it_icon_type"]').val() + '"]' + $pk_aj('.pk_sc_typography_it').find('[name="pk_sc_typography_it_text"]').val() + '[/pk_icon_text]\n');
				break;
			
			case 'works':
				
				window.send_to_editor('\n[pk_' + $pk_aj('.pk_sc_works').find('[name="pk_sc_works_query_type"]').val() + '_works title="' + $pk_aj('.pk_sc_works').find('[name="pk_sc_works_title"]').val() + '" works="' + $pk_aj('.pk_sc_works').find('[name="pk_sc_works_works"]').val() + '" order_by="' + $pk_aj('.pk_sc_works').find('[name="pk_sc_works_order_by"]').val() + '" number="' + $pk_aj('.pk_sc_works').find('[name="pk_sc_works_number"]').val() + '" display_excerpt="' + $pk_aj('.pk_sc_works').find('[name="pk_sc_works_display_excerpt"]').val() + '" display_thumb="' + $pk_aj('.pk_sc_works').find('[name="pk_sc_works_display_thumb"]').val() + '" list_icon="' + $pk_aj('.pk_sc_works').find('[name="pk_sc_works_list_icon"]').val() + '" thumb_icon="' + $pk_aj('.pk_sc_works').find('[name="pk_sc_works_thumb_icon"]').val() + '" thumb_width="' + $pk_aj('.pk_sc_works').find('[name="pk_sc_works_thumb_width"]').val() + '" thumb_height="' + $pk_aj('.pk_sc_works').find('[name="pk_sc_works_thumb_height"]').val() + '"]\n');
				break;
			
		}
		
		return false;
		
	}
	
});