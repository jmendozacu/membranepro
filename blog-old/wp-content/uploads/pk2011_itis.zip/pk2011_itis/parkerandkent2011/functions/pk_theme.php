<?php

if (!class_exists('pk_theme')) {
	
	class pk_theme {
		
		function pk_theme() {
			
			global $content_width;
			
			$content_width = (int)get_option('large_size_w');
			
			define('PK_THEME_FUNCTIONS', PK_FUNCTIONS.'/theme');
			define('PK_THEME_LIBS', PK_THEME_FUNCTIONS.'/libs');
			define('PK_THEME_INCLUDES', PK_THEME_FUNCTIONS.'/includes');
			define('PK_THEME_SHORTCODES', PK_THEME_FUNCTIONS.'/shortcodes');
			define('PK_THEME_TYPES', PK_THEME_FUNCTIONS.'/types');
			define('PK_THEME_WIDGETS', PK_THEME_FUNCTIONS.'/widgets');
			
			require_once(PK_THEME_FUNCTIONS.'/pk_setup.php');
			require_once(PK_THEME_FUNCTIONS.'/pk_get_options.php');
			require_once(PK_THEME_FUNCTIONS.'/pk_get_meta.php');
			require_once(PK_THEME_FUNCTIONS.'/pk_get_skin.php');
			require_once(PK_THEME_FUNCTIONS.'/pk_get_flickr.php');
			require_once(PK_THEME_FUNCTIONS.'/pk_sidebars.php');
			require_once(PK_THEME_FUNCTIONS.'/pk_build_image.php');
			require_once(PK_THEME_FUNCTIONS.'/pk_get_featured_image.php');
			require_once(PK_THEME_FUNCTIONS.'/pk_get_lightbox_gallery.php');
			require_once(PK_THEME_FUNCTIONS.'/pk_contact_form.php');
			require_once(PK_THEME_FUNCTIONS.'/pk_filters.php');
			require_once(PK_THEME_FUNCTIONS.'/pk_pagination.php');
			require_once(PK_THEME_FUNCTIONS.'/pk_add_add_this.php');
			require_once(PK_THEME_FUNCTIONS.'/pk_add_link_pages.php');
			require_once(PK_THEME_FUNCTIONS.'/pk_add_previous_next_post_links.php');
			require_once(PK_THEME_FUNCTIONS.'/pk_google_analytics.php');
			require_once(PK_THEME_FUNCTIONS.'/pk_author.php');
			require_once(PK_THEME_FUNCTIONS.'/pk_header.php');
			require_once(PK_THEME_FUNCTIONS.'/pk_top_slider_page_slider.php');
			require_once(PK_THEME_FUNCTIONS.'/pk_intro.php');
			require_once(PK_THEME_FUNCTIONS.'/pk_blog.php');
			require_once(PK_THEME_FUNCTIONS.'/pk_flickr.php');
			require_once(PK_THEME_FUNCTIONS.'/pk_works.php');
			require_once(PK_THEME_FUNCTIONS.'/pk_sliders.php');
			require_once(PK_THEME_FUNCTIONS.'/pk_comments.php');
			require_once(PK_THEME_FUNCTIONS.'/pk_footer.php');
			
			require_once(PK_THEME_SHORTCODES.'/pk_blog.php');
			require_once(PK_THEME_SHORTCODES.'/pk_boxes.php');
			require_once(PK_THEME_SHORTCODES.'/pk_buttons.php');
			require_once(PK_THEME_SHORTCODES.'/pk_columns.php');
			require_once(PK_THEME_SHORTCODES.'/pk_comments.php');
			require_once(PK_THEME_SHORTCODES.'/pk_dividers.php');
			require_once(PK_THEME_SHORTCODES.'/pk_dribbble.php');
			require_once(PK_THEME_SHORTCODES.'/pk_flickr.php');
			require_once(PK_THEME_SHORTCODES.'/pk_forms.php');
			require_once(PK_THEME_SHORTCODES.'/pk_google_maps.php');
			require_once(PK_THEME_SHORTCODES.'/pk_images.php');
			require_once(PK_THEME_SHORTCODES.'/pk_media.php');
			require_once(PK_THEME_SHORTCODES.'/pk_sliders.php');
			require_once(PK_THEME_SHORTCODES.'/pk_tables.php');
			require_once(PK_THEME_SHORTCODES.'/pk_tabs.php');
			require_once(PK_THEME_SHORTCODES.'/pk_toggles.php');
			require_once(PK_THEME_SHORTCODES.'/pk_twitter.php');
			require_once(PK_THEME_SHORTCODES.'/pk_typography.php');
			require_once(PK_THEME_SHORTCODES.'/pk_utility.php');
			require_once(PK_THEME_SHORTCODES.'/pk_works.php');
			
			require_once(PK_THEME_TYPES.'/pk_slides.php');
			require_once(PK_THEME_TYPES.'/pk_works.php');
			
			require_once(PK_THEME_WIDGETS.'/pk_widgets_overrides.php');
			require_once(PK_THEME_WIDGETS.'/pk_widgets_advertising_125_125.php');
			require_once(PK_THEME_WIDGETS.'/pk_widgets_advertising_300_250.php');
			require_once(PK_THEME_WIDGETS.'/pk_widgets_contact_form.php');
			require_once(PK_THEME_WIDGETS.'/pk_widgets_tabs.php');
			require_once(PK_THEME_WIDGETS.'/pk_widgets_toggles.php');
			require_once(PK_THEME_WIDGETS.'/pk_widgets_dribbble.php');
			require_once(PK_THEME_WIDGETS.'/pk_widgets_twitter.php');
			require_once(PK_THEME_WIDGETS.'/pk_widgets_twitter_boxed.php');
			require_once(PK_THEME_WIDGETS.'/pk_widgets_flickr.php');
			require_once(PK_THEME_WIDGETS.'/pk_widgets_google_maps.php');
			require_once(PK_THEME_WIDGETS.'/pk_widgets_taxonomies.php');
			require_once(PK_THEME_WIDGETS.'/pk_widgets_sub_navigation.php');
			require_once(PK_THEME_WIDGETS.'/pk_widgets_featured_posts.php');
			require_once(PK_THEME_WIDGETS.'/pk_widgets_featured_posts_boxed.php');
			require_once(PK_THEME_WIDGETS.'/pk_widgets_popular_posts.php');
			require_once(PK_THEME_WIDGETS.'/pk_widgets_popular_posts_boxed.php');
			require_once(PK_THEME_WIDGETS.'/pk_widgets_recent_posts.php');
			require_once(PK_THEME_WIDGETS.'/pk_widgets_recent_posts_boxed.php');
			require_once(PK_THEME_WIDGETS.'/pk_widgets_related_posts.php');
			require_once(PK_THEME_WIDGETS.'/pk_widgets_related_posts_boxed.php');
			require_once(PK_THEME_WIDGETS.'/pk_widgets_featured_works.php');
			require_once(PK_THEME_WIDGETS.'/pk_widgets_featured_works_boxed.php');
			require_once(PK_THEME_WIDGETS.'/pk_widgets_popular_works.php');
			require_once(PK_THEME_WIDGETS.'/pk_widgets_popular_works_boxed.php');
			require_once(PK_THEME_WIDGETS.'/pk_widgets_recent_works.php');
			require_once(PK_THEME_WIDGETS.'/pk_widgets_recent_works_boxed.php');
			require_once(PK_THEME_WIDGETS.'/pk_widgets_related_works.php');
			require_once(PK_THEME_WIDGETS.'/pk_widgets_related_works_boxed.php');
			require_once(PK_THEME_WIDGETS.'/pk_widgets_testimonials.php');
			
			add_action('after_setup_theme', array(&$this, 'pk_add_theme_support'));
			
			if (is_admin()) {
				
				require_once(PK_FUNCTIONS.'/pk_admin.php');
				
			}

		}
		
		function pk_add_theme_support() {
	
			if (function_exists('add_theme_support')) {
				
				add_custom_background();
				
				add_theme_support('automatic-feed-links');
				
				add_theme_support('post-thumbnails', array('page', 'post', 'news', 'services', 'slides', 'works'));
				
				add_theme_support('menus');
				
			}
			
			if (function_exists('register_nav_menu')) {
				
				register_nav_menu('pk_main_menu', __('Main Menu', 'pk_text_domain'));
				register_nav_menu('pk_footer_menu', __('Footer Menu', 'pk_text_domain'));
				
			}
	
		}
		
	}
	
}

if (class_exists('pk_theme') && !isset($pk_theme_instance)) {
	
	$pk_theme_instance = new pk_theme();
	
}

?>