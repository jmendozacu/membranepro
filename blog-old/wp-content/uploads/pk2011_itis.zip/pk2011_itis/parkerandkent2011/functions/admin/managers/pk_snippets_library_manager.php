<?php

global $pk_snippets_library_manager_instance;

if (!class_exists('pk_snippets_library_manager')) {
	
	class pk_snippets_library_manager extends pk_forms_manager {
		
		function pk_snippets_library_manager() {
			
		}
		
		function pk_open_table($id = '') {
			
			echo '
			<div class="pk_admin_padding_bottom_div"><table cellspacing="0" id="pk_sl_table_'.$id.'" class="widefat">
				<tbody>';
			
		}
		
		function pk_close_table() {
			
			echo '
				</tbody>
			</table></div>';
			
		}
		
		function pk_open_div() {
			
			echo '
	<!-- pk snippets library metabox - start -->
	<div class="pk_sl_snippets_library">';
			
		}
		
		function pk_close_div() {
			
			echo '
	</div>
	<!-- pk snippets library metabox - end -->

';
			
		}
		
		function pk_add_input_post($name = '', $value = '', $post_type = 'post', $helper = '') {
			
			$posts = get_posts(array('post_type' => trim($post_type), 'posts_per_page' => -1, 'orderby' => 'title', 'order' => 'ASC'));
			
			$values = array('');
			$labels = array(__('-- Select --', 'pk_text_domain'));
			
			foreach ($posts as $post) {
				
				array_push($values, $post -> ID);
				array_push($labels, $post -> post_title);
				
			}
			
			$this -> pk_add_input_select($name, false, $values, $labels, $value, $helper);
			
		}
		
		function pk_add_input_snippet_form($title = '', $text = '', $rows = '6', $helper = '') {
			
			echo '
						<td class="pk_admin_td">
							<p><input class="pk_admin_input_text_field pk_admin_snippet_title" type="text" value="'.$title.'" /></p>
							<p><textarea rows="'.$rows.'" cols="60" class="pk_admin_input_text_area pk_admin_snippet_content">'.$text.'</textarea></p>
							<p class="pk_admin_helper"><strong class="pk_admin_helper_strong">? </strong>'.$helper.'</p>
						</td>
					</tr>';
			
		}
		
		function pk_add_buttons() {
			
			echo '
			<div class="pk_admin_snippets_library_buttons_div">
				<input class="pk_admin_save_snippet_button button-primary" type="button" value="'.__('Save New', 'pk_text_domain').'" />
				<input class="pk_admin_update_snippet_button button-primary" type="button" value="'.__('Update', 'pk_text_domain').'" />
				<input class="pk_admin_delete_snippet_button button-primary" type="button" value="'.__('Delete', 'pk_text_domain').'" data-message="'.__('Are you sure you want to delete this snippet?', 'pk_text_domain').'" />
				<input class="pk_admin_send_snippet_button button" type="button" value="'.__('Send to Editor', 'pk_text_domain').'" />
			</div>';
			
		}
		
	}
	
}

if (class_exists('pk_snippets_library_manager') && !isset($pk_snippets_library_manager_instance)) {
	
	$pk_snippets_library_manager_instance = new pk_snippets_library_manager();
	
}

?>