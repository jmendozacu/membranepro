<?php

$pk_navigation_options = array();

$pk_navigation_options[0]['title'] = __('Main Navigation Options', 'pk_text_domain');
$pk_navigation_options[0]['options'] = array(
										
										'main_navigation_exclude_pages'		=> array('title' => __('Exclude pages:', 'pk_text_domain'), 'type' => 'pages', 'post_type' => 'page', 'helper' => __('Select one or more pages to exclude from the main menu. This selection will be used only in case you don\'t create a custom menu for the theme in the Appearance > Menus page.', 'pk_text_domain'))
										
										);
$pk_navigation_options[0]['values'] = array(
										
										'main_navigation_exclude_pages' 	=> ''
									
										);
$pk_navigation_options[0]['save_button'] = true;

$pk_navigation_options[1]['title'] = __('Footer Navigation Options', 'pk_text_domain');
$pk_navigation_options[1]['options'] = array(
										
										'footer_show_navigation' 			=> array('title' => __('Show navigation:', 'pk_text_domain'), 'type' => 'radio_group', 'values' => array('true', 'false'), 'labels' => array(__('Yes', 'pk_text_domain'), __('No', 'pk_text_domain')), 'helper' => __('Select <i>Yes</i> to add an additional navigation in the footer.', 'pk_text_domain')),
										'footer_navigation_separator' 		=> array('title' => __('Navigation separator:', 'pk_text_domain'), 'type' => 'text', 'helper' => __('Type the separator to use for the footer navigation links.', 'pk_text_domain')),
										'footer_navigation_exclude_pages'	=> array('title' => __('Exclude pages:', 'pk_text_domain'), 'type' => 'pages', 'post_type' => 'page', 'helper' => __('Select one or more pages to exclude from the footer navigation. This selection will be used only in case you don\'t create a custom menu for the theme footer in the Appearance > Menus page.', 'pk_text_domain'))
										
										);
$pk_navigation_options[1]['values'] = array(
										
										'footer_show_navigation' 			=> 'true',
										'footer_navigation_separator' 		=> '|',
										'footer_navigation_exclude_pages' 	=> ''
									
										);
$pk_navigation_options[1]['save_button'] = true;

if (class_exists('pk_options_generator') && !isset($pk_navigation_options_instance)) {
	
	add_option('pk_navigation_options_profiles', array('default'));
	add_option('pk_navigation_options_current_profile', 'default');
	add_option('pk_navigation_options_active_profile', 'default');
	
	$pk_navigation_options_instance = new pk_options_generator($pk_navigation_options, 'level_10', __('Navigation Options', 'pk_text_domain'), 'pk_general_options', 'pk_navigation_options', 'pk_navigation_options', 'pk_', array('pk_navigation_options_profiles', 'pk_navigation_options_current_profile', 'pk_navigation_options_active_profile', 'pk_navigation_options'));
	
	/*global $pk_dashboard_options;
	
	$pk_profiles = get_option('pk_navigation_options_profiles');
	
	foreach ($pk_profiles as $k => $v) {
	
		$pk_dashboard_options['pk_navigation_options_'.$v] = sprintf(__('Navigation Options - %s', 'pk_text_domain'), (($v == 'default') ? __('Default', 'pk_text_domain') : stripslashes(base64_decode($v))));
	
	}*/
	
}

?>