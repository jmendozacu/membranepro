<?php

global $pk_forms_manager_instance;

if (!class_exists('pk_forms_manager')) {
	
	class pk_forms_manager {
		
		function pk_forms_manager() {
			
		}
		
		function pk_add_title($title = '', $color = true, $special_color = false) {
			
			$class = ($color == true) ? 'pk_admin_tr_color' : 'pk_admin_tr';
			$class = ($special_color == true) ? 'pk_admin_tr_special' : $class;
			
			echo '
					<tr class="'.$class.'">
						<th scope="row" class="pk_admin_th">
							<h4>'.$title.'</h4>
						</th>';
			
		}
		
		function pk_add_input_footer_layout_manager($name = '', $value = '', $helper = '') {
			
			$columns_values = array('0', '1_1', '1_2', '1_3', '1_4', '1_5', '1_6', '2_3', '3_4', '2_5', '3_5', '4_5', '5_6');
			$columns_labels = array(__('-- Select --', 'pk_text_domain'), 'Column Full Width', 'Column 1/2', 'Column 1/3', 'Column 1/4', 'Column 1/5', 'Column 1/6', 'Column 2/3', 'Column 3/4', 'Column 2/5', 'Column 3/5', 'Column 4/5', 'Column 5/6');
			
			echo '
						<td class="pk_admin_td">
							<div class="pk_admin_footer_layout_manager">
								<p>
									<input class="pk_admin_footer_layout_value" type="hidden" name="'.$name.'" value="'.$value.'" />
									<select class="pk_admin_input_footer_layout_select pk_admin_input_select">';
			
			for ($i = 0; $i < count($columns_values); $i++) {
				
				echo '
										<option value="'.$columns_values[$i].'">'.$columns_labels[$i].'</option>';
				
			}
			
			echo '
									</select>
									<input class="pk_admin_add_footer_layout_column_button pk_admin_button button" type="button" value="'.__('Add', 'pk_text_domain').'" data-error="'.__('The selected column is too wide for the remaining space!', 'pk_text_domain').'" />
								</p>
								<div class="pk_admin_footer_layout_columns"><ul id="pk_admin_footer_layout_columns_list_'.$name.'" class="pk_admin_footer_layout_columns_list"></ul></div>
							</div>
							<p class="pk_admin_helper"><strong class="pk_admin_helper_strong">? </strong>'.$helper.'</p>
						</td>
					</tr>';
			
		}
		
		function pk_add_input_footer_social_networks_manager($name = '', $value = '', $helper = '') {
			
			$social_networks_labels = array('AIM','Apple','Bebo','Blogger','Brightkite','Cargo','Delicious','DesignFloat','Designmoo','DeviantART','Digg','Dopplr','Dribbble','Email','Ember','Evernote','Facebook','Flickr','Forrst','FriendFeed','GameSpot','Google','GoogleTalk','GoogleVoice','GoogleWave','GoogleTalk','Gowalla','Grooveshark','iLike','KomodoMedia','LastFm','LinkedIn','Mixx','MobileMe','MyNameIsE','MySpace','Netvibes','Newsvine','OpenID','Orkut','Pandora','Paypal','Picasa','Playstation','Plurk','Posterous','Qik','Readernaut','Reddit','Roboto','RSS','ShareThis','Skype','StumbleUpon','Technorati','Tumblr','Twitter','Viddler','Vimeo','Virb','Windows','Wordpress','Xing','Yahoo','YahooBuzz','Yelp','YouTube','Zootool');
			
			$social_networks = array();
			
			for ($i = 0; $i < count($social_networks_labels); $i++) {
				
				$social_networks[$i]['icon_url'] = PK_THEME_DIR.'/parkerandkent2011/images/theme/social_networks_icons/'.strtolower($social_networks_labels[$i]).'_16.png';
				$social_networks[$i]['label'] = $social_networks_labels[$i];
				
			}
			
			echo '
						<td class="pk_admin_td">
							<div class="pk_admin_footer_social_networks_manager">
								<p>
									<input class="pk_admin_footer_social_networks_value" type="hidden" name="'.$name.'" value="'.$value.'" />
									<select class="pk_admin_footer_social_networks_select pk_admin_input_select">
										<option value="select">'.__('-- Select --', 'pk_text_domain').'</option>';
				
			foreach ($social_networks as $social_network) {
					
				echo '
										<option value="'.$social_network['icon_url'].'">'.$social_network['label'].'</option>';
					
			}
				
			echo '
									</select>
									<input class="pk_admin_add_footer_social_network_button pk_admin_button button" type="button" value="'.__('Add', 'pk_text_domain').'" />
								</p>
								<div class="pk_admin_footer_social_networks"><ul id="pk_admin_footer_social_networks_list_'.$name.'" class="pk_admin_footer_social_networks_list"></ul></div>
							</div>
							<p class="pk_admin_helper"><strong class="pk_admin_helper_strong">? </strong>'.$helper.'</p>
						</td>
					</tr>';
			
		}
		
		function pk_add_input_lightbox_gallery_manager($name = '', $value = '', $helper = '') {
			
			global $post;
			
			(isset($post)) ? $post_id = $post -> ID : $post_id = '';
			
			echo '
						<td class="pk_admin_td">
							<div class="pk_admin_lightbox_gallery_manager">
								<input class="pk_admin_lightbox_gallery_value" type="hidden" name="'.$name.'" value="'.$value.'" />
								<div class="pk_admin_slider_div">
									<p><label for="pk_admin_lightbox_gallery_items_width_'.$name.'">'.__('Gallery items min width:', 'pk_text_domain').'</label></p>
									<p><input id="pk_admin_lightbox_gallery_items_width_'.$name.'" class="pk_admin_input_slider" name="pk_admin_lightbox_gallery_items_width_'.$name.'" type="text" value="1280" min="0" max="1920" /> px</p>
								</div>
								<div class="pk_admin_slider_div">
									<p><label for="pk_admin_lightbox_gallery_items_height_'.$name.'">'.__('Gallery items min height:', 'pk_text_domain').'</label></p>
									<p><input id="pk_admin_lightbox_gallery_items_height_'.$name.'" class="pk_admin_input_slider" name="pk_admin_lightbox_gallery_items_height_'.$name.'" type="text" value="720" min="0" max="1080" /> px</p>
								</div>
								<p>Slideshow auto start:</p>
								<p>
									<input id="pk_admin_lightbox_gallery_yes_'.$name.'" class="pk_admin_radio_checkbox" type="radio" name="pk_admin_lightbox_gallery_slideshow_'.$name.'" value="true" checked="checked" />
									<label for="pk_admin_lightbox_gallery_yes_'.$name.'" class="pk_admin_radio_label"> '.__('Yes', 'pk_text_domain').'</label>
								</p>
								<p>
									<input id="pk_admin_lightbox_gallery_no_'.$name.'" class="pk_admin_radio_checkbox" type="radio" name="pk_admin_lightbox_gallery_slideshow_'.$name.'" value="false" />
									<label for="pk_admin_lightbox_gallery_no_'.$name.'" class="pk_admin_radio_label"> '.__('No', 'pk_text_domain').'</label>
								</p>
								<div class="pk_admin_slider_div">
									<p><label for="pk_admin_lightbox_gallery_slideshow_interval_'.$name.'">'.__('Slideshow interval:', 'pk_text_domain').'</label></p>
									<p><input id="pk_admin_lightbox_gallery_slideshow_interval_'.$name.'" class="pk_admin_input_slider" name="pk_admin_lightbox_gallery_slideshow_interval_'.$name.'" type="text" value="5" min="1" max="10" /> '.__('seconds', 'pk_text_domain').'</p>
								</div>
								<p><label for="pk_admin_lightbox_gallery_id_'.$name.'">'.__('Gallery id:', 'pk_text_domain').'</label></p>
								<p>
									<input id="pk_admin_lightbox_gallery_id_'.$name.'" class="pk_admin_input_text_field" name="pk_admin_lightbox_gallery_id_'.$name.'" type="text" value="'.$post_id.'" />
									<input class="pk_admin_add_lightbox_gallery_item_button pk_admin_button button" type="button" value="'.__('Add Item', 'pk_text_domain').'" />
								</p>
								<div class="pk_admin_lightbox_gallery"><ul id="pk_admin_lightbox_gallery_list_'.$name.'" class="pk_admin_lightbox_gallery_list" data-title-label="'.__('Title', 'pk_text_domain').'" data-url-label="'.__('URL', 'pk_text_domain').'"></ul></div>
							</div>
							<p class="pk_admin_helper"><strong class="pk_admin_helper_strong">? </strong>'.$helper.'</p>
						</td>
					</tr>';
			
		}
		
		function pk_add_input_skin_select($name = '', $select_box = false, $values = array(), $labels = array(), $selected = '', $helper = '') {
			
			($select_box == true) ? $class = 'pk_admin_input_select_box' : $class = 'pk_admin_input_select';
			
			echo '
						<td class="pk_admin_td">
							<p>
								<select class="'.$class.'" name="'.$name.'">';
			
			for ($i = 0; $i < count($values); $i++) {
				
				if ($values[$i] == $selected) {
					
					$selected_string = ' selected="selected"';
					
				} else {
					
					$selected_string = '';
					
				}
				
				echo '
									<option value="'.$values[$i].'"'.$selected_string.'>'.$labels[$i].'</option>';
				
			}
			
			echo '
								</select>
							</p>
							<p>';
			
			for ($i = 0; $i < count($values); $i++) {
				
				echo '
								<img src="'.PK_THEME_DIR.'/parkerandkent2011/images/admin/screenshots/'.str_replace('css', 'jpg', $values[$i]).'" alt="'.str_replace('.', '_', $values[$i]).'" class="'.str_replace('.', '_', $values[$i]).'" style="border:solid 1px; border-color:#dddddd"/>';
				
			}
			
			echo '
							</p>
							<p class="pk_admin_helper"><strong class="pk_admin_helper_strong">? </strong>'.$helper.'</p>
						</td>
					</tr>';
			
		}
		
		function pk_add_input_text_field($name = '', $value = '', $helper = '') {
			
			echo '
						<td class="pk_admin_td">
							<p><input class="pk_admin_input_text_field" type="text" name="'.$name.'" value="'.$value.'" /></p>
							<p class="pk_admin_helper"><strong class="pk_admin_helper_strong">? </strong>'.$helper.'</p>
						</td>
					</tr>';
			
		}
		
		function pk_add_input_text_area($name = '', $value = '', $rows = '6', $helper = '') {
			
			echo '
						<td class="pk_admin_td">
							<p><textarea rows="'.$rows.'" cols="60" class="pk_admin_input_text_area" name="'.$name.'">'.$value.'</textarea></p>
							<p class="pk_admin_helper"><strong class="pk_admin_helper_strong">? </strong>'.$helper.'</p>
						</td>
					</tr>';
			
		}
		
		function pk_add_input_radio_group($name = '', $values = array(), $labels = array(), $checked = '', $helper = '') {
			
			echo '
						<td class="pk_admin_td">';
			
			for ($i = 0; $i < count($values); $i++) {
				
				if ($values[$i] == $checked) {
					
					$checked_string = ' checked="checked"';
					
				} else {
					
					$checked_string = '';
					
				}
				
				echo '
							<p><input id="'.$name.'_'.$i.'" class="pk_admin_radio_checkbox" type="radio" name="'.$name.'" value="'.$values[$i].'"'.$checked_string.' /><label for="'.$name.'_'.$i.'" class="pk_admin_radio_label"> '.$labels[$i].'</label></p>';
				
			}
			
			echo '
							<p class="pk_admin_helper"><strong class="pk_admin_helper_strong">? </strong>'.$helper.'</p>
						</td>
					</tr>';
			
		}
		
		function pk_add_input_select($name = '', $select_box = false, $values = array(), $labels = array(), $selected = '', $helper = '') {
			
			($select_box == true) ? $class = 'pk_admin_input_select_box' : $class = 'pk_admin_input_select';
			
			echo '
						<td class="pk_admin_td">
							<p>
								<select class="'.$class.'" name="'.$name.'">';
			
			for ($i = 0; $i < count($values); $i++) {
				
				if ($values[$i] == $selected) {
					
					$selected_string = ' selected="selected"';
					
				} else {
					
					$selected_string = '';
					
				}
				
				echo '
									<option value="'.$values[$i].'"'.$selected_string.'>'.$labels[$i].'</option>';
				
			}
			
			echo '
								</select>
							</p>
							<p class="pk_admin_helper"><strong class="pk_admin_helper_strong">? </strong>'.$helper.'</p>
						</td>
					</tr>';
			
		}
		
		function pk_add_input_color($name = '', $value = '', $helper = '') {
			
			echo '
						<td class="pk_admin_td">
							<p><input class="pk_admin_input_color color {hash:true, caps:false, pickerPosition:\'right\', pickerMode:\'HSV\', pickerFace:15, pickerFaceColor:\'#eeeeee\', pickerBorderColor:\'#d6d6d6\', pickerInsetColor:\'#f3f3f3\'}" type="text" name="'.$name.'" value="'.$value.'" /></p>
							<p class="pk_admin_helper"><strong class="pk_admin_helper_strong">? </strong>'.$helper.'</p>
						</td>
					</tr>';
			
		}
		
		function pk_add_input_slider($name = '', $value = '0', $min = '0', $max = '100', $uom = 'px', $helper = '') {
			
			echo '
						<td class="pk_admin_td">
							<div class="pk_admin_slider_div">
								<p><input class="pk_admin_input_slider" type="text" name="'.$name.'" value="'.$value.'" min="'.$min.'" max="'.$max.'"'.(($max == 1) ? ' step="0.01"' : '').' /> '.$uom.'</p>
							</div>
							<p class="pk_admin_helper"><strong class="pk_admin_helper_strong">? </strong>'.$helper.'</p>
						</td>
					</tr>';
			
		}
		
		function pk_add_input_file($name = '', $value = '', $type = 'file', $preview = 'true', $helper = '') {
			
			global $post;
			
			(isset($post)) ? $post_id = $post -> ID : $post_id = '';
			
			$item_preview = '';
			
			if ($preview == 'true' && $value != '') { $item_preview = ''; }
			
			echo '
						<td class="pk_admin_td">';
			
			switch ($type) {
			
				case 'audio':
				
					$array = explode(',', $value);
					
					echo '
							<input id="'.$name.'" class="pk_audio_field" type="hidden" name="'.$name.'" value="'.$value.'" />
							<p>
								<input data-main="'.$name.'" data-post_id="'.$post_id.'" data-media="'.$type.'" id="'.$name.'_cover_field" class="pk_admin_upload_cover_field" type="text" name="'.$name.'_cover" value="'.((isset($array[0])) ? $array[0] : '').'" />
								<input data-main="'.$name.'" data-post_id="'.$post_id.'" data-media="image" data-main-media="'.$type.'" id="'.$name.'_cover" class="pk_admin_upload_file_button pk_admin_button button" type="button" value="'.__('Cover', 'pk_text_domain').'" />
							</p>
							<p>
								<input data-main="'.$name.'" data-post_id="'.$post_id.'" data-media="'.$type.'" id="'.$name.'_file_field" class="pk_admin_upload_file_field" type="text" name="'.$name.'_file" value="'.((isset($array[1])) ? $array[1] : '').'" />
								<input data-main="'.$name.'" data-post_id="'.$post_id.'" data-media="'.$type.'" id="'.$name.'_file" class="pk_admin_upload_file_button pk_admin_button button" type="button" value="'.__(ucfirst($type), 'pk_text_domain').'" />
							</p>
							<p class="pk_admin_helper"><strong class="pk_admin_helper_strong">? </strong>'.$helper.'</p>';
					
					break;
					
				case 'video':
					
					$array = explode(',', $value);
					$labels = array(__('-- Select --', 'pk_text_domain'), 'Html5 Player (mp4, webm, ogg)', 'Flash Player (flv, mov, mp4, m4a, f4v, mp4v, 3gp, 3g2)', 'YouTube', 'Vimeo');
					
					echo '
							<input id="'.$name.'" class="pk_video_field" type="hidden" name="'.$name.'" value="'.$value.'" />
							<p>
								<select data-main="'.$name.'" data-media="'.$type.'" id="'.$name.'_select_video" class="pk_admin_input_select_video">';
					
					for ($i = 0; $i < count($labels); $i++) {
				
						if ($i == ((isset($array[0])) ? (int)$array[0] : 0)) {
					
							$selected_string = ' selected="selected"';
					
						} else {
					
							$selected_string = '';
					
						}
				
						echo '
									<option value="'.$i.'"'.$selected_string.'>'.$labels[$i].'</option>';
						
					}
					
					echo '
								</select>
							</p>
							<p>
								<input data-main="'.$name.'" data-post_id="'.$post_id.'" data-media="'.$type.'" id="'.$name.'_cover_field" class="pk_admin_upload_cover_field '.$name.'_vt_1 '.$name.'_vt_2 '.$name.'_vt_3 '.$name.'_vt_4" type="text" value="'.((isset($array[1])) ? $array[1] : '').'" />
								<input data-main="'.$name.'" data-post_id="'.$post_id.'" data-media="image" data-main-media="'.$type.'" id="'.$name.'_cover" class="pk_admin_upload_file_button pk_admin_button button '.$name.'_vt_1 '.$name.'_vt_2 '.$name.'_vt_3 '.$name.'_vt_4" type="button" value="'.__('Cover', 'pk_text_domain').'" />
							</p>
							<p>
								<label for="'.$name.'_file_field" class="pk_admin_video_id_label '.$name.'_vt_3 '.$name.'_vt_4">'.__('Video ID:', 'pk_text_domain').'</label>
							</p>
							<p>
								<input data-main="'.$name.'" data-post_id="'.$post_id.'" data-media="'.$type.'" id="'.$name.'_file_field" class="pk_admin_upload_file_field '.$name.'_vt_2 '.$name.'_vt_3 '.$name.'_vt_4" type="text" value="'.((isset($array[2])) ? $array[2] : '').'" />
								<input data-main="'.$name.'" data-post_id="'.$post_id.'" data-media="'.$type.'" id="'.$name.'_file" class="pk_admin_upload_file_button pk_admin_button button '.$name.'_vt_2" type="button" value="'.__(ucfirst($type), 'pk_text_domain').'" />
							</p>
							<p>
								<input data-main="'.$name.'" data-post_id="'.$post_id.'" data-media="'.$type.'" id="'.$name.'_mp4_field" class="pk_admin_upload_file_field '.$name.'_vt_1" type="text" value="'.((isset($array[2])) ? $array[2] : '').'" />
								<input data-main="'.$name.'" data-post_id="'.$post_id.'" data-media="'.$type.'" id="'.$name.'_mp4" class="pk_admin_upload_file_button pk_admin_button button '.$name.'_vt_1" type="button" value="Mp4" />
							</p>
							<p>
								<input data-main="'.$name.'" data-post_id="'.$post_id.'" data-media="'.$type.'" id="'.$name.'_webm_field" class="pk_admin_upload_file_field '.$name.'_vt_1" type="text" value="'.((isset($array[3])) ? $array[3] : '').'" />
								<input data-main="'.$name.'" data-post_id="'.$post_id.'" data-media="'.$type.'" id="'.$name.'_webm" class="pk_admin_upload_file_button pk_admin_button button '.$name.'_vt_1" type="button" value="WebM" />
							</p>
							<p>
								<input data-main="'.$name.'" data-post_id="'.$post_id.'" data-media="'.$type.'" id="'.$name.'_ogg_field" class="pk_admin_upload_file_field '.$name.'_vt_1" type="text" value="'.((isset($array[4])) ? $array[4] : '').'" />
								<input data-main="'.$name.'" data-post_id="'.$post_id.'" data-media="'.$type.'" id="'.$name.'_ogg" class="pk_admin_upload_file_button pk_admin_button button '.$name.'_vt_1" type="button" value="Ogg" />
							</p>
							<p class="pk_admin_helper '.$name.'_vt_0"><strong class="pk_admin_helper_strong">? </strong>'.$helper.'</p>
							<p class="pk_admin_helper '.$name.'_vt_1"><strong class="pk_admin_helper_strong">? </strong>'.__('Type in the cover and the video URLs or click on the buttons to select them from the media library.', 'pk_text_domain').'</p>
							<p class="pk_admin_helper '.$name.'_vt_2"><strong class="pk_admin_helper_strong">? </strong>'.__('Type in the cover and the video URL or click on the buttons to select them from the media library.', 'pk_text_domain').'</p>
							<p class="pk_admin_helper '.$name.'_vt_3"><strong class="pk_admin_helper_strong">? </strong>'.__('Type in the cover URL and the Video ID', 'pk_text_domain').' (http://www.youtube.com/watch?v=<strong class="pk_admin_helper_strong">wwO-wo892pI</strong>&amp;hd=1)</p>
							<p class="pk_admin_helper '.$name.'_vt_4"><strong class="pk_admin_helper_strong">? </strong>'.__('Type in the cover URL and the Video ID', 'pk_text_domain').' (http://www.vimeo.com/<strong class="pk_admin_helper_strong">2847753</strong>)</p>';
					
					break;
					
				case 'file':
				case 'image':
				
					echo '
							<p>
								<input data-post_id="'.$post_id.'" data-media="'.$type.'" id="'.$name.'_file_field" class="pk_admin_upload_file_field" type="text" name="'.$name.'" value="'.$value.'" />
								<input data-post_id="'.$post_id.'" data-media="'.$type.'" data-main-media="'.$type.'" id="'.$name.'_file" class="pk_admin_upload_file_button pk_admin_button button" type="button" value="'.ucfirst($type).'" />
							</p>
							<p class="pk_admin_helper"><strong class="pk_admin_helper_strong">? </strong>'.$helper.'</p>';
					
					break;
					
			}
			
			echo '
						</td>
					</tr>';
			
		}
		
		function pk_add_input_category($name = '', $value = '', $taxonomy = 'category', $helper = '') {
			
			$categories = get_categories(array('hide_empty' => 1, 'hierarchical' => false, 'taxonomy' => trim($taxonomy)));
			
			if (!$categories) {
				
				echo '
						<td class="pk_admin_td">
							<p><strong>'.__('No categories available', 'pk_text_domain').'</strong></p>
							<p class="pk_admin_helper"><strong class="pk_admin_helper_strong">? </strong>'.$helper.'</p>
						</td>
					</tr>';
				
				return;
				
			}
			
			$values = array('');
			$labels = array(__('-- Select --', 'pk_text_domain'));
					
			foreach ($categories as $category) {
				
				array_push($values, $category -> term_id);
				array_push($labels, $category -> name);
				
			}
			
			$this -> pk_add_input_select($name, false, $values, $labels, $value, $helper);
			
		}
		
		function pk_add_input_categories($name = '', $value = '', $taxonomy = 'category', $helper = '') {
			
			$categories = get_categories(array('hide_empty' => 1, 'hierarchical' => false, 'taxonomy' => trim($taxonomy)));
			
			if (!$categories) {
				
				echo '
						<td class="pk_admin_td">
							<p><strong>'.__('No categories available', 'pk_text_domain').'</strong></p>
							<p class="pk_admin_helper"><strong class="pk_admin_helper_strong">? </strong>'.$helper.'</p>
						</td>
					</tr>';
				
				return;
				
			}
			
			$selected_categories = explode(',', $value);
			
			$total = count($categories);
			
			if ($total <= 12) {
					
				echo '
						<td class="pk_admin_td">
							<input class="pk_admin_multiple_field" type="hidden" name="'.$name.'" value="'.$value.'" />
							<div class="pk_admin_multiple_checkbox_div_wrapper">';
				
				$checkboxes_count = 0;
				
				foreach ($categories as $category) {
					
					$checked = '';
					
					if (in_array($category -> term_id, $selected_categories)) {
					
						$checked = ' checked="checked"';
					
					}
					
					echo '
								<div class="pk_admin_multiple_checkbox_div"><input data-main="'.$name.'" id="'.$name.'_checkbox_'.$checkboxes_count.'" class="pk_admin_multiple_checkbox pk_admin_radio_checkbox" type="checkbox" value="'.$category -> term_id.'"'.$checked.' /><label for="'.$name.'_checkbox_'.$checkboxes_count.'" class="pk_admin_multiple_checkbox_label">'.$category -> name.'</label></div>';
					
					$checkboxes_count++;
					
				}
				
				echo '
							</div>
							<p class="pk_admin_helper"><strong class="pk_admin_helper_strong">? </strong>'.$helper.'</p>
						</td>
					</tr>';
				
			} else {
				
				echo '
						<td class="pk_admin_td">
							<input class="pk_admin_multiple_field" type="hidden" name="'.$name.'" value="'.$value.'" />
							<select data-main="'.$name.'" class="pk_admin_input_select_multiple" multiple="multiple">';
				
				foreach ($categories as $category) {
					
					if (in_array($category -> term_id, $selected_categories)) {
					
						$selected_string = ' selected="selected"';
					
					} else {
					
						$selected_string = '';
					
					}
					
					echo '
									<option value="'.$category -> term_id.'"'.$selected_string.'>'.$category -> name.' ('.$category -> category_count.')</option>';
					
				}
				
				echo '
							</select>
							<p class="pk_admin_helper"><strong class="pk_admin_helper_strong">? </strong>'.$helper.'</p>
						</td>
					</tr>';
				
			}
			
		}
		
		function pk_add_input_page($name = '', $value = '', $post_type = 'page', $helper = '') {
			
			$pages = get_pages(array('hierarchical' => false, 'post_type' => trim($post_type)));
			
			if (!$pages) {
				
				echo '
						<td class="pk_admin_td">
							<p><strong>'.__('No pages available', 'pk_text_domain').'</strong></p>
							<p class="pk_admin_helper"><strong class="pk_admin_helper_strong">? </strong>'.$helper.'</p>
						</td>
					</tr>';
				
				return;
				
			}
			
			$values = array('');
			$labels = array(__('-- Select --', 'pk_text_domain'));
			
			foreach ($pages as $page) {
				
				array_push($values, $page -> ID);
				array_push($labels, $page -> post_title);
				
			}
			
			$this -> pk_add_input_select($name, false, $values, $labels, $value, $helper);
			
		}
		
		function pk_add_input_pages($name = '', $value = '', $post_type = 'page', $helper = '') {
			
			$pages = get_pages(array('hierarchical' => false, 'post_type' => trim($post_type)));
			
			if (!$pages) {
				
				echo '
						<td class="pk_admin_td">
							<p><strong>'.__('No pages available', 'pk_text_domain').'</strong></p>
							<p class="pk_admin_helper"><strong class="pk_admin_helper_strong">? </strong>'.$helper.'</p>
						</td>
					</tr>';
				
				return;
				
			}
			
			$selected_pages = explode(',', $value);
			
			$total = count($pages);
			
			if ($total <= 12) {
				
				echo '
						<td class="pk_admin_td">
							<input class="pk_admin_multiple_field" type="hidden" name="'.$name.'" value="'.$value.'" />
							<div class="pk_admin_multiple_checkbox_div_wrapper">';
				
				$checkboxes_count = 0;
				
				foreach ($pages as $page) {
					
					$checked = '';
					
					if (in_array($page -> ID, $selected_pages)) {
						
						$checked = ' checked="checked"';
						
					}
					
					echo '
								<div class="pk_admin_multiple_checkbox_div"><input data-main="'.$name.'" id="'.$name.'_checkbox_'.$checkboxes_count.'" class="pk_admin_multiple_checkbox pk_admin_radio_checkbox" type="checkbox" value="'.$page -> ID.'"'.$checked.' /><label for="'.$name.'_checkbox_'.$checkboxes_count.'" class="pk_admin_multiple_checkbox_label">'.$page -> post_title.'</label></div>';
					
					$checkboxes_count++;
					
				}
				
				echo '
							</div>
							<p class="pk_admin_helper"><strong class="pk_admin_helper_strong">? </strong>'.$helper.'</p>
						</td>
					</tr>';
				
			} else {
				
				echo '
						<td class="pk_admin_td">
							<input class="pk_admin_multiple_field" type="hidden" name="'.$name.'" value="'.$value.'" />
							<select data-main="'.$name.'" class="pk_admin_input_select_multiple" multiple="multiple">';
				
				foreach ($pages as $page) {
					
					if (in_array($page -> ID, $selected_pages)) {
						
						$selected_string = ' selected="selected"';
						
					} else {
						
						$selected_string = '';
						
					}
					
					echo '
									<option value="'.$page -> ID.'"'.$selected_string.'>'.$page -> post_title.'</option>';
					
				}
				
				echo '
							</select>
							<p class="pk_admin_helper"><strong class="pk_admin_helper_strong">? </strong>'.$helper.'</p>
						</td>
					</tr>';
				
			}
			
		}
		
		function pk_add_input_post($name = '', $value = '', $post_type = 'post', $helper = '') {
			
			$posts = get_posts(array('post_type' => trim($post_type), 'posts_per_page' => -1, 'orderby' => 'title', 'order' => 'ASC'));
			
			if (!$posts) {
				
				echo '
						<td class="pk_admin_td">
							<p><strong>'.__('No posts available', 'pk_text_domain').'</strong></p>
							<p class="pk_admin_helper"><strong class="pk_admin_helper_strong">? </strong>'.$helper.'</p>
						</td>
					</tr>';
				
				return;
				
			}
			
			$values = array('');
			$labels = array(__('-- Select --', 'pk_text_domain'));
			
			foreach ($posts as $post) {
				
				array_push($values, $post -> ID);
				array_push($labels, $post -> post_title);
				
			}
			
			$this -> pk_add_input_select($name, false, $values, $labels, $value, $helper);
			
		}
		
		function pk_add_input_posts($name = '', $value = '', $post_type = 'post', $helper = '') {
			
			$posts = get_posts(array('post_type' => trim($post_type), 'posts_per_page' => -1, 'orderby' => 'title', 'order' => 'ASC'));
			
			if (!$posts) {
				
				echo '
						<td class="pk_admin_td">
							<p><strong>'.__('No posts available', 'pk_text_domain').'</strong></p>
							<p class="pk_admin_helper"><strong class="pk_admin_helper_strong">? </strong>'.$helper.'</p>
						</td>
					</tr>';
				
				return;
				
			}
			
			$selected_posts = explode(',', $value);
			
			$total = count($posts);
			
			if ($total <= 12) {
				
				echo '
						<td class="pk_admin_td">
							<input class="pk_admin_multiple_field" type="hidden" name="'.$name.'" value="'.$value.'" />
							<div class="pk_admin_multiple_checkbox_div_wrapper">';
				
				$checkboxes_count = 0;
				
				foreach ($posts as $post) {
					
					$checked = '';
					
					if (in_array($post -> ID, $selected_posts)) {
						
						$checked = ' checked="checked"';
						
					}
					
					echo '
								<div class="pk_admin_multiple_checkbox_div"><input data-main="'.$name.'" id="'.$name.'_checkbox_'.$checkboxes_count.'" class="pk_admin_multiple_checkbox pk_admin_radio_checkbox" type="checkbox" value="'.$post -> ID.'"'.$checked.' /><label for="'.$name.'_checkbox_'.$checkboxes_count.'" class="pk_admin_multiple_checkbox_label">'.$post -> post_title.'</label></div>';
					
					$checkboxes_count++;
					
				}
				
				echo '
							</div>
							<p class="pk_admin_helper"><strong class="pk_admin_helper_strong">? </strong>'.$helper.'</p>
						</td>
					</tr>';
				
			} else {
				
				echo '
						<td class="pk_admin_td">
							<input class="pk_admin_multiple_field" type="hidden" name="'.$name.'" value="'.$value.'" />
							<select data-main="'.$name.'" class="pk_admin_input_select_multiple" multiple="multiple">';
				
				foreach ($posts as $post) {
					
					if (in_array($post -> ID, $selected_posts)) {
						
						$selected_string = ' selected="selected"';
						
					} else {
						
						$selected_string = '';
						
					}
					
					echo '
									<option value="'.$post -> ID.'"'.$selected_string.'>'.$post -> post_title.'</option>';
					
				}
				
				echo '
							</select>
							<p class="pk_admin_helper"><strong class="pk_admin_helper_strong">? </strong>'.$helper.'</p>
						</td>
					</tr>';
				
			}
			
		}
		
		function pk_add_input_tag($name = '', $value = '', $helper = '') {
			
			$tags = get_tags(array('hide_empty' => false));
			
			if (!$tags) {
				
				echo '
						<td class="pk_admin_td">
							<p><strong>'.__('No tags available', 'pk_text_domain').'</strong></p>
							<p class="pk_admin_helper"><strong class="pk_admin_helper_strong">? </strong>'.$helper.'</p>
						</td>
					</tr>';
				
				return;
				
			}
			
			$values = array('');
			$labels = array(__('-- Select --', 'pk_text_domain'));
			
			foreach ($tags as $tag) {
				
				array_push($values, $tag -> term_id);
				array_push($labels, $tag -> name);
				
			}
			
			$this -> pk_add_input_select($name, false, $values, $labels, $value, $helper);
			
		}
		
		function pk_add_input_tags($name = '', $value = '', $helper = '') {
			
			$tags = get_tags(array('hide_empty' => false));
			
			if (!$tags) {
				
				echo '
						<td class="pk_admin_td">
							<p><strong>'.__('No tags available', 'pk_text_domain').'</strong></p>
							<p class="pk_admin_helper"><strong class="pk_admin_helper_strong">? </strong>'.$helper.'</p>
						</td>
					</tr>';
				
				return;
				
			}
			
			$selected_tags = explode(',', $value);
			
			$total = count($tags);
			
			if ($total <= 12) {
				
				echo '
						<td class="pk_admin_td">
							<input class="pk_admin_multiple_field" type="hidden" name="'.$name.'" value="'.$value.'" />
							<div class="pk_admin_multiple_checkbox_div_wrapper">';
				
				$checkboxes_count = 0;
				
				foreach ($tags as $tag) {
					
					$checked = '';
					
					if (in_array($tag -> term_id, $selected_tags)) {
						
						$checked = ' checked="checked"';
						
					}
					
					echo '
								<div class="pk_admin_multiple_checkbox_div"><input data-main="'.$name.'" id="'.$name.'_checkbox_'.$checkboxes_count.'" class="pk_admin_multiple_checkbox pk_admin_radio_checkbox" type="checkbox" value="'.$tag -> term_id.'"'.$checked.' /><label for="'.$name.'_checkbox_'.$checkboxes_count.'" class="pk_admin_multiple_checkbox_label">'.$tag -> name.'</label></div>';
					
					$checkboxes_count++;
					
				}
				
				echo '
							</div>
							<p class="pk_admin_helper"><strong class="pk_admin_helper_strong">? </strong>'.$helper.'</p>
						</td>
					</tr>';
				
			} else {
				
				echo '
						<td class="pk_admin_td">
							<input class="pk_admin_multiple_field" type="hidden" name="'.$name.'" value="'.$value.'" />
							<select data-main="'.$name.'" class="pk_admin_input_select_multiple" multiple="multiple">';
				
				foreach ($tags as $tag) {
					
					if (in_array($tag -> term_id, $selected_tags)) {
						
						$selected_string = ' selected="selected"';
						
					} else {
						
						$selected_string = '';
						
					}
					
					echo '
									<option value="'.$tag -> term_id.'"'.$selected_string.'>'.$tag -> name.'</option>';
					
				}
				
				echo '
							</select>
							<p class="pk_admin_helper"><strong class="pk_admin_helper_strong">? </strong>'.$helper.'</p>
						</td>
					</tr>';
				
			}
			
		}
		
		function pk_add_save_changes($title = '', $add = true) {
			
			if ($add == true) {
				
				echo '
			<div id="pk_'.strtolower(str_replace(' ', '_', $title)).'_save_button"><p class="submit"><input class="pk_admin_save_changes_button button-primary" type="submit" name="submit" value="'.__('Save Changes', 'pk_text_domain').'" /></p></div>';
				
			} else {
				
				echo '
			<p class="submit"></p>';
				
			}
			
		}
		
		function pk_open_table($title = '') {
			
			echo '
			<table id="pk_'.strtolower(str_replace(' ', '_', $title)).'" class="widefat">
				<thead class="pk_admin_clickable_head">
					<tr>
						<th scope="row" colspan="2">'.$title.'</th>
					</tr>
				</thead>
				<tbody class="pk_admin_tggleable_body">';
			
		}
		
		function pk_close_table() {
			
			echo '
				</tbody>
			</table>';
			
		}
		
		function pk_open_form($options_key = '') {
			
			echo '
	<div>
		<form name="pk_form" method="post" action="">
			<input type="hidden" name="pk_form_data" value="true" />';
			
			wp_nonce_field($options_key, md5($options_key));
			
		}
		
		function pk_close_form() {
			
			echo '
		</form>
	</div>';
			
		}
		
		function pk_open_div() {
			
			echo '			
<!-- pk options page - start -->
<div class="wrap">';
			
		}
		
		function pk_close_div() {
			
			echo '
</div>
<!-- pk options page - end -->
';
			
		}
		
	}
	
}

if (class_exists('pk_forms_manager') && !isset($pk_forms_manager_instance)) {
	
	$pk_forms_manager_instance = new pk_forms_manager();
	
}

?>