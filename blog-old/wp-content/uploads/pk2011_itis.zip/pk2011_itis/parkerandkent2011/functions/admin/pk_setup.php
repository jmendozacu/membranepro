<?php

function pk_enqueue_admin_scripts() {
	
	global $pagenow;
	
	wp_enqueue_script('jquery');
	
	wp_enqueue_script('media-upload');
	
	wp_enqueue_script('thickbox');
	
	wp_deregister_script('pk_admin');
	wp_register_script('pk_admin', PK_THEME_DIR.'/parkerandkent2011/js/admin/pk/pk_admin.js');
	wp_enqueue_script('pk_admin');
	
	wp_deregister_script('pk_rangeinput');
	wp_register_script('pk_rangeinput', PK_THEME_DIR.'/parkerandkent2011/js/admin/rangeinput/rangeinput.min.js');
	wp_enqueue_script('pk_rangeinput');
	
	wp_deregister_script('pk_jscolor');
	wp_register_script('pk_jscolor', PK_THEME_DIR.'/parkerandkent2011/js/admin/jscolor/jscolor.js', array('jquery'));
	wp_enqueue_script('pk_jscolor');
	
	wp_deregister_script('swfobject');
	wp_register_script('swfobject', PK_THEME_DIR.'/parkerandkent2011/js/admin/swfobject/swfobject.js');
	wp_enqueue_script('swfobject');
	
	wp_enqueue_script('jquery-ui-sortable');
	
	if (($pagenow == 'post.php' || $pagenow == 'post-new.php')) {
		
		wp_deregister_script('pk_snippets_library');
		wp_register_script('pk_snippets_library', PK_THEME_DIR.'/parkerandkent2011/js/admin/pk/pk_snippets_library.js');
		wp_enqueue_script('pk_snippets_library');
	
		wp_deregister_script('pk_shortcodes_manager');
		wp_register_script('pk_shortcodes_manager', PK_THEME_DIR.'/parkerandkent2011/js/admin/pk/pk_shortcodes_manager.js');
		wp_enqueue_script('pk_shortcodes_manager');
	
	}
	
	if (isset($_REQUEST['page']) && $_REQUEST['page'] == 'pk_slides.php') {
		
		wp_deregister_script('pk_sortable_slides');
		wp_register_script('pk_sortable_slides', PK_THEME_DIR.'/parkerandkent2011/js/admin/pk/pk_sortable_slides.js');
		wp_enqueue_script('pk_sortable_slides');
		
	}
	
	if (isset($_REQUEST['page']) && $_REQUEST['page'] == 'pk_works.php') {
		
		wp_deregister_script('pk_sortable_works');
		wp_register_script('pk_sortable_works', PK_THEME_DIR.'/parkerandkent2011/js/admin/pk/pk_sortable_works.js');
		wp_enqueue_script('pk_sortable_works');
		
	}
	
}

add_action('admin_init', 'pk_enqueue_admin_scripts');

function pk_enqueue_admin_styles() {
	
	global $pagenow;
	
	if ($pagenow == 'index.php') {
		
		wp_deregister_style('pk_dashboard');
		wp_register_style('pk_dashboard', PK_THEME_DIR.'/parkerandkent2011/css/admin/pk/pk_dashboard.css');
		wp_enqueue_style('pk_dashboard');
	
	}
	
	if (($pagenow == 'post.php' || $pagenow == 'post-new.php')) {
	
		wp_deregister_style('pk_meta_options');
		wp_register_style('pk_meta_options', PK_THEME_DIR.'/parkerandkent2011/css/admin/pk/pk_meta_options.css');
		wp_enqueue_style('pk_meta_options');
	
	}
	
	if ($pagenow == 'admin.php') {
	
		wp_deregister_style('pk_options');
		wp_register_style('pk_options', PK_THEME_DIR.'/parkerandkent2011/css/admin/pk/pk_options.css');
		wp_enqueue_style('pk_options');
	
	}
	
	if (isset($_REQUEST['page']) && ($_REQUEST['page'] == 'pk_slides.php' || $_REQUEST['page'] == 'pk_works.php')) {
		
		wp_enqueue_style('pk_sort', PK_THEME_DIR.'/parkerandkent2011/css/admin/pk/pk_sort.css');
		
	}
	
	wp_enqueue_style('thickbox');
	
}

add_action('admin_init', 'pk_enqueue_admin_styles');

?>