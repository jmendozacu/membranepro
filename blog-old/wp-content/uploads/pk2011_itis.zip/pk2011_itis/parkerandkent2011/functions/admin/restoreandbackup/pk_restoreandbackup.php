<?php

function pk_create_restoreandbackup_page() {
	
	global $pk_restoreandbackup_manager_instance;
	
	$pk_options = get_option('pk_options');
	
	$data_recovered = false;
	$data_received = false;
			
	if (isset($_POST['pk_form_data']) && wp_verify_nonce($_POST[md5('pk_restore_options')], 'pk_restore_options')) {
		
		$data_received = true;
		
		$data_to_recover = unserialize(base64_decode($_POST['pk_restore_options_data'], true));
		
		if (is_array($data_to_recover) && $data_to_recover['pk_first'] == 'OK' && $data_to_recover['pk_last'] == 'OK') {
			
			foreach ($data_to_recover as $k => $v) {
				
				if ($k != 'pk_first' && $k != 'pk_last') {
				
					update_option($k, $v);
					
				}
				
			}
			
			$data_recovered = true;
			
		}
		
	} else {
		
		$data_recovered = false;
		
	}
	
	$pk_restoreandbackup_manager_instance -> pk_open_div();
	$pk_restoreandbackup_manager_instance -> pk_add_main_title(__('Options Restore & Backup', 'pk_text_domain'));
	
	if ($data_recovered == true) {
		
		$pk_restoreandbackup_manager_instance -> pk_options_restored();
		
	} else {
		
		if ($data_received == true) {
			
			$pk_restoreandbackup_manager_instance -> pk_options_unrestored();	
			
		}
		
	}
	
	$pk_restoreandbackup_manager_instance -> pk_open_form('pk_restore_options');
	$pk_restoreandbackup_manager_instance -> pk_open_table(__('Options Restore', 'pk_text_domain'));
	$pk_restoreandbackup_manager_instance -> pk_add_title(__('Data:', 'pk_text_domain'), true, false);
	$pk_restoreandbackup_manager_instance -> pk_add_input_text_area('pk_restore_options_data', '', '12', __('Paste here the options data that you want to restore and then press the "Restore Options" button.', 'pk_text_domain'));
	$pk_restoreandbackup_manager_instance -> pk_close_table();
	$pk_restoreandbackup_manager_instance -> pk_add_restore_options_button();
	$pk_restoreandbackup_manager_instance -> pk_close_form();
	
	$backup = array();
	
	$backup['pk_first'] = 'OK';
	
	foreach ($pk_options as $k => $v) {
		
		$backup[$v] = get_option($v);
		
	}
	
	$backup['pk_last'] = 'OK';
	
	$pk_restoreandbackup_manager_instance -> pk_open_form('pk_backup_options');
	$pk_restoreandbackup_manager_instance -> pk_open_table(__('Options Backup', 'pk_text_domain'));
	$pk_restoreandbackup_manager_instance -> pk_add_title(__('Data:', 'pk_text_domain'), true, false);
	$pk_restoreandbackup_manager_instance -> pk_add_input_text_area('pk_backup_options_data', base64_encode(serialize($backup)), '12', __('Copy this data and save it in a text file. Use the saved data to restore your options through the "Options Restore" form.', 'pk_text_domain'));
	$pk_restoreandbackup_manager_instance -> pk_close_table();
	$pk_restoreandbackup_manager_instance -> pk_close_form();
	$pk_restoreandbackup_manager_instance -> pk_close_div();
	
}

function pk_add_restoreandbackup_page() {

	add_menu_page('PK '.__('Utilities', 'pk_text_domain'), 'PK '.__('Utilities', 'pk_text_domain'), 'level_10', 'pk_restoreandbackup', 'pk_create_restoreandbackup_page');
	add_submenu_page('pk_restoreandbackup', __('Restore & Backup', 'pk_text_domain'), __('Restore & Backup', 'pk_text_domain'), 'level_10', 'pk_restoreandbackup', 'pk_create_restoreandbackup_page');

}

add_action('admin_menu', 'pk_add_restoreandbackup_page');

?>