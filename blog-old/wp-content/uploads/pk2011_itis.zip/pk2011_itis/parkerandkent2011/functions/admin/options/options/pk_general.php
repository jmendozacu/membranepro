<?php

$pk_general_options = array();

$pk_general_options[0]['title'] = __('General Options', 'pk_text_domain');
$pk_general_options[0]['options'] = array(
										
										'general_favicon' 					=> array('title' => __('Favicon:', 'pk_text_domain'), 'type' => 'image', 'preview' => 'false', 'helper' => __('Upload or select your favicon from the <i>Media Library</i>', 'pk_text_domain')),
										'general_titles_separator' 			=> array('title' => __('Titles separator:', 'pk_text_domain'), 'type' => 'text', 'helper' => __('Type the separator that you want to use for the theme titles.', 'pk_text_domain')),
										'general_show_intro_text' 			=> array('title' => __('Show intro text:', 'pk_text_domain'), 'type' => 'radio_group', 'values' => array('true', 'false'), 'labels' => array(__('Yes', 'pk_text_domain'), __('No', 'pk_text_domain')), 'helper' => __('Select <i>No</i> to globally disable the <i>Intro</i> area of the theme.', 'pk_text_domain')),
										'general_404_page_id' 				=> array('title' => __('404 Page:', 'pk_text_domain'), 'type' => 'page', 'post_type' => 'page', 'helper' => __('Create and select a custom page to display when a <i>404 Page Not Found</i> error occurs.', 'pk_text_domain')),
										'general_flickr_user_id' 			=> array('title' => __('Your Flickr user id:', 'pk_text_domain'), 'type' => 'text', 'helper' => __('If you don\'t know where to find it, you can use <a href="http://idgettr.com/" title="Flickr idGettr">idGettr</a> to retrive it.', 'pk_text_domain')),
										'general_flickr_api_key' 			=> array('title' => __('Your Flickr api key:', 'pk_text_domain'), 'type' => 'text', 'helper' => __('You can easily get a NON-Commercial key <a href="http://www.flickr.com/services/apps/create/apply" title="Get a Flickr API key">here</a>.', 'pk_text_domain')),
										'general_flickr_api_secret' 		=> array('title' => __('Your Flickr api secret:', 'pk_text_domain'), 'type' => 'text', 'helper' => __('When you request an api key, you will receive an api secret as well.', 'pk_text_domain')),
										'general_show_add_this' 			=> array('title' => __('Show AddThis.com share buttons:', 'pk_text_domain'), 'type' => 'radio_group', 'values' => array('true', 'false'), 'labels' => array(__('Yes', 'pk_text_domain'), __('No', 'pk_text_domain')), 'helper' => __('Select <i>No</i> to globally disable the <a href="http://www.addthis.com/" title="www.addthis.com">AddThis.com</a> built in theme sharing functionalities.', 'pk_text_domain')),
										'general_add_this_username' 		=> array('title' => __('Your AddThis.com username:', 'pk_text_domain'), 'type' => 'text', 'helper' => __('Visit <a href="http://www.addthis.com/" title="www.addthis.com">AddThis.com</a> and register to use the built in theme sharing functionalities.', 'pk_text_domain')),
										'general_google_analytics_code' 	=> array('title' => __('Google Analytics code:', 'pk_text_domain'), 'type' => 'text_area', 'rows' => '6', 'helper' => __('Paste your complete Google Analytics code.', 'pk_text_domain')),
										'general_custom_css' 				=> array('title' => __('Custom CSS:', 'pk_text_domain'), 'type' => 'text_area', 'rows' => '6', 'helper' => __('Enter any custom CSS style you need. You MUST NOT enter the &lt;style&gt; tags.', 'pk_text_domain'))
										
										);
$pk_general_options[0]['values'] = array(
										
										'general_favicon' 					=> '',
										'general_titles_separator' 			=> '|',
										'general_show_intro_text' 			=> 'true',
										'general_404_page_id' 				=> '',
										'general_flickr_user_id' 			=> '',
										'general_flickr_api_key' 			=> '',
										'general_flickr_api_secret' 		=> '',
										'general_show_add_this' 			=> 'true',
										'general_add_this_username' 		=> 'parkerandkent',
										'general_google_analytics_code' 	=> '',
										'general_custom_css' 				=> ''
									
										);
$pk_general_options[0]['save_button'] = true;

if (class_exists('pk_options_generator') && !isset($pk_general_options_instance)) {
	
	add_option('pk_general_options_profiles', array('default'));
	add_option('pk_general_options_current_profile', 'default');
	add_option('pk_general_options_active_profile', 'default');
	
	$pk_general_options_instance = new pk_options_generator($pk_general_options, 'level_10', __('General Options', 'pk_text_domain'), 'pk_general_options', '', 'pk_general_options', 'pk_', array('pk_general_options_profiles', 'pk_general_options_current_profile', 'pk_general_options_active_profile', 'pk_general_options'));
	
	/*global $pk_dashboard_options;
	
	$pk_profiles = get_option('pk_general_options_profiles');
	
	foreach ($pk_profiles as $k => $v) {
	
		$pk_dashboard_options['pk_general_options_'.$v] = sprintf(__('General Options - %s', 'pk_text_domain'), (($v == 'default') ? __('Default', 'pk_text_domain') : stripslashes(base64_decode($v))));
	
	}*/
	
}

?>