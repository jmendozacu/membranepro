<?php

global $pk_democontents_manager_instance;

if (!class_exists('pk_democontents_manager')) {
	
	class pk_democontents_manager extends pk_forms_manager {
		
		function pk_democontents_manager() {
			
		}
		
		function pk_add_main_title($title = '') {
			
			echo '
	<div id="icon-options-general" class="icon32">
		<br />
	</div>
	<h2>'.$title.'</h2>
	<br />';
			
		}
		
	}
	
}

if (class_exists('pk_democontents_manager') && !isset($pk_democontents_manager_instance)) {
	
	$pk_democontents_manager_instance = new pk_democontents_manager();
	
}

?>