<?php

if (!class_exists('pk_options_generator')) {
	
	class pk_options_generator {
		
		private $all;
		private $options;
		private $level;
		private $name;
		private $main_slug;
		private $slug;
		private $options_key;
		private $suffix;
		private $profiles;
		
		function pk_options_generator($options = array(), $level = 'level_10', $name = '', $main_slug = '', $slug = '', $options_key = '', $suffix = '', $profiles = array()) {
			
			$this -> all = array();
			$this -> options = $options;
			$this -> level = $level;
			$this -> name = $name;
			$this -> main_slug = $main_slug;
			$this -> slug = $slug;
			$this -> options_key = $options_key;
			$this -> suffix = $suffix;
			$this -> profiles = $profiles;
			
			$pk_options = get_option('pk_options');
			
			if (count($this -> profiles) > 0) {
				
				$this -> options_key .= '_'.get_option($this -> profiles[1]);

				array_push($pk_options, $this -> profiles[0]);
				array_push($pk_options, $this -> profiles[1]);
				
				if ($this -> profiles[2] != '') {
					
					array_push($pk_options, $this -> profiles[2]);
				
				}
				
			}
			
			array_push($pk_options, $this -> options_key);
			
			update_option('pk_options', array_unique($pk_options));
			
			$this -> pk_init_options();
			
		}
		
		function pk_create_options_page() {
			
			if (count($this -> profiles) > 0) {
				
				global $pk_profiles_manager_instance;
				
				$new_profile_saved = false;
				$profile_deleted = false;
				$profile_activated = false;
				$profile_default_error = false;
				$profiles = array();
				$result = array();
				$found = -1;
			
				if (isset($_POST['pk_profiles_form_data']) && isset($_POST[md5($this -> options_key.'_profiles')]) && wp_verify_nonce($_POST[md5($this -> options_key.'_profiles')], $this -> options_key.'_profiles')) {
					
					switch ($_POST['pk_profiles_button']) {
						
						case __('Add', 'pk_text_domain'):
					
							if (isset($_POST[$this -> suffix.'new_profile']) && $_POST[$this -> suffix.'new_profile'] != '') {
								
								$profiles = get_option($this -> profiles[0]);
								
								if (!in_array($_POST[$this -> suffix.'new_profile'], $profiles)) {
									
									array_push($profiles, base64_encode($_POST[$this -> suffix.'new_profile']));
									
									update_option($this -> profiles[0], $profiles);
									update_option($this -> profiles[1], base64_encode($_POST[$this -> suffix.'new_profile']));
									
									$this -> options_key = $this -> profiles[3].'_'.base64_encode($_POST[$this -> suffix.'new_profile']);
									
									for ($i = 0; $i < count($this -> options); $i++) {
								
										$this -> pk_save_settings($this -> options[$i]['values']);
							
									}
									
									$new_profile_saved = true;
									
								} else {
									
									$new_profile_saved = false;
									
								}
								
							}
							
							break;
							
						case __('Delete', 'pk_text_domain'):
						
							if (isset($_POST[$this -> suffix.'delete_profile']) && $_POST[$this -> suffix.'delete_profile'] != '' && $_POST[$this -> suffix.'delete_profile'] != 'default') {
								
								$profiles = get_option($this -> profiles[0]);
								
								for ($i = 0; $i < count($profiles); $i++) {
								
									if ($profiles[$i] != $_POST[$this -> suffix.'delete_profile']) {
										
										array_push($result, $profiles[$i]);
										
									} else {
										
										$found = $i;
										
										delete_option($this -> profiles[3].'_'.$profiles[$i]);
										
										$profile_deleted = true;
										
									}
							
								}
							
								update_option($this -> profiles[0], $result);
								
								if (get_option($this -> profiles[1]) == $profiles[$found]) {
									
									update_option($this -> profiles[1], $result[0]);
									$this -> options_key = $this -> profiles[3].'_'.$result[0];
									
								}
								
								if ($this -> profiles[2] != '') {
								
									if (get_option($this -> profiles[2]) == $profiles[$found]) {
										
										update_option($this -> profiles[2], $result[0]);
										
									}
								
								}
						
							}
							
							if ($_POST[$this -> suffix.'delete_profile'] == 'default') {
								
								$profile_default_error = true;
								
							}
							
							break;
							
						case __('Load', 'pk_text_domain'):
						
							if (isset($_POST[$this -> suffix.'select_profile']) && $_POST[$this -> suffix.'select_profile'] != '') {
							
								update_option($this -> profiles[1], $_POST[$this -> suffix.'select_profile']);
								$this -> options_key = $this -> profiles[3].'_'.$_POST[$this -> suffix.'select_profile'];
						
							}
							
							break;
							
						case __('Activate', 'pk_text_domain'):
						
							if (isset($_POST[$this -> suffix.'active_profile']) && $_POST[$this -> suffix.'active_profile'] != '') {
							
								update_option($this -> profiles[2], $_POST[$this -> suffix.'active_profile']);
								
								$profile_activated = true;
						
							}
							
							break;
						
					}
				
				}
				
				$profiles = get_option($this -> profiles[0]);
				
				$pk_options = get_option('pk_options');
			
				foreach ($profiles as $k => $v) {
					
					array_push($pk_options, $this -> profiles[3].'_'.$v);
					
				}
				
				update_option('pk_options', array_unique($pk_options));
						
			}
			
			global $pk_options_manager_instance;
			
			$data_saved = false;
			
			if (isset($_POST['pk_form_data']) && isset($_POST[md5($this -> options_key)]) && wp_verify_nonce($_POST[md5($this -> options_key)], $this -> options_key)) {
				
				for ($i = 0; $i < count($this -> options); $i++) {
					
					$this -> pk_save_settings($this -> options[$i]['values'], $i);
				
				}
				
				$data_saved = true;
				
			} else {
				
				$data_saved = false;
				
			}
			
			$pk_options_manager_instance -> pk_open_div();
			$pk_options_manager_instance -> pk_add_main_title($this -> name);
			
			if ($data_saved == true) {
				
				$pk_options_manager_instance -> pk_data_saved();
				
			}
			
			if (count($this -> profiles) > 0) {
			
				if ($new_profile_saved == true) {
					
					$pk_profiles_manager_instance -> pk_data_saved(__('New profile saved!', 'pk_text_domain'));
					
				}
				
				if ($profile_deleted == true) {
					
					$pk_profiles_manager_instance -> pk_data_saved(__('Profile deleted!', 'pk_text_domain'));
					
				}
				
				if ($profile_default_error == true) {
					
					$pk_profiles_manager_instance -> pk_data_saved(__('Attention! You cannot delete the "default" profile!', 'pk_text_domain'));
					
				}
				
				if ($profile_activated == true) {
					
					$pk_profiles_manager_instance -> pk_data_saved(__('Profile activated!', 'pk_text_domain'));
					
				}
				
				$pk_profiles_manager_instance -> pk_open_div(($this -> slug != '') ? $this -> slug : $this -> main_slug);
				$pk_profiles_manager_instance -> pk_open_form($this -> options_key.'_profiles');
				$pk_profiles_manager_instance -> pk_open_table($this -> name.' '.__('Profiles', 'pk_text_domain'));
				
				$pk_profiles_manager_instance -> pk_add_title(__('Add new profile:', 'pk_text_domain'), true);
				$pk_profiles_manager_instance -> pk_add_input_new_profile($this -> suffix.'new_profile', __('By creating a new options profile you will duplicate the whole set of options. In this way, whenever you need, you can use a specific profile (and so different settings) for a specific content. Check the PK Theme Help page for detailed info about how to use the profiles.', 'pk_text_domain'));
				
				if (count(get_option($this -> profiles[0])) > 1) {
				
					$pk_profiles_manager_instance -> pk_add_title(__('Delete profile:', 'pk_text_domain'), true);
					$pk_profiles_manager_instance -> pk_add_input_select($this -> suffix.'delete_profile', 'delete', get_option($this -> profiles[0]), get_option($this -> profiles[0]), get_option($this -> profiles[1]), __('Select the profile to delete. If the profile you\'re deleting is in use somewhere in the theme it will be automatically replaced by the current <i>Active profile</i>.', 'pk_text_domain'));
					$pk_profiles_manager_instance -> pk_add_title(__('Load profile:', 'pk_text_domain'), true);
					$pk_profiles_manager_instance -> pk_add_input_select($this -> suffix.'select_profile', 'load', get_option($this -> profiles[0]), get_option($this -> profiles[0]), get_option($this -> profiles[1]), __('Select the profile that you want to load/edit.', 'pk_text_domain'));
					
					if ($this -> profiles[2] != '') {
						
						$pk_profiles_manager_instance -> pk_add_title(__('Active profile:', 'pk_text_domain'), true);
						$pk_profiles_manager_instance -> pk_add_input_select($this -> suffix.'active_profile', 'activate', get_option($this -> profiles[0]), get_option($this -> profiles[0]), get_option($this -> profiles[2]), __('Select the profile that you want to activate. The <i>Active profile</i> will be the default one used by the theme.', 'pk_text_domain'));
					
					}
				
				}
				
				$pk_profiles_manager_instance -> pk_close_table();
				$pk_profiles_manager_instance -> pk_close_form();
				
				$pk_profiles_manager_instance -> pk_add_main_title((get_option($this -> profiles[1]) == 'default') ? 'Default' : stripslashes(base64_decode(get_option($this -> profiles[1]))).' '.__('Profile', 'pk_text_domain'));
				$pk_profiles_manager_instance -> pk_close_div();
			
			}
			
			$pk_options_manager_instance -> pk_open_form($this -> options_key);
			
			for ($i = 0; $i < count($this -> options); $i++) {
				
				$pk_options_manager_instance -> pk_open_table($this -> options[$i]['title']);
				
				$count = 0;
				
				foreach ($this -> options[$i]['options'] as $k => $v) {
				
					$this -> pk_switch_options_type($k, $this -> options[$i]['options'], $this -> options[$i]['values'], ($count % 2) ? true : false);
					
					$count++;
				
				}
				
				$pk_options_manager_instance -> pk_close_table();
				$pk_options_manager_instance -> pk_add_save_changes($this -> options[$i]['title'], $this -> options[$i]['save_button']);
				
			}
			
			$pk_options_manager_instance -> pk_close_form();
			$pk_options_manager_instance -> pk_close_div();
			
		}
		
		function pk_add_options_page() {
			
			if ($this -> slug == '') {
			
				add_menu_page('PK '.__('Options', 'pk_text_domain'), 'PK '.__('Options', 'pk_text_domain'), $this -> level, $this -> main_slug, array($this, 'pk_create_options_page'));
				add_submenu_page($this -> main_slug, $this -> name, $this -> name, $this -> level, $this -> main_slug, array($this, 'pk_create_options_page'));
				
			} else {
				
				add_submenu_page($this -> main_slug, $this -> name, $this -> name, $this -> level, $this -> slug, array($this, 'pk_create_options_page'));
				
			}
			
		}
		
		function pk_switch_options_type($k = '', $options = array(), $values = array(), $color = false) {
			
			global $pk_options_manager_instance;
			
			if ($options[$k]['title'] != '') {
				
				$pk_options_manager_instance -> pk_add_title($options[$k]['title'], $color, ($options[$k]['type'] == 'metabox_selector') ? true : false);
				
			}
			
			$this -> all = get_option($this -> options_key);
			
			$value = (isset($this -> all[$k])) ? stripslashes(urldecode($this -> all[$k])) : $values[$k];
			$helper = $options[$k]['helper'];
			
			switch ($options[$k]['type']) {
				
				case 'footer_layout_manager':
					
					$pk_options_manager_instance -> pk_add_input_footer_layout_manager($this -> suffix.$k, $value, $helper);
					break;
					
				case 'footer_social_networks_manager':
					
					$pk_options_manager_instance -> pk_add_input_footer_social_networks_manager($this -> suffix.$k, $value, $helper);
					break;
					
				case 'text':
					
					$pk_options_manager_instance -> pk_add_input_text_field($this -> suffix.$k, $value, $helper);
					break;
					
				case 'text_area':
					
					$pk_options_manager_instance -> pk_add_input_text_area($this -> suffix.$k, $value, $options[$k]['rows'], $helper);
					break;
					
				case 'radio_group':
					
					$pk_options_manager_instance -> pk_add_input_radio_group($this -> suffix.$k, $options[$k]['values'], $options[$k]['labels'], $value, $helper);
					break;
					
				case 'select':
					
					$pk_options_manager_instance -> pk_add_input_select($this -> suffix.$k, false, $options[$k]['values'], $options[$k]['labels'], $value, $helper);
					break;
					
				case 'skin_select':
					
					$pk_options_manager_instance -> pk_add_input_skin_select($this -> suffix.$k, false, $options[$k]['values'], $options[$k]['labels'], $value, $helper);
					break;
					
				case 'metabox_selector':
					
					$pk_options_manager_instance -> pk_add_input_select($this -> suffix.$k, true, $options[$k]['values'], $options[$k]['labels'], $value, $helper);
					break;
					
				case 'color':
					
					$pk_options_manager_instance -> pk_add_input_color($this -> suffix.$k, $value, $helper);
					break;
					
				case 'slider':
					
					$pk_options_manager_instance -> pk_add_input_slider($this -> suffix.$k, $value, $options[$k]['min'], $options[$k]['max'], $options[$k]['uom'], $helper);
					break;
					
				case 'image':
				case 'video':
				case 'audio':
				case 'file':
					
					$pk_options_manager_instance -> pk_add_input_file($this -> suffix.$k, $value, $options[$k]['type'], $options[$k]['preview'], $helper);
					break;
					
				case 'category':
					
					$pk_options_manager_instance -> pk_add_input_category($this -> suffix.$k, $value, $options[$k]['taxonomy'], $helper);
					break;
					
				case 'categories':
					
					$pk_options_manager_instance -> pk_add_input_categories($this -> suffix.$k, $value, $options[$k]['taxonomy'], $helper);
					break;
					
				case 'page':
					
					$pk_options_manager_instance -> pk_add_input_page($this -> suffix.$k, $value, $options[$k]['post_type'], $helper);
					break;
					
				case 'pages':
					
					$pk_options_manager_instance -> pk_add_input_pages($this -> suffix.$k, $value, $options[$k]['post_type'], $helper);
					break;
					
				case 'post':
					
					$pk_options_manager_instance -> pk_add_input_post($this -> suffix.$k, $value, $options[$k]['post_type'], $helper);
					break;
					
				case 'posts':
					
					$pk_options_manager_instance -> pk_add_input_posts($this -> suffix.$k, $value, $options[$k]['post_type'], $helper);
					break;
					
				case 'tag':
					
					$pk_options_manager_instance -> pk_add_input_tag($this -> suffix.$k, $value, $helper);
					break;
					
				case 'tags':
					
					$pk_options_manager_instance -> pk_add_input_tags($this -> suffix.$k, $value, $helper);
					break;
					
			}
			
		}
		
		function pk_save_settings($a = array(), $i = 0) {
			
			foreach ($a as $k => $v) {
				
				if (isset($_POST[$this -> suffix.$k]) && $_POST[$this -> suffix.$k] != '') {
					
					$this -> all[$k] = urlencode($_POST[$this -> suffix.$k]);
					
					if ($this -> options[$i]['options'][$k]['type'] == 'video' || $this -> options[$i]['options'][$k]['type'] == 'audio') {
						
						if ($this -> options[$i]['options'][$k]['type'] == 'video') {
							
							$array = explode(',', $_POST[$this -> suffix.$k]);
							
							if ($array[0] == '0' || $array[2] == '') {
								
								$this -> all[$k] = '';
								
							}
							
						} else {
							
							$array = explode(',', $_POST[$this -> suffix.$k]);
							
							if ($array[1] == '') {
								
								$this -> all[$k] = '';
								
							}
							
						}
						
					}
					
				} else {
					
					$this -> all[$k] = $a[$k];
					
				}
				
			}
			
			update_option($this -> options_key, $this -> all);
			
			do_action('pk_ah_options_updated');
			
		}
		
		function pk_init_options() {
			
			for ($i = 0; $i < count($this -> options); $i++) {
			
				foreach ($this -> options[$i]['values'] as $k => $v) {
					
					$this -> all[$k] = $v;
					
				}
				
			}
			
			add_option($this -> options_key, $this -> all);
			
			add_action('admin_menu', array(&$this, 'pk_add_options_page'));
			
		}
		
	}
	
}

?>