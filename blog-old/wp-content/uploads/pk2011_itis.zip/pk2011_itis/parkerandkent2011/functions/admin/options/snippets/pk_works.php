<?php

if (class_exists('pk_snippets_library_generator') && !isset($pk_works_snippets_library_generator_instance)) {
	
	global $pk_shortcodes;
	
	$pk_works_snippets_library_generator_instance = new pk_snippets_library_generator('works', 'pk_sl_');
	
}

?>