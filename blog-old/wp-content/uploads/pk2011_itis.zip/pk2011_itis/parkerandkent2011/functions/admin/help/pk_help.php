<?php

function pk_create_theme_help_page() {
	
	global $pk_options_manager_instance;
	
	$pk_options_manager_instance -> pk_open_div();
	$pk_options_manager_instance -> pk_add_main_title(__('Theme Help', 'pk_text_domain'));
	?>
	<h3 id="pk_help_table_of_contents">Table of contents:</h3>
	<ul>
		<li><a href="#pk_help_important_notes">Important Notes</a></li>
		<li><a href="#pk_help_demo_contents_setup">Demo Contents Setup</a></li>
		<li><a href="#pk_help_home_blog_setup">Home Page and Blog Setup</a></li>
		<li><a href="#pk_help_options_overview">Options Overview</a></li>
		<li><a href="#pk_help_options_profiles">Options Profiles</a></li>
		<li><a href="#pk_help_theme_menus">Theme Menus</a></li>
		<li><a href="#pk_help_post_types">Post Types</a></li>
		<li><a href="#pk_help_page_templates">Page Templates</a></li>
		<li><a href="#pk_help_shortcodes">Shortcodes</a></li>
		<li><a href="#pk_help_snippets_library">The Snippets Library</a></li>
		<li><a href="#pk_help_sidebars_widgets">Sidebars and Widgets</a></li>
		<li><a href="#pk_help_custom_hooks">Custom Hooks</a></li>
		<li><a href="#pk_help_branding_admin">Branding the Admin</a></li>
		<li><a href="#pk_help_theme_translation">Theme Translation</a></li>
	</ul>
	<br />
	<table id="pk_help_important_notes" class="widefat">
		<thead class="pk_admin_clickable_head">
			<tr>
				<th scope="row" colspan="2">Important Notes</th>
			</tr>
		</thead>
		<tbody class="pk_admin_tggleable_body">
			<tr class="pk_admin_tr">
				<td>
				<p><strong>Please, read this help page:</strong></p>
				<p>We know that sometimes reading an help file can be a not so exciting activity and that you would like to jump right into the theme admin and start to play with it. For this reason, here in this help section, we've tried to give you the more essential information to get started, nothing less and nothing more. We really believe that, by reading this page, you will understand the basic key concepts to use this theme at its best.</p>
				<p>We also know that it's hard to remember too many information, so we have added, below each theme's option, a piece of knowledge that you may need in that moment, just to make your life easier. Hoping to have made our best, we wish you an happy time using our theme. Enjoy it!</p>
				<hr />
				<p><strong>Minimal requirements:</strong></p>
				<p>In order to use this theme you need to have at least <strong>WordPress 3.1.x</strong> and <strong>php 5.x</strong> running on your server.</p>
				<p>If you're using an older WordPress version, you can automatically update to the latest version from your <a href="<?php echo home_url(); ?>/wp-admin/update-core.php">Dashboard -> Updates</a> page.</p>
				<p>If the theme outputs any error or warning probably the php version running on your server isn't the one required by the theme. Many hosting providers give you the option to upgrade the php version directly from the administration panel of the server. If you don't know how to make the upgrade to php 5.x by yourself, just contact your hosting provider support and ask to make the upgrade for you.</p>
				<hr />
				<p><strong>Logo setup:</strong></p>
				<p>In order to set your own logo you need to upload it through the <a href="<?php echo home_url(); ?>/wp-admin/admin.php?page=pk_skin_options">PK Options -> Skin Options</a> page.</p>
				<hr />
				<p><strong>Flickr integration:</strong></p>
				<p>In order to activate the Flickr functionality of this theme you need to set your Flickr API Key in the <a href="<?php echo home_url(); ?>/wp-admin/admin.php?page=pk_general_options">PK Options -> General Options</a> page. The process to request and obtain an API key is very simple and it is explained very well in the page previously linked.</p>
				<hr />
				<p><strong>Contact page:</strong></p>
				<p>This theme doesn't have a page template for the contact page. You can simply create one using a default page template and, thanks to the shortcodes, place in it a contact form, a Google Map, etc.</p>
				<hr />
				<p><strong>Missing options panels:</strong></p>
				<p>If you are using a brand new WordPress installation probably some options panels are hidden by default. If you feel that something is missing, on many admin pages there is a <strong><i>Screen Options</i></strong> button on the top-right corner. By clicking on it a new panel will appear and you will see a serie of check boxes to activate/deactivate some theme options. Be sure to keep deactivated only the options that you don't need.</p>
				<hr />
				<p><strong>Images not showing:</strong></p>
				<p>This theme uses TimThumb to generate thumbnails and to resize images. If any thumbnail or image isn't showing you need to make some checks:</p>
				<ol>
					<li>As very first thing check that the paths (URLs) of your images are correct.</li>
					<li>The images must be hosted on your domain or on Flickr, thanks to the full Flickr integration of this theme.</li>
					<li>The file pk2011_itis/timthumb/timthumb.php should have 644 permissions. The folder pk2011_itis/timthumb/cache should have 777 permissions. If this doesn't work, try giving 755 permissions to the cache folder. See <a href="http://www.siteground.com/tutorials/ftp/ftp_chmod.htm">here</a> how to set permissions to files and folders (CHMODing).</li>
					<li>Be sure that your server has the GD library for PHP enabled. Ask your hosting provider support if you don't know what this means.</li>
					<li>If your images are too big (eg. 8+ megapixels photos) try to reduce their quality and size. Make them usable for the web.</li>
					<li>Some servers may have mod_security settings that will stop the TimThumb script from working. Ask to your hosting provider support to allow the use of TimThumb on your server.</li>
					<li>In case the thumbnails of the images hosted on your server are correctly created, but you're having issues with the thumbnails of the Flickr photos, probably you have to change some settings on your server. In this case contact your hosting provider support and check if the "allow url fopen" is ON and if php allows connections via curl to external sites.</li>
				</ol>
				<p>If after these checks you still have problems don't esitate to contact us for help.</p>
				<hr />
				<p><strong>Theme support:</strong></p>
				<p>In order to keep all the support requests in one place, for any question about this theme, post a comment on the <a href="http://themeforest.net/user/ParkerAndKent/portfolio">theme's discussion page</a>.</p>
				</td>
			</tr>
		</tbody>
	</table>
	<p><a href="#pk_help_table_of_contents">Top</a></p>
	<br />
	<table id="pk_help_demo_contents_setup" class="widefat">
		<thead class="pk_admin_clickable_head">
			<tr>
				<th scope="row" colspan="2">Demo Contents Setup</th>
			</tr>
		</thead>
		<tbody class="pk_admin_tggleable_body">
			<tr class="pk_admin_tr">
				<td>
				<p>To understand how to use all the theme functionalities we suggest to install the demo contents that we have used to showcase the theme. In order to set up the demo contents just follow the few steps we have explained in this page: <a href="<?php echo home_url(); ?>/wp-admin/admin.php?page=pk_democontents">PK Utilities -> Demo Contents</a></p>
				</td>
			</tr>
		</tbody>
	</table>
	<p><a href="#pk_help_table_of_contents">Top</a></p>
	<br />
	<table id="pk_help_home_blog_setup" class="widefat">
		<thead class="pk_admin_clickable_head">
			<tr>
				<th scope="row" colspan="2">Home Page and Blog Setup</th>
			</tr>
		</thead>
		<tbody class="pk_admin_tggleable_body">
			<tr class="pk_admin_tr">
				<td>
				<p>One of the first things you may want to set is an Home Page for your theme. WordPress gives you the option to set as Home Page the Blog or a static page (a static page is a normal page created under the <strong><i>Pages</i></strong> menu).</p>
				<p>In order to set up your Home Page go to the <a href="<?php echo home_url(); ?>/wp-admin/options-reading.php">Settings -> Reading</a> page.</p>
				<p>To show the Blog as Home Page check <strong><i>Your latest posts</i></strong> for the <strong><i>Front page displays</i></strong> option.</p>
				<p>To show a custom static page as Home Page check <strong><i>A static page</i></strong> for the <strong><i>Front page displays</i></strong> option. By selecting this option you will have to select 2 pages, one for the Home Page and one for the Blog. The one that you select for the Home Page can have any style and content, so it can be any page. The one that you select for the Blog doesn't need to have any content or style, just use a default page and give it a title (to use for the menu navigation). The contents of the selected Blog page will be generated by WordPress, resulting in your latest posts.</p>
				<p>As said before, by using a static custom page for the Home Page you have the freedom to use any page template and show any type of content. We haven't created any specific template for the Home Page, because we don't want to force you to use a specific model. Thanks to the huge set of shortcodes of this theme you can really create the best page for your needs. The demo contents include one Home Page layout that we have created to give you some ideas about what a custom Home Page can be. You can use this layout as starting point for your Home Page.</p>
				<p>If you have chosen to show your Blog as Home Page you will find a complete set of options to customize its look here: <a href="<?php echo home_url(); ?>/wp-admin/admin.php?page=pk_blog_options">PK Options -> Blog Options</a>. An overview of all the theme options is available in the next section of this help.</p>
				<p>Another important option of the <a href="<?php echo home_url(); ?>/wp-admin/options-reading.php">Settings -> Reading</a> page is the <strong><i>Blog pages show at most</i></strong> one. This option takes the number of posts that you want to show on each page of the Blog. So, if you want to show 100 posts on each Blog page this is the option you're looking for.</p>
				</td>
			</tr>
		</tbody>
	</table>
	<p><a href="#pk_help_table_of_contents">Top</a></p>
	<br />
	<table id="pk_help_options_overview" class="widefat">
		<thead class="pk_admin_clickable_head">
			<tr>
				<th scope="row" colspan="2">Options Overview</th>
			</tr>
		</thead>
		<tbody class="pk_admin_tggleable_body">
			<tr class="pk_admin_tr">
				<td>
				<p>In this section we won't explain the theme options one by one (all the options have a detailed description below their input fields), but we'll explain the options groups, when they're used, why they're used and what you can do with them.</p>
				<hr />
				<p><strong>General Options:</strong></p>
				<p>The <a href="<?php echo home_url(); ?>/wp-admin/admin.php?page=pk_general_options">PK Options -> General Options</a> are used to manage some different settings of the theme, settings that can't be grouped in any other way. <strong>This set of options should be the first one to set up</strong> when starting the customization of the theme. In few words, through it, you mainly can:</p>
				<ol>
					<li>Set up the <strong>favicon</strong>.</li>
					<li>Set up the <strong>404</strong> page.</li>
					<li>Set up the <strong>Flickr</strong> functionality.</li>
					<li>Set up the <strong>social sharing</strong> options.</li>
					<li>Insert your <strong>Google Analytics</strong> code.</li>
					<li>Insert your <strong>custom CSS</strong> styles.</li>
					<li>Handle some other details of the theme.</li>
				</ol>
				<p>As said before, all the options have a detailed description, so just load the page and set up what you need.</p>
				<hr />
				<p><strong>Navigation Options:</strong></p>
				<p>The <a href="<?php echo home_url(); ?>/wp-admin/admin.php?page=pk_navigation_options">PK Options -> Navigation Options</a> are used to control some aspects of the theme navigation menus. Basically through these options you can exclude some pages from the menus and activate/deactivate the footer navigation. Note that the excluded pages will be hidden only if you don't use the WordPress menu manager to create your menus. We highly recommend to use the WordPress menu manager to build your theme menus: <a href="<?php echo home_url(); ?>/wp-admin/nav-menus.php">Appearance -> Menus</a>. More information about how to create your theme menus are available <a href="#pk_help_theme_menus">here</a>.</p>
				<hr />
				<p><strong>Blog Options:</strong></p>
				<p>The <a href="<?php echo home_url(); ?>/wp-admin/admin.php?page=pk_blog_options">PK Options -> Blog Options</a> are used to control the main blog settings and functionalities. If you need to make any change to the main blog this is the only place where to look at.</p>
				<hr />
				<p><strong>Blog Archive Options:</strong></p>
				<p>The <a href="<?php echo home_url(); ?>/wp-admin/admin.php?page=pk_blog_archive_options">PK Options -> Blog Archive Options</a> are used to control the blog archive settings and functionalities. The blog archive, for those that don't know what it is, basically is the list of blog posts that belong exclusively to a certain category, tag, author, date, etc. Its output is identical to the main blog. We've created a dedicated set of options for the blog archive because you may want to display it in a different way than the main blog.</p>
				<p>The blog archive, for example, is generated when you directly add to the theme menu a blog category (not a page) through the WordPress menu editor, when you click on a category or tag link or when you click on any of the meta information available below each blog list item. The <a href="<?php echo home_url(); ?>/wp-admin/admin.php?page=pk_blog_archive_options">PK Options -> Blog Archive Options</a> are multi-profile, giving you limitless options when customizing your theme. More info about how the options profiles work are available in the next section of this help page.</p>
				<hr />
				<p><strong>Works Archive Options:</strong></p>
				<p>The <a href="<?php echo home_url(); ?>/wp-admin/admin.php?page=pk_works_archive_options">PK Options -> Works Archive Options</a> are used to control the works archive settings and functionalities. This theme, in addition to the default posts and pages, includes the <strong><i>Works</i></strong> post type for your works and portfolio pages. Your works, like the blog posts, can be grouped/categorized under the custom <strong><i>Works Categories</i></strong> taxonomy. When the theme shows a specific works category (when you click on any category of the categories filter of the works pages), WordPress doesn't use a static page created by you to show the contents. For this reason, also if the contents are the same, the theme won't dispone of the specific page settings to control the creation of the output like for the static pages; in this situation the theme will use the <a href="<?php echo home_url(); ?>/wp-admin/admin.php?page=pk_works_archive_options">PK Options -> Works Archive Options</a> instead of the specific page options to generate the same type of output.</p>
				<p><u>Example:</u></p>
				<p>Let's say that you create 10 works posts, 5 under the "Web Design" category and 5 under the "Print" category.</p>
				<p>You create a new page called "Portfolio" to display all these works, so you select the <strong><i>Works</i></strong> page template, you set all the available options (select the works posts to display, the sidebar type, etc.) and save. This new page will load all these works and it will display them accordingly to the page options required by the selected page template.</p>
				<p>The "Portfolio" page, in few words, is a container with a dedicated set of options that are needed to display the selected works posts.</p>
				<p>If you decide, instead of creating a static page to display these works, to add the "Web Design" category directly to the menu, the theme won't dispone of the page options to determine the way to display these contents. So, in this situation, the theme will use the <a href="<?php echo home_url(); ?>/wp-admin/admin.php?page=pk_works_archive_options">PK Options -> Works Archive Options</a> settings to build the output and display all the "Web Design" works in the same way as if they were included in a <strong><i>Works</i></strong> page. This will happen anytime the theme will load some contents that aren't included in a specific page.</p>
				<p>Basically, to build your portfolio, you can completely avoid to use the page templates and add all your categories of works to the menu and handle their display options through the <a href="<?php echo home_url(); ?>/wp-admin/admin.php?page=pk_works_archive_options">PK Options -> Works Archive Options</a></p>.
				<p>The <a href="<?php echo home_url(); ?>/wp-admin/admin.php?page=pk_works_archive_options">PK Options -> Works Archive Options</a> are multi-profile, giving you limitless options when customizing your theme. More info about how the options profiles work are available in the next section of this help page.</p>
				<hr />
				<p><strong>Search Options:</strong></p>
				<p>The <a href="<?php echo home_url(); ?>/wp-admin/admin.php?page=pk_search_options">PK Options -> Search Options</a> are used to control the search settings and functionalities. If you need to change the way the search results are displayed this is the only place where to look at.</p>
				<hr />
				<p><strong>Skin Options:</strong></p>
				<p>The <a href="<?php echo home_url(); ?>/wp-admin/admin.php?page=pk_skin_options">PK Options -> Skin Options</a> are used to control the visual of the theme. Through these options you can <strong>select the main CSS skin of the theme, set a custom logo and set the colors of the custom media players</strong>. The <a href="<?php echo home_url(); ?>/wp-admin/admin.php?page=pk_skin_options">PK Options -> Skin Options</a> are multi-profile, giving you limitless options when customizing your theme. More info about how the options profiles work are available in the next section of this help page.</p>
				<hr />
				<p><strong>Footer Options:</strong></p>
				<p>The <a href="<?php echo home_url(); ?>/wp-admin/admin.php?page=pk_footer_options">PK Options -> Footer Options</a> are used to control the footer area of the theme. Through these options you can control the footer copyright text, add unlimited icons linking to your social profiles pages and manage the layout of the footer widgets area. The <a href="<?php echo home_url(); ?>/wp-admin/admin.php?page=pk_footer_options">PK Options -> Footer Options</a> are multi-profile, giving you limitless options when customizing your theme. More info about how the options profiles work are available in the next section of this help page.</p>
				</td>
			</tr>
		</tbody>
	</table>
	<p><a href="#pk_help_table_of_contents">Top</a></p>
	<br />
	<table id="pk_help_options_profiles" class="widefat">
		<thead class="pk_admin_clickable_head">
			<tr>
				<th scope="row" colspan="2">Options Profiles</th>
			</tr>
		</thead>
		<tbody class="pk_admin_tggleable_body">
			<tr class="pk_admin_tr">
				<td>
				<p>This theme offers an outstanding and innovative way to customize your contents. This is possible thanks to the <strong><i>Options Profiles</i></strong>.</p>
				<p>You have probably noticed in some of the theme options pages a profiles manager at the very top of the page, above the options. Thanks to this feature you can duplicate the entire set of options and apply the new sets to specific contents of your theme.</p>
				<p>The theme options that support this feature are the following:</p>
				<ol>
					<li><a href="<?php echo home_url(); ?>/wp-admin/admin.php?page=pk_blog_archive_options">PK Options -> Blog Archive Options</a></li>
					<li><a href="<?php echo home_url(); ?>/wp-admin/admin.php?page=pk_works_archive_options">PK Options -> Works Archive Options</a></li>
					<li><a href="<?php echo home_url(); ?>/wp-admin/admin.php?page=pk_skin_options">PK Options -> Skin Options</a></li>
					<li><a href="<?php echo home_url(); ?>/wp-admin/admin.php?page=pk_footer_options">PK Options -> Footer Options</a></li>
				</ol>
				<p>Each of these options pages handle the profiles in a different way, for a different goal. Let's see what is possible to achieve creating new profiles with any of these options sets:</p>
				<p><strong>Blog Archive Options:</strong></p>
				<p><img src="<?php echo PK_THEME_DIR.'/parkerandkent2011/functions/admin/help/images/slug.jpg'; ?>" style="margin:10px 0px; display:block; border:solid 1px #dddddd;"/><small><strong><i>Image 1</i></strong></small></p>
				<p>The profiles of this options page allow you to associate a new set of options to a specific blog category or tag. In this way you can completely customize the visual of a selected blog category or tag when in the blog archive.</p>
				<p>To do this you just need to create a new profile by adding the category/tag slug (Image 1) into the <strong><i>Add new profile</i></strong> field. Once you click on the <strong><i>Add</i></strong> button the new profile will be created and three new panels will appear. These new panels will let you load and delete the existing profiles and set the active profile for the theme. The <strong><i>Active profile</i></strong> will be the one used by default by the theme for the contents that don't have a custom profile associated to them.</p>
				<p>Everything is very easy and intuitive. Think a profile as a dedicated set of options for a specific category/tag of the blog. With the new sets of options you can, for example, set a different skin or a different footer to a specific category, use smaller or bigger featured images for the posts list, activate and deactivate some specific meta and so on.</p>
				<p>If you want to receive more information or for any doubt about this feature don't esitate to contact us, we'll be glad to answer to any question.</p>
				<hr />
				<p><strong>Works Archive Options:</strong></p>
				<p>The profiles of this options page allow you to associate a new set of options to a specific works category. In this way you can completely customize the visual of a selected works category when in the works archive.</p>
				<p>To do this you just need to create a new profile by adding the works category slug (Image 1) into the <strong><i>Add new profile</i></strong> field. Once you click on the <strong><i>Add</i></strong> button the new profile will be created and three new panels will appear. These new panels will let you load and delete the existing profiles and set the active profile for the theme. The <strong><i>Active profile</i></strong> will be the one used by default by the theme for the contents that don't have a custom profile associated to them.</p>
				<p>Everything is very easy and intuitive. Think a profile as a dedicated set of options for a specific category of the works. With the new sets of options you can, for example, set a different skin or a different footer to a specific category, use a different grid layout, activate and deactivate some specific meta and so on.</p>
				<p>If you want to receive more information or for any doubt about this feature don't esitate to contact us, we'll be glad to answer to any question.</p>
				<hr />
				<p><strong>Skin Options:</strong></p>
				<p>The profiles of this options page allow you to create an unlimited number of custom skin profiles that can be named as you wish. The skin profiles don't need to be named with a specific category/tag slug, because they can be associated in a indipendent way to any content of the theme.</p>
				<p><img src="<?php echo PK_THEME_DIR.'/parkerandkent2011/functions/admin/help/images/custom_skin.jpg'; ?>" style="margin:10px 0px; display:block; border:solid 1px #dddddd;"/><small><strong><i>Image 2</i></strong></small></p>
				<p>You can set a specific skin profile wherever you find an option that requires a skin selection. For example, in every page/post edit screen, there is a box (Image 2) where to select a skin for that specific content. Everything is very easy and intuitive and well explained below each one of these options, we're sure you won't have any problem understanding this incredible feature we have created for you.</p>
				<p>If you want to receive more information or for any doubt about this feature don't esitate to contact us, we'll be glad to answer to any question.</p>
				<hr />
				<p><strong>Footer Options:</strong></p>
				<p>The profiles of this options page allow you to create an unlimited number of custom footer profiles that can be named as you wish. The footer profiles don't need to be named with a specific category/tag slug, because they can be associated in a indipendent way to any content of the theme.</p>
				<p><img src="<?php echo PK_THEME_DIR.'/parkerandkent2011/functions/admin/help/images/custom_footer.jpg'; ?>" style="margin:10px 0px; display:block; border:solid 1px #dddddd;"/><small><strong><i>Image 3</i></strong></small></p>
				<p>You can set a specific footer profile wherever you find an option that requires a footer selection. For example, in every page/post edit screen, there is a box (Image 3) where to select a footer for that specific content (in a contact poage, for example, you probably want a footer that doesn't have a contact form widget, so for that page you can create a specific footer with a different set of widgets). Everything is very easy and intuitive and well explained below each one of these options, we're sure you won't have any problem understanding this incredible feature we have created for you.</p>
				<p>If you want to receive more information or for any doubt about this feature don't esitate to contact us, we'll be glad to answer to any question.</p>
				</td>
			</tr>
		</tbody>
	</table>
	<p><a href="#pk_help_table_of_contents">Top</a></p>
	<br />
	<table id="pk_help_theme_menus" class="widefat">
		<thead class="pk_admin_clickable_head">
			<tr>
				<th scope="row" colspan="2">Theme Menus</th>
			</tr>
		</thead>
		<tbody class="pk_admin_tggleable_body">
			<tr class="pk_admin_tr">
				<td>
				<p>This theme supports the WordPress menu system introduced with the WordPress 3.0 version. If you intend to use the WordPress menu manager instead of the page hierarchy for the theme navigations, just go to the <a href="<?php echo home_url(); ?>/wp-admin/nav-menus.php">Appareance -> Menus</a> page to create your menus. </p>
				<p><img src="<?php echo PK_THEME_DIR.'/parkerandkent2011/functions/admin/help/images/screen_options.jpg'; ?>" style="margin:10px 0px; display:block; border:solid 1px #dddddd;"/><small><strong><i>Image 4</i></strong></small></p>
				<p>As first operation click on the <strong><i>Screen Options</i></strong> button (Image 4) on the top-right corner of the page; be sure to check all the needed options to be able to add any content to your custom menus. Then you have to create two menus (or just one if you want) that you have to associate to the theme navigations.</p>
				<p><img src="<?php echo PK_THEME_DIR.'/parkerandkent2011/functions/admin/help/images/theme_locations.jpg'; ?>" style="margin:10px 0px; display:block; border:solid 1px #dddddd;"/><small><strong><i>Image 5</i></strong></small></p>
				<p>Once you have created your menus a new panel will appear, the <strong><i>Theme Locations</i></strong> one (Image 5). In this panel you have to associate your custom menus to the theme navigations (<strong><i>Main Menu</i></strong> and <strong><i>Footer Menu</i></strong>) and save. Reload your theme and enjoy your new menus!</p>
				<p>Note that the <strong><i>Footer Menu</i></strong> supports only one level, while the <strong><i>Main Menu</i></strong> can have unlimited sub levels.</p>
				</td>
			</tr>
		</tbody>
	</table>
	<p><a href="#pk_help_table_of_contents">Top</a></p>
	<br />
	<table id="pk_help_post_types" class="widefat">
		<thead class="pk_admin_clickable_head">
			<tr>
				<th scope="row" colspan="2">Post Types</th>
			</tr>
		</thead>
		<tbody class="pk_admin_tggleable_body">
			<tr class="pk_admin_tr">
				<td>
				<p>This theme has 2 custom post types, each of these post types has its own dedicated taxonomy. The default posts are dedicated for the blog only, as well its <strong><i>Categories</i></strong> taxonomy.</p>
				<p>The custom post types are:</p>
				<ol>
					<li>Slides (categorized under the <strong><i>Slides Categories</i></strong> taxonomy).</li>
					<li>Works (categorized under the <strong><i>Works Categories</i></strong> taxonomy).</li>
				</ol>
				<p>Each custom post type is dedicated to one or more page templates, in this way you can keep your contents well organized.</p>
				<p><img src="<?php echo PK_THEME_DIR.'/parkerandkent2011/functions/admin/help/images/sortable_contents.jpg'; ?>" style="margin:10px 0px; display:block; border:solid 1px #dddddd;"/><small><strong><i>Image 6</i></strong></small></p>
				<p>The custom post types can be manually ordered thanks to a drag&amp;drop functionality (Image 6), in this way you can sort your contents as you prefer. The blog posts are ordered by date only.</p>
				<p>The slides posts are loaded by the <strong><i>Top Slider Page</i></strong> page template and by the <strong><i>Slider (slides)</i></strong> (check the <strong><i>Shortcodes Manager</i></strong> for the sliders creation). When you create a <strong><i>Top Slider Page</i></strong> page you can add through the page options all the slides posts that you want to show in that page: you can select your recent slides as well entire <strong><i>Slides Categories</i></strong>. The <strong><i>Top Slider Page</i></strong> page template can load many different contents in its slider: recent blog posts, recent works, recent slides or a selected category of any of the available post types.</p>
				<p>The works posts are loaded by the <strong><i>Works - (1, 2, 3, 4, 5, 6) Column/s</i></strong> page templates. When you create a <strong><i>Works - (1, 2, 3, 4, 5, 6) Column/s</i></strong> page you will add through the page options all the single works posts that you want to show in that page, as well entire <strong><i>Works Categories</i></strong>.</p>
				</td>
			</tr>
		</tbody>
	</table>
	<p><a href="#pk_help_table_of_contents">Top</a></p>
	<br />
	<table id="pk_help_page_templates" class="widefat">
		<thead class="pk_admin_clickable_head">
			<tr>
				<th scope="row" colspan="2">Page Templates</th>
			</tr>
		</thead>
		<tbody class="pk_admin_tggleable_body">
			<tr class="pk_admin_tr">
				<td>
				<p>This theme has 8 custom page templates. Each template can be full width or have a sidebar, on the left or on the right.</p>
				<p><img src="<?php echo PK_THEME_DIR.'/parkerandkent2011/functions/admin/help/images/page_templates.jpg'; ?>" style="margin:10px 0px; display:block; border:solid 1px #dddddd;"/><small><strong><i>Image 7</i></strong></small></p>
				<p>When you add a new page to your theme, the first thing to do is to select the page template that you want to use from the <strong><i>Page Attributes</i></strong> panel (Image 7).</p>
				<p>Once you select a page template, depending on which one you have selected, a specific options panel will appear below the page editor. These options panels group all the options that are needed by the selected page template. Each option has a detailed description below its input field to help you during the page creation.</p>
				<p>When you create your first page, click on the <strong><i>Screen Options</i></strong> button located in the top-right corner. A panel will slide down and then check all the available checkboxes in order to activate all the options panels (WordPress by default doesn't show all the panels that you may need).</p>
				</td>
			</tr>
		</tbody>
	</table>
	<p><a href="#pk_help_table_of_contents">Top</a></p>
	<br />
	<table id="pk_help_shortcodes" class="widefat">
		<thead class="pk_admin_clickable_head">
			<tr>
				<th scope="row" colspan="2">Shortcodes</th>
			</tr>
		</thead>
		<tbody class="pk_admin_tggleable_body">
			<tr class="pk_admin_tr">
				<td>
				<p>A shortcode is literally a "short code" that you can insert into any post or page (and even into a widget) that will display some kind of content. Think of it like an abbreviation for a larger amount of code. All shortcodes go between brackets, like this: [shortcode attribute="value"]content[/shortcode].</p>
				<p>Shortcodes are very useful to display complex contents with a very little effort, just think about galleries, sliders, media players, etc. If you had to write a slider HTML markup and some php functions every time you need one of them, that would be a very complex and time consuming operation. So, that's why in this theme we've created something like 100 base shortcodes to create any type of complex content, from a button that opens a lightbox gallery to a full working multi media slider.</p>
				<p>The funny thing is that, when the contents to generate are particularly complex or customizable, also typing a shortcode could be a tricky thing, especially if it requires many attributes to be set. Some of the most common problems with shortcodes are missing or broken attributes, missing closing tags, etc. All these errors result in a wrongly generated output and time needed to identify and fix the errors.</p>
				<p>For all these reasons we have created a <strong><i>Shortcodes Manager</i></strong> that will be a very time saver when you will need to add a shortcode within your contents. The <strong><i>Shortcodes Manager</i></strong> is present in every page/post edit screen, it is basically a collection of input forms that will help you to select and set all the options needed, by simply using a nice visual interface. Once you have set all the required options, you will only need to click on the <strong><i>Generate Shortcode</i></strong> button to automatically insert the complete and correct shortcode into your page/post content.</p>
				<p>All this awesomeness was not enough for us. At a certain point we started to think that some shortcodes could be needed more than once (some buttons, image formats, boxes, etc.) during the contents creation and so, because some of them require many fields to be filled, we have created a <strong><i>Shortocdes Library</i></strong>. Basically every time you generate a shortcode, the system will ask you if you want to save it into the <strong><i>Shortocdes Library</i></strong> to make it available in a second moment. So, for example, if you create a large pink button that makes a specific action, you can save it with the "Pink Button" label and then, when you need to use it again, you will just need to select it from the <strong><i>Shortocdes Library</i></strong> (integrated into the <strong><i>Shortcodes Manager</i></strong>) and the system will complete all the fields for you and the shortcode will be ready to be created again.</p>
				<p>Well, everything is easier to be used than to be explained, so just check the <strong><i>Shortcodes Manager</i></strong> when creating your first page/post and you will find it very intuitive.</p>
				<hr />
				<p><strong>Shortcodes not included within the <strong><i>Shortcodes Manager</i></strong></strong></p>
				<p>Some shortcodes, for their simplicity, aren't included in the <strong><i>Shortcodes Manager</i></strong>. Here they are:</p>
				<ol>
					<li><strong>[pk_get_size]</strong> - Use it within the pages, columns, widget areas, etc. to discover the width of the available space. This shortcode is useful to correctly size elements like images, videos, etc. that you want to include in any area of the theme.</li>
					<li><strong>[pk_add_this]</strong> - This shortcode generates the sharing system of the theme. Use it where the sharing system isn't included by default, eg. standard pages.</li>
				</ol>
				</td>
			</tr>
		</tbody>
	</table>
	<p><a href="#pk_help_table_of_contents">Top</a></p>
	<br />
	<table id="pk_help_snippets_library" class="widefat">
		<thead class="pk_admin_clickable_head">
			<tr>
				<th scope="row" colspan="2">The Snippets Library</th>
			</tr>
		</thead>
		<tbody class="pk_admin_tggleable_body">
			<tr class="pk_admin_tr">
				<td>
				<p>The <strong><i>Snippets Library</i></strong> is another utility that we have created with the goal of making your life easier when working with this theme. It is a very simple utility, it basically allows you to name and save pieces of HTML markup, texts, shortcodes compositions, etc. to make them available again in the future. Many times happens that we need to reuse on different pages/posts the same piece of HTML or textual content and in those cases the only way is to go back and forth copying and pasting the content manually. In these situations the <strong><i>Snippets Library</i></strong> becomes a life saver.</p>
				<p>All the saved contents will be available in every page/post edit screen and by simply clicking on the <strong><i>Send to Editor</i></strong> button our saved contents will be automatically added to the page/post editor. Then, could be very cool to share with other users your snippets (especially the shortcodes compositions, in fact we have created some cool ones for you). Share them or take the snippets of other users and save them in your <strong><i>Snippets Library</i></strong> for your personal collection.</p>
				</td>
			</tr>
		</tbody>
	</table>
	<p><a href="#pk_help_table_of_contents">Top</a></p>
	<br />
	<table id="pk_help_sidebars_widgets" class="widefat">
		<thead class="pk_admin_clickable_head">
			<tr>
				<th scope="row" colspan="2">Sidebars and Widgets</th>
			</tr>
		</thead>
		<tbody class="pk_admin_tggleable_body">
			<tr class="pk_admin_tr">
				<td>
				<p>This theme has 41 widgets ready to be used into your sidebars.</p>
				<p><img src="<?php echo PK_THEME_DIR.'/parkerandkent2011/functions/admin/help/images/drag_and_drop_widgets.jpg'; ?>" style="margin:10px 0px; display:block; border:solid 1px #dddddd;"/><small><strong><i>Image 8</i></strong></small></p>
				<p>To add any widget to the theme go to the <a href="<?php echo home_url(); ?>/wp-admin/widgets.php">Appareance -> Widgets</a> page and drag the widgets that you want to activate over one of the theme sidebars (Image 8), then just fill in the requested fields and save. There are 17 default sidebars (each one dedicated to a specific section/content of the theme), 6 of them are dedicated for the footer widgets area (if you set up additional footer profiles you will have 6 additional sidebars for each footer profile).</p>
				<p><img src="<?php echo PK_THEME_DIR.'/parkerandkent2011/functions/admin/help/images/custom_sidebar.jpg'; ?>" style="margin:10px 0px; display:block; border:solid 1px #dddddd;"/><small><strong><i>Image 9</i></strong></small></p>
				<p>You can create a custom sidebar for each page/post of the theme (if you need to associate an unique set of widgets to a specific content). The custom sidebars creation is a very easy task. You will find a little option box in every page/post edit screen (Image 9), where you will only need to make a click to create a custom sidebar for that content. After saving the page/post you will find a new sidebar in the <a href="<?php echo home_url(); ?>/wp-admin/widgets.php">Appareance -> Widgets</a> page, named with the parent page/post title to be easily recognizable.</p>
				<p>If you intend to use any of the theme shortcodes within a text widget, be sure to have checked the checkbox below the text widget textarea.</p>
				</td>
			</tr>
		</tbody>
	</table>
	<p><a href="#pk_help_table_of_contents">Top</a></p>
	<br />
	<table id="pk_help_custom_hooks" class="widefat">
		<thead class="pk_admin_clickable_head">
			<tr>
				<th scope="row" colspan="2">Custom Hooks</th>
			</tr>
		</thead>
		<tbody class="pk_admin_tggleable_body">
			<tr class="pk_admin_tr">
				<td>
				<p>If you are comfortable with WordPress hooks, we have placed 82 custom hooks in the theme templates to give you the option to easily place custom HTML almost everywhere. For the full hooks list check the pk2011_itis/functions.php file.</p>
				</td>
			</tr>
		</tbody>
	</table>
	<p><a href="#pk_help_table_of_contents">Top</a></p>
	<br />
	<table id="pk_help_branding_admin" class="widefat">
		<thead class="pk_admin_clickable_head">
			<tr>
				<th scope="row" colspan="2">Branding the Admin</th>
			</tr>
		</thead>
		<tbody class="pk_admin_tggleable_body">
			<tr class="pk_admin_tr">
				<td>
				<p>If you want to brand the theme administration with your logo and with a custom footer just follow these steps:</p>
				<ol>
					<li>Open with your preferred editor the pk2011_itis/functions.php file.</li>
					<li>Uncomment the following lines: 43, 44, 69 and save the file. Reloading the admin you will see the WordPress logo and footer being replaced.</li>
					<li>To set your logo for the log in screen and for the admin header replace the images login_logo.png and admin_logo.png located into the pk2011_itis/parkerandkent2011/images/admin/ folder. If you prefer, you can simply set a new path for the logo images in the functions.php file by editing the following lines: 50, 59.</li>
					<li>To set a custom text for the footer admin simply edit the line 73, always into the functions.php file.</li>
				</ol>
				</td>
			</tr>
		</tbody>
	</table>
	<p><a href="#pk_help_table_of_contents">Top</a></p>
	<br />
	<table id="pk_help_theme_translation" class="widefat">
		<thead class="pk_admin_clickable_head">
			<tr>
				<th scope="row" colspan="2">Theme Translation</th>
			</tr>
		</thead>
		<tbody class="pk_admin_tggleable_body">
			<tr class="pk_admin_tr">
				<td>
				<p>This theme is localized. This means that it is translation-ready. To translate, follow these instructions:</p>
				<ol>
					<li>If not already done, convert your WordPress install to the preferred language. Check this <a href="http://codex.wordpress.org/WordPress_in_Your_Language">link</a> for more info.</li>
					<li>Download <a href="http://www.poedit.net/download.php">PoEdit</a> or a similar software.</li>
					<li>Open the file pk_text_domain_front.po located in the pk2011_itis/translate/theme/ folder using PoEdit.</li>
					<li>Enter a translation for each string.</li>
					<li>Once you have finished, save the file twice, once as .po and once as .mo, the filename should be your language code. Example: it_IT.po and it_IT.mo for Italian. See the language codes <a href="http://codex.wordpress.org/WordPress_in_Your_Language">here</a>.</li>
					<li>Save and upload these files in the same folder where the original pk_text_domain_front.po is located. Your theme will be localized.</li>
				</ol>
				<p>You can translate the back-end too, you will find the pk_text_domain.po file to translate the theme admin in the pk2011_itis/translate/admin/ folder. Just repeat the steps explained for the front-end translation.</p>
				</td>
			</tr>
		</tbody>
	</table>
	<p><a href="#pk_help_table_of_contents">Top</a></p>
	<?php
	$pk_options_manager_instance -> pk_close_div();
	
}

function pk_add_theme_help_page() {

	add_menu_page('PK '.__('Theme Help', 'pk_text_domain'), 'PK '.__('Theme Help', 'pk_text_domain'), 'level_10', 'pk_theme_help', 'pk_create_theme_help_page');

}

add_action('admin_menu', 'pk_add_theme_help_page');

function pk_load_theme_help_page_on_activation() {

	wp_redirect('admin.php?page=pk_theme_help');
	
}

if (isset($_GET['activated']) && is_admin()){
	
	pk_load_theme_help_page_on_activation();
	
}

?>