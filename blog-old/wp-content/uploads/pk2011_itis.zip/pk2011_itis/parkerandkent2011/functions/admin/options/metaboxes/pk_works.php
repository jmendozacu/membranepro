<?php

$pk_works_metaboxes = array();

$pk_works_metaboxes['title'] = __('Options', 'pk_text_domain');

$pk_works_metaboxes['options'][0] = array(
										
										'top_slider_background_color' 	=> array('title' => __('Top slider background color:', 'pk_text_domain'), 'type' => 'color', 'helper' => __('Click on this field to pick a color to use for the color animation of the top slider background. This option needs to be set only if you add this work to a top slider.', 'pk_text_domain')),
										'top_slider_thumbnail_label' 	=> array('title' => __('Top slider thumbnail label (optional):', 'pk_text_domain'), 'type' => 'text', 'helper' => __('Type here a text to show on the top slider thumbnail. This option needs to be set only if you add this work to a top slider.', 'pk_text_domain'))
											
										);
$pk_works_metaboxes['values'][0] = array(
										
										'top_slider_background_color' 	=> '',
										'top_slider_thumbnail_label' 	=> ''
											
										);

$pk_works_metaboxes['options'][1] = array(
										
										'intro' 				=> array('title' => __('Intro:', 'pk_text_domain'), 'type' => 'text_area', 'rows' => '3', 'helper' => __('This textarea is dedicated for the <i>Intro</i> area of the page. Type here your HTML markup.', 'pk_text_domain')),
										'sidebar' 				=> array('title' => __('Sidebar:', 'pk_text_domain'), 'type' => 'select', 'values' => array('none', 'left', 'right'), 'labels' => array(__('None', 'pk_text_domain'), __('Left', 'pk_text_domain'), __('Right', 'pk_text_domain')), 'helper' => __('Select the position of the sidebar for this post. Select <i>None</i> if you want a full width layout.', 'pk_text_domain')),
										'show_comments_sidebar' => array('title' => __('Show comments sidebar:', 'pk_text_domain'), 'type' => 'radio_group', 'values' => array('true', 'false'), 'labels' => array(__('Yes', 'pk_text_domain'), __('No', 'pk_text_domain')), 'helper' => __('Select <i>Yes</i> to display the comments sidebar on the right of the comments. The comments sidebar will be shown only if you\'ve selected the full width layout (<i>None</i>) in the previous <i>Sidebar</i> option.', 'pk_text_domain')),
										'show_author_info' 		=> array('title' => __('Show author info:', 'pk_text_domain'), 'type' => 'radio_group', 'values' => array('true', 'false'), 'labels' => array(__('Yes', 'pk_text_domain'), __('No', 'pk_text_domain')), 'helper' => __('Select <i>Yes</i> to display the author info at the end of the post.', 'pk_text_domain')),
										'show_add_this' 		=> array('title' => __('Show AddThis.com share buttons:', 'pk_text_domain'), 'type' => 'radio_group', 'values' => array('true', 'false'), 'labels' => array(__('Yes', 'pk_text_domain'), __('No', 'pk_text_domain')), 'helper' => __('Select <i>Yes</i> to display the <a href="http://www.addthis.com/" title="www.addthis.com">AddThis.com</a> built in theme sharing functionalities at the end of the post.', 'pk_text_domain'))
											
										);
$pk_works_metaboxes['values'][1] = array(
										
										'intro' 				=> '',
										'sidebar' 				=> 'right',
										'show_comments_sidebar' => 'true',
										'show_author_info' 		=> 'true',
										'show_add_this' 		=> 'true'
											
										);

$pk_works_metaboxes['options'][2] = array(
										
										'use_featured_image' 	=> array('title' => __('Use featured image:', 'pk_text_domain'), 'type' => 'radio_group', 'values' => array('true', 'false'), 'labels' => array(__('Yes', 'pk_text_domain'), __('No', 'pk_text_domain')), 'helper' => __('This option is used to tell the theme which image to use for the thumbnail of this post. If you select <i>Yes</i> the theme will use the featured image in every place where an image is required (eg. the covers of the audio/video players). Also if you select <i>No</i> and decide to set a specific image where required, we suggest to always set a featured image, because it will show in the <i>Sort Works</i> admin page list making the sorting easier (each work will be visually recognizable).', 'pk_text_domain')),
										'use_custom_players' 	=> array('title' => __('Use custom players:', 'pk_text_domain'), 'type' => 'radio_group', 'values' => array('true', 'false'), 'labels' => array(__('Yes', 'pk_text_domain'), __('No', 'pk_text_domain')), 'helper' => __('Select <i>Yes</i> if you want to use the custom Flash AS3 video player for YouTube videos.', 'pk_text_domain')),
										'auto_play' 			=> array('title' => __('Player auto play:', 'pk_text_domain'), 'type' => 'radio_group', 'values' => array('true', 'false'), 'labels' => array(__('Yes', 'pk_text_domain'), __('No', 'pk_text_domain')), 'helper' => __('Select <i>Yes</i> if you want your video/audio players to auto start on page load.', 'pk_text_domain')),
										'thumb_icon' 			=> array('title' => __('Thumbnail icon:', 'pk_text_domain'), 'type' => 'select', 'values' => array('', 'pk_page_icon', 'pk_link_icon', 'pk_play_icon', 'pk_zoom_icon'), 'labels' => array(__('None', 'pk_text_domain'), __('Page', 'pk_text_domain'), __('Link', 'pk_text_domain'), __('Play', 'pk_text_domain'), __('Zoom', 'pk_text_domain')), 'helper' => __('Select the icon type that you want to show for the roll over on the thumbnail. The selected icon will be used only if the thumbnail is an image.', 'pk_text_domain')),
										'thumb_style' 			=> array('title' => __('Thumbnail style:', 'pk_text_domain'), 'type' => 'select', 'values' => array('16/9', '4/3', 'portrait', 'square', 'auto', 'custom'), 'labels' => array(__('16/9', 'pk_text_domain'), __('4/3', 'pk_text_domain'), __('Portrait', 'pk_text_domain'), __('Square', 'pk_text_domain'), __('Auto Height', 'pk_text_domain'), __('Custom Height', 'pk_text_domain')), 'helper' => __('Select the style of the thumbnail.', 'pk_text_domain')),
										'thumb_height' 			=> array('title' => __('Thumbnail height:', 'pk_text_domain'), 'type' => 'slider', 'min' => '0', 'max' => '920', 'uom' => 'px', 'helper' => __('Set the thumbnails height. This setting will be used only if you\'ve set the thumbnail style to <i>Custom Height</i>.', 'pk_text_domain')),
										'thumb_action' 			=> array('title' => __('Thumbnail action:', 'pk_text_domain'), 'type' => 'select', 'values' => array('', 'link', 'lightbox'), 'labels' => array(__('None', 'pk_text_domain'), __('Link to post', 'pk_text_domain'), __('Open lightbox gallery', 'pk_text_domain')), 'helper' => __('Select the action for the click on the thumbnail. This setting will be used only if the thumbnail is an image.', 'pk_text_domain')),
										'thumb_type' 			=> array('title' => __('Thumbnail type:', 'pk_text_domain'), 'type' => 'metabox_selector', 'values' => array('pk_metabox_div_2', 'pk_metabox_div_3,image', 'pk_metabox_div_4,video', 'pk_metabox_div_5,audio', 'pk_metabox_div_6,swf'), 'labels' => array(__('-- Select --', 'pk_text_domain'), __('Image', 'pk_text_domain'), __('Video', 'pk_text_domain'), __('Audio', 'pk_text_domain'), __('Swf', 'pk_text_domain')), 'helper' => __('Select the thumbnail type for this post.', 'pk_text_domain'))
										
										);
$pk_works_metaboxes['values'][2] = array(
										
										'use_featured_image' 	=> 'true',
										'use_custom_players' 	=> 'true',
										'auto_play' 			=> 'false',
										'thumb_icon' 			=> '',
										'thumb_style' 			=> '16/9',
										'thumb_height' 			=> '0',
										'thumb_action' 			=> '',
										'thumb_type' 			=> 'pk_metabox_div_2'
										
										);

$pk_works_metaboxes['options'][3] = array(
										
										'image' 				=> array('title' => __('Image:', 'pk_text_domain'), 'type' => 'image', 'preview' => 'false', 'helper' => __('Type in the image URL to use for the thumbnail or click on the <i>Image</i> button to insert an image from the media library. If you\'ve selected <i>Yes</i> for the previous <i>Use featured image</i> option you can just leave this field empty.', 'pk_text_domain'))
										
										);
$pk_works_metaboxes['values'][3] = array(
										
										'image' 				=> ''
										
										);

$pk_works_metaboxes['options'][4] = array(
										
										'video' 				=> array('title' => __('Video:', 'pk_text_domain'), 'type' => 'video', 'preview' => 'false', 'helper' => __('Select the video type that you want to use for the thumbnail.', 'pk_text_domain'))
										
										);
$pk_works_metaboxes['values'][4] = array(
										
										'video' 				=> ''
										
										);

$pk_works_metaboxes['options'][5] = array(
										
										'audio' 				=> array('title' => __('Audio:', 'pk_text_domain'), 'type' => 'audio', 'preview' => 'false', 'helper' => __('Type in the cover and the audio URLs that you want to use for the thumbnail or click on the buttons to select them from the media library.', 'pk_text_domain'))
										
										);
$pk_works_metaboxes['values'][5] = array(
										
										'audio' 				=> ''
										
										);

$pk_works_metaboxes['options'][6] = array(
										
										'swf' 					=> array('title' => __('Swf:', 'pk_text_domain'), 'type' => 'file', 'preview' => 'false', 'helper' => __('Type in the swf URL to use for the thumbnail or click on the <i>File</i> button to insert an swf file from the media library.', 'pk_text_domain')),
										'swf_flashvars' 		=> array('title' => __('SwfObject flashvars object:', 'pk_text_domain'), 'type' => 'text_area', 'rows' => '2', 'helper' => __('Type in the SWFObject flashvars object. Use only double quotes within this field.', 'pk_text_domain')),
										'swf_params' 			=> array('title' => __('SwfObject params object:', 'pk_text_domain'), 'type' => 'text_area', 'rows' => '2', 'helper' => __('Type in the SWFObject params object. Use only double quotes within this field.', 'pk_text_domain')),
										'swf_fp_version' 		=> array('title' => __('SwfObject flash player version:', 'pk_text_domain'), 'type' => 'text', 'helper' => __('Type in the flash player version that you want to use for your swf file.', 'pk_text_domain'))
										
										);
$pk_works_metaboxes['values'][6] = array(
										
										'swf' 					=> '',
										'swf_flashvars' 		=> '{}',
										'swf_params' 			=> '{allowfullscreen:"true", allowscriptaccess:"always", wmode:"transparent", menu:"false"}',
										'swf_fp_version' 		=> '9.0.0'
										
										);

$pk_works_metaboxes['options'][7] = array(
										
										'lightbox_gallery' 		=> array('title' => __('Lightbox gallery manager:', 'pk_text_domain'), 'type' => 'lightbox_gallery_manager', 'helper' => __('By clicking on the <i>Add Item</i> button you can add as many items (images, videos, etc.) as you need (check the <a href="http://www.no-margin-for-errors.com/projects/prettyphoto-jquery-lightbox-clone/" title="prettyPhoto official website">prettyPhoto official website</a> for more info about what kind of contents you can load). By dragging and dropping you can modify the order of your gallery items. The lightbox gallery of this post can be opened by clicking on the works grid thumbnails (check the previous <i>Thumbnail action</i> option). You can also open this gallery by using a button or a cover image in your post (check the <i>Buttons</i> and the <i>Images</i> panels of the Shortcodes Manager). The <i>Gallery id</i> field is automatically filled with the post id, it is needed to identify the gallery and we suggest to keep this value as it is also because there isn\'t any reason to change it. You can also open this gallery with a normal link within your post, check the prettyPhoto official website linked before for more info about how to open prettyPhoto by using a link tag.', 'pk_text_domain'))
										
										);
$pk_works_metaboxes['values'][7] = array(
										
										'lightbox_gallery' 		=> ''
										
										);
									
if (class_exists('pk_metaboxes_generator') && !isset($pk_works_metaboxes_instance)) {
	
	$pk_works_metaboxes_instance = new pk_metaboxes_generator($pk_works_metaboxes, 'works', 'pk_');
	
}

?>