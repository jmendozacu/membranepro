<?php

$pk_works_archive_skin_profiles = get_option('pk_skin_options_profiles');
$pk_works_archive_skin_profiles_values = array('');
$pk_works_archive_skin_profiles_labels = array(__('-- Select --', 'pk_text_domain'));

for ($i = 0; $i < count($pk_works_archive_skin_profiles); $i++) {
	
	$pk_works_archive_skin_profiles_values[] = $pk_works_archive_skin_profiles[$i];
	$pk_works_archive_skin_profiles_labels[] = (($pk_works_archive_skin_profiles[$i] == 'default') ? 'Default' : stripslashes(base64_decode($pk_works_archive_skin_profiles[$i])));
	
}

$pk_works_archive_footer_profiles = get_option('pk_footer_options_profiles');
$pk_works_archive_footer_profiles_values = array('');
$pk_works_archive_footer_profiles_labels = array(__('-- Select --', 'pk_text_domain'));

for ($i = 0; $i < count($pk_works_archive_footer_profiles); $i++) {
	
	$pk_works_archive_footer_profiles_values[] = $pk_works_archive_footer_profiles[$i];
	$pk_works_archive_footer_profiles_labels[] = (($pk_works_archive_footer_profiles[$i] == 'default') ? 'Default' : stripslashes(base64_decode($pk_works_archive_footer_profiles[$i])));
	
}

$pk_works_archive_options = array();

$pk_works_archive_options[0]['title'] = __('Works Archive Options', 'pk_text_domain');
$pk_works_archive_options[0]['options'] = array(
										
										'works_archive_layout'					=> array('title' => __('Layout:', 'pk_text_domain'), 'type' => 'select', 'values' => array('1', '2', '3', '4', '5', '6'), 'labels' => array(__('One Column', 'pk_text_domain'), __('Two Columns', 'pk_text_domain'), __('Three Columns', 'pk_text_domain'), __('Four Columns', 'pk_text_domain'), __('Five Columns', 'pk_text_domain'), __('Six Columns', 'pk_text_domain')), 'helper' => __('Select the layout to use for the works archive pages.', 'pk_text_domain')),
										'works_archive_sidebar' 				=> array('title' => __('Sidebar:', 'pk_text_domain'), 'type' => 'select', 'values' => array('none', 'left', 'right'), 'labels' => array(__('None', 'pk_text_domain'), __('Left', 'pk_text_domain'), __('Right', 'pk_text_domain')), 'helper' => __('Select the position of the sidebar for the works archive pages. Select <i>None</i> if you want a full width layout.', 'pk_text_domain')),
										'works_archive_order_by' 				=> array('title' => __('Sort by:', 'pk_text_domain'), 'type' => 'radio_group', 'values' => array('date', 'menu_order', 'comment_count'), 'labels' => array(__('Date', 'pk_text_domain'), __('Custom order (manual sorting)', 'pk_text_domain'), __('Comments count (popular)', 'pk_text_domain')), 'helper' => __('Select the order criteria to apply to the works archive pages. By selecting the <i>Custom order (manual sorting)</i> option the works will be displayed in the order they appear in the <i>Sort Works</i> page.', 'pk_text_domain')),
										'works_archive_show_categories_filter' 	=> array('title' => __('Show categories filter:', 'pk_text_domain'), 'type' => 'radio_group', 'values' => array('true', 'false'), 'labels' => array(__('Yes', 'pk_text_domain'), __('No', 'pk_text_domain')), 'helper' => __('Select <i>Yes</i> to display a categories filter/switcher on top of the works grids.', 'pk_text_domain')),
										'works_archive_show_read_more' 			=> array('title' => __('Show read more button:', 'pk_text_domain'), 'type' => 'radio_group', 'values' => array('true', 'false'), 'labels' => array(__('Yes', 'pk_text_domain'), __('No', 'pk_text_domain')), 'helper' => __('Select <i>Yes</i> to display the read more buttons below each works grid item. The 5 and 6 columns layouts can\'t show the read more buttons, for these layouts this setting will be ignored.', 'pk_text_domain')),
										'works_archive_posts_per_page' 			=> array('title' => __('Posts per page:', 'pk_text_domain'), 'type' => 'slider', 'min' => '1', 'max' => '30', 'uom' => __('posts', 'pk_text_domain'), 'helper' => __('Select the max number of works to load for each works archive page. (If you set 9 and you select the 3 columns layout you will obtain a 3x3 grid).', 'pk_text_domain')),
										'works_archive_skin_profile' 			=> array('title' => __('Skin profile:', 'pk_text_domain'), 'type' => 'select', 'values' => $pk_works_archive_skin_profiles_values, 'labels' => $pk_works_archive_skin_profiles_labels, 'helper' => __('Select the skin profile to use for the works archive pages. If you don\'t select a specific skin profile will be used the current active profile of the <i>Skin Options</i> page. You can set for each page of the theme a different skin or simply use everywhere the default one that you have set.', 'pk_text_domain')),
										'works_archive_footer_profile' 			=> array('title' => __('Footer profile:', 'pk_text_domain'), 'type' => 'select', 'values' => $pk_works_archive_footer_profiles_values, 'labels' => $pk_works_archive_footer_profiles_labels, 'helper' => __('Select the footer profile to use for the works archive pages. If you don\'t select a specific footer profile will be used the current active profile of the <i>Footer Options</i> page. You can set for each page of the theme a different footer or simply use everywhere the default one that you have set.', 'pk_text_domain'))
										
										);
$pk_works_archive_options[0]['values'] = array(
										
										'works_archive_layout' 					=> '3',
										'works_archive_sidebar' 				=> 'none',
										'works_archive_order_by' 				=> 'date',
										'works_archive_show_categories_filter' 	=> 'true',
										'works_archive_show_read_more' 			=> 'true',
										'works_archive_posts_per_page' 			=> '9',
										'works_archive_skin_profile' 			=> '',
										'works_archive_footer_profile' 			=> ''
									
										);
$pk_works_archive_options[0]['save_button'] = true;

if (class_exists('pk_options_generator') && !isset($pk_works_archive_options_instance)) {
	
	add_option('pk_works_archive_options_profiles', array('default'));
	add_option('pk_works_archive_options_current_profile', 'default');
	add_option('pk_works_archive_options_active_profile', 'default');
	
	$pk_works_archive_options_instance = new pk_options_generator($pk_works_archive_options, 'level_10', __('Works Archive Options', 'pk_text_domain'), 'pk_general_options', 'pk_works_archive_options', 'pk_works_archive_options', 'pk_', array('pk_works_archive_options_profiles', 'pk_works_archive_options_current_profile', 'pk_works_archive_options_active_profile', 'pk_works_archive_options'));
	
	/*global $pk_dashboard_options;
	
	$pk_profiles = get_option('pk_works_archive_options_profiles');
	
	foreach ($pk_profiles as $k => $v) {
	
		$pk_dashboard_options['pk_works_archive_options_'.$v] = sprintf(__('Other Archives Options - %s', 'pk_text_domain'), (($v == 'default') ? __('Default', 'pk_text_domain') : stripslashes(base64_decode($v))));
	
	}*/
	
}

?>