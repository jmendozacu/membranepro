<?php

if (!class_exists('pk_shortcodes_manager_generator')) {
	
	class pk_shortcodes_manager_generator {
		
		private $options;
		private $type;
		private $suffix;
		
		function pk_shortcodes_manager_generator($options = array(), $type = '', $suffix = '') {
			
			$this -> options = $options;
			$this -> type = $type;
			$this -> suffix = $suffix;
			
			add_action('admin_init', array(&$this, 'pk_init_metabox'));
			
		}
		
		function pk_init_metabox() {
			
			if (function_exists('add_meta_box')) {
				
				add_meta_box(strtolower($this -> suffix.str_replace(' ', '_', $this -> options['title'])), 'PK '.$this -> options['title'], array(&$this, 'pk_create_metabox'), $this -> type, 'normal', 'high');
				
				add_action('wp_ajax_save_shortcode', array(&$this, 'pk_ajax_save_shortcode'));
				add_action('wp_ajax_nopriv_save_shortcode', array(&$this, 'pk_ajax_save_shortcode'));
				add_action('wp_ajax_delete_shortcode', array(&$this, 'pk_ajax_delete_shortcode'));
				add_action('wp_ajax_nopriv_delete_shortcode', array(&$this, 'pk_ajax_delete_shortcode'));
			
			}
			
		}
		
		function pk_ajax_save_shortcode() {
			
			if (!isset($_POST['saved_shortcodes_data']) || !is_array($_POST['saved_shortcodes_data'])) {
				
				echo 'error';
				die();
				
			}
			
			$options = get_option('pk_options');
			
			if (!in_array('pk_shortcodes_library', $options)) {
				
				$options[] = 'pk_shortcodes_library';
				update_option('pk_options', $options);
				
			}
			
			$shortcodes_library = get_option('pk_shortcodes_library');
			$saved_shortcode_data = $_POST['saved_shortcodes_data'];
			
			if (isset($shortcodes_library[$saved_shortcode_data[0]][$saved_shortcode_data[1]]) && $_POST['update'] == 'false') {
				
				echo __('A shortcode using this name already exists. Do you want to replace it?', 'pk_text_domain');
				die();
				
			}
			
			$shortcodes_library[$saved_shortcode_data[0]][$saved_shortcode_data[1]]['type'] = $saved_shortcode_data[0];
			$shortcodes_library[$saved_shortcode_data[0]][$saved_shortcode_data[1]]['name'] = $saved_shortcode_data[1];
			$shortcodes_library[$saved_shortcode_data[0]][$saved_shortcode_data[1]]['fields'] = $saved_shortcode_data[2];
			$shortcodes_library[$saved_shortcode_data[0]][$saved_shortcode_data[1]]['values'] = $saved_shortcode_data[3];
			
			if ($shortcodes_library == get_option('pk_shortcodes_library') || update_option('pk_shortcodes_library', $shortcodes_library)) {
				
				echo 'success,'.urlencode(json_encode($shortcodes_library[$saved_shortcode_data[0]][$saved_shortcode_data[1]]));
				
			} else {
				
				echo 'error';
				
			}
			
			die();
			
		}
		
		function pk_ajax_delete_shortcode() {
			
			$shortcodes_library = get_option('pk_shortcodes_library');
			$deleted_shortcode_data = json_decode(urldecode($_POST['deleted_shortcode_data']), true);
			
			if (isset($shortcodes_library[$deleted_shortcode_data['type']][$deleted_shortcode_data['name']])) {
				
				unset($shortcodes_library[$deleted_shortcode_data['type']][$deleted_shortcode_data['name']]);
				
				if (update_option('pk_shortcodes_library', $shortcodes_library)) {
				
					echo 'success';
					
				} else {
					
					echo 'error';
					
				}
				
			} else {
				
				echo 'error';
				
			}
			
			die();
			
		}
		
		function pk_create_metabox() {
			
			global $pk_shortcodes_manager_instance;
			
			$shortcodes_library = get_option('pk_shortcodes_library');
			
			$pk_shortcodes_manager_instance -> pk_open_div();
			
			echo '
		<div id="pk_admin_saving_shortcode" class="pk_admin_messages updated">
			<p><strong>'.__('Saving shortcode...', 'pk_text_domain').'</strong></p>
		</div>
		<div id="pk_admin_success_saving_shortcode" class="pk_admin_messages updated">
			<p><strong>'.__('Shortcode saved!', 'pk_text_domain').'</strong></p>
		</div>
		<div id="pk_admin_error_saving_shortcode" class="pk_admin_messages updated">
			<p><strong>'.__('Error saving the shortcode, please try again.', 'pk_text_domain').'</strong></p>
		</div>
		<div id="pk_admin_deleting_shortcode" class="pk_admin_messages updated">
			<p><strong>'.__('Deleting shortcode...', 'pk_text_domain').'</strong></p>
		</div>
		<div id="pk_admin_success_deleting_shortcode" class="pk_admin_messages updated">
			<p><strong>'.__('Shortcode deleted!', 'pk_text_domain').'</strong></p>
		</div>
		<div id="pk_admin_error_deleting_shortcode" class="pk_admin_messages updated">
			<p><strong>'.__('Error deleting the shortcode, please try again.', 'pk_text_domain').'</strong></p>
		</div>';
			
			for ($i = 0; $i < count($this -> options['options']); $i++) {
				
				$pk_shortcodes_manager_instance -> pk_open_shortcodes_manager_div($this -> suffix.$this -> options['type'][$i]);
				
				if (count($this -> options['options'][$i]) > 0) {
					
					$pk_shortcodes_manager_instance -> pk_open_table($this -> options['type'][$i]);
					
					if ($this -> options['add_library'][$i] == true) {
						
						echo '
					<tr id="pk_admin_tr_delete_shortcode_'.$this -> options['type'][$i].'" class="pk_admin_tr_delete_shortcode">
						<th scope="row" class="pk_admin_th">
							<h4>'.__('Delete shortcode:', 'pk_text_domain').'</h4>
						</th>
						<td class="pk_admin_td">
							<p><select id="pk_admin_delete_shortcodes_list_'.$this -> options['type'][$i].'" class="pk_admin_delete_shortcodes_list pk_admin_input_select">
								<option value="select" selected="selected">'.__('-- Select --', 'pk_text_domain').'</option>';
						
						if (isset($shortcodes_library[$this -> options['type'][$i]]) && count($shortcodes_library[$this -> options['type'][$i]]) > 0) {
						
							foreach ($shortcodes_library[$this -> options['type'][$i]] as $k => $v) {
								
								echo '
									<option value="'.urlencode(json_encode($v)).'">'.stripslashes($k).'</option>';
								
							}
						
						}
						
						echo '
							</select>
							<input class="pk_sc_delete_shortcode_button pk_admin_button button" type="button" value="'.__('Delete', 'pk_text_domain').'" data-message="'.__('Are you sure you want to delete this shortcode?', 'pk_text_domain').'" data-type="'.$this -> options['type'][$i].'" /></p>
							<p class="pk_admin_helper"><strong class="pk_admin_helper_strong">? </strong>Select the shortcode that you want to delete.</p>
						</td>
					</tr>
					<tr id="pk_admin_tr_load_shortcode_'.$this -> options['type'][$i].'" class="pk_admin_tr_load_shortcode">
						<th scope="row" class="pk_admin_th">
							<h4>'.__('Load shortcode:', 'pk_text_domain').'</h4>
						</th>
						<td class="pk_admin_td">
							<p>
								<select id="pk_admin_load_shortcodes_list_'.$this -> options['type'][$i].'" class="pk_admin_load_shortcodes_list pk_admin_input_select">
									<option value="select" selected="selected">'.__('-- Select --', 'pk_text_domain').'</option>';
						
						if (isset($shortcodes_library[$this -> options['type'][$i]]) && count($shortcodes_library[$this -> options['type'][$i]]) > 0) {
						
							foreach ($shortcodes_library[$this -> options['type'][$i]] as $k => $v) {
								
								echo '
										<option value="'.urlencode(json_encode($v)).'">'.stripslashes($k).'</option>';
								
							}
						
						}
						
						echo '
									</select>
								</p>
								<p class="pk_admin_helper"><strong class="pk_admin_helper_strong">? </strong>Select the shortcode that you want to load.</p>
							</td>
						</tr>';
						
					}
						
					$count = 0;
				
					foreach ($this -> options['options'][$i] as $k => $v) {
					
						if ($this -> options['options'][$i][$k]['title'] != '') {
										
							$pk_shortcodes_manager_instance -> pk_add_title($this -> options['options'][$i][$k]['title'], ($count % 2) ? true : false, ($this -> options['options'][$i][$k]['type'] == 'metabox_selector') ? true : false);
										
						}
						
						$default = $this -> options['values'][$i][$k];
						$helper = $this -> options['options'][$i][$k]['helper'];
				
						switch ($this -> options['options'][$i][$k]['type']) {
					
							case 'text':
								
								$pk_shortcodes_manager_instance -> pk_add_input_text_field($this -> suffix.$k, $default, $helper);
								break;
								
							case 'text_area':
								
								$pk_shortcodes_manager_instance -> pk_add_input_text_area($this -> suffix.$k, $default, $this -> options['options'][$i][$k]['rows'], $helper);
								break;
								
							case 'radio_group':
								
								$pk_shortcodes_manager_instance -> pk_add_input_radio_group($this -> suffix.$k, $this -> options['options'][$i][$k]['values'], $this -> options['options'][$i][$k]['labels'], $default, $helper);
								break;
								
							case 'select':
								
								$pk_shortcodes_manager_instance -> pk_add_input_select($this -> suffix.$k, false, $this -> options['options'][$i][$k]['values'], $this -> options['options'][$i][$k]['labels'], $default, $helper);
								break;
								
							case 'metabox_selector':
								
								$pk_shortcodes_manager_instance -> pk_add_input_select($this -> suffix.$k, true, $this -> options['options'][$i][$k]['values'], $this -> options['options'][$i][$k]['labels'], $default, $helper);
								break;
								
							case 'color':
								
								$pk_shortcodes_manager_instance -> pk_add_input_color($this -> suffix.$k, $default, $helper);
								break;
								
							case 'slider':
								
								$pk_shortcodes_manager_instance -> pk_add_input_slider($this -> suffix.$k, $default, $this -> options['options'][$i][$k]['min'], $this -> options['options'][$i][$k]['max'], $this -> options['options'][$i][$k]['uom'], $helper);
								break;
								
							case 'image':
							case 'video':
							case 'audio':
							case 'file':
								
								$pk_shortcodes_manager_instance -> pk_add_input_file($this -> suffix.$k, $default, $this -> options['options'][$i][$k]['type'], $this -> options['options'][$i][$k]['preview'], $helper);
								break;
								
							case 'category':
						
								$pk_shortcodes_manager_instance -> pk_add_input_category($this -> suffix.$k, $default, $this -> options['options'][$i][$k]['taxonomy'], $helper);
								break;
								
							case 'categories':
						
								$pk_shortcodes_manager_instance -> pk_add_input_categories($this -> suffix.$k, $default, $this -> options['options'][$i][$k]['taxonomy'], $helper);
								break;
								
							case 'page':
						
								$pk_shortcodes_manager_instance -> pk_add_input_page($this -> suffix.$k, $default, $this -> options['options'][$i][$k]['post_type'], $helper);
								break;
								
							case 'pages':
						
								$pk_shortcodes_manager_instance -> pk_add_input_pages($this -> suffix.$k, $default, $this -> options['options'][$i][$k]['post_type'], $helper);
								break;
								
							case 'post':
						
								$pk_shortcodes_manager_instance -> pk_add_input_post($this -> suffix.$k, $default, $this -> options['options'][$i][$k]['post_type'], $helper);
								break;
								
							case 'posts':
						
								$pk_shortcodes_manager_instance -> pk_add_input_posts($this -> suffix.$k, $default, $this -> options['options'][$i][$k]['post_type'], $helper);
								break;
								
							case 'tag':
						
								$pk_shortcodes_manager_instance -> pk_add_input_tag($this -> suffix.$k, $default, $helper);
								break;
								
							case 'tags':
						
								$pk_shortcodes_manager_instance -> pk_add_input_tags($this -> suffix.$k, $default, $helper);
								break;
								
						}
					
						$count++;
				
					}
					
					$pk_shortcodes_manager_instance -> pk_close_table();
					
				}
				
				if ($this -> options['add_buttons'][$i] == true) {
					
					$pk_shortcodes_manager_instance -> pk_add_buttons($this -> options['type'][$i], $this -> options['add_library'][$i]);
					
				}
				
				$pk_shortcodes_manager_instance -> pk_close_shortcodes_manager_div();
				
			}
			
			$pk_shortcodes_manager_instance -> pk_open_shortcodes_manager_div($this -> suffix.'save_shortcode');
			
			echo '
			<table cellspacing="0" id="pk_sc_table_save_shortcode" class="widefat">
				<tbody>
					<tr class="pk_admin_tr_save_shortcode">
						<th scope="row" class="pk_admin_th">
							<h4>'.__('Save shortcode as:', 'pk_text_domain').'</h4>
						</th>
						<td class="pk_admin_td">
							<p>
								<input class="pk_admin_input_text_field" type="text" name="'.$this -> suffix.'save_shortcode_name" value="" />
								<input class="pk_admin_button button" type="button" id="'.$this -> suffix.'save_shortcode_button" value="'.__('Save', 'pk_text_domain').'" data-message="'.__('Please, enter a name for this shortcode.', 'pk_text_domain').'" />
								<input class="pk_admin_button button" type="button" id="'.$this -> suffix.'close_save_shortcode_button" value="'.__('No, thanks!', 'pk_text_domain').'" />
							</p>
							<p class="pk_admin_helper"><strong class="pk_admin_helper_strong">? </strong>Select an unique and descriptive name for this shortcode (<i>eg. My black button!, My small image!, etc.</i>). All the saved shortcodes will be available in every shortcodes category library to easily reproduce all the shortcodes previously created.</p>
						</td>
					</tr>
				</tbody>
			</table>';

			$pk_shortcodes_manager_instance -> pk_close_shortcodes_manager_div();
			
			$pk_shortcodes_manager_instance -> pk_close_div();
			
		}
		
	}
	
}

?>