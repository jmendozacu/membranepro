<?php

if (!class_exists('pk_metaboxes_generator')) {
	
	class pk_metaboxes_generator {
		
		private $all;
		private $sidebar;
		private $add_custom_sidebar;
		private $add_skin_profiles;
		private $add_footer_profiles;
		private $show_default_sidebar;
		private $options;
		private $type;
		private $suffix;
		
		function pk_metaboxes_generator($options = array(), $type = '', $suffix = '', $add_custom_sidebar = true, $add_skin_profiles = true, $add_footer_profiles = true) {
			
			$this -> all = array();
			$this -> add_custom_sidebar = $add_custom_sidebar;
			$this -> add_skin_profiles = $add_skin_profiles;
			$this -> add_footer_profiles = $add_footer_profiles;
			$this -> show_default_sidebar = 'true';
			$this -> options = $options;
			$this -> type = $type;
			$this -> suffix = $suffix;
			
			add_action('admin_init', array(&$this, 'pk_init_metaboxes'));
			add_action('save_post', array(&$this, 'pk_save_metaboxes_values'));
			
		}
		
		function pk_init_metaboxes() {
			
			if (function_exists('add_meta_box')) {
						
				add_meta_box(strtolower($this -> suffix.$this -> options['title']), 'PK '.$this -> options['title'], array(&$this, 'pk_create_metabox'), $this -> type, 'normal', 'high');
				
				if ($this -> add_custom_sidebar == true && function_exists('register_sidebar')) {
					
					add_meta_box($this -> suffix.'custom_sidebar', 'PK '.__('Custom Sidebar', 'pk_text_domain'), array(&$this, 'pk_create_custom_sidebar_metabox'), $this -> type, 'side', 'low');
				
				}
				
				if ($this -> add_skin_profiles == true) {
					
					add_meta_box($this -> suffix.'skin_profile', 'PK '.__('Skin Profile', 'pk_text_domain'), array(&$this, 'pk_create_skin_profile_metabox'), $this -> type, 'side', 'low');
					
				}
				
				if ($this -> add_footer_profiles == true) {
					
					add_meta_box($this -> suffix.'footer_profile', 'PK '.__('Footer Profile', 'pk_text_domain'), array(&$this, 'pk_create_footer_profile_metabox'), $this -> type, 'side', 'low');
					
				}
				
			}
			
		}
		
		function pk_create_custom_sidebar_metabox() {
			
			global $post;
			
			$pk_custom_sidebars = get_option('pk_custom_sidebars');
			
			if (!is_array($pk_custom_sidebars) || !isset($pk_custom_sidebars[$post -> ID])) {
				
				$this -> sidebar = 'false';
				
			} else {
				
				$this -> sidebar = $pk_custom_sidebars[$post -> ID]['registered'];
				$this -> show_default_sidebar = $pk_custom_sidebars[$post -> ID]['show_default_sidebar'];
				
			}
			
			echo '
	<!-- pk custom sidebar metabox - start -->
	<table cellspacing="0" id="pk_metabox_table_custom_sidebar" class="widefat"><tbody>
		<tr class="pk_admin_tr_special">
			<td class="pk_admin_td">
				<p><strong>'.__('Add custom sidebar for this entry:', 'pk_text_domain').'</strong></p>
				<p><input id="'.$this -> suffix.'create_sidebar_1" class="pk_admin_radio_checkbox" type="radio" name="'.$this -> suffix.'create_sidebar" value="true"'.(($this -> sidebar == 'true') ? ' checked="checked"' : '').' /><label for="'.$this -> suffix.'create_sidebar_1" class="pk_admin_radio_label"> '.__('Yes', 'pk_text_domain').'</label></p>
				<p><input id="'.$this -> suffix.'create_sidebar_2" class="pk_admin_radio_checkbox" type="radio" name="'.$this -> suffix.'create_sidebar" value="false"'.(($this -> sidebar == 'false') ? ' checked="checked"' : '').' /><label for="'.$this -> suffix.'create_sidebar_2" class="pk_admin_radio_label"> '.__('No', 'pk_text_domain').'</label></p>
				<p class="pk_admin_helper"><strong class="pk_admin_helper_strong">? </strong>'.__('Check <i>Yes</i> to register a specific sidebar for this entry.', 'pk_text_domain').'</p>
			</td>
		</tr>
		<tr class="pk_admin_tr_special">
			<td class="pk_admin_td">
				<p><strong>'.__('Show default sidebars:', 'pk_text_domain').'</strong></p>
				<p><input id="'.$this -> suffix.'show_default_sidebar_1" class="pk_admin_radio_checkbox" type="radio" name="'.$this -> suffix.'show_default_sidebar" value="true"'.(($this -> show_default_sidebar == 'true') ? ' checked="checked"' : '').' /><label for="'.$this -> suffix.'show_default_sidebar_1" class="pk_admin_radio_label"> '.__('Yes', 'pk_text_domain').'</label></p>
				<p><input id="'.$this -> suffix.'show_default_sidebar_2" class="pk_admin_radio_checkbox" type="radio" name="'.$this -> suffix.'show_default_sidebar" value="false"'.(($this -> show_default_sidebar == 'false') ? ' checked="checked"' : '').' /><label for="'.$this -> suffix.'show_default_sidebar_2" class="pk_admin_radio_label"> '.__('No', 'pk_text_domain').'</label></p>
				<p class="pk_admin_helper"><strong class="pk_admin_helper_strong">? </strong>'.__('Check <i>No</i> if you want to show only the custom sidebar registered for this entry. This setting will be evaluated only if a custom sidebar has been registered.', 'pk_text_domain').'</p>
			</td>
		</tr>
	</tbody></table>
	<!-- pk custom sidebar metabox - end -->
	
';
			
		}
		
		function pk_create_skin_profile_metabox() {
			
			global $post;
			
			$profiles = get_option('pk_skin_options_profiles');
			$selected = get_post_meta($post -> ID, '_pk_skin_profile', true);
			
			if (!in_array($selected, $profiles)) {
				
				$selected = '';
				
			}
			
			echo '
	<!-- pk skin profile metabox - start -->
	<table cellspacing="0" id="pk_metabox_table_skin_profile" class="widefat"><tbody>
		<tr class="pk_admin_tr_special">
			<td class="pk_admin_td">
				<p><strong>'.__('Select the skin profile for this entry:', 'pk_text_domain').'</strong></p>';
			
			echo '
				<p>
					<select class="pk_admin_input_select" name="'.$this -> suffix.'selected_skin_profile">
						<option value="">'.__('-- Select --', 'pk_text_domain').'</option>';
			
			for ($i = 0; $i < count($profiles); $i++) {
				
				if ($profiles[$i] == $selected) {
					
					$selected_string = ' selected="selected"';
					
				} else {
					
					$selected_string = '';
					
				}
				
				echo '
						<option value="'.$profiles[$i].'"'.$selected_string.'>'.(($profiles[$i] == 'default') ? 'Default' : stripslashes(base64_decode($profiles[$i]))).'</option>';
				
			}
			
			echo '
					</select>
				</p>
				<p class="pk_admin_helper"><strong class="pk_admin_helper_strong">? </strong>'.__('You can create more skin profiles in the <i>Skin Options</i> page. You can create and set a different skin for each page or post of the theme. The default one <i>(Skin Options > Active Profile)</i> is automatically set by the system.', 'pk_text_domain').'</p>
			</td>
		</tr>
	</tbody></table>
	<!-- pk skin profile metabox - end -->
	
';
					
		}
		
		function pk_create_footer_profile_metabox() {
			
			global $post;
			
			$profiles = get_option('pk_footer_options_profiles');
			$selected = get_post_meta($post -> ID, '_pk_footer_profile', true);
			
			if (!in_array($selected, $profiles)) {
				
				$selected = '';
				
			}
			
			echo '
	<!-- pk footer profile metabox - start -->
	<table cellspacing="0" id="pk_metabox_table_footer_profile" class="widefat"><tbody>
		<tr class="pk_admin_tr_special">
			<td class="pk_admin_td">
				<p><strong>'.__('Select the footer profile for this entry:', 'pk_text_domain').'</strong></p>';
			
			echo '
				<p>
					<select class="pk_admin_input_select" name="'.$this -> suffix.'selected_footer_profile">
						<option value="">'.__('-- Select --', 'pk_text_domain').'</option>';
			
			for ($i = 0; $i < count($profiles); $i++) {
				
				if ($profiles[$i] == $selected) {
					
					$selected_string = ' selected="selected"';
					
				} else {
					
					$selected_string = '';
					
				}
				
				echo '
						<option value="'.$profiles[$i].'"'.$selected_string.'>'.(($profiles[$i] == 'default') ? 'Default' : stripslashes(base64_decode($profiles[$i]))).'</option>';
				
			}
			
			echo '
					</select>
				</p>
				<p class="pk_admin_helper"><strong class="pk_admin_helper_strong">? </strong>'.__('You can create more footer profiles in the <i>Footer Options</i> page. You can create and set a different footer for each page or post of the theme. The default one <i>(Footer Options > Active Profile)</i> is automatically set by the system.', 'pk_text_domain').'</p>
			</td>
		</tr>
	</tbody></table>
	<!-- pk footer profile metabox - end -->
	
';
			
		}
		
		function pk_create_metabox() {
			
			global $post, $pk_metaboxes_manager_instance;
			
			$this -> all = get_post_meta($post -> ID, '_pk_meta', true);
			
			$pk_metaboxes_manager_instance -> pk_open_div();
			$pk_metaboxes_manager_instance -> pk_open_form($this -> type, $post -> ID);
			
			for ($i = 0; $i < count($this -> options['options']); $i++) {
				
				$pk_metaboxes_manager_instance -> pk_open_table($i);
			
				$count = 0;
			
				foreach ($this -> options['options'][$i] as $k => $v) {
				
					if ($this -> options['options'][$i][$k]['title'] != '') {
									
						$pk_metaboxes_manager_instance -> pk_add_title($this -> options['options'][$i][$k]['title'], ($count % 2) ? true : false, ($this -> options['options'][$i][$k]['type'] == 'metabox_selector') ? true : false);
									
					}
					
					$value = (isset($this -> all[$k]) && is_array($this -> all)) ? stripslashes(urldecode($this -> all[$k])) : false;
					$default = $this -> options['values'][$i][$k];
					$helper = $this -> options['options'][$i][$k]['helper'];
			
					switch ($this -> options['options'][$i][$k]['type']) {
				
						case 'lightbox_gallery_manager':
							
							$pk_metaboxes_manager_instance -> pk_add_input_lightbox_gallery_manager($this -> suffix.$k, ($value) ? $value : $default, $helper);
							break;
							
						case 'text':
							
							$pk_metaboxes_manager_instance -> pk_add_input_text_field($this -> suffix.$k, ($value) ? $value : $default, $helper);
							break;
							
						case 'text_area':
							
							$pk_metaboxes_manager_instance -> pk_add_input_text_area($this -> suffix.$k, ($value) ? $value : $default, $this -> options['options'][$i][$k]['rows'], $helper);
							break;
							
						case 'radio_group':
							
							$pk_metaboxes_manager_instance -> pk_add_input_radio_group($this -> suffix.$k, $this -> options['options'][$i][$k]['values'], $this -> options['options'][$i][$k]['labels'], ($value) ? $value : $default, $helper);
							break;
							
						case 'select':
							
							$pk_metaboxes_manager_instance -> pk_add_input_select($this -> suffix.$k, false, $this -> options['options'][$i][$k]['values'], $this -> options['options'][$i][$k]['labels'], ($value) ? $value : $default, $helper);
							break;
							
						case 'metabox_selector':
							
							$pk_metaboxes_manager_instance -> pk_add_input_select($this -> suffix.$k, true, $this -> options['options'][$i][$k]['values'], $this -> options['options'][$i][$k]['labels'], ($value) ? $value : $default, $helper);
							break;
							
						case 'color':
							
							$pk_metaboxes_manager_instance -> pk_add_input_color($this -> suffix.$k, ($value) ? $value : $default, $helper);
							break;
							
						case 'slider':
							
							$pk_metaboxes_manager_instance -> pk_add_input_slider($this -> suffix.$k, ($value) ? $value : $default, $this -> options['options'][$i][$k]['min'], $this -> options['options'][$i][$k]['max'], $this -> options['options'][$i][$k]['uom'], $helper);
							break;
							
						case 'image':
						case 'video':
						case 'audio':
						case 'file':
							
							$pk_metaboxes_manager_instance -> pk_add_input_file($this -> suffix.$k, ($value) ? $value : $default, $this -> options['options'][$i][$k]['type'], $this -> options['options'][$i][$k]['preview'], $helper);
							break;
							
						case 'category':
					
							$pk_metaboxes_manager_instance -> pk_add_input_category($this -> suffix.$k, ($value) ? $value : $default, $this -> options['options'][$i][$k]['taxonomy'], $helper);
							break;
							
						case 'categories':
					
							$pk_metaboxes_manager_instance -> pk_add_input_categories($this -> suffix.$k, ($value) ? $value : $default, $this -> options['options'][$i][$k]['taxonomy'], $helper);
							break;
							
						case 'page':
					
							$pk_metaboxes_manager_instance -> pk_add_input_page($this -> suffix.$k, ($value) ? $value : $default, $this -> options['options'][$i][$k]['post_type'], $helper);
							break;
							
						case 'pages':
					
							$pk_metaboxes_manager_instance -> pk_add_input_pages($this -> suffix.$k, ($value) ? $value : $default, $this -> options['options'][$i][$k]['post_type'], $helper);
							break;
							
						case 'post':
					
							$pk_metaboxes_manager_instance -> pk_add_input_post($this -> suffix.$k, ($value) ? $value : $default, $this -> options['options'][$i][$k]['post_type'], $helper);
							break;
							
						case 'posts':
					
							$pk_metaboxes_manager_instance -> pk_add_input_posts($this -> suffix.$k, ($value) ? $value : $default, $this -> options['options'][$i][$k]['post_type'], $helper);
							break;
							
						case 'tag':
					
							$pk_metaboxes_manager_instance -> pk_add_input_tag($this -> suffix.$k, ($value) ? $value : $default, $helper);
							break;
							
						case 'tags':
					
							$pk_metaboxes_manager_instance -> pk_add_input_tags($this -> suffix.$k, ($value) ? $value : $default, $helper);
							break;
							
					}
				
					$count++;
			
				}
			
				$pk_metaboxes_manager_instance -> pk_close_table();
				
			}
			
			$pk_metaboxes_manager_instance -> pk_close_form();
			$pk_metaboxes_manager_instance -> pk_close_div();
			
		}
		
		function pk_save_metaboxes_values($post_id) {
			
			if (!isset($_POST['pk_'.$this -> type.'_noncename']) || !wp_verify_nonce($_POST['pk_'.$this -> type.'_noncename'], 'pk_'.$post_id.'_noncename')) {
				
				return $post_id;
				
			}
			
			if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
				
				return $post_id;
				 
			}
			
			if ('page' == $_POST['post_type']) {
				
				if (!current_user_can('edit_page', $post_id)) {
					
					return $post_id;
					
				}
				
			} else {
				
				if (!current_user_can('edit_post', $post_id)) {
					
					return $post_id;
					
				}
				
			}
			
			$this -> all = array();
			
			$options = $this -> options;
			
			for ($i = 0; $i < count($options['options']); $i++) {
			
				foreach ($options['options'][$i] as $k => $v) {
					
					if (isset($_POST[$this -> suffix.$k]) && $_POST[$this -> suffix.$k] != '') {
						
						$this -> all[$k] = urlencode($_POST[$this -> suffix.$k]);
						
						if ($options['options'][$i][$k]['type'] == 'video' || $options['options'][$i][$k]['type'] == 'audio') {
							
							if ($options['options'][$i][$k]['type'] == 'video') {
								
								$array = explode(',', $_POST[$this -> suffix.$k]);
								
								if ($array[0] == '0' || $array[2] == '') {
									
									$this -> all[$k] = '';
									
								}
								
							} else {
								
								$array = explode(',', $_POST[$this -> suffix.$k]);
								
								if ($array[1] == '') {
									
									$this -> all[$k] = '';
									
								}
								
							}
							
						}
						
					} else {
						
						$this -> all[$k] = '';
						
					}
			
				}
				
			}
			
			update_post_meta($post_id, '_pk_meta', $this -> all);
			
			if (isset($_POST[$this -> suffix.'create_sidebar'])) {
				
				$pk_custom_sidebars = get_option('pk_custom_sidebars');
				
				if (!is_array($pk_custom_sidebars)) {
					
					$pk_custom_sidebars = array();
					
				}
				
				if ($_POST[$this -> suffix.'create_sidebar'] == 'false' && (!isset($pk_custom_sidebars[$post_id]) || $pk_custom_sidebars[$post_id]['registered'] == 'false')) {
					
				} else {
				
					$pk_custom_sidebars[$post_id]['registered'] = $_POST[$this -> suffix.'create_sidebar'];
					$pk_custom_sidebars[$post_id]['show_default_sidebar'] = $_POST[$this -> suffix.'show_default_sidebar'];
					$pk_custom_sidebars[$post_id]['id'] = $post_id;
				
					update_option('pk_custom_sidebars', $pk_custom_sidebars);
				
				}
				
			}
			
			if (isset($_POST[$this -> suffix.'selected_skin_profile'])) {
				
				update_post_meta($post_id, '_pk_skin_profile', $_POST[$this -> suffix.'selected_skin_profile']);
				
			}
			
			if (isset($_POST[$this -> suffix.'selected_footer_profile'])) {
				
				update_post_meta($post_id, '_pk_footer_profile', $_POST[$this -> suffix.'selected_footer_profile']);
				
			}
			
		}
		
	}
	
}

?>