<?php

$pk_skin_options = array();

$pk_skin_options[0]['title'] = __('Main Theme Skin', 'pk_text_domain');
$pk_skin_options[0]['options'] = array(
										
										'main_theme_skin' 	=> array('title' => __('Select the skin:', 'pk_text_domain'), 'type' => 'skin_select', 'values' => array('pk_skin_light_white.css', 'pk_skin_light_grey.css', 'pk_skin_light_black.css', 'pk_skin_light_sand.css', 'pk_skin_light_orange.css', 'pk_skin_light_yellow.css', 'pk_skin_light_green.css', 'pk_skin_light_blue.css', 'pk_skin_light_purple.css', 'pk_skin_light_red.css', 'pk_skin_dark_white.css', 'pk_skin_dark_grey.css', 'pk_skin_dark_black.css', 'pk_skin_dark_sand.css', 'pk_skin_dark_orange.css', 'pk_skin_dark_yellow.css', 'pk_skin_dark_green.css', 'pk_skin_dark_blue.css', 'pk_skin_dark_purple.css', 'pk_skin_dark_red.css'), 'labels' => array('Skin Light White', 'Skin Light Grey', 'Skin Light Black', 'Skin Light Sand', 'Skin Light Orange', 'Skin Light Yellow', 'Skin Light Green', 'Skin Light Blue', 'Skin Light Purple', 'Skin Light Red', 'Skin Dark White', 'Skin Dark Grey', 'Skin Dark Black', 'Skin Dark Sand', 'Skin Dark Orange', 'Skin Dark Yellow', 'Skin Dark Green', 'Skin Dark Blue', 'Skin Dark Purple', 'Skin Dark Red'), 'helper' => __('Select the CSS skin to use for this profile.', 'pk_text_domain'))
										
										);
$pk_skin_options[0]['values'] = array(
										
										'main_theme_skin' 	=> 'pk_skin_light_white.css'
										
										);
$pk_skin_options[0]['save_button'] = true;

$pk_skin_options[1]['title'] = __('Logo', 'pk_text_domain');
$pk_skin_options[1]['options'] = array(
										
										'logo' 			=> array('title' => __('Logo:', 'pk_text_domain'), 'type' => 'image', 'preview' => 'false', 'helper' => __('Upload or select the logo from the <i>Media Library</i>. This logo will be used for the standard pages.', 'pk_text_domain')),
										'logo_width' 	=> array('title' => __('Logo width:', 'pk_text_domain'), 'type' => 'slider', 'min' => '0', 'max' => '920', 'uom' => 'px', 'helper' => __('Set the logo width.', 'pk_text_domain')),
										'logo_height' 	=> array('title' => __('Logo height:', 'pk_text_domain'), 'type' => 'slider', 'min' => '0', 'max' => '920', 'uom' => 'px', 'helper' => __('Set the logo height.', 'pk_text_domain'))
										
										);
$pk_skin_options[1]['values'] = array(
										
										'logo' 			=> PK_THEME_DIR.'/parkerandkent2011/images/theme/logo.png',
										'logo_width' 	=> '200',
										'logo_height' 	=> '60'
									
										);
$pk_skin_options[1]['save_button'] = true;

$pk_skin_options[2]['title'] = __('Custom Flash Players', 'pk_text_domain');
$pk_skin_options[2]['options'] = array(
										
										'custom_player_c1' 		=> array('title' => __('Player back ground color:', 'pk_text_domain'), 'type' => 'color', 'helper' => __('Click on the color field to pick a new color.', 'pk_text_domain')),
										'custom_player_c2' 		=> array('title' => __('Player buttons color:', 'pk_text_domain'), 'type' => 'color', 'helper' => __('Click on the color field to pick a new color.', 'pk_text_domain')),
										'custom_player_c3' 		=> array('title' => __('Player time label color:', 'pk_text_domain'), 'type' => 'color', 'helper' => __('Click on the color field to pick a new color.', 'pk_text_domain')),
										'custom_player_c4' 		=> array('title' => __('Player controls background color:', 'pk_text_domain'), 'type' => 'color', 'helper' => __('Click on the color field to pick a new color.', 'pk_text_domain')),
										'custom_player_c5' 		=> array('title' => __('Player progress bar color:', 'pk_text_domain'), 'type' => 'color', 'helper' => __('Click on the color field to pick a new color.', 'pk_text_domain')),
										'custom_player_c6' 		=> array('title' => __('Player progress bar back ground color:', 'pk_text_domain'), 'type' => 'color', 'helper' => __('Click on the color field to pick a new color.', 'pk_text_domain')),
										'custom_player_c7' 		=> array('title' => __('Player loading bar color:', 'pk_text_domain'), 'type' => 'color', 'helper' => __('Click on the color field to pick a new color.', 'pk_text_domain')),
										'custom_player_c8' 		=> array('title' => __('Player volume bar color:', 'pk_text_domain'), 'type' => 'color', 'helper' => __('Click on the color field to pick a new color.', 'pk_text_domain')),
										'custom_player_c9' 		=> array('title' => __('Player volume bar back ground color:', 'pk_text_domain'), 'type' => 'color', 'helper' => __('Click on the color field to pick a new color.', 'pk_text_domain')),
										'custom_player_c10' 	=> array('title' => __('Player audio spectrum color:', 'pk_text_domain'), 'type' => 'color', 'helper' => __('Click on the color field to pick a new color.', 'pk_text_domain'))
										
										);
$pk_skin_options[2]['values'] = array(
										
										'custom_player_c1' 		=> '#000000',
										'custom_player_c2' 		=> '#181818',
										'custom_player_c3' 		=> '#111111',
										'custom_player_c4' 		=> '#ffffff',
										'custom_player_c5' 		=> '#181818',
										'custom_player_c6' 		=> '#999999',
										'custom_player_c7' 		=> '#e0e0e0',
										'custom_player_c8' 		=> '#181818',
										'custom_player_c9' 		=> '#e0e0e0',
										'custom_player_c10' 	=> '#ffffff'
										
										);
$pk_skin_options[2]['save_button'] = true;

if (class_exists('pk_options_generator') && !isset($pk_skin_options_instance)) {
	
	add_option('pk_skin_options_profiles', array('default'));
	add_option('pk_skin_options_current_profile', 'default');
	add_option('pk_skin_options_active_profile', 'default');
	
	$pk_skin_options_instance = new pk_options_generator($pk_skin_options, 'level_10', __('Skin Options', 'pk_text_domain'), 'pk_general_options', 'pk_skin_options', 'pk_skin_options', 'pk_', array('pk_skin_options_profiles', 'pk_skin_options_current_profile', 'pk_skin_options_active_profile', 'pk_skin_options'));
	
	/*global $pk_dashboard_options;
	
	$pk_profiles = get_option('pk_skin_options_profiles');
	
	foreach ($pk_profiles as $k => $v) {
	
		$pk_dashboard_options['pk_skin_options_'.$v] = sprintf(__('Skin Light Options - %s', 'pk_text_domain'), (($v == 'default') ? __('Default', 'pk_text_domain') : stripslashes(base64_decode($v))));
	
	}*/
	
}

?>