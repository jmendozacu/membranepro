<?php

$pk_slides_metaboxes = array();

$pk_slides_metaboxes['title'] = __('Options', 'pk_text_domain');

$pk_slides_metaboxes['options'][0] = array(
										
										'top_slider_background_color' 	=> array('title' => __('Top slider background color:', 'pk_text_domain'), 'type' => 'color', 'helper' => __('Click on this field to pick a color to use for the color animation of the top slider background. This option needs to be set only if you add this slide to a top slider.', 'pk_text_domain')),
										'top_slider_thumbnail_label' 	=> array('title' => __('Top slider thumbnail label (optional):', 'pk_text_domain'), 'type' => 'text', 'helper' => __('Type here a text to show on the top slider thumbnail. This option needs to be set only if you add this slide to a top slider.', 'pk_text_domain'))
											
										);
$pk_slides_metaboxes['values'][0] = array(
										
										'top_slider_background_color' 	=> '',
										'top_slider_thumbnail_label' 	=> ''
											
										);

$pk_slides_metaboxes['options'][1] = array(
										
										'use_featured_image' 	=> array('title' => __('Use featured image:', 'pk_text_domain'), 'type' => 'radio_group', 'values' => array('true', 'false'), 'labels' => array(__('Yes', 'pk_text_domain'), __('No', 'pk_text_domain')), 'helper' => __('This option is used to tell the theme which image to use for this slide. If you select <i>Yes</i> the theme will use the featured image in every place where an image is required (eg. the covers of the audio/video players). Also if you select <i>No</i> and decide to set a specific image where required, we suggest to always set a featured image, because it will show in the <i>Sort Slides</i> admin page list making the sorting easier (each slide will be visually recognizable).', 'pk_text_domain')),
										'image_action' 			=> array('title' => __('Image action:', 'pk_text_domain'), 'type' => 'select', 'values' => array('', 'link', 'lightbox'), 'labels' => array(__('None', 'pk_text_domain'), __('Link to URL', 'pk_text_domain'), __('Open lightbox', 'pk_text_domain')), 'helper' => __('Select the action for the click on the slide image. This setting will be used only if the current slide is an image. The <i>Open lightbox</i> action will be used only if this slide is loaded within a <i>Slider (slides)</i>. Check the Shortcodes Manager <i>Slider (slides)</i> panel to understand how to create a slider of slides.', 'pk_text_domain')),
										'image_link_url' 		=> array('title' => __('Image link URL:', 'pk_text_domain'), 'type' => 'text', 'helper' => __('Type in the URL to open when clicking on the slide image. This option will be used only if: you\'ve selected <i>Link to URL</i> for the previous option, the slide is an image and the slide is loaded within a <i>Slider (slides)</i>. Check the Shortcodes Manager <i>Slider (slides)</i> panel to understand how to create a slider of slides.', 'pk_text_domain')),
										'use_custom_players' 	=> array('title' => __('Use custom players:', 'pk_text_domain'), 'type' => 'radio_group', 'values' => array('true', 'false'), 'labels' => array(__('Yes', 'pk_text_domain'), __('No', 'pk_text_domain')), 'helper' => __('Select <i>Yes</i> if you want to use the custom Flash AS3 video player for YouTube videos.', 'pk_text_domain')),
										'auto_play' 			=> array('title' => __('Player auto play:', 'pk_text_domain'), 'type' => 'radio_group', 'values' => array('true', 'false'), 'labels' => array(__('Yes', 'pk_text_domain'), __('No', 'pk_text_domain')), 'helper' => __('Select <i>Yes</i> if you want your video/audio players to auto start on page load.', 'pk_text_domain')),
										'file_type' 			=> array('title' => __('Select file type:', 'pk_text_domain'), 'type' => 'metabox_selector', 'values' => array('pk_metabox_div_1', 'pk_metabox_div_2,image', 'pk_metabox_div_3,video', 'pk_metabox_div_4,audio', 'pk_metabox_div_5,swf'), 'labels' => array(__('-- Select --', 'pk_text_domain'), __('Image', 'pk_text_domain'), __('Video', 'pk_text_domain'), __('Audio', 'pk_text_domain'), __('Swf', 'pk_text_domain')), 'helper' => __('Select the file type for this slide.', 'pk_text_domain'))
										
										);
$pk_slides_metaboxes['values'][1] = array(
										
										'use_featured_image' 	=> 'true',
										'image_action' 			=> '',
										'image_link_url' 		=> '',
										'use_custom_players' 	=> 'true',
										'auto_play' 			=> 'false',
										'file_type' 			=> 'pk_metabox_div_1'
										
										);

$pk_slides_metaboxes['options'][2] = array(
										
										'image' 				=> array('title' => __('Image:', 'pk_text_domain'), 'type' => 'image', 'preview' => 'false', 'helper' => __('Type in the image URL to use for this slide or click on the <i>Image</i> button to insert an image from the media library. If you\'ve selected <i>Yes</i> for the previous <i>Use featured image</i> option you can just leave this field empty.', 'pk_text_domain'))
										
										);
$pk_slides_metaboxes['values'][2] = array(
										
										'image' 				=> ''
										
										);

$pk_slides_metaboxes['options'][3] = array(
										
										'video' 				=> array('title' => __('Video:', 'pk_text_domain'), 'type' => 'video', 'preview' => 'false', 'helper' => __('Select the video type that you want use for this slide.', 'pk_text_domain'))
										
										);
$pk_slides_metaboxes['values'][3] = array(
										
										'video' 				=> ''
										
										);

$pk_slides_metaboxes['options'][4] = array(
										
										'audio' 				=> array('title' => __('Audio:', 'pk_text_domain'), 'type' => 'audio', 'preview' => 'false', 'helper' => __('Type in the cover and the audio URLs that you want to use for this slide or click on the buttons to select them from the media library.', 'pk_text_domain'))
										
										);
$pk_slides_metaboxes['values'][4] = array(
										
										'audio' 				=> ''
										
										);

$pk_slides_metaboxes['options'][5] = array(
										
										'swf' 					=> array('title' => __('Swf:', 'pk_text_domain'), 'type' => 'file', 'preview' => 'false', 'helper' => __('Type in the swf URL to use for this slide or click on the <i>File</i> button to insert an swf file from the media library.', 'pk_text_domain')),
										'swf_flashvars' 		=> array('title' => __('SwfObject flashvars object:', 'pk_text_domain'), 'type' => 'text_area', 'rows' => '2', 'helper' => __('Type in the SWFObject flashvars object. Use only double quotes within this field.', 'pk_text_domain')),
										'swf_params' 			=> array('title' => __('SwfObject params object:', 'pk_text_domain'), 'type' => 'text_area', 'rows' => '2', 'helper' => __('Type in the SWFObject params object. Use only double quotes within this field.', 'pk_text_domain')),
										'swf_fp_version' 		=> array('title' => __('SwfObject flash player version:', 'pk_text_domain'), 'type' => 'text', 'helper' => __('Type in the flash player version that you want to use for your swf file.', 'pk_text_domain'))
										
										);
$pk_slides_metaboxes['values'][5] = array(
										
										'swf' 					=> '',
										'swf_flashvars' 		=> '{}',
										'swf_params' 			=> '{allowfullscreen:"true", allowscriptaccess:"always", wmode:"transparent", menu:"false"}',
										'swf_fp_version' 		=> '9.0.0'
										
										);

if (class_exists('pk_metaboxes_generator') && !isset($pk_slides_metaboxes_instance)) {
	
	$pk_slides_metaboxes_instance = new pk_metaboxes_generator($pk_slides_metaboxes, 'slides', 'pk_', false, false, false);
	
}

?>