<?php

$pk_post_metaboxes = array();

$pk_post_metaboxes['title'] = __('Options', 'pk_text_domain');

$pk_post_metaboxes['options'][0] = array(
										
										'top_slider_background_color' 	=> array('title' => __('Top slider background color:', 'pk_text_domain'), 'type' => 'color', 'helper' => __('Click on this field to pick a color to use for the color animation of the top slider background. This option needs to be set only if you add this post to a top slider.', 'pk_text_domain')),
										'top_slider_thumbnail_label' 	=> array('title' => __('Top slider thumbnail label (optional):', 'pk_text_domain'), 'type' => 'text', 'helper' => __('Type here a text to show on the top slider thumbnail. This option needs to be set only if you add this post to a top slider.', 'pk_text_domain'))
											
										);
$pk_post_metaboxes['values'][0] = array(
										
										'top_slider_background_color' 	=> '',
										'top_slider_thumbnail_label' 	=> ''
											
										);

$pk_post_metaboxes['options'][1] = array(
										
										'intro' 				=> array('title' => __('Intro:', 'pk_text_domain'), 'type' => 'text_area', 'rows' => '3', 'helper' => __('This textarea is dedicated for the <i>Intro</i> area of the page. Type here your HTML markup.', 'pk_text_domain')),
										'sidebar' 				=> array('title' => __('Sidebar:', 'pk_text_domain'), 'type' => 'select', 'values' => array('none', 'left', 'right'), 'labels' => array(__('None', 'pk_text_domain'), __('Left', 'pk_text_domain'), __('Right', 'pk_text_domain')), 'helper' => __('Select the position of the sidebar for this post. Select <i>None</i> if you want a full width layout.', 'pk_text_domain')),
										'show_comments_sidebar' => array('title' => __('Show comments sidebar:', 'pk_text_domain'), 'type' => 'radio_group', 'values' => array('true', 'false'), 'labels' => array(__('Yes', 'pk_text_domain'), __('No', 'pk_text_domain')), 'helper' => __('Select <i>Yes</i> to display the comments sidebar on the right of the comments. The comments sidebar will be shown only if you\'ve selected the full width layout (<i>None</i>) in the previous <i>Sidebar</i> option.', 'pk_text_domain')),
										'show_author_info' 		=> array('title' => __('Show author info:', 'pk_text_domain'), 'type' => 'radio_group', 'values' => array('true', 'false'), 'labels' => array(__('Yes', 'pk_text_domain'), __('No', 'pk_text_domain')), 'helper' => __('Select <i>Yes</i> to display the author info at the end of the post.', 'pk_text_domain')),
										'show_add_this' 		=> array('title' => __('Show AddThis.com share buttons:', 'pk_text_domain'), 'type' => 'radio_group', 'values' => array('true', 'false'), 'labels' => array(__('Yes', 'pk_text_domain'), __('No', 'pk_text_domain')), 'helper' => __('Select <i>Yes</i> to display the <a href="http://www.addthis.com/" title="www.addthis.com">AddThis.com</a> built in theme sharing functionalities at the end of the post.', 'pk_text_domain'))
											
										);
$pk_post_metaboxes['values'][1] = array(
										
										'intro' 				=> '',
										'sidebar' 				=> 'right',
										'show_comments_sidebar' => 'true',
										'show_author_info' 		=> 'false',
										'show_add_this' 		=> 'true'
											
										);

$pk_post_metaboxes['options'][2] = array(
										
										'lightbox_gallery' 		=> array('title' => __('Lightbox gallery manager:', 'pk_text_domain'), 'type' => 'lightbox_gallery_manager', 'helper' => __('By clicking on the <i>Add Item</i> button you can add as many items (images, videos, etc.) as you need (check the <a href="http://www.no-margin-for-errors.com/projects/prettyphoto-jquery-lightbox-clone/" title="prettyPhoto official website">prettyPhoto official website</a> for more info about what kind of contents you can load). By dragging and dropping you can modify the order of your gallery items. The lightbox gallery of this post can be opened by using a button or a cover image in your post (check the <i>Buttons</i> and the <i>Images</i> panels of the Shortcodes Manager). The <i>Gallery id</i> field is automatically filled with the post id, it is needed to identify the gallery and we suggest to keep this value as it is also because there isn\'t any reason to change it. You can also open this gallery with a normal link within your post, check the prettyPhoto official website linked before for more info about how to open prettyPhoto by using a link tag.', 'pk_text_domain'))
										
										);
$pk_post_metaboxes['values'][2] = array(
										
										'lightbox_gallery' 		=> ''
										
										);
										
if (class_exists('pk_metaboxes_generator') && !isset($pk_post_metaboxes_instance)) {
	
	$pk_post_metaboxes_instance = new pk_metaboxes_generator($pk_post_metaboxes, 'post', 'pk_');
	
}

?>