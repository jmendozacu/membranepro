<?php

if (class_exists('pk_shortcodes_manager_generator') && !isset($pk_works_shortcodes_manager_generator_instance)) {
	
	global $pk_shortcodes;
	
	$pk_works_shortcodes_manager_generator_instance = new pk_shortcodes_manager_generator($pk_shortcodes, 'works', 'pk_sc_');
	
}

?>