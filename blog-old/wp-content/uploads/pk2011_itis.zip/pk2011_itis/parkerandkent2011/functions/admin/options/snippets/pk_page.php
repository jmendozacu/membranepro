<?php

if (class_exists('pk_snippets_library_generator') && !isset($pk_page_snippets_library_generator_instance)) {
	
	global $pk_shortcodes;
	
	$pk_page_snippets_library_generator_instance = new pk_snippets_library_generator('page', 'pk_sl_');
	
}

?>