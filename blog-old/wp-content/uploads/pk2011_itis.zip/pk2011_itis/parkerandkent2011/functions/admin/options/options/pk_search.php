<?php

$pk_search_skin_profiles = get_option('pk_skin_options_profiles');
$pk_search_skin_profiles_values = array('');
$pk_search_skin_profiles_labels = array(__('-- Select --', 'pk_text_domain'));

for ($i = 0; $i < count($pk_search_skin_profiles); $i++) {
	
	$pk_search_skin_profiles_values[] = $pk_search_skin_profiles[$i];
	$pk_search_skin_profiles_labels[] = (($pk_search_skin_profiles[$i] == 'default') ? 'Default' : stripslashes(base64_decode($pk_search_skin_profiles[$i])));
	
}

$pk_search_footer_profiles = get_option('pk_footer_options_profiles');
$pk_search_footer_profiles_values = array('');
$pk_search_footer_profiles_labels = array(__('-- Select --', 'pk_text_domain'));

for ($i = 0; $i < count($pk_search_footer_profiles); $i++) {
	
	$pk_search_footer_profiles_values[] = $pk_search_footer_profiles[$i];
	$pk_search_footer_profiles_labels[] = (($pk_search_footer_profiles[$i] == 'default') ? 'Default' : stripslashes(base64_decode($pk_search_footer_profiles[$i])));
	
}

$pk_search_options = array();

$pk_search_options[0]['title'] = __('Search Options', 'pk_text_domain');
$pk_search_options[0]['options'] = array(
										
										'search_sidebar' 				=> array('title' => __('Sidebar:', 'pk_text_domain'), 'type' => 'select', 'values' => array('none', 'left', 'right'), 'labels' => array(__('None', 'pk_text_domain'), __('Left', 'pk_text_domain'), __('Right', 'pk_text_domain')), 'helper' => __('Select the position of the sidebar for the search results. Select <i>None</i> if you want a full width layout.', 'pk_text_domain')),
										'search_skin_profile' 			=> array('title' => __('Skin profile:', 'pk_text_domain'), 'type' => 'select', 'values' => $pk_search_skin_profiles_values, 'labels' => $pk_search_skin_profiles_labels, 'helper' => __('Select the skin profile to use for the search results. If you don\'t select a specific skin profile will be used the current active profile of the <i>Skin Options</i> page. You can set for each page of the theme a different skin or simply use everywhere the default one that you have set.', 'pk_text_domain')),
										'search_footer_profile' 		=> array('title' => __('Footer profile:', 'pk_text_domain'), 'type' => 'select', 'values' => $pk_search_footer_profiles_values, 'labels' => $pk_search_footer_profiles_labels, 'helper' => __('Select the footer profile to use for the search results. If you don\'t select a specific footer profile will be used the current active profile of the <i>Footer Options</i> page. You can set for each page of the theme a different footer or simply use everywhere the default one that you have set.', 'pk_text_domain'))
										
										);
$pk_search_options[0]['values'] = array(
										
										'search_sidebar' 				=> 'right',
										'search_skin_profile' 			=> '',
										'search_footer_profile' 		=> ''
									
										);
$pk_search_options[0]['save_button'] = true;

$pk_search_options[1]['title'] = __('Search Layout Options', 'pk_text_domain');
$pk_search_options[1]['options'] = array(
										
										'search_layout' 				=> array('title' => __('Layout:', 'pk_text_domain'), 'type' => 'select', 'values' => array('standard', 'alternative'), 'labels' => array(__('Standard', 'pk_text_domain'), __('Alternative', 'pk_text_domain')), 'helper' => __('Select the layout to use for the search results posts list.', 'pk_text_domain')),
										'search_show_posts_meta' 		=> array('title' => __('Show posts meta:', 'pk_text_domain'), 'type' => 'radio_group', 'values' => array('true', 'false'), 'labels' => array(__('Yes', 'pk_text_domain'), __('No', 'pk_text_domain')), 'helper' => __('Select <i>No</i> to completely remove all the posts meta information.', 'pk_text_domain')),
										'search_show_author_meta' 		=> array('title' => __('Show author meta:', 'pk_text_domain'), 'type' => 'radio_group', 'values' => array('true', 'false'), 'labels' => array(__('Yes', 'pk_text_domain'), __('No', 'pk_text_domain')), 'helper' => __('Select <i>No</i> to specifically remove the author information from the posts meta.', 'pk_text_domain')),
										'search_show_date_meta' 		=> array('title' => __('Show date meta:', 'pk_text_domain'), 'type' => 'radio_group', 'values' => array('true', 'false'), 'labels' => array(__('Yes', 'pk_text_domain'), __('No', 'pk_text_domain')), 'helper' => __('Select <i>No</i> to specifically remove the date from the posts meta.', 'pk_text_domain')),
										'search_show_date_meta_links' 	=> array('title' => __('Show date meta links:', 'pk_text_domain'), 'type' => 'radio_group', 'values' => array('true', 'false'), 'labels' => array(__('Yes', 'pk_text_domain'), __('No', 'pk_text_domain')), 'helper' => __('Select <i>No</i> to disable the date links of the posts meta (the date links, if present, link to the specific day/month/year archive pages of the blog).', 'pk_text_domain')),
										'search_show_categories_meta'	=> array('title' => __('Show categories meta:', 'pk_text_domain'), 'type' => 'radio_group', 'values' => array('true', 'false'), 'labels' => array(__('Yes', 'pk_text_domain'), __('No', 'pk_text_domain')), 'helper' => __('Select <i>No</i> to specifically remove the categories from the posts meta.', 'pk_text_domain')),
										'search_show_tags_meta' 		=> array('title' => __('Show tags meta:', 'pk_text_domain'), 'type' => 'radio_group', 'values' => array('true', 'false'), 'labels' => array(__('Yes', 'pk_text_domain'), __('No', 'pk_text_domain')), 'helper' => __('Select <i>No</i> to specifically remove the tags from the posts meta.', 'pk_text_domain')),
										'search_show_comments_meta' 	=> array('title' => __('Show comments meta:', 'pk_text_domain'), 'type' => 'radio_group', 'values' => array('true', 'false'), 'labels' => array(__('Yes', 'pk_text_domain'), __('No', 'pk_text_domain')), 'helper' => __('Select <i>No</i> to specifically remove the comments information from the posts meta.', 'pk_text_domain')),
										'search_show_full_posts' 		=> array('title' => __('Show full posts:', 'pk_text_domain'), 'type' => 'radio_group', 'values' => array('true', 'false'), 'labels' => array(__('Yes', 'pk_text_domain'), __('No', 'pk_text_domain')), 'helper' => __('Select <i>No</i> to show only the excerpt of the posts in the search results posts list.', 'pk_text_domain')),
										'search_show_read_more' 		=> array('title' => __('Show read more button:', 'pk_text_domain'), 'type' => 'radio_group', 'values' => array('true', 'false'), 'labels' => array(__('Yes', 'pk_text_domain'), __('No', 'pk_text_domain')), 'helper' => __('Select <i>No</i> to remove the read more buttons from the search results posts list (the featured images and the posts titles already link to the posts pages).', 'pk_text_domain')),
										'search_image_style' 			=> array('title' => __('Featured image style:', 'pk_text_domain'), 'type' => 'select', 'values' => array('16/9', '4/3', 'portrait', 'square', 'auto'), 'labels' => array(__('16/9', 'pk_text_domain'), __('4/3', 'pk_text_domain'), __('Portrait', 'pk_text_domain'), __('Square', 'pk_text_domain'), __('Auto Height', 'pk_text_domain')), 'helper' => __('Select the style to use for the featured images of the search results posts list.', 'pk_text_domain')),
										'search_image_icon' 			=> array('title' => __('Featured image icon:', 'pk_text_domain'), 'type' => 'select', 'values' => array('', 'pk_page_icon', 'pk_link_icon', 'pk_play_icon', 'pk_zoom_icon'), 'labels' => array(__('None', 'pk_text_domain'), __('Page', 'pk_text_domain'), __('Link', 'pk_text_domain'), __('Play', 'pk_text_domain'), __('Zoom', 'pk_text_domain')), 'helper' => __('Select the icon type that you want to show for the roll over on the featured images.', 'pk_text_domain'))
										
										);
$pk_search_options[1]['values'] = array(
										
										'search_layout' 				=> 'standard',
										'search_show_posts_meta' 		=> 'true',
										'search_show_author_meta' 		=> 'true',
										'search_show_date_meta' 		=> 'true',
										'search_show_date_meta_links' 	=> 'true',
										'search_show_categories_meta'	=> 'true',
										'search_show_tags_meta' 		=> 'true',
										'search_show_comments_meta' 	=> 'true',
										'search_show_full_posts' 		=> 'false',
										'search_show_read_more' 		=> 'true',
										'search_image_style' 			=> '16/9',
										'search_image_icon' 			=> ''
									
										);
$pk_search_options[1]['save_button'] = true;

if (class_exists('pk_options_generator') && !isset($pk_search_options_instance)) {
	
	add_option('pk_search_options_profiles', array('default'));
	add_option('pk_search_options_current_profile', 'default');
	add_option('pk_search_options_active_profile', 'default');
	
	$pk_search_options_instance = new pk_options_generator($pk_search_options, 'level_10', __('Search Options', 'pk_text_domain'), 'pk_general_options', 'pk_search_options', 'pk_search_options', 'pk_', array('pk_search_options_profiles', 'pk_search_options_current_profile', 'pk_search_options_active_profile', 'pk_search_options'));
	
	/*global $pk_dashboard_options;
	
	$pk_profiles = get_option('pk_search_options_profiles');
	
	foreach ($pk_profiles as $k => $v) {
	
		$pk_dashboard_options['pk_search_options_'.$v] = sprintf(__('Search Options - %s', 'pk_text_domain'), (($v == 'default') ? __('Default', 'pk_text_domain') : stripslashes(base64_decode($v))));
	
	}*/
	
}

?>