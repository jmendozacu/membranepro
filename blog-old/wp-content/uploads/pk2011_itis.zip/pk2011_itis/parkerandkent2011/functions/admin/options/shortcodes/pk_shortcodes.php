<?php

global $pk_shortcodes;

$pk_shortcodes = array();

$pk_shortcodes['title'] = __('Shortcodes Manager', 'pk_text_domain');

$pk_shortcodes['add_library'][] = true;
$pk_shortcodes['add_buttons'][] = false;
$pk_shortcodes['type'][] = 'selector';
$pk_shortcodes['options'][] = array(
										
										'shortcode_type' 	=> array('title' => __('Select shortcode type:', 'pk_text_domain'), 'type' => 'metabox_selector', 
									
										'values' => array(
										'pk_sc_selector',
										'pk_sc_blog',
										'pk_sc_normal_box',
										'pk_sc_titled_box',
										'pk_sc_message_box',
										'pk_sc_normal_buttons',
										'pk_sc_columns',
										'pk_sc_recent_comments',
										'pk_sc_dividers',
										'pk_sc_dribbble',
										'pk_sc_flickr',
										'pk_sc_contact_form',
										'pk_sc_search_form',
										'pk_sc_google_maps',
										'pk_sc_images',
										'pk_sc_media_video',
										'pk_sc_media_audio',
										'pk_sc_media_swf',
										'pk_sc_slides_slider',
										'pk_sc_tables',
										'pk_sc_tabs',
										'pk_sc_toggles',
										'pk_sc_twitter',
										'pk_sc_typography_hu',
										'pk_sc_typography_hb',
										'pk_sc_typography_pre',
										'pk_sc_typography_code',
										'pk_sc_typography_quote',
										'pk_sc_typography_lists',
										'pk_sc_typography_hl',
										'pk_sc_typography_dc',
										'pk_sc_typography_il',
										'pk_sc_typography_it',
										'pk_sc_works'),
									
										'labels' => array(
										__('-- Select --', 'pk_text_domain'),
										__('Blog (featured, popular, recent, related)', 'pk_text_domain'),
										__('Box (normal)', 'pk_text_domain'),
										__('Box (titled)', 'pk_text_domain'),
										__('Box (message)', 'pk_text_domain'),
										__('Buttons', 'pk_text_domain'),
										__('Columns', 'pk_text_domain'),
										__('Comments (recent)', 'pk_text_domain'),
										__('Dividers', 'pk_text_domain'),
										__('Dribbble', 'pk_text_domain'),
										__('Flickr', 'pk_text_domain'),
										__('Forms (contact)', 'pk_text_domain'),
										__('Forms (search)', 'pk_text_domain'),
										__('Google Maps', 'pk_text_domain'),
										__('Images', 'pk_text_domain'),
										__('Media (video)', 'pk_text_domain'),
										__('Media (audio)', 'pk_text_domain'),
										__('Media (swf)', 'pk_text_domain'),
										__('Slider (slides)', 'pk_text_domain'),
										__('Tables', 'pk_text_domain'),
										__('Tabs', 'pk_text_domain'),
										__('Toggles', 'pk_text_domain'),
										__('Twitter', 'pk_text_domain'),
										__('Typography (heading underline)', 'pk_text_domain'),
										__('Typography (heading background)', 'pk_text_domain'),
										__('Typography (pre tag)', 'pk_text_domain'),
										__('Typography (code tag)', 'pk_text_domain'),
										__('Typography (quote)', 'pk_text_domain'),
										__('Typography (lists)', 'pk_text_domain'),
										__('Typography (highlight)', 'pk_text_domain'),
										__('Typography (drop caps)', 'pk_text_domain'),
										__('Typography (icon link)', 'pk_text_domain'),
										__('Typography (icon text)', 'pk_text_domain'),
										__('Works (featured, popular, recent, related)', 'pk_text_domain')),
									
										'helper' => __('Select the shortcode type that you want to set up and generate. To avoid HTML validation/visualization problems (related to the WordPress auto-formatting filters) the Shortcodes Manager should <strong>NOT</strong> be used when the editor is in <strong>Visual</strong> mode.<br /><br />Many shortcodes require a <i>width</i> value. To know the width of the column/page where you intend to use your shortcodes, simply use the [pk_get_size] shortcode. It will display on the theme page the width of the area where it has been placed.<br /><br />Every time a shortcode is generated you will be asked by the system if you want to save its settings. Each shortcodes category has a library where you can save the shortcodes that you\'ve created. Thanks to this feature you don\'t need to fill again and again each setting. For example, if you create a large pink button, just save it and re use it every time you need a pink button. Click on the <i>Open Shortcodes Library</i> button and select the saved shortcode from the list. The saved data will fill for you all the settings and then just click on the <i>Generate Shortcode</i> button to send it to the editor. The saved settings of each shortcode can be changed anytime you want.', 'pk_text_domain'))
										
										);
$pk_shortcodes['values'][] = array(
										
										'shortcode_type' 	=> 'pk_shortcodes_table_selector'
										
										);
										
/*
 * Blog (featured, popular, recent, related)
*/

$pk_shortcodes['add_library'][] = true;
$pk_shortcodes['add_buttons'][] = true;
$pk_shortcodes['type'][] = 'blog';
$pk_shortcodes['options'][] = array(
									
										'blog_query_type' 		=> array('title' => __('Query type:', 'pk_text_domain'), 'type' => 'select', 'values' => array('featured', 'popular', 'recent', 'related'), 'labels' => array(__('Featured Posts', 'pk_text_domain'), __('Popular Posts', 'pk_text_domain'), __('Recent Posts', 'pk_text_domain'), __('Related Posts', 'pk_text_domain')), 'helper' => __('Select which query you want to run. Note that the <i>Related Posts</i> will show only on a single post page (related to the current post).', 'pk_text_domain')),
										'blog_title' 			=> array('title' => __('Title:', 'pk_text_domain'), 'type' => 'text', 'helper' => __('Type here a title to show before the posts list. You can leave this field empty.', 'pk_text_domain')),
										'blog_posts' 			=> array('title' => __('Select posts:', 'pk_text_domain'), 'type' => 'posts', 'post_type' => 'post', 'helper' => __('Select the posts to load. This option is needed by the <i>Featured Posts</i> only.', 'pk_text_domain')),
										'blog_order_by' 		=> array('title' => __('Order posts by:', 'pk_text_domain'), 'type' => 'select', 'values' => array('date', 'comment_count', 'title', 'author', 'rand'), 'labels' => array(__('Date', 'pk_text_domain'), __('Comments Count', 'pk_text_domain'), __('Title', 'pk_text_domain'), __('Author', 'pk_text_domain'), __('Random', 'pk_text_domain')), 'helper' => __('Select the order criteria for the query. This option is needed by the <i>Featured Posts</i> only.', 'pk_text_domain')),
										'blog_number' 			=> array('title' => __('Number of posts to load:', 'pk_text_domain'), 'type' => 'slider', 'min' => '1', 'max' => '30', 'uom' => __('posts', 'pk_text_domain'), 'helper' => __('Set the number of posts to load. This option isn\'t needed by the <i>Featured Posts</i>, that will load only the selected posts of the previous option.', 'pk_text_domain')),
										'blog_display_excerpt' 	=> array('title' => __('Display excerpt:', 'pk_text_domain'), 'type' => 'select', 'values' => array('true', 'false'), 'labels' => array(__('Yes', 'pk_text_domain'), __('No', 'pk_text_domain')), 'helper' => __('Select <i>Yes</i> to display the posts excerpt.', 'pk_text_domain')),
										'blog_display_thumb' 	=> array('title' => __('Display thumbnail:', 'pk_text_domain'), 'type' => 'select', 'values' => array('true', 'false'), 'labels' => array(__('Yes', 'pk_text_domain'), __('No', 'pk_text_domain')), 'helper' => __('Select <i>Yes</i> to display the posts thumbnails (featured images).', 'pk_text_domain')),
										'blog_list_icon' 		=> array('title' => __('Select list icon type:', 'pk_text_domain'), 'type' => 'select', 'values' => array('clear', 'arrow', 'check', 'posts', 'circle'), 'labels' => array(__('No Icon', 'pk_text_domain'), __('Arrow Icon', 'pk_text_domain'), __('Check Icon', 'pk_text_domain'), __('Post Icon', 'pk_text_domain'), __('Circle Icon', 'pk_text_domain')), 'helper' => __('Select the icon type for the posts list. It will be visible only if the <i>Display thumbnail</i> option is set to <i>No</i>.', 'pk_text_domain')),
										'blog_thumb_icon' 		=> array('title' => __('Select thumbnails icon type:', 'pk_text_domain'), 'type' => 'select', 'values' => array('', 'page', 'link', 'play', 'zoom'), 'labels' => array(__('No Icon', 'pk_text_domain'), __('Page Icon', 'pk_text_domain'), __('Link Icon', 'pk_text_domain'), __('Play Icon', 'pk_text_domain'), __('Zoom Icon', 'pk_text_domain')), 'helper' => __('Select the icon type that you want to show for the roll over on the thumbnails.', 'pk_text_domain')),
										'blog_thumb_width' 		=> array('title' => __('Thumbnails width:', 'pk_text_domain'), 'type' => 'slider', 'min' => '0', 'max' => '940', 'uom' => 'px', 'helper' => __('Set the thumbnails width.', 'pk_text_domain')),
										'blog_thumb_height' 	=> array('title' => __('Thumbnails height:', 'pk_text_domain'), 'type' => 'slider', 'min' => '0', 'max' => '940', 'uom' => 'px', 'helper' => __('Set the thumbnails height.', 'pk_text_domain'))
										
										);
$pk_shortcodes['values'][] = array(
									
										'blog_query_type' 		=> 'featured',
										'blog_title' 			=> '',
										'blog_posts' 			=> '',
										'blog_order_by' 		=> 'date',
										'blog_number' 			=> '5',
										'blog_display_excerpt' 	=> 'true',
										'blog_display_thumb' 	=> 'true',
										'blog_list_icon' 		=> 'arrow',
										'blog_thumb_icon' 		=> 'link',
										'blog_thumb_width' 		=> '160',
										'blog_thumb_height' 	=> '90'
										
										);
										
/*
 * Box (normal)
*/

$pk_shortcodes['add_library'][] = true;
$pk_shortcodes['add_buttons'][] = true;
$pk_shortcodes['type'][] = 'normal_box';
$pk_shortcodes['options'][] = array(
									
										'normal_box_width' 		=> array('title' => __('Width:', 'pk_text_domain'), 'type' => 'slider', 'min' => '0', 'max' => '940', 'uom' => 'px', 'helper' => __('Set the box width. Set <i>0</i> for a full width box.', 'pk_text_domain')),
										'normal_box_align' 		=> array('title' => __('Align:', 'pk_text_domain'), 'type' => 'select', 'values' => array('none', 'left', 'center', 'right'), 'labels' => array(__('None', 'pk_text_domain'), __('Left', 'pk_text_domain'), __('Center', 'pk_text_domain'), __('Right', 'pk_text_domain')), 'helper' => __('Set the box alignment. Set <i>None</i> if your box is full width.', 'pk_text_domain')),
										'normal_box_text_align' => array('title' => __('Text align:', 'pk_text_domain'), 'type' => 'select', 'values' => array('left', 'center', 'right'), 'labels' => array(__('Left', 'pk_text_domain'), __('Center', 'pk_text_domain'), __('Right', 'pk_text_domain')), 'helper' => __('Set the alignment of the box content.', 'pk_text_domain')),
										'normal_box_content' 	=> array('title' => __('Content:', 'pk_text_domain'), 'type' => 'text_area', 'rows' => '10', 'helper' => __('Type here the box content. You can include shortcodes.', 'pk_text_domain'))
										
										);
$pk_shortcodes['values'][] = array(
									
										'normal_box_width' 		=> '0',
										'normal_box_align' 		=> 'none',
										'normal_box_text_align' => 'left',
										'normal_box_content' 	=> ''
										
										);
										
/*
 * Box (titled)
*/

$pk_shortcodes['add_library'][] = true;
$pk_shortcodes['add_buttons'][] = true;
$pk_shortcodes['type'][] = 'titled_box';
$pk_shortcodes['options'][] = array(
									
										'titled_box_width' 				=> array('title' => __('Width:', 'pk_text_domain'), 'type' => 'slider', 'min' => '0', 'max' => '940', 'uom' => 'px', 'helper' => __('Set the box width. Set <i>0</i> for a full width box.', 'pk_text_domain')),
										'titled_box_align' 				=> array('title' => __('Align:', 'pk_text_domain'), 'type' => 'select', 'values' => array('none', 'left', 'center', 'right'), 'labels' => array(__('None', 'pk_text_domain'), __('Left', 'pk_text_domain'), __('Center', 'pk_text_domain'), __('Right', 'pk_text_domain')), 'helper' => __('Set the box alignment. Set <i>None</i> if your box is full width.', 'pk_text_domain')),
										'titled_box_title_text_align' 	=> array('title' => __('Title text align:', 'pk_text_domain'), 'type' => 'select', 'values' => array('left', 'center', 'right'), 'labels' => array(__('Left', 'pk_text_domain'), __('Center', 'pk_text_domain'), __('Right', 'pk_text_domain')), 'helper' => __('Set the alignment of the box title.', 'pk_text_domain')),
										'titled_box_content_text_align' => array('title' => __('Content text align:', 'pk_text_domain'), 'type' => 'select', 'values' => array('left', 'center', 'right'), 'labels' => array(__('Left', 'pk_text_domain'), __('Center', 'pk_text_domain'), __('Right', 'pk_text_domain')), 'helper' => __('Set the alignment of the box content.', 'pk_text_domain')),
										'titled_box_title' 				=> array('title' => __('Title:', 'pk_text_domain'), 'type' => 'text', 'helper' => __('Type here the box title.', 'pk_text_domain')),
										'titled_box_content' 			=> array('title' => __('Content:', 'pk_text_domain'), 'type' => 'text_area', 'rows' => '10', 'helper' => __('Type here the box content. You can include shortcodes. You can leave this field empty and type the content directly in the main editor.', 'pk_text_domain'))
										
										);
$pk_shortcodes['values'][] = array(
									
										'titled_box_width' 				=> '0',
										'titled_box_align' 				=> 'none',
										'titled_box_title_text_align' 	=> 'left',
										'titled_box_content_text_align' => 'left',
										'titled_box_title' 				=> '',
										'titled_box_content' 			=> ''
										
										);
										
/*
 * Box (message)
*/

$pk_shortcodes['add_library'][] = true;
$pk_shortcodes['add_buttons'][] = true;
$pk_shortcodes['type'][] = 'message_box';
$pk_shortcodes['options'][] = array(
									
										'message_box_width' 	=> array('title' => __('Width:', 'pk_text_domain'), 'type' => 'slider', 'min' => '0', 'max' => '940', 'uom' => 'px', 'helper' => __('Set the box width. Set <i>0</i> for a full width box.', 'pk_text_domain')),
										'message_box_type' 		=> array('title' => __('Message type:', 'pk_text_domain'), 'type' => 'select', 'values' => array('info', 'note', 'success', 'error', 'warning', 'important', 'help'), 'labels' => array(__('Info', 'pk_text_domain'), __('Note', 'pk_text_domain'), __('Success', 'pk_text_domain'), __('Error', 'pk_text_domain'), __('Warning', 'pk_text_domain'), __('Important', 'pk_text_domain'), __('Help', 'pk_text_domain')), 'helper' => __('Select the message type for the current box. Each message type will output a specific box style.', 'pk_text_domain')),
										'message_box_content' 	=> array('title' => __('Content:', 'pk_text_domain'), 'type' => 'text_area', 'rows' => '6', 'helper' => __('Type here the box content. You can include shortcodes. You can leave this field empty and type the content directly in the main editor.', 'pk_text_domain'))
										
										);
$pk_shortcodes['values'][] = array(
									
										'message_box_width' 	=> '0',
										'message_box_type' 		=> 'info',
										'message_box_content' 	=> ''
										
										);
										
/*
 * Buttons
*/

$pk_shortcodes['add_library'][] = true;
$pk_shortcodes['add_buttons'][] = true;
$pk_shortcodes['type'][] = 'normal_buttons';
$pk_shortcodes['options'][] = array(
									
										'normal_buttons_label' 					=> array('title' => __('Label:', 'pk_text_domain'), 'type' => 'text', 'helper' => __('Type here the button label.', 'pk_text_domain')),
										'normal_buttons_size' 					=> array('title' => __('Size:', 'pk_text_domain'), 'type' => 'select', 'values' => array('small', 'medium', 'big'), 'labels' => array(__('Small', 'pk_text_domain'), __('Medium', 'pk_text_domain'), __('Big', 'pk_text_domain')), 'helper' => __('Select a button size.', 'pk_text_domain')),
										'normal_buttons_align' 					=> array('title' => __('Align:', 'pk_text_domain'), 'type' => 'select', 'values' => array('none', 'left', 'right'), 'labels' => array(__('None', 'pk_text_domain'), __('Left', 'pk_text_domain'), __('Right', 'pk_text_domain')), 'helper' => __('Select the button alignment.', 'pk_text_domain')),
										'normal_buttons_color' 					=> array('title' => __('Color:', 'pk_text_domain'), 'type' => 'select', 'values' => array('', 'white', 'grey', 'black', 'sand', 'orange', 'yellow', 'green', 'blue', 'purple', 'red'), 'labels' => array(__('Default', 'pk_text_domain'), __('White', 'pk_text_domain'), __('Grey', 'pk_text_domain'), __('Black', 'pk_text_domain'), __('Sand', 'pk_text_domain'), __('Orange', 'pk_text_domain'), __('Yellow', 'pk_text_domain'), __('Green', 'pk_text_domain'), __('Blue', 'pk_text_domain'), __('Purple', 'pk_text_domain'), __('Red', 'pk_text_domain')), 'helper' => __('Select the button color.', 'pk_text_domain')),
										'normal_buttons_icon' 					=> array('title' => __('Icon:', 'pk_text_domain'), 'type' => 'select', 'values' => array('', 'arrow', 'download', 'home', 'mail', 'mini_arrow', 'zoom'), 'labels' => array(__('No Icon', 'pk_text_domain'), __('Arrow Icon', 'pk_text_domain'), __('Download Icon', 'pk_text_domain'), __('Home Icon', 'pk_text_domain'), __('Mail Icon', 'pk_text_domain'), __('Mini Arrow Icon', 'pk_text_domain'), __('Zoom Icon', 'pk_text_domain')), 'helper' => __('Select the icon type to add to the button.', 'pk_text_domain')),
										'normal_buttons_action' 				=> array('title' => __('Action:', 'pk_text_domain'), 'type' => 'select', 'values' => array('link', 'lightbox'), 'labels' => array(__('Link', 'pk_text_domain'), __('Open lightbox gallery', 'pk_text_domain')), 'helper' => __('Select the button action. By selecting the <i>Open lightbox gallery</i> the button will open the lightbox gallery created for this post (if supported by the current template). If this will be your selection, you don\'t need to set the next <i>Link</i> and <i>Link target</i> options.', 'pk_text_domain')),
										'normal_buttons_link' 					=> array('title' => __('Link:', 'pk_text_domain'), 'type' => 'text', 'helper' => __('Type here the link to open by clicking on this button.', 'pk_text_domain')),
										'normal_buttons_link_target' 			=> array('title' => __('Link target:', 'pk_text_domain'), 'type' => 'select', 'values' => array('_self', '_blank'), 'labels' => array(__('Self', 'pk_text_domain'), __('Blank', 'pk_text_domain')), 'helper' => __('Select the window target for the link. Select <i>Self</i> to open the link in the current browser window, select <i>Blank</i> to open the link in a new browser window.', 'pk_text_domain')),
										'normal_buttons_title' 					=> array('title' => __('Link tag title:', 'pk_text_domain'), 'type' => 'text', 'helper' => __('Type here the title attribute for the button link. The title will appear on roll over.', 'pk_text_domain')),
										'normal_buttons_lightbox_gallery_id' 	=> array('title' => __('Lightbox gallery id:', 'pk_text_domain'), 'type' => 'text', 'helper' => __('Set here the unique gallery id of the lightbox gallery of this page (if supported by the current template). The gallery id is the one that you\'ve entered in the lightbox gallery manager of the options panel below.', 'pk_text_domain'))
										
										);
$pk_shortcodes['values'][] = array(
										
										'normal_buttons_label' 					=> '',
										'normal_buttons_size' 					=> 'small',
										'normal_buttons_align' 					=> 'none',
										'normal_buttons_color' 					=> '',
										'normal_buttons_icon' 					=> '',
										'normal_buttons_action' 				=> 'link',
										'normal_buttons_link' 					=> '#',
										'normal_buttons_link_target' 			=> '_self',
										'normal_buttons_title' 					=> '',
										'normal_buttons_lightbox_gallery_id' 	=> ''
										
										);
										
/*
 * Columns
*/

$pk_shortcodes['add_library'][] = true;
$pk_shortcodes['add_buttons'][] = true;
$pk_shortcodes['type'][] = 'columns';
$pk_shortcodes['options'][] = array(
									
										'columns_size' 		=> array('title' => __('Column size:', 'pk_text_domain'), 'type' => 'select', 'values' => array('pk_full_width', 'pk_one_half', 'pk_one_third', 'pk_one_fourth', 'pk_one_fifth', 'pk_one_sixth', 'pk_two_third', 'pk_three_fourth', 'pk_two_fifth', 'pk_three_fifth', 'pk_four_fifth', 'pk_five_sixth', 'pk_one_half_last', 'pk_one_third_last', 'pk_one_fourth_last', 'pk_one_fifth_last', 'pk_one_sixth_last', 'pk_two_third_last', 'pk_three_fourth_last', 'pk_two_fifth_last', 'pk_three_fifth_last', 'pk_four_fifth_last', 'pk_five_sixth_last'), 'labels' => array('Column Full Width', 'Column 1/2', 'Column 1/3', 'Column 1/4', 'Column 1/5', 'Column 1/6', 'Column 2/3', 'Column 3/4', 'Column 2/5', 'Column 3/5', 'Column 4/5', 'Column 5/6', 'Column 1/2 Last', 'Column 1/3 Last', 'Column 1/4 Last', 'Column 1/5 Last', 'Column 1/6 Last', 'Column 2/3 Last', 'Column 3/4 Last', 'Column 2/5 Last', 'Column 3/5 Last', 'Column 4/5 Last', 'Column 5/6 Last'), 'helper' => __('Select the column size that you want to generate. Remember that the last column of each row must be a <i>Last</i> column.', 'pk_text_domain')),
										'columns_content' 	=> array('title' => __('Content:', 'pk_text_domain'), 'type' => 'text_area', 'rows' => '10', 'helper' => __('Enter here the column content. You can leave this field empty and type the content directly in the main editor.', 'pk_text_domain'))
										
										);
$pk_shortcodes['values'][] = array(
									
										'columns_size' 		=> '',
										'columns_content' 	=> ''
										
										);
										
/*
 * Comments (recent)
*/

$pk_shortcodes['add_library'][] = true;
$pk_shortcodes['add_buttons'][] = true;
$pk_shortcodes['type'][] = 'recent_comments';
$pk_shortcodes['options'][] = array(
									
										'recent_comments_title' 	=> array('title' => __('Title:', 'pk_text_domain'), 'type' => 'text', 'helper' => __('Type here a title to show before the comments list. You can leave this field empty.', 'pk_text_domain')),
										'recent_comments_number' 	=> array('title' => __('Number of recent comments to load:', 'pk_text_domain'), 'type' => 'slider', 'min' => '1', 'max' => '30', 'uom' => __('comments', 'pk_text_domain'), 'helper' => __('Set the number of comments to load.', 'pk_text_domain'))
										
										);
$pk_shortcodes['values'][] = array(
										
										'recent_comments_title' 	=> '',
										'recent_comments_number' 	=> '5'
										
										);
										
/*
 * Dividers
*/

$pk_shortcodes['add_library'][] = true;
$pk_shortcodes['add_buttons'][] = true;
$pk_shortcodes['type'][] = 'dividers';
$pk_shortcodes['options'][] = array(
										
										'dividers_type' 	=> array('title' => __('Divider type:', 'pk_text_domain'), 'type' => 'select', 'values' => array('pk_divider', 'pk_divider_top', 'pk_clear_both', 'pk_empty_space'), 'labels' => array('Divider', 'Dvider Top', 'Clear Both', 'Empty Space'), 'helper' => __('Select the divider type that you want to use.', 'pk_text_domain')),
										'dividers_height' 	=> array('title' => __('Height:', 'pk_text_domain'), 'type' => 'slider', 'min' => '0', 'max' => '200', 'uom' => 'px', 'helper' => __('The height attribute is used by the <i>Empty Space</i> divider only.', 'pk_text_domain'))
										
										);
$pk_shortcodes['values'][] = array(
										
										'dividers_type' 	=> '',
										'dividers_height' 	=> '30'
										
										);
										
/*
 * Dribbble
*/

$pk_shortcodes['add_library'][] = true;
$pk_shortcodes['add_buttons'][] = true;
$pk_shortcodes['type'][] = 'dribbble';
$pk_shortcodes['options'][] = array(
										
										'dribbble_title' 	=> array('title' => __('Title:', 'pk_text_domain'), 'type' => 'text', 'helper' => __('Type here a title to show before the Dribbble images. You can leave this field empty.', 'pk_text_domain')),
										'dribbble_username' => array('title' => __('Dribbble username:', 'pk_text_domain'), 'type' => 'text', 'helper' => __('Type here your Dribbble username.', 'pk_text_domain')),
										'dribbble_number' 	=> array('title' => __('Number of images to load:', 'pk_text_domain'), 'type' => 'slider', 'min' => '1', 'max' => '20', 'uom' => __('thumbnails', 'pk_text_domain'), 'helper' => __('Set the number of images to show.', 'pk_text_domain'))
										
										);
$pk_shortcodes['values'][] = array(
										
										'dribbble_title' 	=> '',
										'dribbble_username' => '',
										'dribbble_number' 	=> '3'
										
										);
										
/*
 * Flickr
*/

$pk_shortcodes['add_library'][] = true;
$pk_shortcodes['add_buttons'][] = true;
$pk_shortcodes['type'][] = 'flickr';
$pk_shortcodes['options'][] = array(
										
										'flickr_title' 					=> array('title' => __('Title:', 'pk_text_domain'), 'type' => 'text', 'helper' => __('Type here a title to show before the Flickr thumbnails. You can leave this field empty.', 'pk_text_domain')),
										'flickr_feed' 					=> array('title' => __('Flickr RSS2 feed URL:', 'pk_text_domain'), 'type' => 'text', 'helper' => __('Type here the URL of the RSS2 feed that you want to load.', 'pk_text_domain')),
										'flickr_number' 				=> array('title' => __('Number of thumbnails to load:', 'pk_text_domain'), 'type' => 'slider', 'min' => '1', 'max' => '50', 'uom' => __('thumbnails', 'pk_text_domain'), 'helper' => __('Set the number of thumbnails to show.', 'pk_text_domain')),
										'flickr_thumb_icon' 			=> array('title' => __('Select thumbnails icon type:', 'pk_text_domain'), 'type' => 'select', 'values' => array('', 'page', 'link', 'play', 'zoom'), 'labels' => array(__('No Icon', 'pk_text_domain'), __('Page Icon', 'pk_text_domain'), __('Link Icon', 'pk_text_domain'), __('Play Icon', 'pk_text_domain'), __('Zoom Icon', 'pk_text_domain')), 'helper' => __('Select the icon type that you want to show for the roll over on the thumbnails.', 'pk_text_domain')),
										'flickr_open_with_lightbox' 	=> array('title' => __('Open photos with lightbox:', 'pk_text_domain'), 'type' => 'select', 'values' => array('true', 'false'), 'labels' => array(__('Yes', 'pk_text_domain'), __('No', 'pk_text_domain')), 'helper' => __('Select <i>Yes</i> to open the photos using the lightbox. By selecting <i>No</i> the thumbnails will link directly to the Flickr website.', 'pk_text_domain')),
										'flickr_slideshow_autostart' 	=> array('title' => __('Slideshow auto start:', 'pk_text_domain'), 'type' => 'select', 'values' => array('true', 'false'), 'labels' => array(__('Yes', 'pk_text_domain'), __('No', 'pk_text_domain')), 'helper' => __('Select <i>Yes</i> to automatically start the slideshow. This setting will be used if the lightbox option is selected.', 'pk_text_domain')),
										'flickr_slideshow_interval' 	=> array('title' => __('Slideshow duration:', 'pk_text_domain'), 'type' => 'slider', 'min' => '1', 'max' => '10', 'uom' => __('seconds', 'pk_text_domain'), 'helper' => __('Set the slideshow duration. This setting will be used if the lightbox option is selected.', 'pk_text_domain'))
										
										);
$pk_shortcodes['values'][] = array(
										
										'flickr_title' 					=> '',
										'flickr_feed' 					=> '',
										'flickr_number' 				=> '16',
										'flickr_thumb_icon' 			=> '',
										'flickr_open_with_lightbox' 	=> 'true',
										'flickr_slideshow_autostart' 	=> 'false',
										'flickr_slideshow_interval' 	=> '5'
										
										);
										
/*
 * Forms (contact)
*/

$pk_shortcodes['add_library'][] = true;
$pk_shortcodes['add_buttons'][] = true;
$pk_shortcodes['type'][] = 'contact_form';
$pk_shortcodes['options'][] = array(
										
										'contact_form_send_to' 			=> array('title' => __('Admin email:', 'pk_text_domain'), 'type' => 'text', 'helper' => __('Type here the email address where you want to receive the emails.', 'pk_text_domain')),
										'contact_form_name_label' 		=> array('title' => __('Name field label:', 'pk_text_domain'), 'type' => 'text', 'helper' => __('Type here the name field label.', 'pk_text_domain')),
										'contact_form_email_label' 		=> array('title' => __('Email field label:', 'pk_text_domain'), 'type' => 'text', 'helper' => __('Type here the email field label.', 'pk_text_domain')),
										'contact_form_message_label' 	=> array('title' => __('Message field label:', 'pk_text_domain'), 'type' => 'text', 'helper' => __('Type here the message field label.', 'pk_text_domain')),
										'contact_form_subject' 			=> array('title' => __('Email subject:', 'pk_text_domain'), 'type' => 'text', 'helper' => __('Enter a subject for the contact form. You can use the following placeholders: %name% for the sender name, %sitename% for your site name.', 'pk_text_domain'))
										
										);
$pk_shortcodes['values'][] = array(
										
										'contact_form_send_to' 			=> get_option('admin_email'),
										'contact_form_name_label' 		=> __('Name', 'pk_text_domain_front'),
										'contact_form_email_label' 		=> __('Email', 'pk_text_domain_front'),
										'contact_form_message_label' 	=> __('Message', 'pk_text_domain_front'),
										'contact_form_subject' 			=> '%sitename%: email from %name%'
										
										);
										
/*
 * Forms (search)
*/

$pk_shortcodes['add_library'][] = true;
$pk_shortcodes['add_buttons'][] = true;
$pk_shortcodes['type'][] = 'search_form';
$pk_shortcodes['options'][] = array(
										
										'search_form_title' => array('title' => __('Title:', 'pk_text_domain'), 'type' => 'text', 'helper' => __('Type here a title to show before the search form. You can leave this field empty.', 'pk_text_domain'))
										
										);
$pk_shortcodes['values'][] = array(
										
										'search_form_title' => ''
										
										);
										
/*
 * Google Maps
*/

$pk_shortcodes['add_library'][] = true;
$pk_shortcodes['add_buttons'][] = true;
$pk_shortcodes['type'][] = 'google_maps';
$pk_shortcodes['options'][] = array(
										
										'google_maps_title' 		=> array('title' => __('Title:', 'pk_text_domain'), 'type' => 'text', 'helper' => __('Type here a title to show before the map. You can leave this field empty.', 'pk_text_domain')),
										'google_maps_map_url' 		=> array('title' => __('Map URL:', 'pk_text_domain'), 'type' => 'text', 'helper' => __('Type here the URL of the map that you want to load.', 'pk_text_domain')),
										'google_maps_map_height' 	=> array('title' => __('Map height:', 'pk_text_domain'), 'type' => 'slider', 'min' => '0', 'max' => '1000', 'uom' => 'px', 'helper' => __('Set the height of the map.', 'pk_text_domain')),
										
										
										);
$pk_shortcodes['values'][] = array(
										
										'google_maps_title' 		=> '',
										'google_maps_map_url' 		=> '',
										'google_maps_map_height' 	=> '400'
										
										);
										
/*
 * Images
*/

$pk_shortcodes['add_library'][] = true;
$pk_shortcodes['add_buttons'][] = true;
$pk_shortcodes['type'][] = 'images';
$pk_shortcodes['options'][] = array(
										
										'images_title' 					=> array('title' => __('Title:', 'pk_text_domain'), 'type' => 'text', 'helper' => __('Type here the image title.', 'pk_text_domain')),
										'images_image' 					=> array('title' => __('Image URL:', 'pk_text_domain'), 'type' => 'image', 'preview' => 'false', 'helper' => __('Type in the image URL or click on the <i>Image</i> button to insert an image from the media library.', 'pk_text_domain')),
										'images_w' 						=> array('title' => __('Width:', 'pk_text_domain'), 'type' => 'slider', 'min' => '0', 'max' => '940', 'uom' => 'px', 'helper' => __('Set the image width.', 'pk_text_domain')),
										'images_image_style' 			=> array('title' => __('Style:', 'pk_text_domain'), 'type' => 'select', 'values' => array('16/9', '4/3', 'portrait', 'square', 'auto', 'custom'), 'labels' => array(__('16/9', 'pk_text_domain'), __('4/3', 'pk_text_domain'), __('Portrait', 'pk_text_domain'), __('Square', 'pk_text_domain'), __('Auto Height', 'pk_text_domain'), __('Custom Height', 'pk_text_domain')), 'helper' => __('Select the style of the image.', 'pk_text_domain')),
										'images_h' 						=> array('title' => __('Height:', 'pk_text_domain'), 'type' => 'slider', 'min' => '0', 'max' => '940', 'uom' => 'px', 'helper' => __('Set the image height. This setting will be used only if you\'ve set the image style to <i>Custom Height</i>.', 'pk_text_domain')),
										'images_align' 					=> array('title' => __('Align:', 'pk_text_domain'), 'type' => 'select', 'values' => array('none', 'left', 'center', 'right'), 'labels' => array(__('None', 'pk_text_domain'), __('Left', 'pk_text_domain'), __('Center', 'pk_text_domain'), __('Right', 'pk_text_domain')), 'helper' => __('Select the image alignment.', 'pk_text_domain')),
										'images_icon' 					=> array('title' => __('Icon:', 'pk_text_domain'), 'type' => 'select', 'values' => array('', 'page', 'link', 'play', 'zoom'), 'labels' => array(__('None', 'pk_text_domain'), __('Page', 'pk_text_domain'), __('Link', 'pk_text_domain'), __('Play', 'pk_text_domain'), __('Zoom', 'pk_text_domain')), 'helper' => __('Select the icon type that you want to show for the roll over on the image.', 'pk_text_domain')),
										'images_action' 				=> array('title' => __('Action:', 'pk_text_domain'), 'type' => 'select', 'values' => array('', 'link', 'lightbox'), 'labels' => array(__('None', 'pk_text_domain'), __('Link', 'pk_text_domain'), __('Open lightbox gallery', 'pk_text_domain')), 'helper' => __('Select the image action. By selecting the <i>Open lightbox gallery</i> the image will open (on click) the lightbox gallery created for this post (if supported by the current template). If this will be your selection, you don\'t need to set the next <i>Link</i> and <i>Link target</i> options.', 'pk_text_domain')),
										'images_link' 					=> array('title' => __('Link:', 'pk_text_domain'), 'type' => 'text', 'helper' => __('Type here the link to open by clicking on this image.', 'pk_text_domain')),
										'images_link_target' 			=> array('title' => __('Link target:', 'pk_text_domain'), 'type' => 'select', 'values' => array('_self', '_blank'), 'labels' => array(__('Self', 'pk_text_domain'), __('Blank', 'pk_text_domain')), 'helper' => __('Select the window target for the link. Select <i>Self</i> to open the link in the current browser window, select <i>Blank</i> to open the link in a new browser window.', 'pk_text_domain')),
										'images_lightbox_gallery_id' 	=> array('title' => __('Lightbox gallery id:', 'pk_text_domain'), 'type' => 'text', 'helper' => __('Set here the unique gallery id of the lightbox gallery of this page (if supported by the current template). The gallery id is the one that you\'ve entered in the lightbox gallery manager of the options panel below.', 'pk_text_domain')),
										
										);
$pk_shortcodes['values'][] = array(
										
										'images_title' 					=> '',
										'images_image' 					=> '',
										'images_w' 						=> '690',
										'images_image_style' 			=> '16/9',
										'images_h' 						=> '',
										'images_align' 					=> 'none',
										'images_icon' 					=> '',
										'images_action' 				=> '',
										'images_link' 					=> '',
										'images_link_target' 			=> '_self',
										'images_lightbox_gallery_id' 	=> ''
										
										);
										
/*
 * Media (video)
*/

$pk_shortcodes['add_library'][] = true;
$pk_shortcodes['add_buttons'][] = true;
$pk_shortcodes['type'][] = 'media_video';
$pk_shortcodes['options'][] = array(
										
										'media_video_width' 			=> array('title' => __('Width:', 'pk_text_domain'), 'type' => 'slider', 'min' => '0', 'max' => '940', 'uom' => 'px', 'helper' => __('Set the video player width.', 'pk_text_domain')),
										'media_video_height' 			=> array('title' => __('Height:', 'pk_text_domain'), 'type' => 'slider', 'min' => '0', 'max' => '940', 'uom' => 'px', 'helper' => __('Set the video player height.', 'pk_text_domain')),
										'media_video_align' 			=> array('title' => __('Align:', 'pk_text_domain'), 'type' => 'select', 'values' => array('none', 'left', 'center', 'right'), 'labels' => array(__('None', 'pk_text_domain'), __('Left', 'pk_text_domain'), __('Center', 'pk_text_domain'), __('Right', 'pk_text_domain')), 'helper' => __('Select the video player alignment.', 'pk_text_domain')),
										'media_video_use_custom_player' => array('title' => __('Use custom players:', 'pk_text_domain'), 'type' => 'select', 'values' => array('true', 'false'), 'labels' => array(__('Yes', 'pk_text_domain'), __('No', 'pk_text_domain')), 'helper' => __('Select <i>Yes</i> if you want to use the custom Flash AS3 video player for YouTube videos.', 'pk_text_domain')),
										'media_video_autoplay' 			=> array('title' => __('Player auto play:', 'pk_text_domain'), 'type' => 'select', 'values' => array('true', 'false'), 'labels' => array(__('Yes', 'pk_text_domain'), __('No', 'pk_text_domain')), 'helper' => __('Select <i>Yes</i> if you want your video player to auto start on page load.', 'pk_text_domain')),
										'media_video_file' 				=> array('title' => __('Video:', 'pk_text_domain'), 'type' => 'video', 'preview' => 'false', 'helper' => __('Select a video type.', 'pk_text_domain'))
										
										);
$pk_shortcodes['values'][] = array(
										
										'media_video_width' 			=> '690',
										'media_video_height' 			=> '315',
										'media_video_align' 			=> 'none',
										'media_video_use_custom_player' => 'true',
										'media_video_autoplay' 			=> 'false',
										'media_video_file' 				=> ''
										
										);
										
/*
 * Media (audio)
*/

$pk_shortcodes['add_library'][] = true;
$pk_shortcodes['add_buttons'][] = true;
$pk_shortcodes['type'][] = 'media_audio';
$pk_shortcodes['options'][] = array(
										
										'media_audio_width' 	=> array('title' => __('Width:', 'pk_text_domain'), 'type' => 'slider', 'min' => '0', 'max' => '940', 'uom' => 'px', 'helper' => __('Set the audio player width.', 'pk_text_domain')),
										'media_audio_height' 	=> array('title' => __('Height:', 'pk_text_domain'), 'type' => 'slider', 'min' => '0', 'max' => '940', 'uom' => 'px', 'helper' => __('Set the audio player height.', 'pk_text_domain')),
										'media_audio_align' 	=> array('title' => __('Align:', 'pk_text_domain'), 'type' => 'select', 'values' => array('none', 'left', 'center', 'right'), 'labels' => array(__('None', 'pk_text_domain'), __('Left', 'pk_text_domain'), __('Center', 'pk_text_domain'), __('Right', 'pk_text_domain')), 'helper' => __('Select the audio player alignment.', 'pk_text_domain')),
										'media_audio_autoplay' 	=> array('title' => __('Player auto play:', 'pk_text_domain'), 'type' => 'select', 'values' => array('true', 'false'), 'labels' => array(__('Yes', 'pk_text_domain'), __('No', 'pk_text_domain')), 'helper' => __('Select <i>Yes</i> if you want your audio player to auto start on page load.', 'pk_text_domain')),
										'media_audio_file' 		=> array('title' => __('Audio:', 'pk_text_domain'), 'type' => 'audio', 'preview' => 'false', 'helper' => __('Type in the cover and the audio URLs or click on the buttons to select them from the media library.', 'pk_text_domain'))
										
										);
$pk_shortcodes['values'][] = array(
										
										'media_audio_width' 	=> '690',
										'media_audio_height' 	=> '315',
										'media_audio_align' 	=> 'none',
										'media_audio_autoplay' 	=> 'false',
										'media_audio_file' 		=> ''
										
										);
										
/*
 * Media (swf)
*/

$pk_shortcodes['add_library'][] = true;
$pk_shortcodes['add_buttons'][] = true;
$pk_shortcodes['type'][] = 'media_swf';
$pk_shortcodes['options'][] = array(
										
										'media_swf_width' 		=> array('title' => __('Width:', 'pk_text_domain'), 'type' => 'slider', 'min' => '0', 'max' => '940', 'uom' => 'px', 'helper' => __('Set the swf container width.', 'pk_text_domain')),
										'media_swf_height' 		=> array('title' => __('Height:', 'pk_text_domain'), 'type' => 'slider', 'min' => '0', 'max' => '940', 'uom' => 'px', 'helper' => __('Set the swf container height.', 'pk_text_domain')),
										'media_swf_align' 		=> array('title' => __('Align:', 'pk_text_domain'), 'type' => 'select', 'values' => array('none', 'left', 'center', 'right'), 'labels' => array(__('None', 'pk_text_domain'), __('Left', 'pk_text_domain'), __('Center', 'pk_text_domain'), __('Right', 'pk_text_domain')), 'helper' => __('Select the swf container alignment.', 'pk_text_domain')),
										'media_swf_file' 		=> array('title' => __('Swf:', 'pk_text_domain'), 'type' => 'file', 'preview' => 'false', 'helper' => __('Type in the swf URL or click on the <i>File</i> button to insert an swf file from the media library.', 'pk_text_domain')),
										'media_swf_flashvars' 	=> array('title' => __('SwfObject flashvars object:', 'pk_text_domain'), 'type' => 'text_area', 'rows' => '2', 'helper' => __('Type in the SWFObject flashvars object. Use only double quotes within this field.', 'pk_text_domain')),
										'media_swf_params' 		=> array('title' => __('SwfObject params object:', 'pk_text_domain'), 'type' => 'text_area', 'rows' => '2', 'helper' => __('Type in the SWFObject params object. Use only double quotes within this field.', 'pk_text_domain')),
										'media_swf_fp_version' 	=> array('title' => __('SwfObject flash player version:', 'pk_text_domain'), 'type' => 'text', 'helper' => __('Type in the flash player version that you want to use for your swf file.', 'pk_text_domain'))
										
										);
$pk_shortcodes['values'][] = array(
										
										'media_swf_width' 		=> '690',
										'media_swf_height' 		=> '315',
										'media_swf_align' 		=> 'none',
										'media_swf_file' 		=> '',
										'media_swf_flashvars' 	=> '{}',
										'media_swf_params' 		=> '{allowfullscreen:"true", allowscriptaccess:"always", wmode:"transparent", menu:"false"}',
										'media_swf_fp_version' 	=> '9.0.0'
										
										);
										
/*
 * Slider (slides)
*/

$pk_shortcodes['add_library'][] = true;
$pk_shortcodes['add_buttons'][] = true;
$pk_shortcodes['type'][] = 'slides_slider';
$pk_shortcodes['options'][] = array(
										
										'slides_slider_width' 					=> array('title' => __('Width:', 'pk_text_domain'), 'type' => 'slider', 'min' => '0', 'max' => '940', 'uom' => 'px', 'helper' => __('Set the slider width.', 'pk_text_domain')),
										'slides_slider_height' 					=> array('title' => __('Height:', 'pk_text_domain'), 'type' => 'slider', 'min' => '0', 'max' => '940', 'uom' => 'px', 'helper' => __('Set the slider height.', 'pk_text_domain')),
										'slides_slider_slides_categories' 		=> array('title' => __('Select categories:', 'pk_text_domain'), 'type' => 'categories', 'taxonomy' => 'taxonomy_slides', 'helper' => __('With this option you can include one or more categories of slides to this slider.', 'pk_text_domain')),
										'slides_slider_slides_ids' 				=> array('title' => __('Select slides:', 'pk_text_domain'), 'type' => 'posts', 'post_type' => 'slides', 'helper' => __('With this option you can manually add specific slides to this slider.', 'pk_text_domain')),
										'slides_slider_info_text_align' 		=> array('title' => __('Info text align:', 'pk_text_domain'), 'type' => 'select', 'values' => array('left', 'center', 'right'), 'labels' => array(__('Left', 'pk_text_domain'), __('Center', 'pk_text_domain'), __('Right', 'pk_text_domain')), 'helper' => __('Select the info text alignment.', 'pk_text_domain')),
										'slides_slider_info_back_ground_alpha' 	=> array('title' => __('Info text background alpha:', 'pk_text_domain'), 'type' => 'slider', 'min' => '0', 'max' => '1', 'uom' => '%', 'helper' => __('Set the alpha value of the info\s background.', 'pk_text_domain')),
										'slides_slider_slideshow' 				=> array('title' => __('Enable slideshow:', 'pk_text_domain'), 'type' => 'select', 'values' => array('true', 'false'), 'labels' => array(__('Yes', 'pk_text_domain'), __('No', 'pk_text_domain')), 'helper' => __('Select <i>Yes</i> to enable the slideshow functionality.', 'pk_text_domain')),
										'slides_slider_slideshow_auto_start' 	=> array('title' => __('Slideshow auto start:', 'pk_text_domain'), 'type' => 'select', 'values' => array('true', 'false'), 'labels' => array(__('Yes', 'pk_text_domain'), __('No', 'pk_text_domain')), 'helper' => __('Select <i>Yes</i> to automatically start the slideshow.', 'pk_text_domain')),
										'slides_slider_slideshow_interval' 		=> array('title' => __('Slideshow duration:', 'pk_text_domain'), 'type' => 'slider', 'min' => '1', 'max' => '10', 'uom' => __('seconds', 'pk_text_domain'), 'helper' => __('Set the slideshow duration.', 'pk_text_domain')),
										'slides_slider_open_info_label'			=> array('title' => __('Open info label:', 'pk_text_domain'), 'type' => 'text', 'helper' => __('Type here the label for the open info button.', 'pk_text_domain')),
										'slides_slider_close_info_label'		=> array('title' => __('Close info label:', 'pk_text_domain'), 'type' => 'text', 'helper' => __('Type here the label for the close info button.', 'pk_text_domain'))
										
										);
$pk_shortcodes['values'][] = array(
										
										'slides_slider_width' 					=> '690',
										'slides_slider_height' 					=> '315',
										'slides_slider_slides_categories' 		=> '',
										'slides_slider_slides_ids' 				=> '',
										'slides_slider_info_text_align' 		=> 'left',
										'slides_slider_info_back_ground_alpha' 	=> '0.7',
										'slides_slider_slideshow' 				=> 'true',
										'slides_slider_slideshow_auto_start' 	=> 'false',
										'slides_slider_slideshow_interval' 		=> '5',
										'slides_slider_open_info_label' 		=> __('info', 'pk_text_domain_front'),
										'slides_slider_close_info_label' 		=> __('close info', 'pk_text_domain_front')
										
										);
										
/*
 * Tables
*/

$pk_shortcodes['add_library'][] = true;
$pk_shortcodes['add_buttons'][] = true;
$pk_shortcodes['type'][] = 'tables';
$pk_shortcodes['options'][] = array(
										
										'tables_width' 	=> array('title' => __('Width:', 'pk_text_domain'), 'type' => 'slider', 'min' => '0', 'max' => '940', 'uom' => 'px', 'helper' => __('Set the table width. Set <i>0</i> for a full width table.', 'pk_text_domain')),
										'tables_align' 	=> array('title' => __('Align:', 'pk_text_domain'), 'type' => 'select', 'values' => array('none', 'left', 'center', 'right'), 'labels' => array(__('None', 'pk_text_domain'), __('Left', 'pk_text_domain'), __('Center', 'pk_text_domain'), __('Right', 'pk_text_domain')), 'helper' => __('Set the table alignment.', 'pk_text_domain')),
										'tables_hover' 	=> array('title' => __('Hover style:', 'pk_text_domain'), 'type' => 'select', 'values' => array('true', 'false'), 'labels' => array(__('Yes', 'pk_text_domain'), __('No', 'pk_text_domain')), 'helper' => __('Select <i>Yes</i> to have a roll over effect for the table rows.', 'pk_text_domain')),
										'tables_html' 	=> array('title' => __('Table markup (HTML):', 'pk_text_domain'), 'type' => 'text_area', 'rows' => '10', 'helper' => __('Type here the full table HTML markup. You can leave this field empty and type the content directly in the main editor.', 'pk_text_domain'))
										
										);
$pk_shortcodes['values'][] = array(
										
										'tables_width' 	=> '690',
										'tables_align' 	=> 'none',
										'tables_hover' 	=> 'false',
										'tables_html' 	=> ''
										
										);
										
/*
 * Tabs
*/

$pk_shortcodes['add_library'][] = true;
$pk_shortcodes['add_buttons'][] = true;
$pk_shortcodes['type'][] = 'tabs';
$pk_shortcodes['options'][] = array(
										
										'tabs_title' 			=> array('title' => __('Title:', 'pk_text_domain'), 'type' => 'text', 'helper' => __('Type here a general title for the tabs. You can leave this field empty.', 'pk_text_domain')),
										'tabs_style' 	=> array('title' => __('Style:', 'pk_text_domain'), 'type' => 'select', 'values' => array('minimal', 'boxed'), 'labels' => array(__('Minimal', 'pk_text_domain'), __('Boxed', 'pk_text_domain')), 'helper' => __('Select the tabs style.', 'pk_text_domain')),
										'tabs_width' 	=> array('title' => __('Width:', 'pk_text_domain'), 'type' => 'slider', 'min' => '0', 'max' => '940', 'uom' => 'px', 'helper' => __('Set the tabs width. Set <i>0</i> for full width tabs.', 'pk_text_domain')),
										'tabs_align' 	=> array('title' => __('Align:', 'pk_text_domain'), 'type' => 'select', 'values' => array('none', 'left', 'center', 'right'), 'labels' => array(__('None', 'pk_text_domain'), __('Left', 'pk_text_domain'), __('Center', 'pk_text_domain'), __('Right', 'pk_text_domain')), 'helper' => __('Select the tabs alignment.', 'pk_text_domain')),
										'tabs_number' 	=> array('title' => __('Number of tabs:', 'pk_text_domain'), 'type' => 'slider', 'min' => '1', 'max' => '30', 'uom' => __('tabs', 'pk_text_domain'), 'helper' => __('Select the number of tabs that you need. You will create the tabs contents directly in the main editor.', 'pk_text_domain'))
										
										);
$pk_shortcodes['values'][] = array(
										'tabs_title' 	=> '',
										'tabs_style' 	=> 'minimal',
										'tabs_width' 	=> '0',
										'tabs_align' 	=> 'none',
										'tabs_number' 	=> '3'
										
										);
										
/*
 * Toggles
*/

$pk_shortcodes['add_library'][] = true;
$pk_shortcodes['add_buttons'][] = true;
$pk_shortcodes['type'][] = 'toggles';
$pk_shortcodes['options'][] = array(
										
										'toggles_style' 	=> array('title' => __('Style:', 'pk_text_domain'), 'type' => 'select', 'values' => array('minimal', 'boxed'), 'labels' => array(__('Minimal', 'pk_text_domain'), __('Boxed', 'pk_text_domain')), 'helper' => __('Select the toggles style.', 'pk_text_domain')),
										'toggles_width' 	=> array('title' => __('Width:', 'pk_text_domain'), 'type' => 'slider', 'min' => '0', 'max' => '940', 'uom' => 'px', 'helper' => __('Set the toggles width. Set <i>0</i> for full width toggles.', 'pk_text_domain')),
										'toggles_align' 	=> array('title' => __('Align:', 'pk_text_domain'), 'type' => 'select', 'values' => array('none', 'left', 'center', 'right'), 'labels' => array(__('None', 'pk_text_domain'), __('Left', 'pk_text_domain'), __('Center', 'pk_text_domain'), __('Right', 'pk_text_domain')), 'helper' => __('Select the toggles alignment.', 'pk_text_domain')),
										'toggles_number' 	=> array('title' => __('Number of toggles:', 'pk_text_domain'), 'type' => 'slider', 'min' => '1', 'max' => '30', 'uom' => __('toggles', 'pk_text_domain'), 'helper' => __('Select the number of toggles that you need. You will create the toggles contents directly in the main editor.', 'pk_text_domain'))
										
										);
$pk_shortcodes['values'][] = array(
										
										'toggles_style' 	=> 'minimal',
										'toggles_width' 	=> '0',
										'toggles_align' 	=> 'none',
										'toggles_number' 	=> '3'
										
										);
										
/*
 * Twitter
*/

$pk_shortcodes['add_library'][] = true;
$pk_shortcodes['add_buttons'][] = true;
$pk_shortcodes['type'][] = 'twitter';
$pk_shortcodes['options'][] = array(
										
										'twitter_title' 			=> array('title' => __('Title:', 'pk_text_domain'), 'type' => 'text', 'helper' => __('Type here a title to show before the tweets. You can leave this field empty.', 'pk_text_domain')),
										'twitter_username' 			=> array('title' => __('Twitter username:', 'pk_text_domain'), 'type' => 'text', 'helper' => __('Type here your Twitter username.', 'pk_text_domain')),
										'twitter_number' 			=> array('title' => __('Number of tweets to load:', 'pk_text_domain'), 'type' => 'slider', 'min' => '1', 'max' => '20', 'uom' => __('tweets', 'pk_text_domain'), 'helper' => __('Set the number of tweets to load.', 'pk_text_domain')),
										'twitter_show_follow_link' 	=> array('title' => __('Show follow link:', 'pk_text_domain'), 'type' => 'select', 'values' => array('true', 'false'), 'labels' => array(__('Yes', 'pk_text_domain'), __('No', 'pk_text_domain')), 'helper' => __('Select <i>Yes</i> to add a direct link to your Twitter account.', 'pk_text_domain')),
										
										
										);
$pk_shortcodes['values'][] = array(
										
										'twitter_title' 			=> '',
										'twitter_username' 			=> '',
										'twitter_number' 			=> '5',
										'twitter_show_follow_link' 	=> 'false'
										
										);
										
/*
 * Typography (heading underline)
*/

$pk_shortcodes['add_library'][] = true;
$pk_shortcodes['add_buttons'][] = true;
$pk_shortcodes['type'][] = 'typography_hu';
$pk_shortcodes['options'][] = array(
										
										'typography_hu_color' 	=> array('title' => __('Text color:', 'pk_text_domain'), 'type' => 'color', 'helper' => __('Click on the color field to pick a new color.', 'pk_text_domain')),
										'typography_hu_heading' => array('title' => __('Heading markup (HTML):', 'pk_text_domain'), 'type' => 'text_area', 'rows' => '3', 'helper' => __('Type here the HTML markup of the heading.', 'pk_text_domain'))
										
										);
$pk_shortcodes['values'][] = array(
										
										'typography_hu_color' 	=> '',
										'typography_hu_heading' => '<h1>Your heading markup</h1>'
										
										);
										
/*
 * Typography (heading background)
*/

$pk_shortcodes['add_library'][] = true;
$pk_shortcodes['add_buttons'][] = true;
$pk_shortcodes['type'][] = 'typography_hb';
$pk_shortcodes['options'][] = array(
										
										'typography_hb_color' 				=> array('title' => __('Text color:', 'pk_text_domain'), 'type' => 'color', 'helper' => __('Click on the color field to pick a new color.', 'pk_text_domain')),
										'typography_hb_background_color' 	=> array('title' => __('Background color:', 'pk_text_domain'), 'type' => 'color', 'helper' => __('Click on the color field to pick a new color.', 'pk_text_domain')),
										'typography_hb_rounded' 			=> array('title' => __('Rounded background:', 'pk_text_domain'), 'type' => 'select', 'values' => array('true', 'false'), 'labels' => array(__('Yes', 'pk_text_domain'), __('No', 'pk_text_domain')), 'helper' => __('Select <i>Yes</i> for rounded background.', 'pk_text_domain')),
										'typography_hb_heading' 			=> array('title' => __('Heading markup (HTML):', 'pk_text_domain'), 'type' => 'text_area', 'rows' => '3', 'helper' => __('Type here the HTML markup of the heading.', 'pk_text_domain'))
										
										);
$pk_shortcodes['values'][] = array(
										
										'typography_hb_color' 				=> '',
										'typography_hb_background_color' 	=> '',
										'typography_hb_rounded' 			=> 'true',
										'typography_hb_heading' 			=> '<h1>Your heading markup</h1>'
										
										);
										
/*
 * Typography (pre tag)
*/

$pk_shortcodes['add_library'][] = true;
$pk_shortcodes['add_buttons'][] = true;
$pk_shortcodes['type'][] = 'typography_pre';
$pk_shortcodes['options'][] = array(
										
										'typography_pre_content' 	=> array('title' => __('Pre tag content:', 'pk_text_domain'), 'type' => 'text_area', 'rows' => '10', 'helper' => __('Type here the <i>pre</i> tag content. You can leave this field empty and type the content directly in the main editor.', 'pk_text_domain'))
										
										);
$pk_shortcodes['values'][] = array(
										
										'typography_pre_content' 	=> ''
										
										);
										
/*
 * Typography (code tag)
*/

$pk_shortcodes['add_library'][] = true;
$pk_shortcodes['add_buttons'][] = true;
$pk_shortcodes['type'][] = 'typography_code';
$pk_shortcodes['options'][] = array(
										
										'typography_code_content' 	=> array('title' => __('Code tag content:', 'pk_text_domain'), 'type' => 'text_area', 'rows' => '10', 'helper' => __('Type here the <i>code</i> tag content. You can leave this field empty and type the content directly in the main editor.', 'pk_text_domain'))
										
										);
$pk_shortcodes['values'][] = array(
										
										'typography_code_content' 	=> ''
										
										);
										
/*
 * Typography (quote)
*/

$pk_shortcodes['add_library'][] = true;
$pk_shortcodes['add_buttons'][] = true;
$pk_shortcodes['type'][] = 'typography_quote';
$pk_shortcodes['options'][] = array(
										
										'typography_quote_width' 	=> array('title' => __('Width:', 'pk_text_domain'), 'type' => 'slider', 'min' => '0', 'max' => '940', 'uom' => 'px', 'helper' => __('Set the quote width. Set <i>0</i> for full width quote.', 'pk_text_domain')),
										'typography_quote_align' 	=> array('title' => __('Align:', 'pk_text_domain'), 'type' => 'select', 'values' => array('none', 'left', 'center', 'right'), 'labels' => array(__('None', 'pk_text_domain'), __('Left', 'pk_text_domain'), __('Center', 'pk_text_domain'), __('Right', 'pk_text_domain')), 'helper' => __('Set the quote alignment.', 'pk_text_domain')),
										'typography_quote_cite' 	=> array('title' => __('Cite:', 'pk_text_domain'), 'type' => 'text_area', 'rows' => '3', 'helper' => __('Type here the citation text.', 'pk_text_domain')),
										'typography_quote_quote' 	=> array('title' => __('Quote:', 'pk_text_domain'), 'type' => 'text_area', 'rows' => '6', 'helper' => __('Type here the quote content. You can leave this field empty and type the content directly in the main editor.', 'pk_text_domain'))
										
										);
$pk_shortcodes['values'][] = array(
										
										'typography_quote_width' 	=> '0',
										'typography_quote_align' 	=> 'none',
										'typography_quote_cite' 	=> '',
										'typography_quote_quote' 	=> ''
										
										);
										
/*
 * Typography (lists)
*/

$pk_shortcodes['add_library'][] = true;
$pk_shortcodes['add_buttons'][] = true;
$pk_shortcodes['type'][] = 'typography_lists';
$pk_shortcodes['options'][] = array(
										
										'typography_lists_style' 		=> array('title' => __('Style:', 'pk_text_domain'), 'type' => 'select', 'values' => array('pk_underline_list', 'pk_clear_list', 'pk_arrow_list', 'pk_circle_list', 'pk_check_list', 'pk_posts_list', 'pk_thumbnail_list'), 'labels' => array(__('Underline List', 'pk_text_domain'), __('Clear List', 'pk_text_domain'), __('Arrow List', 'pk_text_domain'), __('Circle List', 'pk_text_domain'), __('Check List', 'pk_text_domain'), __('Posts List', 'pk_text_domain'), __('Thumbnail List', 'pk_text_domain')), 'helper' => __('Select a list style.', 'pk_text_domain')),
										'typography_lists_underline' 	=> array('title' => __('Underline:', 'pk_text_domain'), 'type' => 'select', 'values' => array('true', 'false'), 'labels' => array(__('Yes', 'pk_text_domain'), __('No', 'pk_text_domain')), 'helper' => __('Select <i>Yes</i> to have an underlined list.', 'pk_text_domain')),
										'typography_lists_list' 		=> array('title' => __('List markup (HTML):', 'pk_text_domain'), 'type' => 'text_area', 'rows' => '6', 'helper' => __('Type here the HTML markup of the list. You can leave this field empty and type the content directly in the main editor.', 'pk_text_domain'))
										
										);
$pk_shortcodes['values'][] = array(
										
										'typography_lists_style' 		=> 'pk_underline_list',
										'typography_lists_underline' 	=> 'false',
										'typography_lists_list' 		=> '
<ul>
<li><span>Your list item</span></li>
<li><span>Your list item</span></li>
<li><span>Your list item</span></li>
</ul>'
										
										);
										
/*
 * Typography (highlight)
*/

$pk_shortcodes['add_library'][] = true;
$pk_shortcodes['add_buttons'][] = true;
$pk_shortcodes['type'][] = 'typography_hl';
$pk_shortcodes['options'][] = array(
										
										'typography_hl_color' 				=> array('title' => __('Text color:', 'pk_text_domain'), 'type' => 'color', 'helper' => __('Click on the color field to pick a new color.', 'pk_text_domain')),
										'typography_hl_background_color' 	=> array('title' => __('Background color:', 'pk_text_domain'), 'type' => 'color', 'helper' => __('Click on the color field to pick a new color.', 'pk_text_domain')),
										'typography_hl_rounded' 			=> array('title' => __('Rounded background:', 'pk_text_domain'), 'type' => 'select', 'values' => array('true', 'false'), 'labels' => array(__('Yes', 'pk_text_domain'), __('No', 'pk_text_domain')), 'helper' => __('Select <i>Yes</i> for rounded background.', 'pk_text_domain')),
										'typography_hl_content' 			=> array('title' => __('Content to highlight:', 'pk_text_domain'), 'type' => 'text_area', 'rows' => '3', 'helper' => __('type here the text to highlight.', 'pk_text_domain'))
										
										);
$pk_shortcodes['values'][] = array(
										
										'typography_hl_color' 				=> '',
										'typography_hl_background_color' 	=> '',
										'typography_hl_rounded' 			=> 'true',
										'typography_hl_content' 			=> ''
										
										);
										
/*
 * Typography (drop caps)
*/

$pk_shortcodes['add_library'][] = true;
$pk_shortcodes['add_buttons'][] = true;
$pk_shortcodes['type'][] = 'typography_dc';
$pk_shortcodes['options'][] = array(
										
										'typography_dc_type' 		=> array('title' => __('Type:', 'pk_text_domain'), 'type' => 'select', 'values' => array('1', '2', '3'), 'labels' => array(__('Only text', 'pk_text_domain'), __('Text with inner background', 'pk_text_domain'), __('Text with outer background', 'pk_text_domain')), 'helper' => __('Select the drop caps type.', 'pk_text_domain')),
										'typography_dc_color' 		=> array('title' => __('Color:', 'pk_text_domain'), 'type' => 'select', 'values' => array('', 'white', 'grey', 'black', 'sand', 'orange', 'yellow', 'green', 'blue', 'purple', 'red'), 'labels' => array(__('Default', 'pk_text_domain'), __('White', 'pk_text_domain'), __('Grey', 'pk_text_domain'), __('Black', 'pk_text_domain'), __('Sand', 'pk_text_domain'), __('Orange', 'pk_text_domain'), __('Yellow', 'pk_text_domain'), __('Green', 'pk_text_domain'), __('Blue', 'pk_text_domain'), __('Purple', 'pk_text_domain'), __('Red', 'pk_text_domain')), 'helper' => __('Select the drop cap color.', 'pk_text_domain')),
										'typography_dc_text' 		=> array('title' => __('Text:', 'pk_text_domain'), 'type' => 'text', 'helper' => __('Type here the character to capitilize.', 'pk_text_domain'))
										
										);
$pk_shortcodes['values'][] = array(
										
										'typography_dc_type' 		=> '1',
										'typography_dc_color' 		=> '',
										'typography_dc_text' 		=> ''
										
										);
										
/*
 * Typography (icon link)
*/

$pk_shortcodes['add_library'][] = true;
$pk_shortcodes['add_buttons'][] = true;
$pk_shortcodes['type'][] = 'typography_il';
$pk_shortcodes['options'][] = array(
										
										'typography_il_icon' 		=> array('title' => __('Icon type:', 'pk_text_domain'), 'type' => 'select', 'values' => array('address', 'chain', 'comments', 'download', 'home', 'id', 'link', 'mail', 'mobile_phone', 'phone', 'read_post', 'tags'), 'labels' => array(__('Address Icon', 'pk_text_domain'), __('Chain Icon', 'pk_text_domain'), __('Comments Icon', 'pk_text_domain'), __('Download Icon', 'pk_text_domain'), __('Home Icon', 'pk_text_domain'), __('Id Icon', 'pk_text_domain'), __('Link Icon', 'pk_text_domain'), __('Mail Icon', 'pk_text_domain'), __('Mobile Phone Icon', 'pk_text_domain'), __('Phone Icon', 'pk_text_domain'), __('Read Post Icon', 'pk_text_domain'), __('Tags Icon', 'pk_text_domain')), 'helper' => __('Select an icon.', 'pk_text_domain')),
										'typography_il_icon_type' 	=> array('title' => __('Icon style:', 'pk_text_domain'), 'type' => 'select', 'values' => array('light', 'dark'), 'labels' => array(__('Light', 'pk_text_domain'), __('Dark', 'pk_text_domain')), 'helper' => __('Select the icon style.', 'pk_text_domain')),
										'typography_il_link' 		=> array('title' => __('Link markup (HTML):', 'pk_text_domain'), 'type' => 'text_area', 'rows' => '2', 'helper' => __('Type here the HTML markup of the link.', 'pk_text_domain'))
										
										);
$pk_shortcodes['values'][] = array(
										
										'typography_il_icon' 		=> 'address',
										'typography_il_icon_type' 	=> 'light',
										'typography_il_link' 		=> '<a href="" title="">Your link label</a>'
										
										);
										
/*
 * Typography (icon text)
*/

$pk_shortcodes['add_library'][] = true;
$pk_shortcodes['add_buttons'][] = true;
$pk_shortcodes['type'][] = 'typography_it';
$pk_shortcodes['options'][] = array(
										
										'typography_it_icon' 		=> array('title' => __('Icon type:', 'pk_text_domain'), 'type' => 'select', 'values' => array('address', 'chain', 'comments', 'download', 'home', 'id', 'link', 'mail', 'mobile_phone', 'phone', 'read_post', 'tags'), 'labels' => array(__('Address Icon', 'pk_text_domain'), __('Chain Icon', 'pk_text_domain'), __('Comments Icon', 'pk_text_domain'), __('Download Icon', 'pk_text_domain'), __('Home Icon', 'pk_text_domain'), __('Id Icon', 'pk_text_domain'), __('Link Icon', 'pk_text_domain'), __('Mail Icon', 'pk_text_domain'), __('Mobile Phone Icon', 'pk_text_domain'), __('Phone Icon', 'pk_text_domain'), __('Read Post Icon', 'pk_text_domain'), __('Tags Icon', 'pk_text_domain')), 'helper' => __('Select an icon.', 'pk_text_domain')),
										'typography_it_icon_type' 	=> array('title' => __('Icon style:', 'pk_text_domain'), 'type' => 'select', 'values' => array('light', 'dark'), 'labels' => array(__('Light', 'pk_text_domain'), __('Dark', 'pk_text_domain')), 'helper' => __('Select the icon style.', 'pk_text_domain')),
										'typography_it_text' 		=> array('title' => __('Text:', 'pk_text_domain'), 'type' => 'text_area', 'rows' => '2', 'helper' => __('Type here the text.', 'pk_text_domain'))
										
										);
$pk_shortcodes['values'][] = array(
										
										'typography_it_icon' 		=> 'address',
										'typography_it_icon_type' 	=> 'light',
										'typography_it_text' 		=> ''
										
										);
										
/*
 * Works (featured, popular, recent, related)
*/

$pk_shortcodes['add_library'][] = true;
$pk_shortcodes['add_buttons'][] = true;
$pk_shortcodes['type'][] = 'works';
$pk_shortcodes['options'][] = array(
									
										'works_query_type' 		=> array('title' => __('Query type:', 'pk_text_domain'), 'type' => 'select', 'values' => array('featured', 'popular', 'recent', 'related'), 'labels' => array(__('Featured Works', 'pk_text_domain'), __('Popular Works', 'pk_text_domain'), __('Recent Works', 'pk_text_domain'), __('Related Works', 'pk_text_domain')), 'helper' => __('Select which query you want to run. Note that the <i>Related Works</i> will show only on a single work page (related to the current work).', 'pk_text_domain')),
										'works_title' 			=> array('title' => __('Title:', 'pk_text_domain'), 'type' => 'text', 'helper' => __('Type here a title to show before the works list. You can leave this field empty.', 'pk_text_domain')),
										'works_works' 			=> array('title' => __('Select works:', 'pk_text_domain'), 'type' => 'posts', 'post_type' => 'works', 'helper' => __('Select the works to load. This option is needed by the <i>Featured Works</i> only.', 'pk_text_domain')),
										'works_order_by' 		=> array('title' => __('Order works by:', 'pk_text_domain'), 'type' => 'select', 'values' => array('menu_order', 'date', 'comment_count', 'title', 'author', 'rand'), 'labels' => array(__('Manual Sort', 'pk_text_domain'), __('Date', 'pk_text_domain'), __('Comments Count', 'pk_text_domain'), __('Title', 'pk_text_domain'), __('Author', 'pk_text_domain'), __('Random', 'pk_text_domain')), 'helper' => __('Select the order criteria for the query. This option is needed by the <i>Featured Works</i> only.', 'pk_text_domain')),
										'works_number' 			=> array('title' => __('Number of works to load:', 'pk_text_domain'), 'type' => 'slider', 'min' => '1', 'max' => '30', 'uom' => __('works', 'pk_text_domain'), 'helper' => __('Set the number of works to load. This option isn\'t needed by the <i>Featured Works</i>, that will load only the selected works of the previous option.', 'pk_text_domain')),
										'works_display_excerpt' => array('title' => __('Display excerpt:', 'pk_text_domain'), 'type' => 'select', 'values' => array('true', 'false'), 'labels' => array(__('Yes', 'pk_text_domain'), __('No', 'pk_text_domain')), 'helper' => __('Select <i>Yes</i> to display the posts excerpt.', 'pk_text_domain')),
										'works_display_thumb' 	=> array('title' => __('Display thumbnail:', 'pk_text_domain'), 'type' => 'select', 'values' => array('true', 'false'), 'labels' => array(__('Yes', 'pk_text_domain'), __('No', 'pk_text_domain')), 'helper' => __('Select <i>Yes</i> to display the works thumbnails (featured images).', 'pk_text_domain')),
										'works_list_icon' 		=> array('title' => __('Select list icon type:', 'pk_text_domain'), 'type' => 'select', 'values' => array('clear', 'arrow', 'check', 'posts', 'circle'), 'labels' => array(__('No Icon', 'pk_text_domain'), __('Arrow Icon', 'pk_text_domain'), __('Check Icon', 'pk_text_domain'), __('Post Icon', 'pk_text_domain'), __('Heart Icon', 'pk_text_domain')), 'helper' => __('Select the icon type for the works list. It will be visible only if the <i>Display thumbnail</i> option is set to <i>No</i>.', 'pk_text_domain')),
										'works_thumb_icon' 		=> array('title' => __('Select thumbnails icon type:', 'pk_text_domain'), 'type' => 'select', 'values' => array('', 'page', 'link', 'play', 'zoom'), 'labels' => array(__('No Icon', 'pk_text_domain'), __('Page Icon', 'pk_text_domain'), __('Link Icon', 'pk_text_domain'), __('Play Icon', 'pk_text_domain'), __('Zoom Icon', 'pk_text_domain')), 'helper' => __('Select the icon type that you want to show for the roll over on the thumbnails.', 'pk_text_domain')),
										'works_thumb_width' 	=> array('title' => __('Thumbnails width:', 'pk_text_domain'), 'type' => 'slider', 'min' => '0', 'max' => '940', 'uom' => 'px', 'helper' => __('Set the thumbnails width.', 'pk_text_domain')),
										'works_thumb_height' 	=> array('title' => __('Thumbnails height:', 'pk_text_domain'), 'type' => 'slider', 'min' => '0', 'max' => '940', 'uom' => 'px', 'helper' => __('Set the thumbnails height.', 'pk_text_domain'))
										
										);
$pk_shortcodes['values'][] = array(
									
										'works_query_type' 		=> 'featured',
										'works_title' 			=> '',
										'works_works' 			=> '',
										'works_order_by' 		=> 'date',
										'works_number' 			=> '5',
										'works_display_excerpt' => 'true',
										'works_display_thumb' 	=> 'true',
										'works_list_icon' 		=> 'arrow',
										'works_thumb_icon' 		=> 'link',
										'works_thumb_width' 	=> '160',
										'works_thumb_height' 	=> '90'
										
										);

?>