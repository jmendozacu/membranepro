<?php

function pk_register_snippets() {
	
	$args = array(
		'label' => __('Snippets', 'pk_text_domain'),
		'public' => false,
		'capability_type' => 'post',
		'hierarchical' => false
	);
	
	register_post_type('snippets', $args);
	
}

pk_register_snippets();