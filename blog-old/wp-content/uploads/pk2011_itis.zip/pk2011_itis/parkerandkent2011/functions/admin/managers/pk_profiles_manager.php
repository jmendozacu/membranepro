<?php

global $pk_profiles_manager_instance;

if (!class_exists('pk_profiles_manager')) {
	
	class pk_profiles_manager extends pk_forms_manager {
		
		function pk_profiles_manager() {
			
		}
		
		function pk_add_main_title($title = '') {
			
			echo '
	<div id="icon-themes" class="icon32">
		<br />
	</div>
	<h2>'.$title.'</h2>
	<br />';
			
		}
		
		function pk_data_saved($message = '') {
			
			echo '
	<div class="updated">
		<p><strong>'.$message.'</strong></p>
	</div>';
			
		}
		
		function pk_add_title($title = '', $special_color = false) {
			
			$class = ($special_color == true) ? 'pk_admin_tr_special' : 'pk_admin_tr';
			
			echo '
					<tr class="'.$class.'">
						<th scope="row" class="pk_admin_th_profiles">
							<h4>'.$title.'</h4>
						</th>';
			
		}
		
		function pk_add_input_new_profile($name = '', $helper = '?') {
						
			echo '
						<td class="pk_admin_td_profiles">
							<p>
								<input class="pk_admin_input_text_field" type="text" name="'.$name.'" value="" />
								<input class="pk_admin_button button" type="submit" name="pk_profiles_button" value="'.__('Add', 'pk_text_domain').'" />
							</p>
							<p class="pk_admin_helper"><strong class="pk_admin_helper_strong">? </strong>'.$helper.'</p>
						</td>
					</tr>';
			
		}
		
		function pk_add_input_select($name = '', $type = '', $values = array(), $labels = array(), $selected = '', $helper = '') {
			
			$require_confirmation = ($type == 'load' || $type == 'activate') ? '' : ' pk_admin_delete_profile_button';
			$button_string = ($type == 'load') ? __('Load', 'pk_text_domain') : (($type == 'activate') ? __('Activate', 'pk_text_domain') : __('Delete', 'pk_text_domain'));
			
			echo '
						<td class="pk_admin_td_profiles">
							<p>
								<select class="pk_admin_input_select" name="'.$name.'">';
			
			for ($i = 0; $i < count($values); $i++) {
				
				if ($values[$i] == $selected) {
					
					$selected_string = ' selected="selected"';
					
				} else {
					
					$selected_string = '';
					
				}
				
			echo '
									<option value="'.$values[$i].'"'.$selected_string.'>'.(($labels[$i] == 'default') ? 'Default' : stripslashes(base64_decode($labels[$i]))).'</option>';
				
			}
			
			echo '
								</select>
								<input class="pk_admin_button'.$require_confirmation.' button" type="submit" name="pk_profiles_button" value="'.$button_string.'" data-message="'.__('Are you sure you want to delete this profile?', 'pk_text_domain').'" />
							</p>
							<p class="pk_admin_helper"><strong class="pk_admin_helper_strong">? </strong>'.$helper.'</p>
						</td>
					</tr>';
			
		}
		
		function pk_open_form($options_key = '') {
			
			echo '
	<div>
		<form name="pk_profiles_form" method="post" action="">
			<input type="hidden" name="pk_profiles_form_data" value="true" />';
			
			wp_nonce_field($options_key, md5($options_key));
			
		}
		
		function pk_open_div($slug) {
			
			echo '			
	<!-- pk options profiles - start -->
	<div class="'.$slug.'">';
			
		}
		
		function pk_close_div() {
			
			echo '
	</div>
	<!-- pk options profiles - end -->
';
			
		}
		
	}
	
}

if (class_exists('pk_profiles_manager') && !isset($pk_profiles_manager_instance)) {
	
	$pk_profiles_manager_instance = new pk_profiles_manager();
	
}

?>