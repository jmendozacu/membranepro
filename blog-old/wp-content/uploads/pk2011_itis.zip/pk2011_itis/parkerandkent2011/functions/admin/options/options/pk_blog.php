<?php

$pk_blog_skin_profiles = get_option('pk_skin_options_profiles');
$pk_blog_skin_profiles_values = array('');
$pk_blog_skin_profiles_labels = array(__('-- Select --', 'pk_text_domain'));

for ($i = 0; $i < count($pk_blog_skin_profiles); $i++) {
	
	$pk_blog_skin_profiles_values[] = $pk_blog_skin_profiles[$i];
	$pk_blog_skin_profiles_labels[] = (($pk_blog_skin_profiles[$i] == 'default') ? 'Default' : stripslashes(base64_decode($pk_blog_skin_profiles[$i])));
	
}

$pk_blog_footer_profiles = get_option('pk_footer_options_profiles');
$pk_blog_footer_profiles_values = array('');
$pk_blog_footer_profiles_labels = array(__('-- Select --', 'pk_text_domain'));

for ($i = 0; $i < count($pk_blog_footer_profiles); $i++) {
	
	$pk_blog_footer_profiles_values[] = $pk_blog_footer_profiles[$i];
	$pk_blog_footer_profiles_labels[] = (($pk_blog_footer_profiles[$i] == 'default') ? 'Default' : stripslashes(base64_decode($pk_blog_footer_profiles[$i])));
	
}

$pk_blog_options = array();

$pk_blog_options[0]['title'] = __('Blog Options', 'pk_text_domain');
$pk_blog_options[0]['options'] = array(
										
										'blog_intro' 					=> array('title' => __('Intro:', 'pk_text_domain'), 'type' => 'text_area', 'rows' => '3', 'helper' => __('Type any custom HTML content to display in the <i>Intro</i> area of the main blog.', 'pk_text_domain')),
										'blog_exclude_categories'		=> array('title' => __('Exclude categories:', 'pk_text_domain'), 'type' => 'categories', 'taxonomy' => 'category', 'helper' => __('Select one or more categories to completely exclude from the theme. The selected categories will be excluded from the main blog, from the blog archive pages, from the RSS feeds, from the widgets and also from the meta information of each blog post. Categories should be excluded only if you need to hide them for a specific time frame or for any other reason you may have. In a normal situation you shouldn\'t need to exclude any category, considering that you won\'t use any blog category for other types of contents. Works, slides, news and services post types have their own specific taxonomies (categories).', 'pk_text_domain')),
										'blog_soft_exclude_categories'	=> array('title' => __('Exclude categories (soft):', 'pk_text_domain'), 'type' => 'categories', 'taxonomy' => 'category', 'helper' => __('Select one or more categories to soft exclude from the main blog loop only. Thanks to this setting, you can create one or more menu items linking to the soft excluded categories, just in case you need to separate them from the main blog.', 'pk_text_domain')),
										'blog_sidebar' 					=> array('title' => __('Sidebar:', 'pk_text_domain'), 'type' => 'select', 'values' => array('none', 'left', 'right'), 'labels' => array(__('None', 'pk_text_domain'), __('Left', 'pk_text_domain'), __('Right', 'pk_text_domain')), 'helper' => __('Select the position of the sidebar for the main blog page. Select <i>None</i> if you want a full width layout.', 'pk_text_domain')),
										'blog_skin_profile' 			=> array('title' => __('Skin profile:', 'pk_text_domain'), 'type' => 'select', 'values' => $pk_blog_skin_profiles_values, 'labels' => $pk_blog_skin_profiles_labels, 'helper' => __('Select the skin profile to use for the main blog. If you don\'t select a specific skin profile will be used the current active profile of the <i>Skin Options</i> page. You can set for each page of the theme a different skin or simply use everywhere the default one that you have set.', 'pk_text_domain')),
										'blog_footer_profile' 			=> array('title' => __('Footer profile:', 'pk_text_domain'), 'type' => 'select', 'values' => $pk_blog_footer_profiles_values, 'labels' => $pk_blog_footer_profiles_labels, 'helper' => __('Select the footer profile to use for the main blog. If you don\'t select a specific footer profile will be used the current active profile of the <i>Footer Options</i> page. You can set for each page of the theme a different footer or simply use everywhere the default one that you have set.', 'pk_text_domain'))
										
										);
$pk_blog_options[0]['values'] = array(
										
										'blog_intro' 					=> '',
										'blog_exclude_categories' 		=> '',
										'blog_soft_exclude_categories' 	=> '',
										'blog_sidebar' 					=> 'right',
										'blog_skin_profile' 			=> '',
										'blog_footer_profile' 			=> ''
									
										);
$pk_blog_options[0]['save_button'] = true;

$pk_blog_options[1]['title'] = __('Blog Layout Options', 'pk_text_domain');
$pk_blog_options[1]['options'] = array(
										
										'blog_layout' 				=> array('title' => __('Layout:', 'pk_text_domain'), 'type' => 'select', 'values' => array('standard', 'alternative'), 'labels' => array(__('Standard', 'pk_text_domain'), __('Alternative', 'pk_text_domain')), 'helper' => __('Select the layout to use for the main blog posts list.', 'pk_text_domain')),
										'blog_show_posts_meta' 		=> array('title' => __('Show posts meta:', 'pk_text_domain'), 'type' => 'radio_group', 'values' => array('true', 'false'), 'labels' => array(__('Yes', 'pk_text_domain'), __('No', 'pk_text_domain')), 'helper' => __('Select <i>No</i> to completely remove all the posts meta information.', 'pk_text_domain')),
										'blog_show_author_meta' 	=> array('title' => __('Show author meta:', 'pk_text_domain'), 'type' => 'radio_group', 'values' => array('true', 'false'), 'labels' => array(__('Yes', 'pk_text_domain'), __('No', 'pk_text_domain')), 'helper' => __('Select <i>No</i> to specifically remove the author information from the posts meta.', 'pk_text_domain')),
										'blog_show_date_meta' 		=> array('title' => __('Show date meta:', 'pk_text_domain'), 'type' => 'radio_group', 'values' => array('true', 'false'), 'labels' => array(__('Yes', 'pk_text_domain'), __('No', 'pk_text_domain')), 'helper' => __('Select <i>No</i> to specifically remove the date from the posts meta.', 'pk_text_domain')),
										'blog_show_date_meta_links' => array('title' => __('Show date meta links:', 'pk_text_domain'), 'type' => 'radio_group', 'values' => array('true', 'false'), 'labels' => array(__('Yes', 'pk_text_domain'), __('No', 'pk_text_domain')), 'helper' => __('Select <i>No</i> to disable the date links of the posts meta (the date links, if present, link to the specific day/month/year archive pages of the blog).', 'pk_text_domain')),
										'blog_show_categories_meta' => array('title' => __('Show categories meta:', 'pk_text_domain'), 'type' => 'radio_group', 'values' => array('true', 'false'), 'labels' => array(__('Yes', 'pk_text_domain'), __('No', 'pk_text_domain')), 'helper' => __('Select <i>No</i> to specifically remove the categories from the posts meta.', 'pk_text_domain')),
										'blog_show_tags_meta' 		=> array('title' => __('Show tags meta:', 'pk_text_domain'), 'type' => 'radio_group', 'values' => array('true', 'false'), 'labels' => array(__('Yes', 'pk_text_domain'), __('No', 'pk_text_domain')), 'helper' => __('Select <i>No</i> to specifically remove the tags from the posts meta.', 'pk_text_domain')),
										'blog_show_comments_meta' 	=> array('title' => __('Show comments meta:', 'pk_text_domain'), 'type' => 'radio_group', 'values' => array('true', 'false'), 'labels' => array(__('Yes', 'pk_text_domain'), __('No', 'pk_text_domain')), 'helper' => __('Select <i>No</i> to specifically remove the comments information from the posts meta.', 'pk_text_domain')),
										'blog_show_full_posts' 		=> array('title' => __('Show full posts:', 'pk_text_domain'), 'type' => 'radio_group', 'values' => array('true', 'false'), 'labels' => array(__('Yes', 'pk_text_domain'), __('No', 'pk_text_domain')), 'helper' => __('Select <i>No</i> to show only the excerpt of the posts in the main blog posts list.', 'pk_text_domain')),
										'blog_show_read_more' 		=> array('title' => __('Show read more button:', 'pk_text_domain'), 'type' => 'radio_group', 'values' => array('true', 'false'), 'labels' => array(__('Yes', 'pk_text_domain'), __('No', 'pk_text_domain')), 'helper' => __('Select <i>No</i> to remove the read more buttons from the main blog posts list (the featured images and the posts titles already link to the posts pages).', 'pk_text_domain')),
										'blog_image_style' 			=> array('title' => __('Featured image style:', 'pk_text_domain'), 'type' => 'select', 'values' => array('16/9', '4/3', 'portrait', 'square', 'auto'), 'labels' => array(__('16/9', 'pk_text_domain'), __('4/3', 'pk_text_domain'), __('Portrait', 'pk_text_domain'), __('Square', 'pk_text_domain'), __('Auto Height', 'pk_text_domain')), 'helper' => __('Select the style to use for the featured images of the main blog posts list.', 'pk_text_domain')),
										'blog_image_icon' 			=> array('title' => __('Featured image icon:', 'pk_text_domain'), 'type' => 'select', 'values' => array('', 'pk_page_icon', 'pk_link_icon', 'pk_play_icon', 'pk_zoom_icon'), 'labels' => array(__('None', 'pk_text_domain'), __('Page', 'pk_text_domain'), __('Link', 'pk_text_domain'), __('Play', 'pk_text_domain'), __('Zoom', 'pk_text_domain')), 'helper' => __('Select the icon type that you want to show for the roll over on the featured images.', 'pk_text_domain'))
										
										);
$pk_blog_options[1]['values'] = array(
										
										'blog_layout' 				=> 'standard',
										'blog_show_posts_meta' 		=> 'true',
										'blog_show_author_meta' 	=> 'true',
										'blog_show_date_meta' 		=> 'true',
										'blog_show_date_meta_links' => 'true',
										'blog_show_categories_meta'	=> 'true',
										'blog_show_tags_meta' 		=> 'true',
										'blog_show_comments_meta' 	=> 'true',
										'blog_show_full_posts' 		=> 'false',
										'blog_show_read_more' 		=> 'true',
										'blog_image_style' 			=> '16/9',
										'blog_image_icon' 			=> ''
									
										);
$pk_blog_options[1]['save_button'] = true;

if (class_exists('pk_options_generator') && !isset($pk_blog_options_instance)) {
	
	add_option('pk_blog_options_profiles', array('default'));
	add_option('pk_blog_options_current_profile', 'default');
	add_option('pk_blog_options_active_profile', 'default');
	
	$pk_blog_options_instance = new pk_options_generator($pk_blog_options, 'level_10', __('Blog Options', 'pk_text_domain'), 'pk_general_options', 'pk_blog_options', 'pk_blog_options', 'pk_', array('pk_blog_options_profiles', 'pk_blog_options_current_profile', 'pk_blog_options_active_profile', 'pk_blog_options'));
	
	/*global $pk_dashboard_options;
	
	$pk_profiles = get_option('pk_blog_options_profiles');
	
	foreach ($pk_profiles as $k => $v) {
	
		$pk_dashboard_options['pk_blog_options_'.$v] = sprintf(__('Blog Options - %s', 'pk_text_domain'), (($v == 'default') ? __('Default', 'pk_text_domain') : stripslashes(base64_decode($v))));
	
	}*/
	
}

?>