<?php

if (!class_exists('pk_snippets_library_generator')) {
	
	class pk_snippets_library_generator {
		
		private $type;
		private $suffix;
		
		function pk_snippets_library_generator($type = '', $suffix = '') {
			
			$this -> type = $type;
			$this -> suffix = $suffix;
			
			add_action('admin_init', array(&$this, 'pk_init_metabox'));
			
		}
		
		function pk_init_metabox() {
			
			if (function_exists('add_meta_box')) {
				
				add_meta_box(strtolower($this -> suffix.str_replace(' ', '_', __('Snippets Library', 'pk_text_domain'))), 'PK '.__('Snippets Library', 'pk_text_domain'), array(&$this, 'pk_create_metabox'), $this -> type, 'normal', 'high');
				
				add_action('wp_ajax_load_snippet', array(&$this, 'pk_ajax_load_snippet'));
				add_action('wp_ajax_nopriv_load_snippet', array(&$this, 'pk_ajax_load_snippet'));
				add_action('wp_ajax_save_snippet', array(&$this, 'pk_ajax_save_snippet'));
				add_action('wp_ajax_nopriv_save_snippet', array(&$this, 'pk_ajax_save_snippet'));
				add_action('wp_ajax_update_snippet', array(&$this, 'pk_ajax_update_snippet'));
				add_action('wp_ajax_nopriv_update_snippet', array(&$this, 'pk_ajax_update_snippet'));
				add_action('wp_ajax_delete_snippet', array(&$this, 'pk_ajax_delete_snippet'));
				add_action('wp_ajax_nopriv_delete_snippet', array(&$this, 'pk_ajax_delete_snippet'));
			
			}
			
		}
		
		function pk_ajax_load_snippet() {
			
			$snippet_id = $_POST['snippet_id'];
			
			if (isset($snippet_id)) {
				
				$snippet = get_post(intval($snippet_id));
				
				if ($snippet) {
				
					echo 'success,'.urlencode($snippet -> post_title).','.urlencode($snippet -> post_content);
					
				} else {
					
					echo 'error';
					
				}
				
			} else {
				
				echo 'error';
				
			}
			
			die();
			
		}
		
		function pk_ajax_save_snippet() {
			
			$snippet_title = $_POST['snippet_title'];
			$snippet_content = $_POST['snippet_content'];
			
			if (isset($snippet_title) && isset($snippet_content)) {
				
				$new_snippet = array(
					'post_title' => $snippet_title,
					'post_content' => $snippet_content,
					'post_status' => 'publish',
					'post_author' => 1,
					'post_type' => 'snippets'
				);
				
				$result = wp_insert_post($new_snippet);
				
				if ($result) {
				
					echo 'success,'.$result;
					
				} else {
					
					echo 'error';
					
				}
				
			} else {
				
				echo 'error';
				
			}
			
			die();
			
		}
		
		function pk_ajax_update_snippet() {
			
			$snippet_id = $_POST['snippet_id'];
			$snippet_title = $_POST['snippet_title'];
			$snippet_content = $_POST['snippet_content'];
			
			if (isset($snippet_id) && isset($snippet_title) && isset($snippet_content)) {
				
				$update_snippet = array(
					'ID' => intval($snippet_id),
					'post_title' => $snippet_title,
					'post_content' => $snippet_content,
					'post_type' => 'snippets'
				);
				
				$result = wp_update_post($update_snippet);
				
				if ($result) {
				
					echo 'success,'.$snippet_id.','.urlencode($snippet_title).','.urlencode($snippet_content);
					
				} else {
					
					echo 'error';
					
				}
				
			} else {
				
				echo 'error';
				
			}
			
			die();
			
		}
		
		function pk_ajax_delete_snippet() {
			
			$snippet_id = $_POST['snippet_id'];
			
			if (isset($snippet_id)) {
				
				$result = wp_delete_post((int)$snippet_id, true);
				
				if ($result) {
				
					echo 'success';
					
				} else {
					
					echo 'error';
					
				}
				
			} else {
				
				echo 'error';
				
			}
			
			die();
			
		}
		
		function pk_create_metabox() {
			
			global $pk_snippets_library_manager_instance;
			
			$pk_snippets_library_manager_instance -> pk_open_div();
			
			echo '
		<div id="pk_admin_loading_snippet" class="pk_admin_messages updated">
			<p><strong>'.__('Loading snippet...', 'pk_text_domain').'</strong></p>
		</div>
		<div id="pk_admin_success_loading_snippet" class="pk_admin_messages updated">
			<p><strong>'.__('Snippet loaded!', 'pk_text_domain').'</strong></p>
		</div>
		<div id="pk_admin_error_loading_snippet" class="pk_admin_messages updated">
			<p><strong>'.__('Error loading the snippet, please try again.', 'pk_text_domain').'</strong></p>
		</div>
		<div id="pk_admin_saving_snippet" class="pk_admin_messages updated">
			<p><strong>'.__('Saving snippet...', 'pk_text_domain').'</strong></p>
		</div>
		<div id="pk_admin_success_saving_snippet" class="pk_admin_messages updated">
			<p><strong>'.__('Snippet saved!', 'pk_text_domain').'</strong></p>
		</div>
		<div id="pk_admin_error_saving_snippet" class="pk_admin_messages updated">
			<p><strong>'.__('Error saving the snippet, please try again.', 'pk_text_domain').'</strong></p>
		</div>
		<div id="pk_admin_updating_snippet" class="pk_admin_messages updated">
			<p><strong>'.__('Updating snippet...', 'pk_text_domain').'</strong></p>
		</div>
		<div id="pk_admin_success_updating_snippet" class="pk_admin_messages updated">
			<p><strong>'.__('Snippet updated!', 'pk_text_domain').'</strong></p>
		</div>
		<div id="pk_admin_error_updating_snippet" class="pk_admin_messages updated">
			<p><strong>'.__('Error updating the snippet, please try again.', 'pk_text_domain').'</strong></p>
		</div>
		<div id="pk_admin_deleting_snippet" class="pk_admin_messages updated">
			<p><strong>'.__('Deleting snippet...', 'pk_text_domain').'</strong></p>
		</div>
		<div id="pk_admin_success_deleting_snippet" class="pk_admin_messages updated">
			<p><strong>'.__('Snippet deleted!', 'pk_text_domain').'</strong></p>
		</div>
		<div id="pk_admin_error_deleting_snippet" class="pk_admin_messages updated">
			<p><strong>'.__('Error deleting the snippet, please try again.', 'pk_text_domain').'</strong></p>
		</div>';
			
			$pk_snippets_library_manager_instance -> pk_open_table('select_snippet');
			$pk_snippets_library_manager_instance -> pk_add_title('Select snippet:', false, true);
			$pk_snippets_library_manager_instance -> pk_add_input_post('pk_sl_snippets_list', '', 'snippets', $helper = __('Select the snippet to load.', 'pk_text_domain'));
			$pk_snippets_library_manager_instance -> pk_close_table();
			$pk_snippets_library_manager_instance -> pk_open_table('snippet');
			$pk_snippets_library_manager_instance -> pk_add_title('Snippet:', false, false);
			$pk_snippets_library_manager_instance -> pk_add_input_snippet_form('', '', $rows = '8', $helper = __('Insert the title and the content of a new snippet or update/delete the existing ones.', 'pk_text_domain'));
			$pk_snippets_library_manager_instance -> pk_close_table();
			$pk_snippets_library_manager_instance -> pk_add_buttons();
			$pk_snippets_library_manager_instance -> pk_close_div();
			
		}
		
	}
	
}

?>