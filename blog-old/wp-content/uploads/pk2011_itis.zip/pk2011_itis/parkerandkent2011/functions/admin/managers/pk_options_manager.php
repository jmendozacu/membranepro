<?php

global $pk_options_manager_instance;

if (!class_exists('pk_options_manager')) {
	
	class pk_options_manager extends pk_forms_manager {
		
		function pk_options_manager() {
			
		}
		
		function pk_add_main_title($title = '') {
			
			echo '
	<div id="icon-options-general" class="icon32">
		<br />
	</div>
	<h2>'.$title.'</h2>
	<br />';
			
		}
		
		function pk_data_saved() {
			
			echo '
	<div class="updated">
		<p><strong>'.__('Options saved!', 'pk_text_domain').'</strong></p>
	</div>';
			
		}
		
	}
	
}

if (class_exists('pk_options_manager') && !isset($pk_options_manager_instance)) {
	
	$pk_options_manager_instance = new pk_options_manager();
	
}

?>