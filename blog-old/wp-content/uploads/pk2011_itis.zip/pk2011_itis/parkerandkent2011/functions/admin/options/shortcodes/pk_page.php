<?php

if (class_exists('pk_shortcodes_manager_generator') && !isset($pk_page_shortcodes_manager_generator_instance)) {
	
	global $pk_shortcodes;
	
	$pk_page_shortcodes_manager_generator_instance = new pk_shortcodes_manager_generator($pk_shortcodes, 'page', 'pk_sc_');
	
}

?>