<?php

$pk_page_metaboxes = array();

$pk_page_metaboxes['title'] = __('Options', 'pk_text_domain');
										
$pk_page_metaboxes['options'][0] = array(
										
										'intro' 					=> array('title' => __('Intro:', 'pk_text_domain'), 'type' => 'text_area', 'rows' => '3', 'helper' => __('This textarea is dedicated for the <i>Intro</i> area of the page. Type here your HTML markup.', 'pk_text_domain')),
										'sidebar' 					=> array('title' => __('Sidebar:', 'pk_text_domain'), 'type' => 'select', 'values' => array('none', 'left', 'right'), 'labels' => array(__('None', 'pk_text_domain'), __('Left', 'pk_text_domain'), __('Right', 'pk_text_domain')), 'helper' => __('Select the position of the sidebar for this post. Select <i>None</i> if you want a full width layout.', 'pk_text_domain')),
										'show_comments_sidebar' 	=> array('title' => __('Show comments sidebar:', 'pk_text_domain'), 'type' => 'radio_group', 'values' => array('true', 'false'), 'labels' => array(__('Yes', 'pk_text_domain'), __('No', 'pk_text_domain')), 'helper' => __('Select <i>Yes</i> to display the comments sidebar on the right of the comments. The comments sidebar will be shown only if you\'ve selected the full width layout (<i>None</i>) in the previous <i>Sidebar</i> option.', 'pk_text_domain'))
											
										);
$pk_page_metaboxes['values'][0] = array(
										
										'intro' 					=> '',
										'sidebar' 					=> 'right',
										'show_comments_sidebar' 	=> 'true'
											
										);

$pk_page_metaboxes['options'][1] = array(
										
										'wo_order_by' 				=> array('title' => __('Sort by:', 'pk_text_domain'), 'type' => 'radio_group', 'values' => array('date', 'menu_order', 'comment_count'), 'labels' => array(__('Date', 'pk_text_domain'), __('Custom order (manual sorting)', 'pk_text_domain'), __('Comments count (popular)', 'pk_text_domain')), 'helper' => __('Select the order criteria to apply to this works page. By selecting the <i>Custom order (manual sorting)</i> option the works will be displayed in the order they appear in the <i>Sort Works</i> page.', 'pk_text_domain')),
										'wo_posts_per_page' 		=> array('title' => __('Posts per page:', 'pk_text_domain'), 'type' => 'slider', 'min' => '1', 'max' => '30', 'uom' => __('posts', 'pk_text_domain'), 'helper' => __('Select the max number of works to load for each works page. (If you set 9 and you select the 3 columns layout you will obtain a 3x3 grid).', 'pk_text_domain')),
										'wo_include_ids'			=> array('title' => __('Include single works:', 'pk_text_domain'), 'type' => 'posts', 'post_type' => 'works', 'helper' => __('With this option you can manually add specific works to this page.', 'pk_text_domain')),
										'wo_include_categories'		=> array('title' => __('Include categories:', 'pk_text_domain'), 'type' => 'categories', 'taxonomy' => 'taxonomy_works', 'helper' => __('With this option you can include one or more categories of works to this page.', 'pk_text_domain')),
										'wo_show_categories_filter' => array('title' => __('Show categories filter:', 'pk_text_domain'), 'type' => 'radio_group', 'values' => array('true', 'false'), 'labels' => array(__('Yes', 'pk_text_domain'), __('No', 'pk_text_domain')), 'helper' => __('Select <i>Yes</i> to display a categories filter/switcher on top of the works grid. Note that the filter will be visible only if you add to this page works from more than one category or by including two or more whole categories of works.', 'pk_text_domain')),
										'wo_show_read_more' 		=> array('title' => __('Show read more button:', 'pk_text_domain'), 'type' => 'radio_group', 'values' => array('true', 'false'), 'labels' => array(__('Yes', 'pk_text_domain'), __('No', 'pk_text_domain')), 'helper' => __('Select <i>Yes</i> to display the read more buttons below each works grid item. The 5 and 6 columns layouts can\'t show the read more buttons, for these layouts this setting will be ignored.', 'pk_text_domain'))
										
										);
$pk_page_metaboxes['values'][1] = array(
										
										'wo_order_by' 				=> 'menu_order',
										'wo_posts_per_page' 		=> '9',
										'wo_include_ids' 			=> '',
										'wo_include_categories' 	=> '',
										'wo_show_categories_filter' => 'true',
										'wo_show_read_more' 		=> 'true'
									
										);

$pk_page_metaboxes['options'][2] = array(
										
										'fgg_layout'					=> array('title' => __('Layout:', 'pk_text_domain'), 'type' => 'select', 'values' => array('1', '2', '3', '4'), 'labels' => array(__('One Column', 'pk_text_domain'), __('Two Columns', 'pk_text_domain'), __('Three Columns', 'pk_text_domain'), __('Four Columns', 'pk_text_domain')), 'helper' => __('Select the layout to use for this Flickr grid gallery page.', 'pk_text_domain')),
										'fgg_load_photos_from' 			=> array('title' => __('Load from Flickr:', 'pk_text_domain'), 'type' => 'radio_group', 'values' => array('recent', 'favorites', 'tags', 'photoset', 'galleries'), 'labels' => array(__('Recent photos', 'pk_text_domain'), __('Favorite photos', 'pk_text_domain'), __('Tagged photos', 'pk_text_domain'), __('Photo set', 'pk_text_domain'), __('Photo gallery', 'pk_text_domain')), 'helper' => __('Select which type of photos you want to load from Flickr. Flickr galleries are limited to 18 photos and can\'t be paginated, we recommend to always prefer the photo sets.', 'pk_text_domain')),
										'fgg_flickr_user_id' 			=> array('title' => __('Flickr user id:', 'pk_text_domain'), 'type' => 'text', 'helper' => __('By entering a Flickr user id the system will automatically load all the photo sets and galleries that belong to that Flickr account. If you don\'t know where to find it, you can use <a href="http://idgettr.com/" title="Flickr idGettr">idGettr</a> to retrive it.', 'pk_text_domain')),
										'fgg_flickr_group_id' 			=> array('title' => __('Flickr group id:', 'pk_text_domain'), 'type' => 'text', 'helper' => __('By entering a Flickr group id you can load recent and tagged photos that belong to the specified Flickr group. If you don\'t know where to find it, you can use <a href="http://idgettr.com/" title="Flickr idGettr">idGettr</a> to retrive it.', 'pk_text_domain')),
										'fgg_flickr_user_tags' 			=> array('title' => __('Flickr photo tags:', 'pk_text_domain'), 'type' => 'text', 'helper' => __('Type here a comma separated list of tags (eg. design,art,architecture). The tags will be used if you\'ve selected <i>Tagged photos</i> in the previous <i>Load from Flickr</i> option.', 'pk_text_domain')),
										'fgg_select_set' 				=> array('title' => __('Select a Flickr photo set:', 'pk_text_domain'), 'type' => 'select', 'values' => array(), 'labels' => array(), 'helper' => __('Select the Flickr photo set that you want to load. The selected photo set will be loaded only if you\'ve selected <i>Photo set</i> in the previous <i>Load from Flickr</i> option.', 'pk_text_domain')),
										'fgg_select_galleries' 			=> array('title' => __('Select a Flickr photo gallery:', 'pk_text_domain'), 'type' => 'select', 'values' => array(), 'labels' => array(), 'helper' => __('Select the Flickr gallery that you want to load. The selected gallery will be loaded only if you\'ve selected <i>Photo gallery</i> in the previous <i>Load from Flickr</i> option.', 'pk_text_domain')),
										'fgg_total_images' 				=> array('title' => __('Number of photos per page:', 'pk_text_domain'), 'type' => 'slider', 'min' => '1', 'max' => '50', 'uom' => __('photos', 'pk_text_domain'), 'helper' => __('Set the max number of photos to load for each gallery page. (If you set 9 and you select the 3 columns layout you will obtain a 3x3 grid).', 'pk_text_domain')),
										'fgg_thumbs_style' 				=> array('title' => __('Thumbnails style:', 'pk_text_domain'), 'type' => 'select', 'values' => array('16/9', '4/3', 'portrait', 'square', 'auto', 'custom'), 'labels' => array(__('16/9', 'pk_text_domain'), __('4/3', 'pk_text_domain'), __('Portrait', 'pk_text_domain'), __('Square', 'pk_text_domain'), __('Auto Height', 'pk_text_domain'), __('Custom Height', 'pk_text_domain')), 'helper' => __('Select the style of the thumbnails.', 'pk_text_domain')),
										'fgg_thumbs_height' 			=> array('title' => __('Thumbnails height:', 'pk_text_domain'), 'type' => 'slider', 'min' => '0', 'max' => '920', 'uom' => 'px', 'helper' => __('Set the thumbnails height. This setting will be used only if you\'ve set the thumbnail style to <i>Custom Height</i>.', 'pk_text_domain')),
										'fgg_thumbs_icon' 				=> array('title' => __('Thumbnails icon:', 'pk_text_domain'), 'type' => 'select', 'values' => array('', 'pk_page_icon', 'pk_link_icon', 'pk_play_icon', 'pk_zoom_icon'), 'labels' => array(__('None', 'pk_text_domain'), __('Page', 'pk_text_domain'), __('Link', 'pk_text_domain'), __('Play', 'pk_text_domain'), __('Zoom', 'pk_text_domain')), 'helper' => __('Select the icon type that you want to show for the roll over on the thumbnails.', 'pk_text_domain')),
										'fgg_thumbs_action' 			=> array('title' => __('Thumbnails action:', 'pk_text_domain'), 'type' => 'select', 'values' => array('link', 'lightbox'), 'labels' => array(__('Link to Flickr', 'pk_text_domain'), __('Open lightbox gallery', 'pk_text_domain')), 'helper' => __('Select the action for the click on the thumbnails.', 'pk_text_domain')),
										'fgg_title_action' 				=> array('title' => __('Titles action:', 'pk_text_domain'), 'type' => 'select', 'values' => array('', 'link'), 'labels' => array(__('None', 'pk_text_domain'), __('Link to Flickr', 'pk_text_domain')), 'helper' => __('Select the action for the click on the title.', 'pk_text_domain')),
										'fgg_show_photo_title' 			=> array('title' => __('Show photo titles:', 'pk_text_domain'), 'type' => 'radio_group', 'values' => array('true', 'false'), 'labels' => array(__('Yes', 'pk_text_domain'), __('No', 'pk_text_domain')), 'helper' => __('Select <i>No</i> to hide the photo title.', 'pk_text_domain')),
										'fgg_show_photo_description' 	=> array('title' => __('Show photo descriptions:', 'pk_text_domain'), 'type' => 'radio_group', 'values' => array('true', 'false'), 'labels' => array(__('Yes', 'pk_text_domain'), __('No', 'pk_text_domain')), 'helper' => __('Select <i>No</i> to hide the photo description.', 'pk_text_domain')),
										'fgg_slideshow_auto_start' 		=> array('title' => __('Slideshow auto start:', 'pk_text_domain'), 'type' => 'radio_group', 'values' => array('true', 'false'), 'labels' => array(__('Yes', 'pk_text_domain'), __('No', 'pk_text_domain')), 'helper' => __('Select <i>Yes</i> to automatically start the slideshow. This setting will be used if the lightbox option is active.', 'pk_text_domain')),
										'fgg_slideshow_interval' 		=> array('title' => __('Slideshow duration:', 'pk_text_domain'), 'type' => 'slider', 'min' => '1', 'max' => '10', 'uom' => __('seconds', 'pk_text_domain'), 'helper' => __('Set the slideshow duration. This setting will be used if the lightbox option is selected.', 'pk_text_domain'))
										
										);
$pk_page_metaboxes['values'][2] = array(
										
										'fgg_layout' 					=> '3',
										'fgg_load_photos_from' 			=> 'recent',
										'fgg_flickr_user_id' 			=> pk_get_options('pk_general_options', 'general_flickr_user_id'),
										'fgg_flickr_group_id' 			=> '',
										'fgg_flickr_user_tags' 			=> '',
										'fgg_select_set' 				=> '',
										'fgg_select_galleries' 			=> '',
										'fgg_total_images' 				=> '9',
										'fgg_thumbs_style' 				=> '16/9',
										'fgg_thumbs_height' 			=> '0',
										'fgg_thumbs_icon' 				=> 'pk_zoom_icon',
										'fgg_thumbs_action' 			=> 'lightbox',
										'fgg_title_action' 				=> 'link',
										'fgg_show_photo_title' 			=> 'true',
										'fgg_show_photo_description' 	=> 'false',
										'fgg_slideshow_auto_start' 		=> 'false',
										'fgg_slideshow_interval' 		=> '5'
									
										);

$pk_page_metaboxes['options'][3] = array(
										
										'tsp_slider_posts_type' 		=> array('title' => __('Slider type:', 'pk_text_domain'), 'type' => 'select', 'values' => array('post', 'works', 'slides', 'categories'), 'labels' => array(__('Recent posts', 'pk_text_domain'), __('Recent works', 'pk_text_domain'), __('Recent slides', 'pk_text_domain'), __('Categories (select below)', 'pk_text_domain')), 'helper' => __('Select which type of posts to load in the slider. If you select the option <i>Categories</i> you have to select one or more categories of slides, works or blog posts below. You can\'t mix the categories, so select only categories of a specific type (slides, works or posts).', 'pk_text_domain')),
										'tsp_slider_slides_categories' 	=> array('title' => __('Slides categories:', 'pk_text_domain'), 'type' => 'categories', 'taxonomy' => 'taxonomy_slides', 'helper' => __('With this option you can include one or more categories of slides to this slider.', 'pk_text_domain')),
										'tsp_slider_works_categories' 	=> array('title' => __('Works categories:', 'pk_text_domain'), 'type' => 'categories', 'taxonomy' => 'taxonomy_works', 'helper' => __('With this option you can include one or more categories of works to this slider.', 'pk_text_domain')),
										'tsp_slider_posts_categories' 	=> array('title' => __('Posts categories:', 'pk_text_domain'), 'type' => 'categories', 'taxonomy' => 'category', 'helper' => __('With this option you can include one or more categories of blog posts to this slider.', 'pk_text_domain')),
										'tsp_slider_total_posts' 		=> array('title' => __('Slider total posts:', 'pk_text_domain'), 'type' => 'slider', 'min' => '1', 'max' => '30', 'uom' => __('posts', 'pk_text_domain'), 'helper' => __('Set the max number of posts to load in the slider.', 'pk_text_domain')),
										'tsp_slider_width' 				=> array('title' => __('Slider width:', 'pk_text_domain'), 'type' => 'slider', 'min' => '0', 'max' => '940', 'uom' => __('px', 'pk_text_domain'), 'helper' => __('Set the width of the slider.', 'pk_text_domain')),
										'tsp_slider_height' 			=> array('title' => __('Slider height:', 'pk_text_domain'), 'type' => 'slider', 'min' => '0', 'max' => '940', 'uom' => __('px', 'pk_text_domain'), 'helper' => __('Set the height of the slider.', 'pk_text_domain')),
										'tsp_thumbnails_spacing' 		=> array('title' => __('Slider thumbnails spacing:', 'pk_text_domain'), 'type' => 'slider', 'min' => '0', 'max' => '30', 'uom' => 'px', 'helper' => __('Set the space to add between the thumbnails.', 'pk_text_domain')),
										'tsp_thumbnails_width' 			=> array('title' => __('Slider thumbnails width:', 'pk_text_domain'), 'type' => 'slider', 'min' => '0', 'max' => '470', 'uom' => 'px', 'helper' => __('Set the thumbnails width.', 'pk_text_domain')),
										'tsp_thumbnails_height' 		=> array('title' => __('Slider thumbnails height:', 'pk_text_domain'), 'type' => 'slider', 'min' => '0', 'max' => '470', 'uom' => 'px', 'helper' => __('Set the thumbnails heigh.', 'pk_text_domain')),
										'tsp_thumbnails_visible' 		=> array('title' => __('Slider visible thumbnails:', 'pk_text_domain'), 'type' => 'slider', 'min' => '0', 'max' => '10', 'uom' => 'thumbnails', 'helper' => __('Set the number of visible thumbnails. If you set a smaller value than the total number of thumbnails, the hidden ones will be shown by using the slider navigation controls.', 'pk_text_domain')),
										'tsp_tooltips_width' 			=> array('title' => __('Slider tooltips width:', 'pk_text_domain'), 'type' => 'slider', 'min' => '0', 'max' => '470', 'uom' => 'px', 'helper' => __('Set the width of the tooltip that appears on thumbnails roll over.', 'pk_text_domain')),
										'tsp_tooltips_read_more' 		=> array('title' => __('Slider show tooltips read more button:', 'pk_text_domain'), 'type' => 'radio_group', 'values' => array('true', 'false'), 'labels' => array(__('Yes', 'pk_text_domain'), __('No', 'pk_text_domain')), 'helper' => __('Select <i>Yes</i> to show a read more button within the thumbnails tooltip.', 'pk_text_domain')),
										'tsp_slideshow_auto_start' 		=> array('title' => __('Slider slideshow auto start:', 'pk_text_domain'), 'type' => 'radio_group', 'values' => array('true', 'false'), 'labels' => array(__('Yes', 'pk_text_domain'), __('No', 'pk_text_domain')), 'helper' => __('Select <i>Yes</i> to automatically start the slideshow.', 'pk_text_domain')),
										'tsp_slideshow_interval' 		=> array('title' => __('Slider slideshow duration:', 'pk_text_domain'), 'type' => 'slider', 'min' => '1', 'max' => '10', 'uom' => __('seconds', 'pk_text_domain'), 'helper' => __('Set the slideshow duration.', 'pk_text_domain'))
										
										);
$pk_page_metaboxes['values'][3] = array(
										
										'tsp_slider_posts_type' 		=> 'post',
										'tsp_slider_slides_categories' 	=> '',
										'tsp_slider_works_categories' 	=> '',
										'tsp_slider_posts_categories' 	=> '',
										'tsp_slider_total_posts' 		=> '6',
										'tsp_slider_width' 				=> '940',
										'tsp_slider_height' 			=> '400',
										'tsp_thumbnails_spacing' 		=> '2',
										'tsp_thumbnails_width' 			=> '155',
										'tsp_thumbnails_height' 		=> '60',
										'tsp_thumbnails_visible' 		=> '6',
										'tsp_tooltips_width' 			=> '180',
										'tsp_tooltips_read_more' 		=> 'true',
										'tsp_slideshow_auto_start' 		=> 'true',
										'tsp_slideshow_interval' 		=> '5'
									
										);

$pk_page_metaboxes['options'][4] = array(
										
										'lightbox_gallery' 				=> array('title' => __('Lightbox gallery manager:', 'pk_text_domain'), 'type' => 'lightbox_gallery_manager', 'helper' => __('By clicking on the <i>Add Item</i> button you can add as many items (images, videos, etc.) as you need (check the <a href="http://www.no-margin-for-errors.com/projects/prettyphoto-jquery-lightbox-clone/" title="prettyPhoto official website">prettyPhoto official website</a> for more info about what kind of contents you can load). By dragging and dropping you can modify the order of your gallery items. The lightbox gallery of this post can be opened by using a button or a cover image in your post (check the <i>Buttons</i> and the <i>Images</i> panels of the Shortcodes Manager). The <i>Gallery id</i> field is automatically filled with the post id, it is needed to identify the gallery and we suggest to keep this value as it is also because there isn\'t any reason to change it. You can also open this gallery with a normal link within your post, check the prettyPhoto official website linked before for more info about how to open prettyPhoto by using a link tag.', 'pk_text_domain'))
										
										);
$pk_page_metaboxes['values'][4] = array(
										
										'lightbox_gallery' 				=> ''
										
										);
										
if (class_exists('pk_metaboxes_generator') && !isset($pk_page_metaboxes_instance)) {
	
	$pk_page_metaboxes_instance = new pk_metaboxes_generator($pk_page_metaboxes, 'page', 'pk_');
	
}

?>