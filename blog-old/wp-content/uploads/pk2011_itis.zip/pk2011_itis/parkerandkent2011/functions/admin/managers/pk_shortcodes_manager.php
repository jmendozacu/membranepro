<?php

global $pk_shortcodes_manager_instance;

if (!class_exists('pk_shortcodes_manager')) {
	
	class pk_shortcodes_manager extends pk_forms_manager {
		
		function pk_shortcodes_manager() {
			
		}
		
		function pk_open_table($id = '') {
			
			echo '
			<table cellspacing="0" id="pk_sc_table_'.$id.'" class="widefat">
				<tbody>';
			
		}
		
		function pk_close_table() {
			
			echo '
				</tbody>
			</table>';
			
		}
		
		function pk_open_shortcodes_manager_div($class = '') {
			
			echo '
		<div class="'.(($class != 'pk_sc_selector') ? 'pk_admin_sc_div pk_admin_padding_top_div ' : '').$class.'">';
			
		}
		
		function pk_close_shortcodes_manager_div() {
			
			echo '
		</div>';
			
		}
		
		function pk_open_div() {
			
			echo '
	<!-- pk shortcodes manager metabox - start -->
	<div class="pk_sc_shortcodes_manager">';
			
		}
		
		function pk_close_div() {
			
			echo '
	</div>
	<!-- pk shortcodes manager metabox - end -->

';
			
		}
		
		function pk_add_buttons($type, $add_library) {
			
			echo '
			<div class="pk_admin_shortcode_manager_buttons_div">'.(($add_library == true) ? '
				<input id="pk_sc_table_'.$type.'_open_shortcodes_library_button" class="pk_admin_open_shortcodes_library_button button-primary" type="button" value="'.__('Open Shortcodes Library', 'pk_text_domain').'" data-type="'.$type.'" data-message="'.__('There are no shortcodes saved for this category.', 'pk_text_domain').'" />
				<input id="pk_sc_table_'.$type.'_close_shortcodes_library_button" class="pk_admin_close_shortcodes_library_button button-primary" type="button" value="'.__('Close Shortcodes Library', 'pk_text_domain').'" data-type="'.$type.'" />' : '').'
				<input id="pk_sc_table_'.$type.'_generate_shortcode_button" class="pk_admin_generate_shortcode_button button-primary" type="button" value="'.__('Generate Shortcode', 'pk_text_domain').'" />
			</div>';
			
		}
		
	}
	
}

if (class_exists('pk_shortcodes_manager') && !isset($pk_shortcodes_manager_instance)) {
	
	$pk_shortcodes_manager_instance = new pk_shortcodes_manager();
	
}

?>