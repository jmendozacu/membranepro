<?php

$pk_footer_options = array();

$pk_footer_options[0]['title'] = __('Footer Options', 'pk_text_domain');
$pk_footer_options[0]['options'] = array(
										
										'footer_copyright_text' 		=> array('title' => __('Copyright text:', 'pk_text_domain'), 'type' => 'text', 'helper' => __('The copyright text will be visible on the bottom-right of the pages.', 'pk_text_domain')),
										'footer_show_top_link' 			=> array('title' => __('Show "top" link:', 'pk_text_domain'), 'type' => 'radio_group', 'values' => array('true', 'false'), 'labels' => array(__('Yes', 'pk_text_domain'), __('No', 'pk_text_domain')), 'helper' => __('Select <i>Yes</i> to show a "top" link in the theme footer.', 'pk_text_domain')),
										'footer_show_widget_area' 		=> array('title' => __('Show widgets area:', 'pk_text_domain'), 'type' => 'radio_group', 'values' => array('true', 'false'), 'labels' => array(__('Yes', 'pk_text_domain'), __('No', 'pk_text_domain')), 'helper' => __('Select <i>No</i> to completely disable the footer widgets area.', 'pk_text_domain')),
										'footer_widget_area_heading' 	=> array('title' => __('Widgets area heading:', 'pk_text_domain'), 'type' => 'text', 'helper' => __('Enter a title for the footer widgets area. Leave it empty if you don\'t want to show a title.', 'pk_text_domain')),
										'footer_widget_area_layout' 	=> array('title' => __('Footer layout:', 'pk_text_domain'), 'type' => 'footer_layout_manager', 'helper' => __('With this utility you can create the layout of the footer widgets area. Add the columns that you need, from 1 to a maximum of 6. For example, if you add 3 columns they will load the first 3 sidebars of the 6 available for this footer profile (Appearance > Widgets).', 'pk_text_domain')),
										'footer_social_networks' 		=> array('title' => __('Social networks:', 'pk_text_domain'), 'type' => 'footer_social_networks_manager', 'helper' => __('With this utility you can add all your social profiles to the footer. Select the social networks from the list and enter the URLs of your profiles. You can also change the order of them using the drag and drop functionality.', 'pk_text_domain'))		
										
										);
$pk_footer_options[0]['values'] = array(
										
										'footer_copyright_text' 		=> '&copy; parker&amp;kent',
										'footer_show_top_link' 			=> 'true',
										'footer_show_widget_area' 		=> 'true',
										'footer_widget_area_heading'	=> '',
										'footer_widget_area_layout'		=> '',
										'footer_social_networks'		=> ''
									
										);
$pk_footer_options[0]['save_button'] = true;

if (class_exists('pk_options_generator') && !isset($pk_footer_options_instance)) {
	
	add_option('pk_footer_options_profiles', array('default'));
	add_option('pk_footer_options_current_profile', 'default');
	add_option('pk_footer_options_active_profile', 'default');
	
	$pk_footer_options_instance = new pk_options_generator($pk_footer_options, 'level_10', __('Footer Options', 'pk_text_domain'), 'pk_general_options', 'pk_footer_options', 'pk_footer_options', 'pk_', array('pk_footer_options_profiles', 'pk_footer_options_current_profile', 'pk_footer_options_active_profile', 'pk_footer_options'));
	
	/*global $pk_dashboard_options;
	
	$pk_profiles = get_option('pk_footer_options_profiles');
	
	foreach ($pk_profiles as $k => $v) {
	
		$pk_dashboard_options['pk_footer_options_'.$v] = sprintf(__('Footer Options - %s', 'pk_text_domain'), (($v == 'default') ? __('Default', 'pk_text_domain') : stripslashes(base64_decode($v))));
	
	}*/
	
}

?>