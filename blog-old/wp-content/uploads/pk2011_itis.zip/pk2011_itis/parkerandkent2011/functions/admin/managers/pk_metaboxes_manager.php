<?php

global $pk_metaboxes_manager_instance;

if (!class_exists('pk_metaboxes_manager')) {
	
	class pk_metaboxes_manager extends pk_forms_manager {
		
		function pk_metaboxes_manager() {
			
		}
		
		function pk_open_table($id = 0) {
			
			echo '
			<div id="pk_metabox_div_'.$id.'"'.(($id > 0) ? ' class="pk_admin_padding_top_div"' : '').'><table id="pk_metabox_table_'.$id.'" cellspacing="0" class="widefat">
				<tbody>';
			
		}
		
		function pk_close_table() {
			
			echo '
				</tbody>
			</table></div>';
			
		}
		
		function pk_open_form($type, $id) {
			
			echo '
		<form name="pk_form" method="post" action="">';
			
			wp_nonce_field('pk_'.$id.'_noncename', 'pk_'.$type.'_noncename');
			
		}
		
		function pk_close_form() {
			
			echo '
		</form>';
			
		}
		
		function pk_open_div() {
			
			global $post;
			
			echo '
	<!-- pk options metabox - start -->
	<div>
		<input id="pk_post_id" type="hidden" value="'.$post -> ID.'" />';
			
		}
		
		function pk_close_div() {
			
			echo '
	</div>
	<!-- pk options metabox - end -->

';
			
		}
		
	}
	
}

if (class_exists('pk_metaboxes_manager') && !isset($pk_metaboxes_manager_instance)) {
	
	$pk_metaboxes_manager_instance = new pk_metaboxes_manager();
	
}

?>