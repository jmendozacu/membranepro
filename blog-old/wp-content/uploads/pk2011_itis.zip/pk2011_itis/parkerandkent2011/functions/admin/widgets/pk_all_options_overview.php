<?php

global $pk_dashboard_options;

function pk_all_options_overview() {
	
	function myprint_r($array, $title) {
		
		if (is_array($array)) {
			
			echo 
'
<table cellspacing="0" class="pk_admin_dashboard_table widefat">';
			echo 
	'
	<thead>
		<tr>
			<th colspan="2">'.stripslashes($title).'</th>
		</tr>
	</thead>
	<tbody>';
				
			foreach ($array as $k => $v) {
				
				echo '
		<tr>
			<td valign="top" class="pk_admin_dashboard_td"><strong>'.$k.'</strong></td>
			<td>';
				myprint_r(stripslashes(strip_tags($v)), '');
				echo '</td>
		</tr>';
		
			}
			
			echo '
	</tbody>
</table>
';
			
		} else {
			
			echo $array;
			
		}
		
	}
	
	global $pk_dashboard_options;
	
	if (!is_array($pk_dashboard_options)) {
		
		return;
		
	}
	
	$count = 0;
	
	foreach ($pk_dashboard_options as $k => $v) {

		if ($count > 0) echo '<br />';
		echo myprint_r(get_option($k), $v);
		
		$count++;
		
	}

} 

function pk_add_dashboard_widgets() {
	
	wp_add_dashboard_widget('pk_all_options_overview_id', __('All Options Overview', 'pk_text_domain'), 'pk_all_options_overview');
	
}

?>