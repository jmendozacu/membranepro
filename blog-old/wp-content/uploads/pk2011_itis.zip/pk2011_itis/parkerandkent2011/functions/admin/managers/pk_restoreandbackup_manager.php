<?php

global $pk_restoreandbackup_manager_instance;

if (!class_exists('pk_restoreandbackup_manager')) {
	
	class pk_restoreandbackup_manager extends pk_forms_manager {
		
		function pk_restoreandbackup_manager() {
			
		}
		
		function pk_add_main_title($title = '') {
			
			echo '
	<div id="icon-options-general" class="icon32">
		<br />
	</div>
	<h2>'.$title.'</h2>
	<br />';
			
		}
		
		function pk_add_input_text_area($name = '', $value = '', $rows = '12', $helper = '') {
			
			($value != '') ? $select_all = ' pk_admin_input_text_area_select_all' : $select_all = '';
			
			echo '
						<td class="pk_admin_td">
							<p><textarea rows="'.$rows.'" class="pk_admin_input_text_area'.$select_all.'" name="'.$name.'">'.$value.'</textarea></p>
							<p class="pk_admin_helper"><strong class="pk_admin_helper_strong">? </strong>'.$helper.'</p>
						</td>
					</tr>';
			
		}
		
		function pk_options_restored() {
			
			echo '
	<div class="updated">
		<p><strong>'.__('Options restored!', 'pk_text_domain').'</strong></p>
	</div>';
			
		}
		
		function pk_options_unrestored() {
			
			echo '
	<div class="updated">
		<p><strong>'.__('Options not restored! Please verify the data you have entered!', 'pk_text_domain').'</strong></p>
	</div>';
			
		}
		
		function pk_add_restore_options_button() {
				
			echo '
			<p class="submit"><input class="pk_admin_restore_options_button button-primary" type="submit" name="submit" value="'.__('Restore Options', 'pk_text_domain').'" data-message="'.__('By restoring the options you will lose all your actual settings. Do you wish to continue?', 'pk_text_domain').'" /></p>';
			
		}
		
	}
	
}

if (class_exists('pk_restoreandbackup_manager') && !isset($pk_restoreandbackup_manager_instance)) {
	
	$pk_restoreandbackup_manager_instance = new pk_restoreandbackup_manager();
	
}

?>