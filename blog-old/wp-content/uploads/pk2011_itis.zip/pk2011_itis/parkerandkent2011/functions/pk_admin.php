<?php

if (!class_exists('pk_admin')) {
	
	class pk_admin {
		
		function pk_admin() {
			
			define('PK_ADMIN_FUNCTIONS', PK_FUNCTIONS.'/admin');
			define('PK_ADMIN_MANAGERS', PK_ADMIN_FUNCTIONS.'/managers');
			define('PK_ADMIN_GENERATORS', PK_ADMIN_FUNCTIONS.'/generators');
			define('PK_ADMIN_OPTIONS', PK_ADMIN_FUNCTIONS.'/options');
			define('PK_ADMIN_TYPES', PK_ADMIN_FUNCTIONS.'/types');
			define('PK_ADMIN_WIDGETS', PK_ADMIN_FUNCTIONS.'/widgets');
			define('PK_ADMIN_RESTOREANDBACKUP', PK_ADMIN_FUNCTIONS.'/restoreandbackup');
			define('PK_ADMIN_DEMOCONTENTS', PK_ADMIN_FUNCTIONS.'/democontents');
			define('PK_ADMIN_HELP', PK_ADMIN_FUNCTIONS.'/help');
				
			require_once(PK_ADMIN_FUNCTIONS.'/pk_setup.php');
				
			require_once(PK_ADMIN_MANAGERS.'/pk_forms_manager.php');
			require_once(PK_ADMIN_MANAGERS.'/pk_profiles_manager.php');
			require_once(PK_ADMIN_MANAGERS.'/pk_options_manager.php');
			require_once(PK_ADMIN_MANAGERS.'/pk_metaboxes_manager.php');
			require_once(PK_ADMIN_MANAGERS.'/pk_shortcodes_manager.php');
			require_once(PK_ADMIN_MANAGERS.'/pk_snippets_library_manager.php');
			require_once(PK_ADMIN_MANAGERS.'/pk_restoreandbackup_manager.php');
			require_once(PK_ADMIN_MANAGERS.'/pk_democontents_manager.php');
			
			require_once(PK_ADMIN_GENERATORS.'/pk_options_generator.php');
			require_once(PK_ADMIN_GENERATORS.'/pk_metaboxes_generator.php');
			require_once(PK_ADMIN_GENERATORS.'/pk_shortcodes_manager_generator.php');
			require_once(PK_ADMIN_GENERATORS.'/pk_snippets_library_generator.php');
			
			require_once(PK_ADMIN_OPTIONS.'/options/pk_options.php');
			require_once(PK_ADMIN_OPTIONS.'/options/pk_general.php');
			require_once(PK_ADMIN_OPTIONS.'/options/pk_navigation.php');
			require_once(PK_ADMIN_OPTIONS.'/options/pk_blog.php');
			require_once(PK_ADMIN_OPTIONS.'/options/pk_blog_archive.php');
			require_once(PK_ADMIN_OPTIONS.'/options/pk_works_archive.php');
			require_once(PK_ADMIN_OPTIONS.'/options/pk_search.php');
			require_once(PK_ADMIN_OPTIONS.'/options/pk_skin.php');
			require_once(PK_ADMIN_OPTIONS.'/options/pk_footer.php');
			
			require_once(PK_ADMIN_OPTIONS.'/shortcodes/pk_shortcodes.php');
			require_once(PK_ADMIN_OPTIONS.'/shortcodes/pk_post.php');
			require_once(PK_ADMIN_OPTIONS.'/shortcodes/pk_page.php');
			require_once(PK_ADMIN_OPTIONS.'/shortcodes/pk_slides.php');
			require_once(PK_ADMIN_OPTIONS.'/shortcodes/pk_works.php');
			
			require_once(PK_ADMIN_OPTIONS.'/snippets/pk_post.php');
			require_once(PK_ADMIN_OPTIONS.'/snippets/pk_page.php');
			require_once(PK_ADMIN_OPTIONS.'/snippets/pk_slides.php');
			require_once(PK_ADMIN_OPTIONS.'/snippets/pk_works.php');
			
			require_once(PK_ADMIN_OPTIONS.'/metaboxes/pk_page.php');
			require_once(PK_ADMIN_OPTIONS.'/metaboxes/pk_post.php');
			require_once(PK_ADMIN_OPTIONS.'/metaboxes/pk_slides.php');
			require_once(PK_ADMIN_OPTIONS.'/metaboxes/pk_works.php');
			
			require_once(PK_ADMIN_TYPES.'/pk_snippets.php');
			
			require_once(PK_ADMIN_WIDGETS.'/pk_all_options_overview.php');
			
			require_once(PK_ADMIN_RESTOREANDBACKUP.'/pk_restoreandbackup.php');
			
			require_once(PK_ADMIN_DEMOCONTENTS.'/pk_democontents.php');
			
			require_once(PK_ADMIN_HELP.'/pk_help.php');

		}
		
	}
	
}

if (class_exists('pk_admin') && !isset($pk_admin_instance)) {
	
	$pk_admin_instance = new pk_admin();
	
}

?>