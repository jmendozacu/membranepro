<?php

function pk_top_slider_page_slider() {
	
	$pk_home_page_meta = pk_get_meta();
	
	if ($pk_home_page_meta['tsp_slider_posts_type'] != 'categories'){
	
		$r = new WP_Query(array('post_type' => $pk_home_page_meta['tsp_slider_posts_type'], 'posts_per_page' => (int)$pk_home_page_meta['tsp_slider_total_posts'], 'post_status' => 'publish', 'ignore_sticky_posts' => 1));
		
		$post_type = $pk_home_page_meta['tsp_slider_posts_type'];
		
	} else {
		
		if ($pk_home_page_meta['tsp_slider_slides_categories'] != '') {
			
			$posts_to_query = get_objects_in_term(explode(',', $pk_home_page_meta['tsp_slider_slides_categories']), 'taxonomy_slides');
			
			$r = new WP_Query(array('post_type' => 'slides', 'post__in' => $posts_to_query, 'posts_per_page' => (int)$pk_home_page_meta['tsp_slider_total_posts'], 'post_status' => 'publish', 'orderby' => 'menu_order', 'order' => 'ASC', 'ignore_sticky_posts' => 1));
			
			$post_type = 'slides';
			
		} else {
			
			if ($pk_home_page_meta['tsp_slider_works_categories'] != '') {
				
				$posts_to_query = get_objects_in_term(explode(',', $pk_home_page_meta['tsp_slider_works_categories']), 'taxonomy_works');
				
				$r = new WP_Query(array('post_type' => 'works', 'post__in' => $posts_to_query, 'posts_per_page' => (int)$pk_home_page_meta['tsp_slider_total_posts'], 'post_status' => 'publish', 'orderby' => 'menu_order', 'order' => 'ASC', 'ignore_sticky_posts' => 1));
				
				$post_type = 'works';
				
			} else {
				
				if ($pk_home_page_meta['tsp_slider_posts_categories'] != '') {
					
					$posts_to_query = get_objects_in_term(explode(',', $pk_home_page_meta['tsp_slider_posts_categories']), 'category');
					
					$r = new WP_Query(array('post_type' => 'post', 'post__in' => $posts_to_query, 'posts_per_page' => (int)$pk_home_page_meta['tsp_slider_total_posts'], 'post_status' => 'publish', 'ignore_sticky_posts' => 1));
					
				} else {
					
					$r = new WP_Query(array('post_type' => 'post', 'posts_per_page' => (int)$pk_home_page_meta['tsp_slider_total_posts'], 'post_status' => 'publish', 'ignore_sticky_posts' => 1));
					
				}
				
				$post_type = 'post';
				
			}
			
		}
		
	}
	
	if ($r -> have_posts()) : 
	
		add_filter('excerpt_more', 'pk_excerpt_more');
		add_filter('excerpt_length', 'pk_sliders_info_filter');
?>

<!-- pk start top slider -->
<div id="pk_featured">
<div class="pk_itis_slider" id="pk_itis_slider">
	
<!-- pk start top slider content -->
<div class="pk_slider_content">
<?php
		while ($r -> have_posts()) : $r -> the_post();
		
			$image = pk_get_featured_image();
			$meta = pk_get_meta();
		
			if ($image && $post_type == 'post') : 
?>

<!-- pk start top slider item -->
<div class="pk_slider_item">
	<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>">
		<img src="<?php echo pk_build_image($image[0], (int)$pk_home_page_meta['tsp_slider_width'], (int)$pk_home_page_meta['tsp_slider_height'], 1); ?>" />
	</a>
	<div class="pk_tooltip_caption">
		<h3><?php the_title(); ?></h3>
		<?php the_excerpt(); ?>
		 <a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" class="pk_tooltip_post_link"><?php _e('Read more &raquo;', 'pk_text_domain_front'); ?></a>
	</div>
</div>
<!-- pk end top slider item -->
<?php
			endif;
			
			if ($post_type == 'slides') : 
				
				$use_featured_image = (isset($meta['use_featured_image'])) ? $meta['use_featured_image'] : 'true';
				$image_action = (isset($meta['image_action'])) ? $meta['image_action'] : '';
				$image_link_url = (isset($meta['image_link_url'])) ? $meta['image_link_url'] : '';
				$use_custom_players = (isset($meta['use_custom_players'])) ? $meta['use_custom_players'] : 'true';
				$auto_play = (isset($meta['auto_play'])) ? $meta['auto_play'] : 'false';
				$file_type = (isset($meta['file_type'])) ? $meta['file_type'] : '';
				
				$file_type = explode(',', $file_type);
				$file_type = (isset($file_type[1])) ? $file_type[1] : '';
				
				if ($use_featured_image == 'true' || $file_type == '') {
					
					if ($file_type == '') $file_type = 'image';
					$image = pk_get_featured_image();
					if ($image) $image = $image[0];
					
				}
				
				if ($use_featured_image == 'false' && $file_type == 'image') {
					
					$image = $meta['image'];
					
				}
				
				if ($file_type == 'audio') {
					
					$audio = explode(',', $meta['audio']);
					if ($use_featured_image == 'false') $image = $audio[0];
					
				}
				
				if ($file_type == 'video') {
					
					$video = explode(',', $meta['video']);
					if ($use_featured_image == 'false') $image = $video[1];
					
					if ((int)$video[0] == 1) $file_type = 'html5';
					if ((int)$video[0] == 2) $file_type = 'video';
					if ((int)$video[0] == 3) $file_type = 'youtube';
					if ((int)$video[0] == 3 && $use_custom_players == 'true') $file_type = 'youtube_custom';
					if ((int)$video[0] == 4) $file_type = 'vimeo';
					
				}
				
				if ($file_type == 'swf') {
					
					$swf = $meta['swf'];
					
				}
?>

<!-- pk start top slider item -->
<div class="pk_slider_item">
<?php
				switch ($file_type) {
					
					case 'image' :
						
						if ($image && $image_action != '') : 
							
							echo '
<!-- pk start image -->
<a href="'.(($image_action == 'link') ? esc_url($image_link_url) : esc_url($image)).'" title="'.get_the_title().'"'.(($image_action == 'lightbox') ? ' rel="prettyPhoto[pk_top_slider_lightbox]"' : '').'>
	<img src="'.pk_build_image($image, (int)$pk_home_page_meta['tsp_slider_width'], (int)$pk_home_page_meta['tsp_slider_height'], 1).'" />
	<span class="pk_image_button_overlay"></span>
</a>
<!-- pk end image -->
';
							
						endif;
						
						if ($image && $image_action == '') : 
							
							echo '
<!-- pk start image -->
<img src="'.pk_build_image($image, (int)$pk_home_page_meta['tsp_slider_width'], (int)$pk_home_page_meta['tsp_slider_height'], 1).'" />
<!-- pk end image -->
';
							
						endif;
						
						break;
						
					case 'audio' :
						
						echo do_shortcode('[pk_audio_player width="'.(int)$pk_home_page_meta['tsp_slider_width'].'" height="'.(int)$pk_home_page_meta['tsp_slider_height'].'" autoplay="'.$auto_play.'" cover="'.$image.'" audio_url="'.$audio[1].'" padding="0"]');
						
						break;
						
					case 'html5' :
						
						echo do_shortcode('[pk_html5_player width="'.(int)$pk_home_page_meta['tsp_slider_width'].'" height="'.(int)$pk_home_page_meta['tsp_slider_height'].'" autoplay="'.$auto_play.'" cover="'.$image.'" mp4="'.$video[2].'" webm="'.$video[3].'" ogg="'.$video[4].'" padding="0"]');
						
						break;
						
						
					case 'video' :
						
						echo do_shortcode('[pk_video_player width="'.(int)$pk_home_page_meta['tsp_slider_width'].'" height="'.(int)$pk_home_page_meta['tsp_slider_height'].'" autoplay="'.$auto_play.'" cover="'.$image.'" video_url="'.$video[2].'" padding="0"]');
						
						break;
						
					case 'youtube_custom' :
						
						echo do_shortcode('[pk_youtube_custom_player width="'.(int)$pk_home_page_meta['tsp_slider_width'].'" height="'.(int)$pk_home_page_meta['tsp_slider_height'].'" autoplay="'.$auto_play.'" cover="'.$image.'" video_id="'.$video[2].'" padding="0"]');
						
						break;
						
					case 'youtube' :
						
						echo do_shortcode('[pk_youtube_player width="'.(int)$pk_home_page_meta['tsp_slider_width'].'" height="'.(int)$pk_home_page_meta['tsp_slider_height'].'" autoplay="'.$auto_play.'" cover="'.$image.'" video_id="'.$video[2].'" padding="0"]');
						
						break;
						
					case 'vimeo' :
						
						echo do_shortcode('[pk_vimeo_player width="'.(int)$pk_home_page_meta['tsp_slider_width'].'" height="'.(int)$pk_home_page_meta['tsp_slider_height'].'" autoplay="'.$auto_play.'" cover="'.$image.'" video_id="'.$video[2].'" padding="0"]');
						
						break;
						
					case 'swf' :
						
						echo do_shortcode('[pk_swf_object width="'.(int)$pk_home_page_meta['tsp_slider_width'].'" height="'.(int)$pk_home_page_meta['tsp_slider_height'].'" flashvars="'.str_replace('"', '\'', $meta['swf_flashvars']).'" params="'.str_replace('"', '\'', $meta['swf_params']).'" swf_url="'.$swf.'" fp_version="'.$meta['swf_fp_version'].'" padding="0"]');
						
						break;
					
				}
?>

<!-- pk start top slider item caption -->
<div class="pk_tooltip_caption">
	<h3><?php the_title(); ?></h3>
	<?php
				the_excerpt();
				
				if (isset($meta['image_link_url']) && $meta['image_link_url'] != '') : 
?>
					 <a href="<?php echo $meta['image_link_url']; ?>" title="<?php the_title(); ?>" class="pk_tooltip_post_link"><?php _e('Read more &raquo;', 'pk_text_domain_front'); ?></a>
<?php
				endif;
?>
</div>
<!-- pk end top slider item caption -->

</div>
<!-- pk end top slider item -->
<?php
			endif;
			
			if ($post_type == 'works') : 
				
				$use_featured_image = (isset($meta['use_featured_image'])) ? $meta['use_featured_image'] : 'true';
				$image_action = (isset($meta['thumb_action'])) ? $meta['thumb_action'] : '';
				$use_custom_players = (isset($meta['use_custom_players'])) ? $meta['use_custom_players'] : 'true';
				$auto_play = (isset($meta['auto_play'])) ? $meta['auto_play'] : 'false';
				$file_type = (isset($meta['thumb_type'])) ? $meta['thumb_type'] : '';
				
				$file_type = explode(',', $file_type);
				$file_type = (isset($file_type[1])) ? $file_type[1] : '';
				
				if ($use_featured_image == 'true' || $file_type == '') {
					
					if ($file_type == '') $file_type = 'image';
					$image = pk_get_featured_image();
					if ($image) $image = $image[0];
					
				}
				
				if ($use_featured_image == 'false' && $file_type == 'image') {
					
					$image = $meta['image'];
					
				}
				
				if ($file_type == 'audio') {
					
					$audio = explode(',', $meta['audio']);
					if ($use_featured_image == 'false') $image = $audio[0];
					
				}
				
				if ($file_type == 'video') {
					
					$video = explode(',', $meta['video']);
					if ($use_featured_image == 'false') $image = $video[1];
					
					if ((int)$video[0] == 1) $file_type = 'html5';
					if ((int)$video[0] == 2) $file_type = 'video';
					if ((int)$video[0] == 3) $file_type = 'youtube';
					if ((int)$video[0] == 3 && $use_custom_players == 'true') $file_type = 'youtube_custom';
					if ((int)$video[0] == 4) $file_type = 'vimeo';
					
				}
				
				if ($file_type == 'swf') {
					
					$swf = $meta['swf'];
					
				}
?>

<!-- pk start top slider item -->
<div class="pk_slider_item">
<?php
				switch ($file_type) {
					
					case 'image' :
						
						if ($image && $image_action != '') : 
							
							echo '
<!-- pk start image -->
<a href="'.(($image_action == 'link') ? get_permalink() : esc_url($image)).'" title="'.get_the_title().'"'.(($image_action == 'lightbox') ? ' rel="prettyPhoto[pk_top_slider_lightbox]"' : '').'>
	<img src="'.pk_build_image($image, (int)$pk_home_page_meta['tsp_slider_width'], (int)$pk_home_page_meta['tsp_slider_height'], 1).'" />
	<span class="pk_image_button_overlay"></span>
</a>
<!-- pk end image -->
';
							
						endif;
						
						if ($image && $image_action == '') : 
							
							echo '
<!-- pk start image -->
<img src="'.pk_build_image($image, (int)$pk_home_page_meta['tsp_slider_width'], (int)$pk_home_page_meta['tsp_slider_height'], 1).'" />
<!-- pk end image -->
';
							
						endif;
						
						break;
						
					case 'audio' :
						
						echo do_shortcode('[pk_audio_player width="'.(int)$pk_home_page_meta['tsp_slider_width'].'" height="'.(int)$pk_home_page_meta['tsp_slider_height'].'" autoplay="'.$auto_play.'" cover="'.$image.'" audio_url="'.$audio[1].'" padding="0"]');
						
						break;
						
					case 'html5' :
						
						echo do_shortcode('[pk_html5_player width="'.(int)$pk_home_page_meta['tsp_slider_width'].'" height="'.(int)$pk_home_page_meta['tsp_slider_height'].'" autoplay="'.$auto_play.'" cover="'.$image.'" mp4="'.$video[2].'" webm="'.$video[3].'" ogg="'.$video[4].'" padding="0"]');
						
						break;
						
						
					case 'video' :
						
						echo do_shortcode('[pk_video_player width="'.(int)$pk_home_page_meta['tsp_slider_width'].'" height="'.(int)$pk_home_page_meta['tsp_slider_height'].'" autoplay="'.$auto_play.'" cover="'.$image.'" video_url="'.$video[2].'" padding="0"]');
						
						break;
						
					case 'youtube_custom' :
						
						echo do_shortcode('[pk_youtube_custom_player width="'.(int)$pk_home_page_meta['tsp_slider_width'].'" height="'.(int)$pk_home_page_meta['tsp_slider_height'].'" autoplay="'.$auto_play.'" cover="'.$image.'" video_id="'.$video[2].'" padding="0"]');
						
						break;
						
					case 'youtube' :
						
						echo do_shortcode('[pk_youtube_player width="'.(int)$pk_home_page_meta['tsp_slider_width'].'" height="'.(int)$pk_home_page_meta['tsp_slider_height'].'" autoplay="'.$auto_play.'" cover="'.$image.'" video_id="'.$video[2].'" padding="0"]');
						
						break;
						
					case 'vimeo' :
						
						echo do_shortcode('[pk_vimeo_player width="'.(int)$pk_home_page_meta['tsp_slider_width'].'" height="'.(int)$pk_home_page_meta['tsp_slider_height'].'" autoplay="'.$auto_play.'" cover="'.$image.'" video_id="'.$video[2].'" padding="0"]');
						
						break;
						
					case 'swf' :
						
						echo do_shortcode('[pk_swf_object width="'.(int)$pk_home_page_meta['tsp_slider_width'].'" height="'.(int)$pk_home_page_meta['tsp_slider_height'].'" flashvars="'.str_replace('"', '\'', $meta['swf_flashvars']).'" params="'.str_replace('"', '\'', $meta['swf_params']).'" swf_url="'.$swf.'" fp_version="'.$meta['swf_fp_version'].'" padding="0"]');
						
						break;
					
				}
?>

<!-- pk start top slider item caption -->
<div class="pk_tooltip_caption">
	<h3><?php the_title(); ?></h3>
	<?php the_excerpt(); ?>
	<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" class="pk_tooltip_post_link"><?php _e('Read more &raquo;', 'pk_text_domain_front'); ?></a>
</div>
<!-- pk end top slider item caption -->

</div>
<!-- pk end top slider item -->
<?php
			endif;
			
		endwhile;
?>

</div>
<!-- pk end top slider content -->

<!-- pk start top slider navigation -->
<div class="pk_slider_navigation">
	<div class="pk_slider_navigation_wrapper">
		<span class="pk_button_circle pk_button_prev">prev</span>
		<span class="pk_button_circle pk_button_next">next</span>
		<ul>
<?php
		while ($r -> have_posts()) : $r -> the_post();
			
			$meta = pk_get_meta();
			
			if ($post_type == 'slides' || $post_type == 'works') {
				
				$use_featured_image = (isset($meta['use_featured_image'])) ? $meta['use_featured_image'] : 'true';
				
				if ($post_type == 'slides') $file_type = (isset($meta['file_type'])) ? $meta['file_type'] : '';
				if ($post_type == 'works') $file_type = (isset($meta['thumb_type'])) ? $meta['thumb_type'] : '';
				
				$file_type = explode(',', $file_type);
				$file_type = (isset($file_type[1])) ? $file_type[1] : '';
				
				if ($use_featured_image == 'true' || $file_type == '') {
					
					if ($file_type == '') $file_type = 'image';
					$image = pk_get_featured_image();
					if ($image) $image = $image[0];
					
				}
				
				if ($use_featured_image == 'false' && $file_type == 'image') {
					
					$image = $meta['image'];
					
				}
				
				if ($file_type == 'audio') {
					
					if ($use_featured_image == 'false') $image = $audio[0];
					
				}
				
				if ($file_type == 'video') {
					
					$video = explode(',', $meta['video']);
					if ($use_featured_image == 'false') $image = $video[1];
					
				}
				
			} else {
				
				$image = pk_get_featured_image();
				if ($image) $image = $image[0];
				
			}
		
			if ($image) : 
?>
			<li>
				<a href="#" title="" class="pk_thumb_button"<?php echo (isset($meta['top_slider_background_color'])) ? ' data-bgColor="'.$meta['top_slider_background_color'].'"' : ''; ?>>
					<div class="pk_thumb_label">
						<span class="pk_thumb_label_text"><?php echo (isset($meta['top_slider_thumbnail_label'])) ? $meta['top_slider_thumbnail_label'] : '---'; ?></span>
						<span class="pk_thumb_overlay"></span>
					</div>
					<img src="<?php echo pk_build_image($image, (int)$pk_home_page_meta['tsp_thumbnails_width'], (int)$pk_home_page_meta['tsp_thumbnails_height'], 1); ?>" />
				</a>

			</li>
<?php
			endif;
			
		endwhile;
?>
		</ul>
	</div>
</div>
<!-- pk end top slider navigation -->

<script type="text/javascript">
	/*<![CDATA[*/
	jQuery("#pk_itis_slider").pk_itis_slider({
		sliderWidth:<?php echo $pk_home_page_meta['tsp_slider_width']; ?>,
		sliderHeight:<?php echo $pk_home_page_meta['tsp_slider_height']; ?>,
		thumbsSpace:<?php echo $pk_home_page_meta['tsp_thumbnails_spacing']; ?>,
		thumbsWidth:<?php echo $pk_home_page_meta['tsp_thumbnails_width']; ?>,
		thumbsHeight:<?php echo $pk_home_page_meta['tsp_thumbnails_height']; ?>,
		thumbsVisible:<?php echo $pk_home_page_meta['tsp_thumbnails_visible']; ?>,
		tooltipWidth:<?php echo $pk_home_page_meta['tsp_tooltips_width']; ?>,
		tooltipButtonReadMore:<?php echo $pk_home_page_meta['tsp_tooltips_read_more']; ?>,
		slideshowAutoStart:<?php echo $pk_home_page_meta['tsp_slideshow_auto_start']; ?>,
		slideshowInterval:<?php echo $pk_home_page_meta['tsp_slideshow_interval'];
?>		
	});
	/*]]>*/
</script>

</div>
</div>
<!-- pk end top slider -->

<?php
		wp_reset_postdata();
		
	endif;	
	
}

?>