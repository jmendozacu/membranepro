<?php

function pk_register_sidebars() {

	if (function_exists('register_sidebar')) {
		
		register_sidebar(array(
						'name' => __('Sidebar - All', 'pk_text_domain'),
						'id' => 'sidebar_all',
						'description' => __('Applied to every page.', 'pk_text_domain'),
						'before_widget' => '<div class="pk_widget">',
						'after_widget' => '</div>',
						'before_title' => '<h5>',
						'after_title' => '</h5>'));
						
		register_sidebar(array(
						'name' => __('Sidebar - Front Page', 'pk_text_domain'),
						'id' => 'sidebar_front_page',
						'description' => __('Applied to the front page.', 'pk_text_domain'),
						'before_widget' => '<div class="pk_widget">',
						'after_widget' => '</div>',
						'before_title' => '<h5>',
						'after_title' => '</h5>'));
						
		register_sidebar(array(
						'name' => __('Sidebar - Pages', 'pk_text_domain'),
						'id' => 'sidebar_pages',
						'description' => __('Applied to every page using the default page template.', 'pk_text_domain'),
						'before_widget' => '<div class="pk_widget">',
						'after_widget' => '</div>',
						'before_title' => '<h5>',
						'after_title' => '</h5>'));
						
		register_sidebar(array(
						'name' => __('Sidebar - Blog', 'pk_text_domain'),
						'id' => 'sidebar_blog',
						'description' => __('Applied to every blog page.', 'pk_text_domain'),
						'before_widget' => '<div class="pk_widget">',
						'after_widget' => '</div>',
						'before_title' => '<h5>',
						'after_title' => '</h5>'));
						
		register_sidebar(array(
						'name' => __('Sidebar - Blog Archive', 'pk_text_domain'),
						'id' => 'sidebar_blog_archive',
						'description' => __('Applied to every blog archive page.', 'pk_text_domain'),
						'before_widget' => '<div class="pk_widget">',
						'after_widget' => '</div>',
						'before_title' => '<h5>',
						'after_title' => '</h5>'));
						
		register_sidebar(array(
						'name' => __('Sidebar - Works', 'pk_text_domain'),
						'id' => 'sidebar_works',
						'description' => __('Applied to every works grid page.', 'pk_text_domain'),
						'before_widget' => '<div class="pk_widget">',
						'after_widget'=> '</div>',
						'before_title'=> '<h5>',
						'after_title' => '</h5>'));
						
		register_sidebar(array(
						'name' => __('Sidebar - Flickr Grid Gallery Pages', 'pk_text_domain'),
						'id' => 'sidebar_flickr_grid_gallery_pages',
						'description' => __('Applied to every Flickr grid gallery page.', 'pk_text_domain'),
						'before_widget' => '<div class="pk_widget">',
						'after_widget'=> '</div>',
						'before_title'=> '<h5>',
						'after_title' => '</h5>'));
						
		register_sidebar(array(
						'name' => __('Sidebar - Works Archive', 'pk_text_domain'),
						'id' => 'sidebar_works_archive',
						'description' => __('Applied to every works archive page.', 'pk_text_domain'),
						'before_widget' => '<div class="pk_widget">',
						'after_widget' => '</div>',
						'before_title' => '<h5>',
						'after_title' => '</h5>'));
						
		register_sidebar(array(
						'name' => __('Sidebar - Comments', 'pk_text_domain'),
						'id' => 'sidebar_comments',
						'description' => __('Applied to the comments block of the full width pages if enabled by post/page options.', 'pk_text_domain'),
						'before_widget' => '<div class="pk_widget">',
						'after_widget' => '</div>',
						'before_title' => '<h5>',
						'after_title' => '</h5>'));
						
		register_sidebar(array(
						'name' => __('Sidebar - Search', 'pk_text_domain'),
						'id' => 'sidebar_search',
						'description' => __('Applied to the search results pages.', 'pk_text_domain'),
						'before_widget' => '<div class="pk_widget">',
						'after_widget' => '</div>',
						'before_title' => '<h5>',
						'after_title' => '</h5>'));
						
		register_sidebar(array(
						'name' => __('Sidebar - 404', 'pk_text_domain'),
						'id' => 'sidebar_404',
						'description' => __('Applied to the "Error 404" page.', 'pk_text_domain'),
						'before_widget' => '<div class="pk_widget">',
						'after_widget' => '</div>',
						'before_title' => '<h5>',
						'after_title' => '</h5>'));
						
		$footer_profiles = get_option('pk_footer_options_profiles');
						
		foreach ($footer_profiles as $profile) {
						
			register_sidebar(array(
							'name' => __('Footer Column 1', 'pk_text_domain').' ('.(($profile == 'default') ? 'Default' : stripslashes(base64_decode($profile))).')',
							'id' => 'footer_column_1_'.md5($profile),
							'description' => __('The first column in the footer widgets area (Set the number of columns in the footer options panel.)', 'pk_text_domain'),
							'before_widget' => '<div class="pk_widget">',
							'after_widget' => '</div>',
							'before_title' => '<h5>',
							'after_title' => '</h5>'));
							
			register_sidebar(array(
							'name' => __('Footer Column 2', 'pk_text_domain').' ('.(($profile == 'default') ? 'Default' : stripslashes(base64_decode($profile))).')',
							'id' => 'footer_column_2_'.md5($profile),
							'description' => __('The second column in the footer widgets area (Set the number of columns in the footer options panel.)', 'pk_text_domain'),
							'before_widget' => '<div class="pk_widget">',
							'after_widget' => '</div>',
							'before_title' => '<h5>',
							'after_title' => '</h5>'));
							
			register_sidebar(array(
							'name' => __('Footer Column 3', 'pk_text_domain').' ('.(($profile == 'default') ? 'Default' : stripslashes(base64_decode($profile))).')',
							'id' => 'footer_column_3_'.md5($profile),
							'description' => __('The third column in the footer widgets area (Set the number of columns in the footer options panel.)', 'pk_text_domain'),
							'before_widget' => '<div class="pk_widget">',
							'after_widget' => '</div>',
							'before_title' => '<h5>',
							'after_title' => '</h5>'));
							
			register_sidebar(array(
							'name' => __('Footer Column 4', 'pk_text_domain').' ('.(($profile == 'default') ? 'Default' : stripslashes(base64_decode($profile))).')',
							'id' => 'footer_column_4_'.md5($profile),
							'description' => __('The fourth column in the footer widgets area (Set the number of columns in the footer options panel.)', 'pk_text_domain'),
							'before_widget' => '<div class="pk_widget">',
							'after_widget' => '</div>',
							'before_title' => '<h5>',
							'after_title' => '</h5>'));
							
			register_sidebar(array(
							'name' => __('Footer Column 5', 'pk_text_domain').' ('.(($profile == 'default') ? 'Default' : stripslashes(base64_decode($profile))).')',
							'id' => 'footer_column_5_'.md5($profile),
							'description' => __('The fifth column in the footer widgets area (Set the number of columns in the footer options panel.)', 'pk_text_domain'),
							'before_widget' => '<div class="pk_widget">',
							'after_widget' => '</div>',
							'before_title' => '<h5>',
							'after_title' => '</h5>'));
							
			register_sidebar(array(
							'name' => __('Footer Column 6', 'pk_text_domain').' ('.(($profile == 'default') ? 'Default' : stripslashes(base64_decode($profile))).')',
							'id' => 'footer_column_6_'.md5($profile),
							'description' => __('The sixth column in the footer widgets area (Set the number of columns in the footer options panel.)', 'pk_text_domain'),
							'before_widget' => '<div class="pk_widget">',
							'after_widget' => '</div>',
							'before_title' => '<h5>',
							'after_title' => '</h5>'));
							
		}
						
		$custom_sidebars = get_option('pk_custom_sidebars');
		
		if (!is_array($custom_sidebars)) {
			
			return;	
			
		}
		
		foreach ($custom_sidebars as $sidebar) {
			
			if ($sidebar['registered'] == 'true') {
				
				$id = (int)$sidebar['id'];
				$post = get_post($id);
			
				if ($post) register_sidebar(array(
								'name' => $post -> post_title,
								'id' => 'sidebar_'.$id,
								'description' => __('Sidebar applied only to', 'pk_text_domain').' "'.$post -> post_title.'" (ID: '.$id.')',
								'before_widget' => '<div class="pk_widget">',
								'after_widget' => '</div>',
								'before_title' => '<h5>',
								'after_title' => '</h5>'));
								
			}
			
		}
						
	}

}

add_action('widgets_init', 'pk_register_sidebars');

?>