<?php

function pk_flickr_grid_items() {
	
	global $pk_gallery_items;
	global $pk_sidebar;
	global $pk_count;
	global $pk_columns;
	global $pk_title_action;
	global $pk_show_image_title;
	global $pk_show_image_description;
	global $pk_image_action;
	global $pk_image_style;
	global $pk_image_icon;
	global $pk_image_height;
	global $pk_slideshow_interval;
	global $pk_slideshow_auto_start;
	
	global $pk_load_photos_from;
	global $pk_flickr_user_id;
	
	foreach($pk_gallery_items as $pk_gallery_item) {
		
		if ($pk_count == $pk_columns + 1) $pk_count = 1;
		
		switch ($pk_columns) :
			
			case 4 :
?>
<!-- ################## -->
<!-- pk start grid item -->
<!-- ################## -->
<div id="post-<?php echo $pk_gallery_item['id']; ?>" class="pk_one_fourth pk_entry_grid<?php if ($pk_count == $pk_columns) echo ' pk_last'; ?>">
<?php
	do_action('pk_ah_pre_flickr_grid_item');
	
	pk_flickr_grid_item_thumb(2, $pk_gallery_item, $pk_image_action, $pk_image_style, $pk_image_icon, (($pk_sidebar == 'none') ? 207 : 152), $pk_image_height);
	
	if ($pk_show_image_title == 'true') : 
		
		if ($pk_title_action == 'link') : 
?>
<!-- pk start grid item title -->
<h4 class="pk_entry_title"><a href="<?php echo esc_url('http://www.flickr.com/photos/'.(($pk_load_photos_from == 'galleries') ? $pk_gallery_item['ownername'] : ((isset($pk_gallery_item['owner'])) ? $pk_gallery_item['owner'] : $pk_flickr_user_id)).'/'.$pk_gallery_item['id']); ?>" target="_blank" title="<?php _e('View the photo on Flickr', 'pk_text_domain_front'); ?>"><?php echo $pk_gallery_item['title']; ?></a></h4>
<!-- pk end grid item title -->
<?php
		else : 
?>

<!-- pk start grid item title -->
<h4 class="pk_entry_title"><?php echo $pk_gallery_item['title']; ?></h4>
<!-- pk end grid item title -->
<?php
		endif;
		
	endif;
	
	if ($pk_show_image_description == 'true') echo '
<!-- pk start grid item description -->	
<p>'.$pk_gallery_item['description'].'</p>
<!-- pk end grid item description -->
';
	
	do_action('pk_ah_after_flickr_grid_item');
?>

</div>
<!-- ################ -->
<!-- pk end grid item -->
<!-- ################ -->

<?php
			break;
			
			case 3 :
?>
<!-- ################## -->
<!-- pk start grid item -->
<!-- ################## -->
<div id="post-<?php echo $pk_gallery_item['id']; ?>" class="pk_one_third pk_entry_grid<?php if ($pk_count == $pk_columns) echo ' pk_last'; ?>">
<?php
	do_action('pk_ah_pre_flickr_grid_item');
	
	pk_flickr_grid_item_thumb(2, $pk_gallery_item, $pk_image_action, $pk_image_style, $pk_image_icon, (($pk_sidebar == 'none') ? 288 : 211), $pk_image_height);
	
	if ($pk_show_image_title == 'true') : 
		
		if ($pk_title_action == 'link') : 
?>
<!-- pk start grid item title -->
<h4 class="pk_entry_title"><a href="<?php echo esc_url('http://www.flickr.com/photos/'.(($pk_load_photos_from == 'galleries') ? $pk_gallery_item['ownername'] : ((isset($pk_gallery_item['owner'])) ? $pk_gallery_item['owner'] : $pk_flickr_user_id)).'/'.$pk_gallery_item['id']); ?>" target="_blank" title="<?php _e('View the photo on Flickr', 'pk_text_domain_front'); ?>"><?php echo $pk_gallery_item['title']; ?></a></h4>
<!-- pk end grid item title -->
<?php
		else : 
?>

<!-- pk start grid item title -->
<h4 class="pk_entry_title"><?php echo $pk_gallery_item['title']; ?></h4>
<!-- pk end grid item title -->
<?php
		endif;
		
	endif;
	
	if ($pk_show_image_description == 'true') echo '
<!-- pk start grid item description -->	
<p>'.$pk_gallery_item['description'].'</p>
<!-- pk end grid item description -->
';
	
	do_action('pk_ah_after_flickr_grid_item');
?>

</div>
<!-- ################ -->
<!-- pk end grid item -->
<!-- ################ -->

<?php
			break;
			
			case 2 :
?>
<!-- ################## -->
<!-- pk start grid item -->
<!-- ################## -->
<div id="post-<?php echo $pk_gallery_item['id']; ?>" class="pk_one_half pk_entry_grid<?php if ($pk_count == $pk_columns) echo ' pk_last'; ?>">
<?php
	do_action('pk_ah_pre_flickr_grid_item');
	
	pk_flickr_grid_item_thumb(2, $pk_gallery_item, $pk_image_action, $pk_image_style, $pk_image_icon, (($pk_sidebar == 'none') ? 451 : 331), $pk_image_height);
	
	if ($pk_show_image_title == 'true') : 
		
		if ($pk_title_action == 'link') : 
?>
<!-- pk start grid item title -->
<h4 class="pk_entry_title"><a href="<?php echo esc_url('http://www.flickr.com/photos/'.(($pk_load_photos_from == 'galleries') ? $pk_gallery_item['ownername'] : ((isset($pk_gallery_item['owner'])) ? $pk_gallery_item['owner'] : $pk_flickr_user_id)).'/'.$pk_gallery_item['id']); ?>" target="_blank" title="<?php _e('View the photo on Flickr', 'pk_text_domain_front'); ?>"><?php echo $pk_gallery_item['title']; ?></a></h4>
<!-- pk end grid item title -->
<?php
		else : 
?>

<!-- pk start grid item title -->
<h4 class="pk_entry_title"><?php echo $pk_gallery_item['title']; ?></h4>
<!-- pk end grid item title -->
<?php
		endif;
		
	endif;
	
	if ($pk_show_image_description == 'true') echo '
<!-- pk start grid item description -->	
<p>'.$pk_gallery_item['description'].'</p>
<!-- pk end grid item description -->
';
	
	do_action('pk_ah_after_flickr_grid_item');
?>

</div>
<!-- ################ -->
<!-- pk end grid item -->
<!-- ################ -->

<?php
			break;
			
			case 1 :
?>
<!-- ################## -->
<!-- pk start grid item -->
<!-- ################## -->
<div id="post-<?php echo $pk_gallery_item['id']; ?>" class="pk_entry_grid pk_entry pk_entry_standard">
<?php
	do_action('pk_ah_pre_flickr_grid_item');
	
	if ($pk_show_image_title == 'false' && $pk_show_image_description == 'false') : 
?>
<div class="pk_full_width">
<?php pk_flickr_grid_item_thumb(1, $pk_gallery_item, $pk_image_action, $pk_image_style, $pk_image_icon, (($pk_sidebar == 'none') ? 940 : 690), $pk_image_height); ?>
</div>
<?php
	else : 
?>
<div class="pk_two_third">
<?php pk_flickr_grid_item_thumb(1, $pk_gallery_item, $pk_image_action, $pk_image_style, $pk_image_icon, (($pk_sidebar == 'none') ? 614 : 451), $pk_image_height); ?>
</div>

<div class="pk_one_third pk_last">
<?php
		if ($pk_show_image_title == 'true') : 
			
			if ($pk_title_action == 'link') : 
?>

<!-- pk start grid item title -->
<h4 class="pk_entry_title"><a href="<?php echo esc_url('http://www.flickr.com/photos/'.(($pk_load_photos_from == 'galleries') ? $pk_gallery_item['ownername'] : ((isset($pk_gallery_item['owner'])) ? $pk_gallery_item['owner'] : $pk_flickr_user_id)).'/'.$pk_gallery_item['id']); ?>" target="_blank" title="<?php _e('View the photo on Flickr', 'pk_text_domain_front'); ?>"><?php echo $pk_gallery_item['title']; ?></a></h4>
<!-- pk end grid item title -->
<?php
			else : 
?>

<!-- pk start grid item title -->
<h4 class="pk_entry_title"><?php echo $pk_gallery_item['title']; ?></h4>
<!-- pk end grid item title -->
<?php
			endif;
			
		endif;
	
		if ($pk_show_image_description == 'true') echo '
<!-- pk start grid item description -->	
<p>'.$pk_gallery_item['description'].'</p>
<!-- pk end grid item description -->
';
?>

</div>
<?php
	endif; 
	
	do_action('pk_ah_after_flickr_grid_item');
?>
</div>
<!-- ################ -->
<!-- pk end grid item -->
<!-- ################ -->

<?php
		
			break;
		
		endswitch;
	
		if ($pk_count == $pk_columns) : 
?>
<span class="pk_clear_both"></span>

<?php
		endif;
		
		$pk_count++;
		
	}
	
?>
<script type="text/javascript">
	/*<![CDATA[*/
	jQuery(document).ready(function() {
		jQuery("a[rel^='prettyPhoto[flickr]']").prettyPhoto({
			slideshow:<?php echo $pk_slideshow_interval; ?>,
			autoplay_slideshow:<?php echo ($pk_slideshow_auto_start != 'false') ? 'true' : 'false'; ?>
		});
	});
	/*]]>*/
</script>

<?php
	
}

function pk_flickr_grid_item_thumb($columns, $gallery_item, $image_action, $image_style, $image_icon, $w, $h) {
	
	global $pk_load_photos_from;
	global $pk_flickr_user_id;
	
	switch ($image_style) {
		
		case '16/9' :
			
			$h = floor(($w / 16) * 9);
			break;
			
		case '4/3' :
			
			$h = floor(($w / 4) * 3);
			break;
			
		case 'portrait' :
			
			$h = floor(($w / 3) * 4);
			break;
			
		case 'square' :
			
			$h = $w;
			break;
			
		case 'auto' :
			
			$h = 0;
			break;
		
	}
	
	$hp = floor(12 * ($h / $w));
	
	if ($columns == 1 && isset($gallery_item['url_l']) && $gallery_item['url_l'] != '') {
		
		$image = $gallery_item['url_l'];
		
	} else {
		
		if (isset($gallery_item['url_m']) && $gallery_item['url_m'] != '') {
			
			$image = $gallery_item['url_m'];
			
		} else {
			
			$image = $gallery_item['url_s'];
			
		}
		
	}
	
	if (isset($gallery_item['url_o']) && $gallery_item['url_o'] != '') {
		
		$image_url = $gallery_item['url_o'];
		
	} else {
		
		if (isset($gallery_item['url_l']) && $gallery_item['url_l'] != '') {
			
			$image_url = $gallery_item['url_l'];
			
		} else {
			
			$image_url = $gallery_item['url_m'];
			
		}
		
	}
	
	if ($image) : 
	
?>

<!-- pk start grid item thumbnail -->
<div class="pk_image" style="<?php echo (($w > 0) ? 'width:'.$w.'px;' : ''); echo (($h > 0) ? ' height:'.$h.'px;' : ''); ?>">
	<div class="pk_image_wrapper">
<?php
		if ($image_action == 'lightbox') : 
?>
		<a href="<?php echo esc_url($image_url); ?>" rel="prettyPhoto[flickr]" title="<?php echo $gallery_item['title']; ?>" class="<?php echo $image_icon; ?>">
			<img src="<?php echo pk_build_image($image, $w - 12, ($h > 0) ? $h - $hp : 0, 1); ?>" />
			<span class="pk_image_button_overlay"></span>
		</a>
<?php
		else : 
?>
		<a href="<?php echo esc_url('http://www.flickr.com/photos/'.(($pk_load_photos_from == 'galleries') ? $gallery_item['ownername'] : ((isset($gallery_item['owner'])) ? $gallery_item['owner'] : $pk_flickr_user_id)).'/'.$gallery_item['id']); ?>" target="_blank" title="<?php _e('View the photo on Flickr', 'pk_text_domain_front'); ?>" class="<?php echo $image_icon; ?>">
			<img src="<?php echo pk_build_image($image, $w - 12, ($h > 0) ? $h - $hp : 0, 1); ?>" />
			<span class="pk_image_button_overlay"></span>
		</a>
<?php
		endif;
?>
	</div>
</div>
<!-- pk end grid item thumbnail -->

<?php
	
	endif;
	
}

function pk_flickr_grid_pagination() {
	
	global $pk_sidebar;
	global $pk_flickr_total_pages;
	global $pk_flickr_page;
	
?>
<span class="pk_clear_both"></span>

<!-- pk start pagination -->
<div class="pk_pagination pk_pagination_<?php echo ($pk_sidebar == 'none') ? 'full' : 'sidebar'; ?>">
	<?php pk_pagination($pk_flickr_total_pages, $pk_flickr_page, 2); ?>
</div>
<!-- pk end pagination -->
<?php
	
}

?>