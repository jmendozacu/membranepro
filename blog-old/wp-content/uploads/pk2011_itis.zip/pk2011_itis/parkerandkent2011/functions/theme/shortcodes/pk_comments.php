<?php

/*
 * Recent Comments
*/

function pk_scp_recent_comments($atts, $content = null) {
	
	global $comments;
	global $comment;
	
	extract(shortcode_atts(array(
		'title' => '',
		'number' => '5'
	), $atts));
	
	$output = '
<!-- pk start recent comments -->
<div class="pk_scp_recent_comments">';
	
	$c = get_comments(array('number' => (int)$number, 'status' => 'approve'));
	
	if ($c) {
		
	if ($title != '') $output .= '
	<h4>'.$title.'</h4>';
	
	$output .= '
	<ul class="pk_comments_list">';
		
		foreach ((array)$c as $comment) {
			
			$output .= '
		<li class="recentcomments">'.sprintf(__('%1$s on %2$s', 'pk_text_domain'), get_comment_author_link(), '<a href="'.esc_url(get_comment_link($comment -> comment_ID)).'">'.get_the_title($comment -> comment_post_ID).'</a>').'</li>';
			
		}
		
		$output .= '
	</ul>';
		
	}
	
	$output .= '
</div>
<!-- pk end recent comments -->
';
	
	return $output;
	
}

add_shortcode('pk_recent_comments', 'pk_scp_recent_comments');

?>