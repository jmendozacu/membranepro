<?php

function pk_enqueue_theme_scripts() {
	
	if (is_admin()) {
		
		return;
		
	}
	
	wp_deregister_script('swfobject');
	wp_register_script('swfobject', PK_THEME_DIR.'/parkerandkent2011/js/theme/swfobject.js');
	wp_enqueue_script('swfobject');
	
	wp_deregister_script('jquery');
	wp_register_script('jquery', PK_THEME_DIR.'/parkerandkent2011/js/theme/jquery-1.5.1.min.js');
	wp_enqueue_script('jquery');
	
	wp_deregister_script('prettyPhoto');
	wp_register_script('prettyPhoto', PK_THEME_DIR.'/parkerandkent2011/js/theme/prettyPhoto/js/jquery.prettyPhoto.js', array('jquery'));
	wp_enqueue_script('prettyPhoto');
	
	wp_deregister_script('jquery_easing');
	wp_register_script('jquery_easing', PK_THEME_DIR.'/parkerandkent2011/js/theme/jquery.easing.js');
	wp_enqueue_script('jquery_easing');
	
	wp_deregister_script('jquery_ui');
	wp_register_script('jquery_ui', PK_THEME_DIR.'/parkerandkent2011/js/theme/jquery-ui.min.js');
	wp_enqueue_script('jquery_ui');
	
	wp_deregister_script('pk_frontend');
	wp_register_script('pk_frontend', PK_THEME_DIR.'/parkerandkent2011/js/theme/pk/pk_frontend.js');
	wp_enqueue_script('pk_frontend');
	
}

add_action('init', 'pk_enqueue_theme_scripts');
	
if (isset($_GET['skin']) && $_GET['skin'] != '') {
	
	setcookie('skin', $_GET['skin']);
	
}

function pk_enqueue_theme_styles() {
	
	if (is_admin()) {
		
		return;
		
	}
	
	if (isset($_COOKIE['skin']) && $_COOKIE['skin'] != '') {
		
		$skin = (isset($_GET['skin']) && $_GET['skin'] != '') ? $_GET['skin'].'.css' : $_COOKIE['skin'].'.css';
		
	} else {
		
		$skin = (isset($_GET['skin']) && $_GET['skin'] != '') ? $_GET['skin'].'.css' : pk_get_skin();
		
	}
	
	wp_deregister_style('pk_google_titles_font');
	wp_register_style('pk_google_titles_font', 'http://fonts.googleapis.com/css?family=Droid+Serif:regular,italic,bold,bolditalic');
	wp_enqueue_style('pk_google_titles_font');
	
	wp_deregister_style('pk_google_texts_font');
	wp_register_style('pk_google_texts_font', 'http://fonts.googleapis.com/css?family=Droid+Sans:regular,bold');
	wp_enqueue_style('pk_google_texts_font');
	
	wp_deregister_style('prettyPhoto_style');
	wp_register_style('prettyPhoto_style', PK_THEME_DIR.'/parkerandkent2011/js/theme/prettyPhoto/css/prettyPhoto.css');
	wp_enqueue_style('prettyPhoto_style');
	
	wp_deregister_style('pk_style');
	wp_register_style('pk_style', PK_THEME_DIR.'/parkerandkent2011/css/theme/pk/pk_style.css');
	wp_enqueue_style('pk_style');
	
	wp_deregister_style('pk_skin');
	wp_enqueue_style('pk_skin', PK_THEME_DIR.'/parkerandkent2011/css/theme/pk/'.$skin);
	wp_enqueue_style('pk_skin');
	
	wp_deregister_style('pk_main_style');
	wp_register_style('pk_main_style', get_stylesheet_uri());
	wp_enqueue_style('pk_main_style');
	
}

?>