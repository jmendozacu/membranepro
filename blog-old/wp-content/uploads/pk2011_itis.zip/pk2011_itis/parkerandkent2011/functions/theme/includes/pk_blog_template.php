<?php
	if ($pk_sidebar == 'none') : 
?>
<!-- pk start page -->
<div id="pk_page" class="pk_full_width">

<!-- pk start left shadow -->
<span class="pk_left_shadow"></span>
<!-- pk end left shadow -->

<!-- pk start right shadow -->
<span class="pk_right_shadow"></span>
<!-- pk end right shadow -->

<!-- pk start center box -->
<div class="pk_center_box">

<!-- pk start inner -->
<div class="pk_inner">

<?php
	require_once(PK_THEME_INCLUDES.'/pk_blog_loop.php');
	
	$wp_query = $pk_temp_query;
	wp_reset_query();
?>

</div>
<!-- pk end inner -->

</div>
<!-- pk end center box -->

<?php
	else : 
?>
<!-- pk start page -->
<div id="pk_page" class="pk_<?php echo $pk_sidebar; ?>_sidebar">

<!-- pk start left shadow -->
<span class="pk_left_shadow"></span>
<!-- pk end left shadow -->

<!-- pk start right shadow -->
<span class="pk_right_shadow"></span>
<!-- pk end right shadow -->

<!-- pk start center box -->
<div class="pk_center_box">

<!-- pk start inner -->
<div class="pk_inner">

<!-- pk start main -->
<div id="pk_main">

<!-- pk start content -->
<div id="pk_content">

<?php
	require_once(PK_THEME_INCLUDES.'/pk_blog_loop.php');
	
	$wp_query = $pk_temp_query;
	wp_reset_query();
?>

</div>
<!-- pk end content -->

</div>
<!-- pk end main -->

<!-- pk start sidebar -->
<aside id="pk_sidebar">

<div id="pk_sidebar_content">

<?php
		get_sidebar();
?>
</div>

</aside>
<!-- pk end sidebar -->

</div>
<!-- pk end inner -->

</div>
<!-- pk end center box -->

<?php
	endif;
	
	get_footer();
?>