<?php

function pk_build_image($url = '', $width = 0, $height = 0, $zc = 1, $amp = '&amp;') {
	
	if ($url == '') {
		
		return '';	
		
	}
	
	global $blog_id;
	
	if (isset($blog_id) && $blog_id > 0) {
		
		$url = explode('/files/', $url);
		
		if (isset($url[1])) {
			
			$url = '/blogs.dir/' . $blog_id . '/files/' . $url[1];
			
		}
		
	}
	
	$final_image_path = '';
	
	$width_string = ($width <= 0 || $width == '') ? '' : $amp.'w='.$width;
	$height_string = ($height <= 0 || $height == '') ? '' : $amp.'h='.$height;
	$zc_string = ($width_string == '' && $height_string == '') ? '' : $amp.'zc='.$zc;
	
	if ($zc_string == '') {
		
		return esc_url($url);
		
	}
	
	$final_image_path = PK_THEME_DIR.'/timthumb/timthumb.php?src='.$url.$width_string.$height_string.$zc_string;
	
	return esc_url($final_image_path);
	
}

?>