<?php

/*
 * Button
*/
	
static $pk_buttons_counter = 0;

function pk_scp_button($atts, $content = null) {
	
	global $post;
	global $pk_buttons_counter;
	
	$pk_buttons_counter++;
	
	extract(shortcode_atts(array(
		'size' => 'small',
		'align' => 'none',
		'color' => '',
		'icon' => '',
		'action' => 'link',
		'link' => '#',
		'link_target' => '_self',
		'title' => '',
		'lightbox_gallery_id' => (isset($post -> ID)) ? $post -> ID : 'pk_button_'.$pk_buttons_counter
	), $atts));
	
	$js = '';
	
	$class = ' class="pk_button_'.strtolower($size).(($color != '') ? ' pk_button_'.$color : '').(($icon != '') ? ' pk_button_with_icon pk_'.$icon.'_icon' : '').'"';
	
	($action == 'lightbox' && $lightbox_gallery_id != '') ? $rel = ' rel="prettyPhoto['.$lightbox_gallery_id.']"' : $rel = '';
	($link_target != '_self' && $action != 'lightbox') ? $link_target = ' target="'.$link_target.'"' : $link_target = '';
	($title != '') ? $title = ' title="'.$title.'"' : $title = '';
	
	if ($action == 'lightbox' && ($link == '#' || $link == '')) {
		
		$js = '<script type="text/javascript"> jQuery(document).ready(function() { var href = jQuery(".pk_lightbox_gallery a:first").attr("href"); var title = jQuery(".pk_lightbox_gallery a:first").attr("title"); jQuery(".pk_lightbox_gallery a:first").attr("rel", ""); jQuery("#pk_button_'.$pk_buttons_counter.'").attr("href", href); jQuery("#pk_button_'.$pk_buttons_counter.'").attr("title", title); }); </script>';
		
	}
	
	return '<div class="pk_align'.$align.'"><a id="pk_button_'.$pk_buttons_counter.'" href="'.esc_url($link).'"'.$rel.$link_target.$title.$class.'><span>'.$content.'</span></a></div>'.$js;
	
}

add_shortcode('pk_button', 'pk_scp_button');

?>