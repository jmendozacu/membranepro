<?php

/*
 * Heading underline
*/

function pk_sc_heading_underline($atts, $content = null){
	
	extract(shortcode_atts(array(
		'color' => ''
	), $atts));
	
	$color = ($color == '') ? '' :  ' style="color:'.$color.';"';
	
	return str_replace(
		array('<h1>', '<h2>', '<h3>', '<h4>', '<h5>', '<h6>'),
		array('<h1 class="pk_heading_underline" style="color:'.$color.';">', '<h2 class="pk_heading_underline"'.$color.'>', '<h3 class="pk_heading_underline"'.$color.'>', '<h4 class="pk_heading_underline"'.$color.'>', '<h5 class="pk_heading_underline"'.$color.'>', '<h6 class="pk_heading_underline"'.$color.'>'),
		do_shortcode($content));
	
}

add_shortcode('pk_heading_underline', 'pk_sc_heading_underline');

/*
 * Heading Background
*/

function pk_sc_heading_background($atts, $content = null){
	
	extract(shortcode_atts(array(
		'color' => '',
		'background_color' => '',
		'rounded' => 'true'
	), $atts));
	
	$color = ($color == '') ? '' :  'color:'.$color.'; ';
	$background_color = ($background_color == '') ? '' :  'background-color:'.$background_color.';';
	
	$style = ($color != '' || $background_color != '') ? 'style="'.$color.$background_color.'"' : '';
	($rounded == 'true') ? $rounded = ' pk_rounded' : $rounded = '';
	
	return str_replace(
		array('<h1>', '<h2>', '<h3>', '<h4>', '<h5>', '<h6>'),
		array('<h1 class="pk_heading_background'.$rounded.'" '.$style.'>', '<h2 class="pk_heading_background'.$rounded.'" '.$style.'>', '<h3 class="pk_heading_background'.$rounded.'" '.$style.'>', '<h4 class="pk_heading_background'.$rounded.'" '.$style.'>', '<h5 class="pk_heading_background'.$rounded.'" '.$style.'>', '<h6 class="pk_heading_background'.$rounded.'" '.$style.'>'),
		do_shortcode($content));
	
}

add_shortcode('pk_heading_background', 'pk_sc_heading_background');

/*
 * Pre
*/

function pk_sc_pre($atts, $content = null){
	
	return '<pre class="pk_pre">'.esc_attr($content).'</pre>';
	
}

add_shortcode('pk_pre', 'pk_sc_pre');

/*
 * Code
*/

function pk_sc_code($atts, $content = null){
	
	return '<pre class="pk_code">'.esc_attr($content).'</pre>';
	
}

add_shortcode('pk_code', 'pk_sc_code');

/*
 * Quote
*/

function pk_sc_quote($atts, $content = null){
	
	extract(shortcode_atts(array(
		'align' => 'none',
		'width' => '',
		'cite' => ''
	), $atts));
	
	($align != '') ? $class = ' class="pk_align'.strtolower($align).'"' : $class = '';
	($width != '' && $width != '0') ? $style = ' style="width:'.$width.'px"' : $style = '';
	($cite != '') ? $cite = '<p><cite>'.$cite.'</cite></p>' : $cite = '';
	
	return '<blockquote'.$class.$style.'><p>'.$content.'</p>'.$cite.'</blockquote>';
	
}

add_shortcode('pk_quote', 'pk_sc_quote');

/*
 * List
*/

function pk_str_replace_first($search, $replace, $data) {
	
	$res = strpos($data, $search);
	
	if ($res === false) {
		
		return $data;
		
	} else {
		
		$left_seg = substr($data, 0, strpos($data, $search));
        $right_seg = substr($data, (strpos($data, $search) + strlen($search)));
		
		return $left_seg . $replace . $right_seg;
		
	}
	
}

function pk_sc_list($atts, $content = null, $class){
	
	extract(shortcode_atts(array(
		'underline' => 'false'
	), $atts));
	
	if ($class == 'pk_underline_list') {
		
		$class = 'class="'.$class.'"';
		
	} else {
		
		$class = 'class="'.(($underline == 'true' && $class != 'pk_thumbnail_list') ? 'pk_underline_list ' : '').$class.'"';
		
	}
	
	return pk_str_replace_first('<ul>', '<ul '.$class.'>', do_shortcode($content));
	
}

add_shortcode('pk_underline_list', 'pk_sc_list');
add_shortcode('pk_clear_list', 'pk_sc_list');
add_shortcode('pk_arrow_list', 'pk_sc_list');
add_shortcode('pk_circle_list', 'pk_sc_list');
add_shortcode('pk_check_list', 'pk_sc_list');
add_shortcode('pk_posts_list', 'pk_sc_list');
add_shortcode('pk_thumbnail_list', 'pk_sc_list');

/*
 * Highlight
*/

function pk_sc_highlight($atts, $content = null){
	
	extract(shortcode_atts(array(
		'color' => '',
		'background_color' => '',
		'rounded' => 'true'
	), $atts));
	
	($rounded == 'true') ? $rounded = ' pk_rounded' : $rounded = '';

	return '<span class="pk_highlight'.$rounded.'" style="color:'.$color.'; background-color:'.$background_color.';">'.$content.'</span>';
	
}

add_shortcode('pk_highlight', 'pk_sc_highlight');

/*
 * Drop caps
*/

function pk_sc_drop_caps($atts, $content = null){
	
	extract(shortcode_atts(array(
		'type' => '1',
		'color' => ''
	), $atts));

	return '<span class="pk_drop_cap_'.$type.(($color != '') ? ' pk_drop_cap_'.$color : '').'">'.$content.'</span>';
	
}

add_shortcode('pk_drop_caps', 'pk_sc_drop_caps');

/*
 * Icon link
*/

function pk_sc_icon_link($atts, $content = null){
	
	extract(shortcode_atts(array(
		'icon' => '',
		'icon_type' => 'light'
	), $atts));
	
	$class = ' class="pk_text_icon pk_'.strtolower($icon_type).'_icon pk_'.str_replace(' ', '_', strtolower($icon)).'_icon"';

	return '<span'.$class.'>'.$content.'</span>';
	
}

add_shortcode('pk_icon_link', 'pk_sc_icon_link');

/*
 * Icon text
*/

function pk_sc_icon_text($atts, $content = null){
	
	extract(shortcode_atts(array(
		'icon' => '',
		'icon_type' => 'light'
	), $atts));
	
	$class = ' class="pk_text_icon pk_'.strtolower($icon_type).'_icon pk_'.str_replace(' ', '_', strtolower($icon)).'_icon"';

	return '<span'.$class.'>'.$content.'</span>';
	
}

add_shortcode('pk_icon_text', 'pk_sc_icon_text');

?>