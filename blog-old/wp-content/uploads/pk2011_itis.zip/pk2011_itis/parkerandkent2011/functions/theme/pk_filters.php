<?php

function pk_pre_get_posts($query) {
	
	if (is_admin()) {
		
		return $query;
		
	}
	
	if ($query -> is_feed) {
		
		$blog_exclude_categories = pk_get_options('pk_blog_options', 'blog_exclude_categories');
		
		$query -> set('category__not_in', explode(',', $blog_exclude_categories));
		
	}
	
	if (is_tax('taxonomy_works') || (function_exists('is_post_type_archive') && is_post_type_archive('works'))) {
		
		$works_archive_options_profile = (isset($query -> query['taxonomy_works']) && in_array(base64_encode($query -> query['taxonomy_works']), get_option('pk_works_archive_options_profiles'))) ? base64_encode($query -> query['taxonomy_works']) : '';
	
		$options = pk_get_options('pk_works_archive_options', '', $works_archive_options_profile);
	
		$columns = (isset($options['works_archive_layout'])) ? strtolower($options['works_archive_layout']) : '4';
		$posts_per_page = (isset($options['works_archive_posts_per_page'])) ? strtolower($options['works_archive_posts_per_page']) : (int)$columns * 3;
		
		$query -> set('posts_per_page', $posts_per_page);
		
	}
	
	return $query;
	
}
	
add_filter('pre_get_posts', 'pk_pre_get_posts');

function pk_exclude_categories_from_widgets($categories_args) {
	
	$blog_exclude_categories = pk_get_options('pk_blog_options', 'blog_exclude_categories');
	
	$categories_args['exclude'] = $blog_exclude_categories;
	$categories_args['title_li'] = '';
		
 	return $categories_args;
	
}

add_filter('widget_categories_args', 'pk_exclude_categories_from_widgets');
add_filter('widget_categories_dropdown_args', 'pk_exclude_categories_from_widgets');

function pk_exclude_categories_from_the_category($categories_list, $separator = ' . ') {
	
	if (!defined('WP_ADMIN')) {
		
		$blog_exclude_categories = pk_get_options('pk_blog_options', 'blog_exclude_categories');
		
		$blog_exclude_categories = explode(',', $blog_exclude_categories);
		
		$exclude_categories_names = array();
		
		foreach ($blog_exclude_categories as $id) {
			
			$exclude_categories_names[] = get_cat_name($id);
			
		}

		$original_categories = explode($separator, $categories_list);
		
		$new_categories_list = array();
		
		foreach ($original_categories as $original_category) {
			
			$category_name = trim(strip_tags($original_category));
			
			if (!in_array($category_name, $exclude_categories_names)){
				
				$new_categories_list[] = $original_category;
				
			}
			
		}
		
		return implode($separator, $new_categories_list);
		
	} else {
		
		return $categories_list;
		
	}
	
}

add_filter('the_category', 'pk_exclude_categories_from_the_category', 10, 2);

function pk_rel_nofollow($content) {
	
	return stripslashes(wp_rel_nofollow($content));
	
}

add_filter('wp_list_categories','pk_rel_nofollow');
add_filter('wp_tag_cloud','pk_rel_nofollow');

function pk_remove_shortcodes_from_feed($content) {
	
	if (is_feed()) $content = strip_shortcodes($content);
	
	return $content;
	
}

add_filter('the_content', 'pk_remove_shortcodes_from_feed');

function pk_add_thumbnail_to_feed($content) {
	
	global $post;
	
	if (is_feed() && has_post_thumbnail($post -> ID)) {
		
		$content = ''.get_the_post_thumbnail($post -> ID, 'thumbnail').''.$content;
		
	}
	
	return $content;
	
}

add_filter('the_excerpt', 'pk_add_thumbnail_to_feed');
add_filter('the_content', 'pk_add_thumbnail_to_feed');

function pk_works_short_excerpt_filter($length) {
	
	return 10;
	
}

function pk_works_long_excerpt_filter($length) {
	
	return 20;
	
}

function pk_works_very_long_excerpt_filter($length) {
	
	return 60;
	
}

function pk_blog_excerpt_filter($length) {
	
	return 60;
	
}

function pk_widgets_excerpt_filter($length) {
	
	return 20;
	
}

function pk_shortcodes_excerpt_filter($length) {
	
	return 30;
	
}

function pk_sliders_info_filter($length) {
	
	return 30;
	
}

function pk_excerpt_more($more) {
	
	return '&hellip;';
	
}

function pk_feed_excerpt_more($more) {
	
	return (is_feed()) ? '&hellip;' : $more;
	
}

add_filter('excerpt_more', 'pk_feed_excerpt_more');

function pk_sidebar_embed_defaults($embed_size){
	
	$embed_size['width'] = 690;
	
	return $embed_size;
	
}

function pk_full_embed_defaults($embed_size){
	
	$embed_size['width'] = 940;
	
	return $embed_size;
	
}

function pk_do_shortcode($content) {
	
	global $shortcode_tags;
	
	$original_tags = $shortcode_tags;
	
	$shortcode_tags = array();
	
	foreach ($original_tags as $k => $v) {
		
		$t = explode('_sc_', $v);
			
		if ($t[0] == 'pk') {
			
			$shortcode_tags[$k] = $v;
			
		}
		
	}
	
	$content = do_shortcode($content);
	
	$shortcode_tags = $original_tags;
	
	return $content;
	
}
 
add_filter('the_content', 'pk_do_shortcode', 9);

add_filter('wp_feed_cache_transient_lifetime', create_function('$a', 'return 3600;'));

remove_filter('comment_text', 'make_clickable', 9);

?>