<?php
	
	do_action('pk_ah_pre_flickr_grid_loop');
	do_action('pk_ah_flickr_print_grid_items');
	do_action('pk_ah_after_flickr_grid_loop');
	
	if ($pk_flickr_total_pages > 1) : 
		
		do_action('pk_ah_pre_flickr_grid_pagination');
		do_action('pk_ah_flickr_grid_pagination');
		do_action('pk_ah_after_flickr_grid_pagination');
		
	endif;
	
	do_action('pk_ah_pre_flickr_grid_comments');
	comments_template();
	do_action('pk_ah_after_flickr_grid_comments');
	
?>