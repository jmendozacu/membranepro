<?php

class PK_Widget_Flickr extends WP_Widget {

	function PK_Widget_Flickr() {
		
		$widget_ops=array('classname' => 'widget_flickr', 'description' => __('Display your Flickr photos feed', 'pk_text_domain'));	
		$this -> WP_Widget('pk-flickr', __('Flickr', 'pk_text_domain'), $widget_ops);
		
	}
	
	function widget($args, $instance) {
		
		extract($args);
		
		$title = apply_filters('widget_title', $instance['title']);
		
		if (empty($title)) $title = false;
		
		$number = absint($instance['number']);
		$thumb_icon = (isset($instance['thumb_icon']) && !empty($instance['thumb_icon'])) ? $instance['thumb_icon'] : '';
		$open_with_lightbox = (isset($instance['open_with_lightbox']) && $instance['open_with_lightbox']) ? 1 : 0;
		$slideshow_autostart = (isset($instance['slideshow_autostart']) && $instance['slideshow_autostart']) ? 1 : 0;
		$slideshow_duration = isset($instance['slideshow_duration']) ? $instance['slideshow_duration'] : '5000';
		$feed = $instance['feed'];
		
		if ($feed != '') $feed .= '&format=rss_200';
		
		include_once(ABSPATH.WPINC.'/feed.php');
		
		echo '<!-- pk start pk-flickr widget -->
'.$before_widget.'
	';
		
		if ($title) {
			
			echo $before_title;
			echo $title;
			echo $after_title;
			
		}
		
		$transients = get_option('pk_flickr_transients');
		$transients[] = $args['widget_id'];
		update_option('pk_flickr_transients', array_unique($transients));
		
		$cache = get_transient($args['widget_id']);
		
		if ($cache) {
			
			echo $cache;
			return;
			
		} else {
			
			$feed = fetch_feed($feed);
			
		}
		
		if ($feed != '' && !is_wp_error($feed)) : 
			
			$items = $feed -> get_items(0, $number);
			
			ob_start();
?>

	<div class="pk_flickr_widget">
<?php
			foreach ($items as $item) : $item_media = $item -> get_enclosures();
?>
		<div class="pk_image">
			<div class="pk_image_wrapper">
<?php
				if ($open_with_lightbox) : 
?>
				<a href="<?php echo esc_attr($item_media[0] -> link); ?>" rel="prettyPhoto[<?php echo $widget_id; ?>]" title="<?php echo $item -> get_title(); ?>"<?php if ($thumb_icon != '') : ?> class="<?php echo $thumb_icon; ?>"<?php endif; ?>>
					<img src="<?php echo esc_attr(str_replace(array('_t.','_m.','_z.'), '_s.', $item_media[0] -> thumbnails[0])); ?>" />
					<span class="pk_image_button_overlay"></span>
				</a>
<?php
				else : 
?>
				<a href="<?php echo esc_attr($item -> get_permalink()); ?>" title="<?php echo $item -> get_title(); ?>"<?php if ($thumb_icon != '') : ?> class="<?php echo $thumb_icon; ?>"<?php endif; ?>>
					<img src="<?php echo esc_attr(str_replace(array('_t.','_m.','_z.'), '_s.', $item_media[0] -> thumbnails[0])); ?>" />
					<span class="pk_image_button_overlay"></span>
				</a>
<?php
				endif;
?>
			</div>
		</div>
<?php
			endforeach;
?>
	</div>
	<script type="text/javascript">
		/*<![CDATA[*/
		jQuery(document).ready(function() {
			jQuery("a[rel^='prettyPhoto[<?php echo $widget_id; ?>]']").prettyPhoto({
				slideshow:<?php echo $slideshow_duration; ?>,
				autoplay_slideshow:<?php echo ($slideshow_autostart) ? 'true' : 'false'; ?>
			});
		});
		/*]]>*/
	</script>
<?php
		else :
			
			echo '<p>'.__('The Flickr feed is either empty or unavailable. Please check back later.', 'pk_text_domain_front').'</p>';
			
		endif;
		
		echo $after_widget.'
<!-- pk end pk-flickr widget -->

';
		
		set_transient($args['widget_id'], ob_get_flush(), 3600);
		
	}
	
	function update($new_instance, $old_instance) {
		
		$instance = $old_instance;
		
		$instance['title'] = strip_tags($new_instance['title']);
		$instance['number'] = absint($new_instance['number']);
		$instance['thumb_icon'] = strip_tags($new_instance['thumb_icon']);
		$instance['open_with_lightbox'] = $new_instance['open_with_lightbox'] ? 1 : 0;
		$instance['slideshow_autostart'] = $new_instance['slideshow_autostart'] ? 1 : 0;
		$instance['slideshow_duration'] = $new_instance['slideshow_duration'];
		$instance['feed'] = $new_instance['feed'];
		
		$transients = get_option('pk_flickr_transients');
		
		foreach ($transients as $transient) {
			
			delete_transient($transient);
			
		}
		
		return $instance;
		
	}
	
	function form($instance) {
		
		$title = isset($instance['title']) ? esc_attr($instance['title']) : '';
		$number = isset($instance['number']) ? absint($instance['number']) : 16;
		$thumb_icon = (isset($instance['thumb_icon']) && !empty($instance['thumb_icon'])) ? $instance['thumb_icon'] : '';
		$open_with_lightbox = (isset($instance['open_with_lightbox']) && !empty($instance['open_with_lightbox'])) ? 'checked="checked"' : '';
		$slideshow_autostart = (isset($instance['slideshow_autostart']) && !empty($instance['slideshow_autostart'])) ? 'checked="checked"' : '';
		$slideshow_duration = isset($instance['slideshow_duration']) ? $instance['slideshow_duration'] : '5000';
		$feed = isset($instance['feed']) ? esc_attr($instance['feed']) : '';
?>
		<p><label for="<?php echo $this -> get_field_id('title'); ?>"><?php _e('Title:', 'pk_text_domain'); ?></label>
		<input class="widefat" id="<?php echo $this -> get_field_id('title'); ?>" name="<?php echo $this -> get_field_name('title'); ?>" type="text" value="<?php echo $title; ?>" /></p>
		
		<p><label for="<?php echo $this -> get_field_id('number'); ?>"><?php _e('Number of thumbnails to show:', 'pk_text_domain'); ?></label>
		<input class="widefat" id="<?php echo $this -> get_field_id('number'); ?>" name="<?php echo $this -> get_field_name('number'); ?>" type="text" value="<?php echo $number; ?>" /></p>
		
		<p>
		<label for="<?php echo $this -> get_field_id('thumb_icon'); ?>"><?php _e('Select thumbnails icon type:', 'pk_text_domain'); ?></label>
		<select class="widefat" id="<?php echo $this -> get_field_id('thumb_icon'); ?>" name="<?php echo $this -> get_field_name('thumb_icon'); ?>">
			<option value=""<?php if ($thumb_icon == '') echo ' selected="selected"';?>><?php _e('No Icon', 'pk_text_domain'); ?></option>
			<option value="pk_page_icon"<?php if ($thumb_icon == 'pk_page_icon') echo ' selected="selected"';?>><?php _e('Page Icon', 'pk_text_domain'); ?></option>
			<option value="pk_link_icon"<?php if ($thumb_icon == 'pk_link_icon') echo ' selected="selected"';?>><?php _e('Link Icon', 'pk_text_domain'); ?></option>
			<option value="pk_play_icon"<?php if ($thumb_icon == 'pk_play_icon') echo ' selected="selected"';?>><?php _e('Play Icon', 'pk_text_domain'); ?></option>
			<option value="pk_zoom_icon"<?php if ($thumb_icon == 'pk_zoom_icon') echo ' selected="selected"';?>><?php _e('Zoom Icon', 'pk_text_domain'); ?></option>
		</select>
		</p>
		
		<p><input class="checkbox" type="checkbox" <?php echo $open_with_lightbox; ?> id="<?php echo $this -> get_field_id('open_with_lightbox'); ?>" name="<?php echo $this -> get_field_name('open_with_lightbox'); ?>" />
		<label for="<?php echo $this -> get_field_id('open_with_lightbox'); ?>"><?php _e('Open photos with lightbox', 'pk_text_domain'); ?></label><br />
		<input class="checkbox" type="checkbox" <?php echo $slideshow_autostart; ?> id="<?php echo $this -> get_field_id('slideshow_autostart'); ?>" name="<?php echo $this -> get_field_name('slideshow_autostart'); ?>" />
		<label for="<?php echo $this -> get_field_id('slideshow_autostart'); ?>"><?php _e('Slideshow auto start', 'pk_text_domain'); ?></label></p>
		
		<p><label for="<?php echo $this -> get_field_id('slideshow_duration'); ?>"><?php _e('Slideshow duration:', 'pk_text_domain'); ?></label>
		<input class="widefat" id="<?php echo $this -> get_field_id('slideshow_duration'); ?>" name="<?php echo $this -> get_field_name('slideshow_duration'); ?>" type="text" value="<?php echo $slideshow_duration; ?>" />
		<br /><small><?php _e('Interval in milliseconds.' ,'pk_text_domain'); ?></small></p>
		
		<p><label for="<?php echo $this -> get_field_id('feed'); ?>"><?php _e('Flickr RSS2 feed URL:', 'pk_text_domain', 'pk_text_domain'); ?></label>
		<input class="widefat" id="<?php echo $this -> get_field_id('feed'); ?>" name="<?php echo $this -> get_field_name('feed'); ?>" type="text" value="<?php echo $feed; ?>" /></p>
<?php
	}
	
}

function pk_widgets_flickr() {
	
	register_widget('PK_Widget_Flickr');
	
}

add_action('widgets_init', 'pk_widgets_flickr');

?>