<?php

function pk_get_featured_image() {
	
	$image = false;
	
	if (has_post_thumbnail()) {
		
		$image = wp_get_attachment_image_src(get_post_thumbnail_id(), 'full');
		
	} else {
		
		$post_images = get_children(array('post_parent' => get_the_ID(), 'post_type' => 'attachment', 'post_mime_type' => 'image', 'orderby' => 'menu_order'));
		
		if (!empty($post_images)) {
			
			$count = count($post_images);
			$first_image = array_shift($post_images);
			$image = wp_get_attachment_image_src($first_image -> ID, 'full');
			
		}
		
	}
	
	return $image;
	
}

function pk_get_featured_image_contents() {
	
	$image_contents = false;
	
	if (has_post_thumbnail()) {
		
		$image_contents = get_post(get_post_thumbnail_id());
		
	} else {
		
		$post_images = get_children(array('post_parent' => get_the_ID(), 'post_type' => 'attachment', 'post_mime_type' => 'image', 'orderby' => 'menu_order'));
		
		if (!empty($post_images)) {
			
			$count = count($post_images);
			$first_image = array_shift($post_images);
			$image_contents = get_post($first_image -> ID);
			
		}
		
	}
	
	return $image_contents;
	
}


?>