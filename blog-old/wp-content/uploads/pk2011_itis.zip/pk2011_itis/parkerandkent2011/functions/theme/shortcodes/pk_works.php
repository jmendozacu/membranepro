<?php

/*
 * Featured works
*/

static $pk_featured_works_counter = 0;

function pk_scp_featured_works($atts, $content = null, $class) {
	
	extract(shortcode_atts(array(
		'title' => '',
		'works' => '',
		'order_by' => 'date',
		'display_excerpt' => 'true',
		'display_thumb' => 'true',
		'list_icon' => 'arrow',
		'thumb_icon' => 'link',
		'thumb_width' => '160',
		'thumb_height' => '90'
	), $atts));
	
	global $pk_featured_works_counter;
	
	$pk_featured_works_counter++;
	
	$id = md5($pk_featured_works_counter.$class.$title.$works.$order_by.$display_excerpt.$display_thumb.$list_icon.$thumb_icon.$thumb_width.$thumb_height);
	
	$transients = get_option('pk_works_sc_transients');
	$transients[] = $id;
	update_option('pk_works_sc_transients', array_unique($transients));
	
	$cache = get_transient($id);
	
	if ($cache) {
		
		return $cache;
		
	}
	
	$display_excerpt = ($display_excerpt == 'true') ? 1 : 0;
	$display_thumb = ($display_thumb == 'true') ? 1 : 0;
	
	$thumb_width = (int)$thumb_width ;
	$thumb_height = (int)$thumb_height;
	
	$works = explode(',', $works);
	
	$output = '';
	
	remove_filter('pre_get_posts', 'pk_pre_get_posts');
	
	$r = new WP_Query(array('post_type' => 'works', 'posts_per_page' => count($works), 'post__in' => $works, 'nopaging' => 0, 'post_status' => 'publish', 'ignore_sticky_posts' => 1, 'orderby' => $order_by, 'order' => ($order_by == 'menu_order') ? 'ASC' : 'DESC'));
	
	if ($r -> have_posts()) : 
	
	$output = '
<!-- pk start featured works -->
<div class="pk_scp_featured_works">';
	
	if ($title != '') $output .= '
	<h4>'.$title.'</h4>';
	
	$output .= '
	<ul class="'.((!$display_thumb && !$display_excerpt) ? 'pk_underline_list pk_clear_list' : 'pk_thumbnail_list').((!$display_thumb && $list_icon != '') ? ' pk_'.$list_icon.'_list' : '').'">';
	
	while ($r -> have_posts()) : $r -> the_post();
		
		if ($display_thumb) : 
			
			$image = pk_get_featured_image();
			
			$output .= '
			<li>';
			
			if ($image) : 
			$output .= '
			<div class="pk_image pk_alignleft" style="width:'.$thumb_width.'px; height:'.$thumb_height.'px;">
				<div class="pk_image_wrapper">
					<a href="'.get_permalink().'" title="'.__('Read more &raquo;', 'pk_text_domain_front').'"'.(($thumb_icon != '') ? ' class="pk_'.$thumb_icon.'_icon"' : '').'>
						<img src="'.pk_build_image($image[0], $thumb_width - 12, $thumb_height - 12, 1).'" />
						<span class="pk_image_button_overlay"></span>
					</a>
				</div>
			</div>';
			endif;
			$output .= '
			<a href="'.get_permalink().'" title="'.esc_attr(get_the_title() ? get_the_title() : get_the_ID()).'">';
			
			if (get_the_title() && !$display_excerpt) : 
				
				$output .= get_the_title().'</h5></a>';
				
			else : 
				
				$output .= '<h5>'.get_the_title().'</h5></a>';
				
				add_filter('excerpt_length', 'pk_shortcodes_excerpt_filter');
				add_filter('excerpt_more', 'pk_excerpt_more');
				
				$output .= get_the_excerpt();
				
			endif;
			
			$output .= '
			</li>';
			
		else : 
			
			$output .= '
			<li><a href="'.get_permalink().'" title="'.esc_attr(get_the_title() ? get_the_title() : get_the_ID()).'">';
			
			if (get_the_title() && !$display_excerpt) : 
				
				$output .= get_the_title().'</h5></a>';
				
			else : 
				
				$output .= '<h5>'.get_the_title().'</h5></a>';
				
				add_filter('excerpt_length', 'pk_shortcodes_excerpt_filter');
				add_filter('excerpt_more', 'pk_excerpt_more');
				
				$output .= get_the_excerpt();
				
			endif;
			
			$output .= '</li>';
			
		endif;
		
	endwhile;
	
	$output .= '
	</ul>
</div>
<!-- pk end featured works -->
';
	
	set_transient($id, $output, 3600);
	
	endif;
	
	add_filter('pre_get_posts', 'pk_pre_get_posts');
	
	wp_reset_postdata();
	
	return $output;
	
}

add_shortcode('pk_featured_works', 'pk_scp_featured_works');

/*
 * Popular works
*/

static $pk_popular_works_counter = 0;

function pk_scp_popular_works($atts, $content = null, $class) {
	
	extract(shortcode_atts(array(
		'title' => '',
		'number' => 5,
		'display_excerpt' => 'true',
		'display_thumb' => 'true',
		'list_icon' => 'arrow',
		'thumb_icon' => 'link',
		'thumb_width' => '160',
		'thumb_height' => '90'
	), $atts));
	
	global $pk_popular_works_counter;
	
	$pk_popular_works_counter++;
	
	$id = md5($pk_popular_works_counter.$class.$title.$number.$display_excerpt.$display_thumb.$list_icon.$thumb_icon.$thumb_width.$thumb_height);
	
	$transients = get_option('pk_works_sc_transients');
	$transients[] = $id;
	update_option('pk_works_sc_transients', array_unique($transients));
	
	$cache = get_transient($id);
	
	if ($cache) {
		
		return $cache;
		
	}
	
	$display_excerpt = ($display_excerpt == 'true') ? 1 : 0;
	$display_thumb = ($display_thumb == 'true') ? 1 : 0;
	
	$thumb_width = (int)$thumb_width ;
	$thumb_height = (int)$thumb_height;
	
	$output = '';
	
	remove_filter('pre_get_posts', 'pk_pre_get_posts');
	
	$r = new WP_Query(array('post_type' => 'works', 'posts_per_page' => $number, 'nopaging' => 0, 'post_status' => 'publish', 'ignore_sticky_posts' => 1, 'orderby' => 'comment_count', 'order' => 'DESC'));
	
	if ($r -> have_posts()) : 
	
	$output = '
<!-- pk start popular works -->
<div class="pk_scp_popular_works">';
	
	if ($title != '') $output .= '
	<h4>'.$title.'</h4>';
	
	$output .= '
	<ul class="'.((!$display_thumb && !$display_excerpt) ? 'pk_underline_list pk_clear_list' : 'pk_thumbnail_list').((!$display_thumb) ? ' pk_'.$list_icon.'_list' : '').'">';
	
	while ($r -> have_posts()) : $r -> the_post();
		
		if ($display_thumb) : 
			
			$image = pk_get_featured_image();
			
			$output .= '
			<li>';
			
			if ($image) : 
			$output .= '
			<div class="pk_image pk_alignleft" style="width:'.$thumb_width.'px; height:'.$thumb_height.'px;">
				<div class="pk_image_wrapper">
					<a href="'.get_permalink().'" title="'.__('Read more &raquo;', 'pk_text_domain_front').'"'.(($thumb_icon != '') ? ' class="pk_'.$thumb_icon.'_icon"' : '').'>
						<img src="'.pk_build_image($image[0], $thumb_width - 12, $thumb_height - 12, 1).'" />
						<span class="pk_image_button_overlay"></span>
					</a>
				</div>
			</div>';
			endif;
			$output .= '
			<a href="'.get_permalink().'" title="'.esc_attr(get_the_title() ? get_the_title() : get_the_ID()).'">';
			
			if (get_the_title() && !$display_excerpt) : 
				
				$output .= get_the_title().'</h5></a>';
				
			else : 
				
				$output .= '<h5>'.get_the_title().'</h5></a>';
				
				add_filter('excerpt_length', 'pk_shortcodes_excerpt_filter');
				add_filter('excerpt_more', 'pk_excerpt_more');
				
				$output .= get_the_excerpt();
				
			endif;
			
			$output .= '
			</li>';
			
		else : 
			
			$output .= '
			<li><a href="'.get_permalink().'" title="'.esc_attr(get_the_title() ? get_the_title() : get_the_ID()).'">';
			
			if (get_the_title() && !$display_excerpt) : 
				
				$output .= get_the_title().'</h5></a>';
				
			else : 
				
				$output .= '<h5>'.get_the_title().'</h5></a>';
				
				add_filter('excerpt_length', 'pk_shortcodes_excerpt_filter');
				add_filter('excerpt_more', 'pk_excerpt_more');
				
				$output .= get_the_excerpt();
				
			endif;
			
			$output .= '</li>';
			
		endif;
		
	endwhile;
	
	$output .= '
	</ul>
</div>
<!-- pk end popular works -->
';
	
	set_transient($id, $output, 3600);
	
	endif;
	
	add_filter('pre_get_posts', 'pk_pre_get_posts');
	
	wp_reset_postdata();
	
	return $output;
	
}

add_shortcode('pk_popular_works', 'pk_scp_popular_works');

/*
 * Recent works
*/

static $pk_recent_works_counter = 0;

function pk_scp_recent_works($atts, $content = null, $class) {
	
	extract(shortcode_atts(array(
		'title' => '',
		'number' => 5,
		'display_excerpt' => 'true',
		'display_thumb' => 'true',
		'list_icon' => 'arrow',
		'thumb_icon' => 'link',
		'thumb_width' => '160',
		'thumb_height' => '90'
	), $atts));
	
	global $pk_recent_works_counter;
	
	$pk_recent_works_counter++;
	
	$id = md5($pk_recent_works_counter.$class.$title.$number.$display_excerpt.$display_thumb.$list_icon.$thumb_icon.$thumb_width.$thumb_height);
	
	$transients = get_option('pk_works_sc_transients');
	$transients[] = $id;
	update_option('pk_works_sc_transients', array_unique($transients));
	
	$cache = get_transient($id);
	
	if ($cache) {
		
		return $cache;
		
	}
	
	$display_excerpt = ($display_excerpt == 'true') ? 1 : 0;
	$display_thumb = ($display_thumb == 'true') ? 1 : 0;
	
	$thumb_width = (int)$thumb_width ;
	$thumb_height = (int)$thumb_height;
	
	$output = '';
	
	remove_filter('pre_get_posts', 'pk_pre_get_posts');
	
	$r = new WP_Query(array('post_type' => 'works', 'posts_per_page' => $number, 'nopaging' => 0, 'post_status' => 'publish', 'ignore_sticky_posts' => 1));
	
	if ($r -> have_posts()) : 
	
	$output = '
<!-- pk start recent works -->
<div class="pk_scp_recent_works">';
	
	if ($title != '') $output .= '
	<h4>'.$title.'</h4>';
	
	$output .= '
	<ul class="'.((!$display_thumb && !$display_excerpt) ? 'pk_underline_list pk_clear_list' : 'pk_thumbnail_list').((!$display_thumb) ? ' pk_'.$list_icon.'_list' : '').'">';
	
	while ($r -> have_posts()) : $r -> the_post();
		
		if ($display_thumb) : 
			
			$image = pk_get_featured_image();
			
			$output .= '
			<li>';
			
			if ($image) : 
			$output .= '
			<div class="pk_image pk_alignleft" style="width:'.$thumb_width.'px; height:'.$thumb_height.'px;">
				<div class="pk_image_wrapper">
					<a href="'.get_permalink().'" title="'.__('Read more &raquo;', 'pk_text_domain_front').'"'.(($thumb_icon != '') ? ' class="pk_'.$thumb_icon.'_icon"' : '').'>
						<img src="'.pk_build_image($image[0], $thumb_width - 12, $thumb_height - 12, 1).'" />
						<span class="pk_image_button_overlay"></span>
					</a>
				</div>
			</div>';
			endif;
			$output .= '
			<a href="'.get_permalink().'" title="'.esc_attr(get_the_title() ? get_the_title() : get_the_ID()).'">';
			
			if (get_the_title() && !$display_excerpt) : 
				
				$output .= get_the_title().'</h5></a>';
				
			else : 
				
				$output .= '<h5>'.get_the_title().'</h5></a>';
				
				add_filter('excerpt_length', 'pk_shortcodes_excerpt_filter');
				add_filter('excerpt_more', 'pk_excerpt_more');
				
				$output .= get_the_excerpt();
				
			endif;
			
			$output .= '
			</li>';
			
		else : 
			
			$output .= '
			<li><a href="'.get_permalink().'" title="'.esc_attr(get_the_title() ? get_the_title() : get_the_ID()).'">';
			
			if (get_the_title() && !$display_excerpt) : 
				
				$output .= get_the_title().'</h5></a>';
				
			else : 
				
				$output .= '<h5>'.get_the_title().'</h5></a>';
				
				add_filter('excerpt_length', 'pk_shortcodes_excerpt_filter');
				add_filter('excerpt_more', 'pk_excerpt_more');
				
				$output .= get_the_excerpt();
				
			endif;
			
			$output .= '</li>';
			
		endif;
		
	endwhile;
	
	$output .= '
	</ul>
</div>
<!-- pk end recent works -->
';
	
	set_transient($id, $output, 3600);
	
	endif;
	
	add_filter('pre_get_posts', 'pk_pre_get_posts');
	
	wp_reset_postdata();
	
	return $output;
	
}

add_shortcode('pk_recent_works', 'pk_scp_recent_works');

/*
 * Related works
*/

static $pk_related_works_counter = 0;

function pk_scp_related_works($atts, $content = null, $class) {
	
	extract(shortcode_atts(array(
		'title' => '',
		'number' => 5,
		'display_excerpt' => 'true',
		'display_thumb' => 'true',
		'list_icon' => 'arrow',
		'thumb_icon' => 'link',
		'thumb_width' => '160',
		'thumb_height' => '90'
	), $atts));
	
	global $post;
	
	if (isset($post) && $post -> post_type == 'works') {
		
		global $pk_related_works_counter;
		
		$pk_related_works_counter++;
		
		$id = md5($pk_related_works_counter.$class.$title.$number.$display_excerpt.$display_thumb.$list_icon.$thumb_icon.$thumb_width.$thumb_height);
		
		$transients = get_option('pk_works_sc_transients');
		$transients[] = $id;
		update_option('pk_works_sc_transients', array_unique($transients));
		
		$cache = get_transient($id);
		
		if ($cache) {
			
			return $cache;
			
		}
		
		$display_excerpt = ($display_excerpt == 'true') ? 1 : 0;
		$display_thumb = ($display_thumb == 'true') ? 1 : 0;
		
		$thumb_width = (int)$thumb_width ;
		$thumb_height = (int)$thumb_height;
		
		$output = '';
		
		$terms = wp_get_post_terms($post -> ID, 'taxonomy_works');
		
		$terms_ids = array();
		$post_in = array();
		
	}
	
	if (isset($terms) && $terms) {
		
		foreach ($terms as $term) {
			
			$terms_ids[] = $term -> term_id;
			
		}
		
		$works_to_query = array_unique(get_objects_in_term($terms_ids, 'taxonomy_works'));
		
		$total_works_to_query = count($works_to_query);
		
		for ($i = 0; $i < $total_works_to_query; $i++) {
			
			if ($works_to_query[$i] != $post -> ID){
				
				$post_in[] = $works_to_query[$i];
				
			}
			
		}
	
		remove_filter('pre_get_posts', 'pk_pre_get_posts');
		
		$r = new WP_Query(array('post_type' => $post -> post_type, 'posts_per_page' => $number, 'post__in' => $post_in, 'nopaging' => 0, 'post_status' => 'publish', 'ignore_sticky_posts' => 1, 'orderby' => 'comment_count', 'order' => 'DESC'));
		
		if ($r -> have_posts()) : 
		
		$output = '
<!-- pk start related works -->
<div class="pk_scp_related_works">';
		
		if ($title != '') $output .= '
	<h4>'.$title.'</h4>';
		
		$output .= '
	<ul class="'.((!$display_thumb && !$display_excerpt) ? 'pk_underline_list pk_clear_list' : 'pk_thumbnail_list').((!$display_thumb) ? ' pk_'.$list_icon.'_list' : '').'">';
		
		while ($r -> have_posts()) : $r -> the_post();
			
			if ($display_thumb) : 
				
				$image = pk_get_featured_image();
				
				$output .= '
			<li>';
				
				if ($image) : 
				$output .= '
			<div class="pk_image pk_alignleft" style="width:'.$thumb_width.'px; height:'.$thumb_height.'px;">
				<div class="pk_image_wrapper">
					<a href="'.get_permalink().'" title="'.__('Read more &raquo;', 'pk_text_domain_front').'"'.(($thumb_icon != '') ? ' class="pk_'.$thumb_icon.'_icon"' : '').'>
						<img src="'.pk_build_image($image[0], $thumb_width - 12, $thumb_height - 12, 1).'" />
						<span class="pk_image_button_overlay"></span>
					</a>
				</div>
			</div>';
				endif;
				$output .= '
			<a href="'.get_permalink().'" title="'.esc_attr(get_the_title() ? get_the_title() : get_the_ID()).'">';
				
				if (get_the_title() && !$display_excerpt) : 
					
					$output .= get_the_title().'</h5></a>';
					
				else : 
					
					$output .= '<h5>'.get_the_title().'</h5></a>';
					
					add_filter('excerpt_length', 'pk_shortcodes_excerpt_filter');
					add_filter('excerpt_more', 'pk_excerpt_more');
					
					$output .= get_the_excerpt();
					
				endif;
				
				$output .= '
			</li>';
			
			else : 
				
				$output .= '
			<li><a href="'.get_permalink().'" title="'.esc_attr(get_the_title() ? get_the_title() : get_the_ID()).'">';
				
				if (get_the_title() && !$display_excerpt) : 
					
					$output .= get_the_title().'</h5></a>';
					
				else : 
					
					$output .= '<h5>'.get_the_title().'</h5></a>';
					
					add_filter('excerpt_length', 'pk_shortcodes_excerpt_filter');
					add_filter('excerpt_more', 'pk_excerpt_more');
					
					$output .= get_the_excerpt();
					
				endif;
				
				$output .= '</li>';
				
			endif;
			
		endwhile;
		
		$output .= '
	</ul>
</div>
<!-- pk end related works -->
';
		
		set_transient($id, $output, 3600);
		
		endif;
		
		add_filter('pre_get_posts', 'pk_pre_get_posts');
		
		wp_reset_postdata();
		
		return $output;
		
	}
	
}

add_shortcode('pk_related_works', 'pk_scp_related_works');

/*
 * Cache management
*/

add_option('pk_works_sc_transients', array());

function pk_delete_works_sc_transients() {
	
	$transients = get_option('pk_works_sc_transients');
	
	foreach ($transients as $transient) {
		
		delete_transient($transient);
		
	}
	
}
	
add_action('publish_post', 'pk_delete_works_sc_transients');
add_action('save_post', 'pk_delete_works_sc_transients');
add_action('edit_post', 'pk_delete_works_sc_transients');
add_action('delete_post', 'pk_delete_works_sc_transients');
add_action('pk_ah_save_text_widget', 'pk_delete_works_sc_transients');
add_action('pk_ah_options_updated', 'pk_delete_works_sc_transients');
add_action('pk_ah_posts_sorted', 'pk_delete_works_sc_transients');

?>