<?php

/*
 * Columns
*/

function pk_sc_column($atts, $content = null, $class) {
	
	return '<div class="'.$class.'">'.do_shortcode($content).'</div>'.(($class == 'pk_full_width') ? '<div class="pk_clear_both"></div>' : '');
	
}

add_shortcode('pk_full_width', 'pk_sc_column');
add_shortcode('pk_one_half', 'pk_sc_column');
add_shortcode('pk_one_third', 'pk_sc_column');
add_shortcode('pk_one_fourth', 'pk_sc_column');
add_shortcode('pk_one_fifth', 'pk_sc_column');
add_shortcode('pk_one_sixth', 'pk_sc_column');
add_shortcode('pk_two_third', 'pk_sc_column');
add_shortcode('pk_three_fourth', 'pk_sc_column');
add_shortcode('pk_two_fifth', 'pk_sc_column');
add_shortcode('pk_three_fifth', 'pk_sc_column');
add_shortcode('pk_four_fifth', 'pk_sc_column');
add_shortcode('pk_five_sixth', 'pk_sc_column');

/*
 * Columns last
*/

function pk_sc_column_last($atts, $content = null, $class) {
	
	return '<div class="'.str_replace('_last', '', $class).' pk_last">'.do_shortcode($content).'</div><div class="pk_clear_both"></div>';
	
}

add_shortcode('pk_one_half_last', 'pk_sc_column_last');
add_shortcode('pk_one_third_last', 'pk_sc_column_last');
add_shortcode('pk_one_fourth_last', 'pk_sc_column_last');
add_shortcode('pk_one_fifth_last', 'pk_sc_column_last');
add_shortcode('pk_one_sixth_last', 'pk_sc_column_last');
add_shortcode('pk_two_third_last', 'pk_sc_column_last');
add_shortcode('pk_three_fourth_last', 'pk_sc_column_last');
add_shortcode('pk_two_fifth_last', 'pk_sc_column_last');
add_shortcode('pk_three_fifth_last', 'pk_sc_column_last');
add_shortcode('pk_four_fifth_last', 'pk_sc_column_last');
add_shortcode('pk_five_sixth_last', 'pk_sc_column_last');

?>