<?php

class PK_Widget_Testimonials extends WP_Widget {
	
	function PK_Widget_Testimonials() {
		
		$widget_ops = array('classname' => 'widget_testimonials', 'description' => __('Displays testimonials', 'pk_text_domain'));	
		$this -> WP_Widget('pk-testimonials', __('Testimonials', 'pk_text_domain'), $widget_ops);
		
	}
	
	function widget($args, $instance) {
		
		extract($args);
		
		$title = apply_filters('widget_title', $instance['title']);
		
		if (empty($title)) $title = false;
		
		$number = absint($instance['number']);
		$instance_testimonials_cite = array();
		$instance_testimonials_quote = array();
		
		for ($i = 1; $i <= $number; $i++) {
			
			$testimonials_cite = 'testimonials_'.$i.'_cite';
			$instance_testimonials_cite[$i] = isset($instance[$testimonials_cite]) ? $instance[$testimonials_cite] : '';
			$testimonials_quote = 'testimonials_'.$i.'_quote';
			$instance_testimonials_quote[$i] = isset($instance[$testimonials_quote]) ? $instance[$testimonials_quote] : '';
			
		}
		
		echo '<!-- pk start pk-testimonials widget -->
'.$before_widget.'
	<div class="pk_titled_widget pk_testimonials">
		<div class="pk_widget_title">
			<span class="pk_left_corner"></span>
			<span class="pk_right_corner"></span>
			';
		
		if ($title) {
			
			echo $before_title;
			echo $title;
			echo $after_title.'
		</div>';
			
		}
?>

		<div class="pk_widget_content">
			<ul>
<?php
		for ($i = 1; $i <= $number; $i++) : 
?>
				<li>
					<p><?php echo $instance_testimonials_quote[$i]; ?></p>
					<cite><?php echo $instance_testimonials_cite[$i];?></cite>
				</li>
<?php	
		endfor;
?>
			</ul>
		</div>
		<div class="pk_widget_navigation">
			<span class="pk_call_to_action"><?php _e('Back to first', 'pk_text_domain_front'); ?></span>
			<span class="pk_button_circle pk_button_next"><?php _e('next', 'pk_text_domain_front'); ?></span>
			<span class="pk_button_circle pk_button_prev"><?php _e('prev', 'pk_text_domain_front'); ?></span>
		</div>
	</div>
<?php

		echo $after_widget.'
<!-- pk end pk-testimonials widget -->

';
		
	}
	
	function update($new_instance, $old_instance) {
		
		$instance = $old_instance;
		
		$instance['title'] = strip_tags($new_instance['title']);
		$instance['number'] = $new_instance['number'];
		for ($i = 1; $i <= absint($instance['number']); $i++) {
			
			$instance['testimonials_'.$i.'_cite'] = $new_instance['testimonials_'.$i.'_cite'];
			$instance['testimonials_'.$i.'_quote'] = $new_instance['testimonials_'.$i.'_quote'];
			
		}
		
		return $instance;
		
	}
	
	function form($instance) {
		
		$title = isset($instance['title']) ? esc_attr($instance['title']) : '';
		$number = isset($instance['number']) ? absint($instance['number']) : 1;
		$instance_testimonials_cite = array();
		$instance_testimonials_quote = array();
		
		for ($i = 1; $i <= $number; $i++) {
			
			$testimonials_cite = 'testimonials_'.$i.'_cite';
			$instance_testimonials_cite[$i] = isset($instance[$testimonials_cite]) ? $instance[$testimonials_cite] : '';
			$testimonials_quote = 'testimonials_'.$i.'_quote';
			$instance_testimonials_quote[$i] = isset($instance[$testimonials_quote]) ? $instance[$testimonials_quote] : '';
			
		}
?>
		<p><label for="<?php echo $this -> get_field_id('title'); ?>"><?php _e('Title:', 'pk_text_domain'); ?></label>
		<input class="widefat" id="<?php echo $this -> get_field_id('title'); ?>" name="<?php echo $this -> get_field_name('title'); ?>" type="text" value="<?php echo $title; ?>" /></p>
		
		<p><label for="<?php echo $this -> get_field_id('number'); ?>"><?php _e('Number of testimonials to show:', 'pk_text_domain'); ?></label>
		<input class="widefat" id="<?php echo $this -> get_field_id('number'); ?>" name="<?php echo $this -> get_field_name('number'); ?>" type="text" value="<?php echo $number; ?>" /></p>
		
		<div>
<?php for ($i = 1; $i <= $number; $i++) : $testimonials_cite = 'testimonials_'.$i.'_cite'; $testimonials_quote = 'testimonials_'.$i.'_quote'; ?>
			<div>
				<p><strong><?php _e('Testimonial', 'pk_text_domain'); ?> <?php echo $i; ?>:</strong></p>
				<p><label for="<?php echo $this -> get_field_id($testimonials_cite); ?>"><?php _e('Cite:', 'pk_text_domain'); ?></label>
				<input class="widefat" id="<?php echo $this -> get_field_id($testimonials_cite); ?>" name="<?php echo $this -> get_field_name($testimonials_cite); ?>" type="text" value="<?php echo $instance_testimonials_cite[$i]; ?>" /></p>
				<p><label for="<?php echo $this -> get_field_id($testimonials_quote); ?>"><?php _e('Quote:', 'pk_text_domain'); ?></label>
				<textarea class="widefat" rows="10" cols="10" id="<?php echo $this -> get_field_id($testimonials_quote); ?>" name="<?php echo $this -> get_field_name($testimonials_quote); ?>"><?php echo $instance_testimonials_quote[$i]; ?></textarea></p>
			</div>
<?php endfor;?>
		</div>
<?php
	}
	
}

function pk_widgets_testimonials() {
	
	register_widget('PK_Widget_Testimonials');
	
}

add_action('widgets_init', 'pk_widgets_testimonials');

?>