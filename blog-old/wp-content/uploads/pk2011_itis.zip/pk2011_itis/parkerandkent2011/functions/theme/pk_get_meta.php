<?php

function pk_get_meta($meta = '', $bool = true) {
	
	global $post;
	
	$post_custom_meta = get_post_meta($post -> ID, '_pk_meta', $bool);
	
	if (isset($post_custom_meta[$meta]) && $meta != '') {
		
		return urldecode($post_custom_meta[$meta]);
		
	} else {
		
		$decoded_meta = array();
		
		if (isset($post_custom_meta) && is_array($post_custom_meta)) foreach ($post_custom_meta as $k => $v) {
			
			$decoded_meta[$k] = urldecode($v);
			
		}
		
		return $decoded_meta;
		
	}
	
}

?>