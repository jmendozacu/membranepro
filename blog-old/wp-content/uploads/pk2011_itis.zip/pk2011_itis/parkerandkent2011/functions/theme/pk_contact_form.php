<?php

function pk_ajax_send_contact_form() {
	
	$admin_email = $_POST['send_to'];
	$admin_email = str_replace('[at]', '@', $admin_email);
	
	$subject = stripslashes($_POST['subject']);
	
	if (!$admin_email || $admin_email == '') {
		
		$admin_email = get_option('admin_email');
		
	}
	
	$name = stripslashes($_POST['contact_name']);
	$email = trim($_POST['contact_email']);
	$message = stripslashes($_POST['contact_message']);
	
	$error = '';
	
	if(!$message || $message == __('Message', 'pk_text_domain_front')) {
		
		$error = __('Please, type in a message.', 'pk_text_domain_front');
		
	}
	
	if ($email && !pk_validate_email($email) || $email == __('Email', 'pk_text_domain_front')) {
		
		$error = __('Please, check your e-mail address.', 'pk_text_domain_front');
		
	}
	
	if (!$email || $email == __('Email', 'pk_text_domain_front')) {
		
		$error = __('Please, type in your e-mail address.', 'pk_text_domain_front');
		
	}
	
	if (!$name || $name == __('Name', 'pk_text_domain_front')) {
		
		$error = __('Please, type in your name.', 'pk_text_domain_front');
		
	}
	
	if(!$error) {
		
		$placeholders = array('%sitename%', '%name%');
		$replacements = array(get_bloginfo('name'), $name);
		
		$subject = str_replace($placeholders, $replacements, $subject);
		
		$mail = wp_mail($admin_email, $subject, $message, "From: $name <$email>\r\nReply-To: $email\r\n");
				
		if ($mail) {
			
			echo '<p class="pk_form_success">'.__('Your message has been sent. Thanks.', 'pk_text_domain_front').'</p>';
			
		} else {
			
			echo '<p class="pk_form_error">'.__('Error in sending message.', 'pk_text_domain_front').'</p>';
			
		}
		
	} else {
		
		echo '<p class="pk_form_error">'.$error.'</p>';
		
	}
	
	die();
	
}

add_action('wp_ajax_pk_ajax_contact_form', 'pk_ajax_send_contact_form');
add_action('wp_ajax_nopriv_pk_ajax_contact_form', 'pk_ajax_send_contact_form');

function pk_validate_email($email) {
	
	return eregi('^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$', $email);
	
}

?>