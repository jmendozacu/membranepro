<?php

/*
 * Box
*/

function pk_sc_box($atts, $content = null) {
	
	extract(shortcode_atts(array(
		'width' => '',
		'align' => 'none',
		'text_align' => 'left'
	), $atts));
	
	($width != '' && $width != '0') ? $width = ' pk_align'.strtolower($align).'" style="width:'.$width.'px;"' : $width = '"';
	
	return '<div class="pk_basic_box'.$width.'><div class="pk_basic_box_content_wrapper"><div class="pk_basic_box_content" style="text-align:'.strtolower($text_align).';">'.do_shortcode($content).'</div></div></div>';
	
}

add_shortcode('pk_box', 'pk_sc_box');

/*
 * Titled box
*/

function pk_sc_titled_box($atts, $content = null) {
	
	extract(shortcode_atts(array(
		'width' => '',
		'align' => 'none'
	), $atts));
	
	($width != '' && $width != '0') ? $width = ' pk_align'.strtolower($align).'" style="width:'.$width.'px;"' : $width = '"';
	
	return '<div class="pk_titled_box'.$width.'>'.do_shortcode($content).'</div>';
	
}

add_shortcode('pk_titled_box', 'pk_sc_titled_box');

/*
 * Box title
*/
	  
function pk_sc_box_title($atts, $content = null) {
	
	extract(shortcode_atts(array(
		'text_align' => ''
	), $atts));
	
	return '<div class="pk_titled_box_title"><span class="pk_left_corner"></span><span class="pk_right_corner"></span><p style="text-align:'.strtolower($text_align).';">'.$content.'</p></div>';
	
}

add_shortcode('pk_box_title', 'pk_sc_box_title');

/*
 * Box content
*/

function pk_sc_box_content($atts, $content = null) {
	
	extract(shortcode_atts(array(
		'text_align' => ''
	), $atts));
	
	return '<div class="pk_titled_box_content_wrapper"><div class="pk_titled_box_content" style="text-align:'.strtolower($text_align).';">'.do_shortcode($content).'</div></div>';
	
}

add_shortcode('pk_box_content', 'pk_sc_box_content');

/*
 * Message box
*/

function pk_sc_message_box($atts, $content = null, $class) {
	
	extract(shortcode_atts(array(
		'width' => ''
	), $atts));
	
	return '<div class="pk_message_box '.$class.'"'.(($width != '' && $width != '0') ? ' style="width:'.$width.'px;"' : '').'><div class="pk_message_box_content_wrapper"><div class="pk_message_box_content">'.do_shortcode($content).'</div></div></div>';
	
}

add_shortcode('pk_info_box', 'pk_sc_message_box');
add_shortcode('pk_note_box', 'pk_sc_message_box');
add_shortcode('pk_success_box', 'pk_sc_message_box');
add_shortcode('pk_error_box', 'pk_sc_message_box');
add_shortcode('pk_warning_box', 'pk_sc_message_box');
add_shortcode('pk_important_box', 'pk_sc_message_box');
add_shortcode('pk_help_box', 'pk_sc_message_box');

?>