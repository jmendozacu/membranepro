<?php

$pk_skin_profile = '';

function pk_get_skin() {
	
	global $pk_skin_profile;
			
	$skin_profiles = get_option('pk_skin_options_profiles');
	
	if (is_singular(array('page', 'post', 'works', 'attachment'))) {
	
		if (is_attachment()) {
	
			$skin = pk_get_options('pk_works_archive_options', 'attachments_skin_profile');
			
		} else {
			
			global $post;
	
			$skin = get_post_meta($post -> ID, '_pk_skin_profile', true);
			
		}
	
	} else {
		
		if (is_home()) {
	
			$skin = pk_get_options('pk_blog_options', 'blog_skin_profile');
			
			if (!in_array($skin, $skin_profiles)) $skin = get_option('pk_skin_options_active_profile');
			
			$pk_skin_profile = $skin;
			
			return pk_get_options('pk_skin_options', 'main_theme_skin', $skin);
	
		} elseif (is_search()) {
	
			$skin = pk_get_options('pk_search_options', 'search_skin_profile');
	
		} elseif ((function_exists('is_post_type_archive') && is_post_type_archive('works')) || is_tax('taxonomy_works')) {
	
			$skin = pk_get_options('pk_works_archive_options', 'works_archive_skin_profile', ((get_query_var('term')) ? base64_encode(get_query_var('term')) : ''));
	
		} elseif (is_archive()) {
			
			if (is_category()) {
				
				$skin = pk_get_options('pk_blog_archive_options', 'blog_archive_skin_profile', base64_encode(get_query_var('category_name')));
				
			}
			
			if (is_tag()) {
				
				$skin = pk_get_options('pk_blog_archive_options', 'blog_archive_skin_profile', base64_encode(get_query_var('tag')));
				
			}
	
		} else {
		
			$skin = '';
			
		}
		
	}
	
	if (!in_array($skin, $skin_profiles)) $skin = get_option('pk_skin_options_active_profile');
	
	$pk_skin_profile = $skin;
	
	return pk_get_options('pk_skin_options', 'main_theme_skin', $pk_skin_profile);
	
}

?>