<?php

/*
 * Flickr
*/

static $pk_flickr_feeds_counter = 0;

function pk_scp_flickr_feed($atts, $content = null) {
	
	extract(shortcode_atts(array(
		'title' => '',
		'feed' => '',
		'number' => '16',
		'thumb_icon' => '',
		'open_with_lightbox' => 'true',
		'slideshow_autostart' => 'false',
		'slideshow_interval' => '5'
	), $atts));
	
	global $pk_flickr_feeds_counter;
	
	$pk_flickr_feeds_counter++;
	
	$id = md5($pk_flickr_feeds_counter.$title.$feed.$number.$thumb_icon.$open_with_lightbox.$slideshow_autostart.$slideshow_interval);
	
	$output = '';
	
	include_once(ABSPATH.WPINC.'/feed.php');
	
	$transients = get_option('pk_flickr_transients');
	$transients[] = $id;
	update_option('pk_flickr_transients', array_unique($transients));
	
	$cache = get_transient($id);
	
	if ($cache) {
		
		return $cache;
		
	} else {
		
		if ($feed != '') {
			
			$feed .= '&format=rss_200';
			$feed = fetch_feed(str_replace('#038;', '&', $feed));
			
		}
		
	}
	
	if ($feed != '' && !is_wp_error($feed)) {
		
		$items = $feed -> get_items(0, $number);
		
		$output = '
<!-- pk start Flickr widget -->
<div class="pk_scp_flickr pk_widget">';
	
	if ($title != '') $output .= '
	<h4>'.$title.'</h4>';
	
	$output .= '
	<div class="pk_flickr_widget">';
	
	foreach ($items as $item) {
		
		$item_media = $item -> get_enclosures();
		
		$output .= '
		<div class="pk_image">
			<div class="pk_image_wrapper">';
		
		if ($open_with_lightbox == 'true') {
			
			$output .= '
				<a href="'.esc_url($item_media[0] -> link).'" rel="prettyPhoto[flickr_feed_'.$pk_flickr_feeds_counter.']" title="'.$item -> get_title().'"'.(($thumb_icon != '') ? ' class="pk_'.$thumb_icon.'_icon"' : '').'>
					<img src="'.esc_url(str_replace(array('_t.','_m.','_z.'), '_s.', $item_media[0] -> thumbnails[0])).'" />
					<span class="pk_image_button_overlay"></span>
				</a>';
			
		} else {
			
			$output .= '
				<a href="'.esc_url($item -> get_permalink()).'" title="'.$item -> get_title().'"'.(($thumb_icon != '') ? ' class="pk_'.$thumb_icon.'_icon"' : '').'>
					<img src="'.esc_url(str_replace(array('_t.','_m.','_z.'), '_s.', $item_media[0] -> thumbnails[0])).'" />
					<span class="pk_image_button_overlay"></span>
				</a>';
			
		}
		
		$output .= '
			</div>
		</div>';
	
	}
	
	$output .= '
	</div>
	<script type="text/javascript">
		/*<![CDATA[*/
		jQuery(document).ready(function() {
			jQuery("a[rel^=\'prettyPhoto[flickr_feed_'.$pk_flickr_feeds_counter.']\']").prettyPhoto({
				slideshow:'.$slideshow_interval.',
				autoplay_slideshow:'.((int)$slideshow_autostart * 1000).'
			});
		});
		/*]]>*/
	</script>
</div>
<!-- pk end Flickr widget -->
';
		
	} else {
		
		$output .= '
<p>'.__('The Flickr feed is either empty or unavailable. Please check back later.', 'pk_text_domain_front').'</p>';
		
	}
	
	set_transient($id, $output, 3600);
	
	return $output;
	
}

add_shortcode('pk_flickr_feed', 'pk_scp_flickr_feed');

/*
 * Cache management
*/

add_option('pk_flickr_transients', array());

function pk_delete_flickr_transients() {
	
	$transients = get_option('pk_flickr_transients');
	
	foreach ($transients as $transient) {
		
		delete_transient($transient);
		
	}
	
}
	
add_action('publish_post', 'pk_delete_flickr_transients');
add_action('save_post', 'pk_delete_flickr_transients');
add_action('edit_post', 'pk_delete_flickr_transients');
add_action('delete_post', 'pk_delete_flickr_transients');
add_action('pk_ah_save_text_widget', 'pk_delete_flickr_transients');
add_action('pk_ah_options_updated', 'pk_delete_flickr_transients');
add_action('pk_ah_posts_sorted', 'pk_delete_flickr_transients');

?>