<?php

class PK_Widget_Tabs extends WP_Widget {
	
	function PK_Widget_Tabs() {
		
		$widget_ops = array('classname' => 'widget_tabs', 'description' => __('Displays content tabs', 'pk_text_domain'));	
		$this -> WP_Widget('pk-tabs', __('Tabs', 'pk_text_domain'), $widget_ops);
		
	}
	
	function widget($args, $instance) {
		
		extract($args);
		
		$title = apply_filters('widget_title', $instance['title']);
		
		if (empty($title)) $title = false;
		
		$number = absint($instance['number']);
		$tabs_type = (isset($instance['tabs_type']) && !empty($instance['tabs_type'])) ? $instance['tabs_type'] : 'minimal';
		$instance_tabs_title = array();
		$instance_tabs_content = array();
		
		for ($i = 1; $i <= $number; $i++) {
			
			$tabs_title = 'tabs_'.$i.'_title';
			$instance_tabs_title[$i] = isset($instance[$tabs_title]) ? $instance[$tabs_title] : '';
			$tabs_content = 'tabs_'.$i.'_content';
			$instance_tabs_content[$i] = isset($instance[$tabs_content]) ? $instance[$tabs_content] : '';
			
		}
		
		echo '<!-- pk start pk-tabs widget -->
'.$before_widget.'
	';
		
		if ($title) {
			
			echo $before_title;
			echo $title;
			echo $after_title;
			
		}
?>
<?php
		if ($tabs_type == 'minimal') : 
?>

	<div class="pk_minimal_tabs pk_alignleft" style="width:100%;">
<?php
		else : 
?>
	<div class="pk_boxed_tabs pk_alignleft" style="width:100%;">
<?php
		endif;
?>
		<ul class="pk_tabs_navigation">
<?php
		for ($i = 1; $i <= $number; $i++) : 
?>
			<li>
				<a href="#" title="<?php _e('View Tab', 'pk_text_domain_front'); ?>"><?php echo $instance_tabs_title[$i]; ?></a>
			</li>
<?php
		endfor;
?>
		</ul>
		<div class="pk_tabs">
<?php
		for ($i = 1; $i <= $number; $i++) : 
?>
			<div class="pk_tab">
				<?php echo $instance_tabs_content[$i];
?>

			</div>
<?php
		endfor;
?>
		</div>
	</div>
	<span class="pk_clear_both"></span>
<?php

		echo $after_widget.'
<!-- pk end pk-tabs widget -->

';
		
	}
	
	function update($new_instance, $old_instance) {
		
		$instance = $old_instance;
		
		$instance['title'] = strip_tags($new_instance['title']);
		$instance['number'] = $new_instance['number'];
		$instance['tabs_type'] = $new_instance['tabs_type'];
		for ($i = 1; $i <= absint($instance['number']); $i++) {
			
			$instance['tabs_'.$i.'_title'] = $new_instance['tabs_'.$i.'_title'];
			$instance['tabs_'.$i.'_content'] = $new_instance['tabs_'.$i.'_content'];
			
		}
		
		return $instance;
		
	}
	
	function form($instance) {
		
		$title = isset($instance['title']) ? esc_attr($instance['title']) : '';
		$number = isset($instance['number']) ? absint($instance['number']) : 1;
		$tabs_type = (isset($instance['tabs_type']) && !empty($instance['tabs_type'])) ? $instance['tabs_type'] : 'minimal';
		$instance_tabs_title = array();
		$instance_tabs_content = array();
		
		for ($i = 1; $i <= $number; $i++) {
			
			$tabs_title = 'tabs_'.$i.'_title';
			$instance_tabs_title[$i] = isset($instance[$tabs_title]) ? $instance[$tabs_title] : '';
			$tabs_content = 'tabs_'.$i.'_content';
			$instance_tabs_content[$i] = isset($instance[$tabs_content]) ? $instance[$tabs_content] : '';
			
		}
?>
		<p><label for="<?php echo $this -> get_field_id('title'); ?>"><?php _e('Title:', 'pk_text_domain'); ?></label>
		<input class="widefat" id="<?php echo $this -> get_field_id('title'); ?>" name="<?php echo $this -> get_field_name('title'); ?>" type="text" value="<?php echo $title; ?>" /></p>
		
		<p><label for="<?php echo $this -> get_field_id('number'); ?>"><?php _e('Number of tabs to show:', 'pk_text_domain'); ?></label>
		<input class="widefat" id="<?php echo $this -> get_field_id('number'); ?>" name="<?php echo $this -> get_field_name('number'); ?>" type="text" value="<?php echo $number; ?>" /></p>
		
		<p>
		<label for="<?php echo $this -> get_field_id('tabs_type'); ?>"><?php _e('Style:', 'pk_text_domain'); ?></label>
		<select class="widefat" id="<?php echo $this -> get_field_id('tabs_type'); ?>" name="<?php echo $this -> get_field_name('tabs_type'); ?>">
			<option value="minimal"<?php if ($tabs_type == 'minimal') echo ' selected="selected"';?>><?php _e('Minimal', 'pk_text_domain'); ?></option>
			<option value="boxed"<?php if ($tabs_type == 'boxed') echo ' selected="selected"';?>><?php _e('Boxed', 'pk_text_domain'); ?></option>
		</select>
		</p>
		
		<div>
<?php for ($i = 1; $i <= $number; $i++) : $tabs_title = 'tabs_'.$i.'_title'; $tabs_content = 'tabs_'.$i.'_content'; ?>
			<div>
				<p><strong><?php _e('Tab', 'pk_text_domain'); ?> <?php echo $i; ?>:</strong></p>
				<p><label for="<?php echo $this -> get_field_id($tabs_title); ?>"><?php _e('Title:', 'pk_text_domain'); ?></label>
				<input class="widefat" id="<?php echo $this -> get_field_id($tabs_title); ?>" name="<?php echo $this -> get_field_name($tabs_title); ?>" type="text" value="<?php echo $instance_tabs_title[$i]; ?>" /></p>
				<p><label for="<?php echo $this -> get_field_id($tabs_content); ?>"><?php _e('Content:', 'pk_text_domain'); ?></label>
				<textarea class="widefat" rows="10" cols="10" id="<?php echo $this -> get_field_id($tabs_content); ?>" name="<?php echo $this -> get_field_name($tabs_content); ?>"><?php echo $instance_tabs_content[$i]; ?></textarea></p>
			</div>
<?php endfor;?>
		</div>
<?php
	}
	
}

function pk_widgets_tabs() {
	
	register_widget('PK_Widget_Tabs');
	
}

add_action('widgets_init', 'pk_widgets_tabs');

?>