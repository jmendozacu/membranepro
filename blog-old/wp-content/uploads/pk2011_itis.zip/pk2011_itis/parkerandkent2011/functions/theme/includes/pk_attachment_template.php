
<!-- pk start page -->
<div id="pk_page" class="pk_full_width">

<!-- pk start left shadow -->
<span class="pk_left_shadow"></span>
<!-- pk end left shadow -->

<!-- pk start right shadow -->
<span class="pk_right_shadow"></span>
<!-- pk end right shadow -->

<!-- pk start center box -->
<div class="pk_center_box">

<!-- pk start inner -->
<div class="pk_inner">
<?php
	if (have_posts()) : 
		
		while (have_posts()) : 
			
			the_post();
			
			if (!empty($post -> post_parent)) : 
?>

<!-- pk start back to post link -->
<p><a href="<?php echo get_permalink($post -> post_parent); ?>" title="<?php esc_attr(printf(__('Return to %s', 'pk_text_domain_front'), get_the_title($post -> post_parent))); ?>" rel="gallery"><?php printf(__('<span class="pk_meta_links">&laquo;</span> %s', 'pk_text_domain_front'), get_the_title($post -> post_parent)); ?></a></p>
<!-- pk end back to post link -->

<?php
			endif;
?>
<!-- pk start entry -->
<div id="post-<?php the_ID(); ?>" class="pk_entry">

<!-- pk start attachment title -->
<h4 class="pk_entry_title"><?php the_title(); ?></h4>
<!-- pk end attachment title -->

<!-- pk start attachment meta -->
<div class="pk_entry_meta">
	<p><?php _e('By:', 'pk_text_domain_front'); ?> <?php the_author_posts_link(); ?><span class="pk_meta_divider">|</span><?php echo get_the_date('d F, Y'); ?><span class="pk_meta_divider">|</span><?php if (wp_attachment_is_image()) : $metadata = wp_get_attachment_metadata(); printf(__('Full size: %s', 'pk_text_domain_front'), sprintf('<a href="%1$s" title="%2$s" rel="prettyPhoto[attachment]">%3$s &times; %4$s</a>', wp_get_attachment_url(), esc_attr(__('View full size image', 'pk_text_domain_front')), $metadata['width'], $metadata['height'])); endif; ?></p>
</div>
<!-- pk end attachment meta -->

<!-- pk start entry text -->
<div class="pk_entry_text">

<!-- pk start entry attachment -->
<div class="pk_entry_attachment">

<?php
			if (wp_attachment_is_image()) : 
			
				$attachments = array_values(get_children(array('post_parent' => $post->post_parent, 'post_status' => 'inherit', 'post_type' => 'attachment', 'post_mime_type' => 'image', 'order' => 'ASC', 'orderby' => 'menu_order ID')));
				
				foreach ($attachments as $k => $attachment) {
					
					if ($attachment -> ID == $post -> ID) break;
					
				}
				
				$k++;
				
				if (count($attachments) > 1) {
					
					if (isset($attachments[$k])) {
					
						$next_attachment_url = get_attachment_link($attachments[$k] -> ID);
						
					} else {
					
						$next_attachment_url = get_attachment_link($attachments[0] -> ID);
						
					}
						
				} else {
					
					$next_attachment_url = wp_get_attachment_url();
					
				}
?>
<!-- pk start attachment -->
<p class="pk_attachment_entry"><a href="<?php echo $next_attachment_url; ?>" title="<?php echo esc_attr(get_the_title()); ?>" rel="attachment"><?php
	$attachment_width  = apply_filters('pk_attachment_size', $content_width);
	$attachment_height = apply_filters('pk_attachment_height', $content_width);
	echo wp_get_attachment_image($post -> ID, array((int)$attachment_width - 12, (int)$attachment_height - 12));
?></a></p>
<!-- pk end attachment -->

<!-- pk start attachment navigation -->	
<div class="pk_attachments_navigation">
	<div class="pk_prev_atachment"><?php previous_image_link(false, __('&laquo; Prev', 'pk_text_domain_front')); ?></div>
	<div class="pk_next_atachment"><?php next_image_link(false, __('Next &raquo;', 'pk_text_domain_front')); ?></div>
</div>
<!-- pk end attachment navigation -->
<?php
			else :
?>
<!-- pk start attachment -->
<a href="<?php echo wp_get_attachment_url(); ?>" title="<?php echo esc_attr(get_the_title()); ?>" rel="attachment"><?php echo basename(get_permalink()); ?></a>
<!-- pk end attachment -->
<?php
			endif;
?>

</div>
<!-- pk end entry attachment -->

<!-- pk start attachment caption -->		
<div class="pk_attachment_caption">
<?php
			(!empty($post -> post_content)) ? the_content() : the_excerpt();
?>
</div>
<!-- pk end attachment caption -->

</div>
<!-- pk end entry text -->

</div>
<!-- pk end entry -->
<?php
			comments_template();
			
		endwhile;
		
	endif;
	
?>

</div>
<!-- pk end inner -->

</div>
<!-- pk center box -->

<?php get_footer(); ?>