<?php

function pk_title() {
	
	$separator = stripslashes(pk_get_options('pk_general_options', 'general_titles_separator'));
	
	if ($separator == '') {
		
		$separator = '|';
		
	}
	
	wp_title($separator, true, 'right');
	
	if (!is_404()) {
		
		if ((int)get_query_var('paged') > 1) { 
		
			echo __('Page', 'pk_text_domain').' '.get_query_var('paged').' '.$separator.' ';
			
		}
		
		if ((int)get_query_var('page') > 1) { 
		
			echo __('Page', 'pk_text_domain').' '.get_query_var('page').' '.$separator.' ';
			
		}
		
		global $cpage;
		
		if ($cpage >= 1) { 
		
			echo __('Comments Page', 'pk_text_domain').' '.$cpage.' '.$separator.' ';
			
		}
		
	}
	
	bloginfo('name');
	
}

function pk_get_logo() {
	
	global $pk_skin_profile;
	
?>
<style type="text/css">

	.pk_logo, .pk_logo a { width:<?php echo pk_get_options('pk_skin_options', 'logo_width', $pk_skin_profile); ?>px; height:<?php echo pk_get_options('pk_skin_options', 'logo_height', $pk_skin_profile); ?>px; }
	.pk_logo{ background:transparent url("<?php echo stripslashes(pk_get_options('pk_skin_options', 'logo', $pk_skin_profile)); ?>") no-repeat 0px 0px; }
	
</style>	
<?php
	
}

function pk_specific_js_vars() {
	
	global $post;
	
	echo '
<script type="text/javascript">
	/*<![CDATA[*/
	
	var ajaxurl = "'.admin_url('admin-ajax.php').'";
	';
	
	echo '
	/*]]>*/
</script>
';
	
}

function pk_header() {
	
	echo '
<!-- pk start header -->
<header>

<!-- pk start header center box -->
<div class="pk_center_box">

<hgroup>
	<h1 class="pk_logo"><a href="'.home_url().'" title="'.__('Home', 'pk_text_domain').'">'.__('Home', 'pk_text_domain').'</a></h1>
	<h2>'.get_bloginfo('description').'</h2>
</hgroup>

<!-- pk start navigation wrapper -->
<div class="pk_navigation_wrapper">

<!-- pk start navigation -->
';
	
	if (function_exists('wp_nav_menu')) {
		
		wp_nav_menu(array('theme_location' => 'pk_main_menu', 'container' => 'nav', 'fallback_cb' => 'pk_page_menu_main', 'walker' => new PK_Walker_Nav_Menu()));
		
	} else {
		
		pk_page_menu_main();
		
	}
	
	echo '
<!-- pk end navigation -->

</div>
<!-- pk end navigation wrapper -->

</div>
<!-- pk end header center box -->

</header>
<!-- pk end header -->
';
	
}

function pk_page_menu_main() {
	
	$main_navigation_exclude_pages = pk_get_options('pk_navigation_options', 'main_navigation_exclude_pages');
	
	echo str_replace(array('<div class="menu">', '<li >', '</div>'), array('<nav>', '<li>', '</nav>'), wp_page_menu(array('echo' => false, 'depth' => 0, 'show_home' => false, 'exclude' => $main_navigation_exclude_pages)));
	
}

class PK_Walker_Nav_Menu extends Walker_Nav_Menu {
	
	function start_el(&$output, $item, $depth, $args) {
		
		global $wp_query;
		
		$indent = ($depth) ? str_repeat("\t", $depth) : '';
		
		$class_names = $value = '';

		$classes = empty($item -> classes) ? array() : (array)$item -> classes;
		$classes[] = 'menu-item-'.$item -> ID;
		
		$class_names = join(' ', apply_filters('nav_menu_css_class', array_filter($classes), $item, $args));
		$class_names = ' class="'.esc_attr($class_names).'"';
		
		$id = apply_filters('nav_menu_item_id', 'menu-item-'. $item -> ID, $item, $args);
		$id = strlen($id) ? ' id="'.esc_attr($id).'"' : '';
		
		$output .= $indent.'<li'.$id.$value.'>';

		$attributes = ! empty($item -> attr_title) ? ' title="'.esc_attr($item -> attr_title).'"' : '';
		$attributes .= ! empty($item -> target) ? ' target="'.esc_attr($item -> target).'"' : '';
		$attributes .= ! empty($item -> xfn) ? ' rel="'.esc_attr($item -> xfn).'"' : '';
		$attributes .= ! empty($item -> url) ? ' href="'.esc_attr($item -> url).'"' : '';

		$item_output = $args -> before;
		$item_output .= '<a'.$class_names.$attributes.'>';
		$item_output .= $args -> link_before.apply_filters('the_title', $item -> title, $item -> ID).$args -> link_after;
		$item_output .= '</a>';
		$item_output .= $args -> after;

		$output .= apply_filters('walker_nav_menu_start_el', $item_output, $item, $depth, $args);
		
	}
	
}

?>