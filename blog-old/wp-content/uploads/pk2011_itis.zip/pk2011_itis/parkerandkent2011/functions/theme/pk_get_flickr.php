<?php

require_once(PK_THEME_LIBS.'/phpFlickr/phpFlickr.php');

global $pk_flickr_api_init;
global $pk_flickr_api_key;
global $pk_flickr_api_secret;

global $pk_flickr_user_id;
global $pk_flickr_group_id;
global $pk_flickr_user_tags;
global $pk_flickr_per_page;
global $pk_flickr_page;
global $pk_flickr_photoset_id;
global $pk_flickr_gallery_id;

global $pk_flickr_services;

function pk_flickr_init() {
	
	global $pk_flickr_api_init;
	global $pk_flickr_api_key;
	global $pk_flickr_api_secret;
	global $pk_flickr_user_id;
	global $pk_flickr_services;
	
	if ($pk_flickr_api_init == true) return;
	
	$pk_flickr_api_key = pk_get_options('pk_general_options', 'general_flickr_api_key');
	$pk_flickr_api_secret = pk_get_options('pk_general_options', 'general_flickr_api_secret');
	$pk_flickr_user_id = pk_get_options('pk_general_options', 'general_flickr_user_id');
	
	$pk_flickr_services= new phpFlickr($pk_flickr_api_key, $pk_flickr_api_secret);
	$pk_flickr_services -> enableCache('db', 'mysql://'.DB_USER.':'.DB_PASSWORD.'@'.DB_HOST.'/'.DB_NAME);
	
	$pk_flickr_api_init = true;
	
}

function pk_flickr_get_recent_photos() {
	
	global $pk_flickr_user_id;
	global $pk_flickr_group_id;
	global $pk_flickr_per_page;
	global $pk_flickr_page;
	global $pk_flickr_services;

	$pk_flickr_data = $pk_flickr_services -> photos_search(array('user_id' => $pk_flickr_user_id, 'group_id' => $pk_flickr_group_id, 'extras' => 'description, date_taken, owner_name, tags, o_dims, views, path_alias, url_sq, url_t, url_s, url_m, url_z, url_l, url_o', 'per_page' => $pk_flickr_per_page, 'page' => $pk_flickr_page, 'sort' => 'date-posted-desc'));
	
	return $pk_flickr_data;

}

function pk_flickr_get_favorites_photos() {
	
	global $pk_flickr_user_id;
	global $pk_flickr_services;
	global $pk_flickr_per_page;
	global $pk_flickr_page;

	$pk_flickr_data = $pk_flickr_services -> favorites_getPublicList($pk_flickr_user_id, NULL, NULL, NULL, 'description, date_taken, owner_name, tags, o_dims, views, path_alias, url_sq, url_t, url_s, url_m, url_z, url_l, url_o', $pk_flickr_per_page, $pk_flickr_page);
	
	return $pk_flickr_data;

}

function pk_flickr_get_tagged_photos() {
	
	global $pk_flickr_user_id;
	global $pk_flickr_group_id;
	global $pk_flickr_user_tags;
	global $pk_flickr_per_page;
	global $pk_flickr_page;
	global $pk_flickr_services;

	$pk_flickr_data = $pk_flickr_services -> photos_search(array('user_id' => $pk_flickr_user_id, 'group_id' => $pk_flickr_group_id, 'extras' => 'description, date_taken, owner_name, tags, o_dims, views, path_alias, url_sq, url_t, url_s, url_m, url_z, url_l, url_o', 'per_page' => $pk_flickr_per_page, 'page' => $pk_flickr_page, 'tags' => $pk_flickr_user_tags));
	
	return $pk_flickr_data;

}

function pk_flickr_get_photosets_photos() {
	
	global $pk_flickr_per_page;
	global $pk_flickr_page;
	global $pk_flickr_photoset_id;
	global $pk_flickr_services;
	
	$pk_flickr_data = $pk_flickr_services -> photosets_getPhotos($pk_flickr_photoset_id, 'description, date_taken, owner_name, tags, o_dims, views, path_alias, url_sq, url_t, url_s, url_m, url_z, url_l, url_o', NULL, $pk_flickr_per_page, $pk_flickr_page, 'photos');
	
	return $pk_flickr_data;

}

function pk_flickr_get_galleries_photos() {
	
	global $pk_flickr_per_page;
	global $pk_flickr_page;
	global $pk_flickr_gallery_id;
	global $pk_flickr_services;

	$pk_flickr_data = $pk_flickr_services -> galleries_getPhotos($pk_flickr_gallery_id, 'description, date_taken, owner_name, tags, o_dims, views, path_alias, url_sq, url_t, url_s, url_m, url_z, url_l, url_o', $pk_flickr_per_page, $pk_flickr_page);
	
	return $pk_flickr_data;

}

function pk_flickr_get_photosets() {
	
	global $pk_flickr_services;
	global $pk_flickr_user_id;
	
	$pk_flickr_data = $pk_flickr_services -> photosets_getList($pk_flickr_user_id);
	
	return $pk_flickr_data;

}

function pk_flickr_get_galleries() {
	
	global $pk_flickr_services;
	global $pk_flickr_user_id;

	$pk_flickr_data = $pk_flickr_services -> galleries_getList($pk_flickr_user_id);
	
	return $pk_flickr_data;

}

function pk_ajax_load_flickr_user_photos() {
	
	pk_flickr_init();
	
	global $pk_flickr_user_id;
	
	$suffix = $_POST['suffix'];
	$post_id = $_POST['post_id'];
	$flickr_user_id = $_POST['flickr_user_id'];
	
	$selected_set = '';
	$selected_gallery = '';
	
	if (isset($post_id) && isset($suffix)) {
		
		$post_custom_meta = get_post_meta($post_id, '_pk_meta', true);
		
		$selected_set = (isset($post_custom_meta[$suffix.'_select_set'])) ? $post_custom_meta[$suffix.'_select_set'] : '';
		$selected_gallery = (isset($post_custom_meta[$suffix.'_select_galleries'])) ? $post_custom_meta[$suffix.'_select_galleries'] : '';
		
	}
	
	if (isset($flickr_user_id)) {
		
		$pk_flickr_user_id = $flickr_user_id;
		
		$photosets_array = pk_flickr_get_photosets();
		$photosets_array_values = array('');
		$photosets_array_labels = array(__('-- Select --', 'pk_text_domain'));
		
		for ($i = 0; $i < count($photosets_array['photoset']); $i++) {
			
			$photosets_array_values[] = $photosets_array['photoset'][$i]['id'];
			$photosets_array_labels[] = $photosets_array['photoset'][$i]['title'].' ('.$photosets_array['photoset'][$i]['photos'].')';
			
		}
		
		$galleries_array = pk_flickr_get_galleries();
		$galleries_array_values = array('');
		$galleries_array_labels = array(__('-- Select --', 'pk_text_domain'));
		
		for ($i = 0; $i < count($galleries_array['galleries']['gallery']); $i++) {
			
			$galleries_array_values[] = $galleries_array['galleries']['gallery'][$i]['id'];
			$galleries_array_labels[] = $galleries_array['galleries']['gallery'][$i]['title'].' ('.$galleries_array['galleries']['gallery'][$i]['count_photos'].')';
			
		}
		
		if (is_array($photosets_array) && is_array($galleries_array)) {
		
			echo 'success[pk_data_sep]'.implode('[pk_sep]', $photosets_array_values).'[pk_data_sep]'.implode('[pk_sep]', $photosets_array_labels).'[pk_data_sep]'.implode('[pk_sep]', $galleries_array_values).'[pk_data_sep]'.implode('[pk_sep]', $galleries_array_labels).'[pk_data_sep]'.$selected_set.'[pk_data_sep]'.$selected_gallery;
			
		} else {
			
			echo 'error';
			
		}
		
	} else {
		
		echo 'error';
		
	}
	
	die();
	
}

add_action('wp_ajax_load_flickr_user_photos', 'pk_ajax_load_flickr_user_photos');
add_action('wp_ajax_nopriv_load_flickr_user_photos', 'pk_ajax_load_flickr_user_photos');

/*
 * Cache management
*/

add_option('pk_special_flickr_gallery_transients', array());

function pk_delete_special_flickr_gallery_transients() {
	
	$transients = get_option('pk_special_flickr_gallery_transients');
	
	foreach ($transients as $transient) {
		
		delete_transient($transient);
		
	}
	
}
	
add_action('publish_post', 'pk_delete_special_flickr_gallery_transients');
add_action('save_post', 'pk_delete_special_flickr_gallery_transients');
add_action('edit_post', 'pk_delete_special_flickr_gallery_transients');
add_action('delete_post', 'pk_delete_special_flickr_gallery_transients');
add_action('pk_ah_save_text_widget', 'pk_delete_special_flickr_gallery_transients');
add_action('pk_ah_options_updated', 'pk_delete_special_flickr_gallery_transients');
add_action('pk_ah_posts_sorted', 'pk_delete_special_flickr_gallery_transients');

add_option('pk_flickr_grid_gallery_page_transients', array());

function pk_delete_flickr_grid_gallery_page_transients() {
	
	$transients = get_option('pk_flickr_grid_gallery_page_transients');
	
	foreach ($transients as $transient) {
		
		delete_transient($transient);
		
	}
	
}
	
add_action('publish_post', 'pk_delete_flickr_grid_gallery_page_transients');
add_action('save_post', 'pk_delete_flickr_grid_gallery_page_transients');
add_action('edit_post', 'pk_delete_flickr_grid_gallery_page_transients');
add_action('delete_post', 'pk_delete_flickr_grid_gallery_page_transients');
add_action('pk_ah_save_text_widget', 'pk_delete_flickr_grid_gallery_page_transients');
add_action('pk_ah_options_updated', 'pk_delete_flickr_grid_gallery_page_transients');
add_action('pk_ah_posts_sorted', 'pk_delete_flickr_grid_gallery_page_transients');

?>