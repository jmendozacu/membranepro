<?php

class PK_Widget_Contact_Form extends WP_Widget {
	
	function PK_Widget_Contact_Form() {
		
		$widget_ops = array('classname' => 'widget_contact_form', 'description' => __('Displays a contact form', 'pk_text_domain'));
		$this -> WP_Widget('pk-contact-form', __('Contact Form', 'pk_text_domain'), $widget_ops);
		
	}
	
	function widget($args, $instance) {
		
		extract($args);
		
		$title = apply_filters('widget_title', $instance['title']);
		$send_to = isset($instance['send_to']) ? $instance['send_to'] : get_option('admin_email');
		$name_label = isset($instance['name_label']) ? $instance['name_label'] : __('Message', 'pk_text_domain_front');
		$email_label = isset($instance['email_label']) ? $instance['email_label'] : __('Message', 'pk_text_domain_front');
		$message_label = isset($instance['message_label']) ? $instance['message_label'] : __('Message', 'pk_text_domain_front');
		$subject = isset($instance['subject']) ? $instance['subject'] : '%sitename%: email from %name%';
		
		if (empty($title)) $title = false;
		
		echo '<!-- pk start pk-contact-form widget -->
'.$before_widget.'
';
		
		if ($title) {
			
			echo $before_title;
			echo $title;
			echo $after_title;
			
		}
		
		echo do_shortcode('[pk_contact_form send_to="'.$send_to.'" name_label="'.$name_label.'" email_label="'.$email_label.'" message_label="'.$message_label.'" subject="'.$subject.'"]');
		
		echo $after_widget.'
<!-- pk end pk-contact-form widget -->

';
			
	}
	
	function update($new_instance, $old_instance) {
		
		$instance = $old_instance;
		
		$instance['title'] = strip_tags($new_instance['title']);
		$instance['send_to'] = strip_tags($new_instance['send_to']);
		$instance['name_label'] = strip_tags($new_instance['name_label']);
		$instance['email_label'] = strip_tags($new_instance['email_label']);
		$instance['message_label'] = strip_tags($new_instance['message_label']);
		$instance['subject'] = strip_tags($new_instance['subject']);
		
		return $instance;
		
	}
	
	function form($instance) {
		
		$title = isset($instance['title']) ? esc_attr($instance['title']) : '';
		$send_to = isset($instance['send_to']) ? $instance['send_to'] : get_option('admin_email');
		$name_label = isset($instance['name_label']) ? $instance['name_label'] : __('Name', 'pk_text_domain_front');
		$email_label = isset($instance['email_label']) ? $instance['email_label'] : __('Email', 'pk_text_domain_front');
		$message_label = isset($instance['message_label']) ? $instance['message_label'] : __('Message', 'pk_text_domain_front');
		$subject = isset($instance['subject']) ? $instance['subject'] : '%sitename%: email from %name%';
?>
		<p><label for="<?php echo $this -> get_field_id('title'); ?>"><?php _e('Title:', 'pk_text_domain'); ?></label>
		<input class="widefat" id="<?php echo $this -> get_field_id('title'); ?>" name="<?php echo $this -> get_field_name('title'); ?>" type="text" value="<?php echo $title; ?>" /></p>
		
		<p><label for="<?php echo $this -> get_field_id('send_to'); ?>"><?php _e('Admin email:', 'pk_text_domain'); ?></label>
		<input class="widefat" id="<?php echo $this -> get_field_id('send_to'); ?>" name="<?php echo $this -> get_field_name('send_to'); ?>" type="text" value="<?php echo $send_to; ?>" /></p>
		
		<p><label for="<?php echo $this -> get_field_id('name_label'); ?>"><?php _e('Name field label:', 'pk_text_domain'); ?></label>
		<input class="widefat" id="<?php echo $this -> get_field_id('name_label'); ?>" name="<?php echo $this -> get_field_name('name_label'); ?>" type="text" value="<?php echo $name_label; ?>" /></p>
		
		<p><label for="<?php echo $this -> get_field_id('email_label'); ?>"><?php _e('Email field label:', 'pk_text_domain'); ?></label>
		<input class="widefat" id="<?php echo $this -> get_field_id('email_label'); ?>" name="<?php echo $this -> get_field_name('email_label'); ?>" type="text" value="<?php echo $email_label; ?>" /></p>
		
		<p><label for="<?php echo $this -> get_field_id('message_label'); ?>"><?php _e('Message field label:', 'pk_text_domain'); ?></label>
		<input class="widefat" id="<?php echo $this -> get_field_id('message_label'); ?>" name="<?php echo $this -> get_field_name('message_label'); ?>" type="text" value="<?php echo $message_label; ?>" /></p>
		
		<p><label for="<?php echo $this -> get_field_id('subject'); ?>"><?php _e('Email subject:', 'pk_text_domain'); ?></label>
		<input class="widefat" id="<?php echo $this -> get_field_id('subject'); ?>" name="<?php echo $this -> get_field_name('subject'); ?>" type="text" value="<?php echo $subject; ?>" />
		<br /><small><?php _e('Enter a subject for the contact form. You can use the following placeholders: %name% for the sender name, %sitename% for your site name.' ,'pk_text_domain'); ?></small></p>
<?php
	}
	
}

function pk_widgets_contact_form() {
	
	register_widget('PK_Widget_Contact_Form');
	
}

add_action('widgets_init', 'pk_widgets_contact_form');

?>