<?php

/*
 * Table
*/

function pk_sc_table($atts, $content = null) {
	
	extract(shortcode_atts(array(
		'width' => '',
		'align' => 'left',
		'hover' => 'false'
	), $atts));
	
	($width != '' && $width != '0') ? $width = ' style="width:'.$width.'px;"' : $width = ' style="width:100%;"';
	
	($hover == 'true') ? $hover = ' pk_table_hover' : $hover = '';
	
	return '<div class="pk_table_wrapper pk_align'.$align.'"'.$width.'><div class="pk_table'.$hover.'">'.do_shortcode($content).'</div></div>';
	
}

add_shortcode('pk_table', 'pk_sc_table');

?>