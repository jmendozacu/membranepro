<?php

function pk_get_lightbox_gallery() {
	
	$page_meta = pk_get_meta();
	
	$lightbox_gallery = (isset($page_meta['lightbox_gallery'])) ? $page_meta['lightbox_gallery'] : '';
	
	$lightbox_gallery = explode('[pk_data_sep]', $lightbox_gallery);
		
	$lightbox_gallery_data = explode('[pk_sep]', $lightbox_gallery[0]);
	
	if (isset($lightbox_gallery[1]) && $lightbox_gallery[1]) {
		
		$lightbox_gallery_items = explode('[pk_items_sep]', $lightbox_gallery[1]);
		
	} else {
		
		$lightbox_gallery_items = '';
		
	}
	
	if (is_array($lightbox_gallery_items)) {
		
?>

<!-- pk start lightbox gallery -->
<div class="pk_lightbox_gallery pk_invisible">
<?php
		
		for ($i = 0; $i < count($lightbox_gallery_items); $i++) {
			
			$item = explode('[pk_sep]', $lightbox_gallery_items[$i]);
			
?>
	<a href="<?php echo esc_url($item[1]); ?>" title="<?php echo strip_tags($item[0]); ?>" rel="prettyPhoto[<?php echo $lightbox_gallery_data[4]; ?>]"></a>
<?php
			
		}
		
?>
	<script type="text/javascript">
		/*<![CDATA[*/
		jQuery(document).ready(function() {
			jQuery("a[rel^='prettyPhoto[<?php echo $lightbox_gallery_data[4]; ?>]']").prettyPhoto({
				default_width:<?php echo $lightbox_gallery_data[0]; ?>,
				default_height:<?php echo $lightbox_gallery_data[1]; ?>,
				autoplay_slideshow:<?php echo ($lightbox_gallery_data[2] != 'false') ? 'true' : 'false'; ?>,
				slideshow:<?php echo (int)$lightbox_gallery_data[3] * 1000; ?>
			});
		});
		/*]]>*/
	</script>
</div>
<!-- pk end lightbox gallery -->
<?php
	
	}
	
}

?>