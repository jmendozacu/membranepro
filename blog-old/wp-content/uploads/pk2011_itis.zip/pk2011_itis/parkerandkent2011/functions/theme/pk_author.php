<?php

function pk_author() {
	
	global $pk_show_author_info;
	
	if ($pk_show_author_info == 'false') {
		
		return;
		
	}
	
?>

<!-- pk start author info box -->
<div id="pk_author_<?php the_author_meta('ID'); ?>" class="pk_basic_box_normal">
	<div class="pk_basic_box_content_wrapper">
		<div class="pk_basic_box_content">
			<div class="pk_one_sixth">
				<div class="pk_image pk_alignleft">
					<div class="pk_image_wrapper">
						<?php
	echo get_avatar(get_the_author_meta('ID'), '52');
?>

					</div>
				</div>
			</div>
			<div class="pk_five_sixth pk_last">
				<h5><?php the_author_meta('display_name'); ?></h5>
				<p class="pk_clear_margin"><?php the_author_meta('description'); ?></p>
			</div>
		</div>
	</div>
</div>
<!-- pk end author info box -->
<?php
	
}

?>