<?php

/*
 * Google Maps
*/

function pk_scp_google_maps($atts, $content = null) {
	
	extract(shortcode_atts(array(
		'title' => '',
		'map_height' => '400',
		'map_url' => 'http://maps.google.com/maps?f=q&source=s_q&hl=it&geocode=&q=Milan&aq=&sll=37.0625,-95.677068&sspn=66.915969,120.673828&ie=UTF8&hq=&hnear=Milano,+Lombardia,+Italia&z=12'
	), $atts));
	
	$map_url = esc_url($map_url);
	
	$output = '
<!-- pk start Google Maps widget -->
<div class="pk_scp_google_maps">';
	
	if ($title != '') $output .= '
	<h4>'.$title.'</h4>';
	
	$output .= '
	<iframe src="'.str_replace('#038;', '&amp;', $map_url).'&amp;output=embed" style="width:100%; height:'.$map_height.'px;"></iframe>
</div>
<!-- pk end Google Maps widget -->
';
	
	return $output;
	
}

add_shortcode('pk_google_maps', 'pk_scp_google_maps');

?>