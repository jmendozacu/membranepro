<?php

/*
 * YouTube player
*/

static $pk_youtube_counter = 0;

function pk_scp_youtube_player($atts, $content = null) {
	
	global $pk_skin_profile;
	
	$pk_player_options = pk_get_options('pk_skin_options', '', $pk_skin_profile);
	
	extract(shortcode_atts(array(
		'padding' => '12',
		'width' => '',
		'height' => '',
		'align' => 'none',
		'autoplay' => 'false',
		'cover' => '',
		'video_id' => ''
	), $atts));
	
	$hp = 0;
	
	if ($width != '' && $width != '0' && $height != '' && $height != '0') $hp = floor((int)$padding * ((int)$height / (int)$width));
	
	if ($width != '' && $width != '0') (int)$width -= (int)$padding;
	if ($height != '' && $height != '0') (int)$height -= $hp;
	
	global $pk_youtube_counter;
	
	$pk_youtube_counter++;
	
	if ($cover != '') {
		
		$cover_no_player = '<a href="http://www.youtube.com/watch?v='.$video_id.'" title="'.__('Watch video', 'pk_text_domain_front').'"><img src="'.pk_build_image($cover, (int)$width, (int)$height, 1).'" alt="'.__('Watch video', 'pk_text_domain_front').'" /></a>';
		
	} else {
		
		$cover_no_player = '<a href="http://www.youtube.com/watch?v='.$video_id.'" title="'.__('Watch video', 'pk_text_domain_front').'">'.__('Watch video', 'pk_text_domain_front').'</a>';
		
	}
	
	($autoplay == 'true') ? $autoplay = '1' : $autoplay = '0';
	
	return '
<!-- pk start YouTube player -->
<div class="pk_video'.(($align != '') ? ' pk_align'.strtolower($align) : '').'"'.((($width == '' || $width == '0') && ($height == '' || $height == '0')) ? '' : ' style="width:'.($width + (int)$padding).'px; height:'.($height + $hp).'px;"').'>
	<div class="pk_video_wrapper'.(((int)$padding == 0) ? '_no_padding' : '').'"'.((($width == '' || $width == '0') && ($height == '' || $height == '0')) ? '' : ' style="width:'.$width.'px; height:'.$height.'px;"').'>
		<div id="pk_youtube_'.$pk_youtube_counter.'" class="pk_fit">'.$cover_no_player.'</div>
	</div>
	<script type="text/javascript">
		/*<![CDATA[*/
		var flashvars = {};
		var params = {
			allowfullscreen:"true",
			allowscriptaccess:"always",
			wmode:"transparent"
		};
		var attributes = {};
		swfobject.embedSWF("http://www.youtube.com/v/'.$video_id.'?autoplay='.$autoplay.'&amp;fs=1&amp;showinfo=0&amp;rel=0&amp;iv_load_policy=0&amp;autohide=1", "pk_youtube_'.$pk_youtube_counter.'", "100%", "100%", "9.0.0", null, flashvars, params, attributes);
		/*]]>*/
	</script>
</div>
<!-- pk end YouTube player -->
';
	
}

add_shortcode('pk_youtube_player', 'pk_scp_youtube_player');

/*
 * Vimeo player
*/

static $pk_vimeo_counter = 0;

function pk_scp_vimeo_player($atts, $content = null) {
	
	global $pk_skin_profile;
	
	$pk_player_options = pk_get_options('pk_skin_options', '', $pk_skin_profile);
	
	extract(shortcode_atts(array(
		'padding' => '12',
		'width' => '',
		'height' => '',
		'align' => 'none',
		'autoplay' => 'false',
		'cover' => '',
		'video_id' => ''
	), $atts));
	
	$hp = 0;
	
	if ($width != '' && $width != '0' && $height != '' && $height != '0') $hp = floor((int)$padding * ((int)$height / (int)$width));
	
	if ($width != '' && $width != '0') (int)$width -= (int)$padding;
	if ($height != '' && $height != '0') (int)$height -= $hp;
	
	global $pk_vimeo_counter;
	
	$pk_vimeo_counter++;
	
	if ($cover != '') {
		
		$cover_no_player = '<a href="http://www.vimeo.com/'.$video_id.'" title="'.__('Watch video', 'pk_text_domain_front').'"><img src="'.pk_build_image($cover, (int)$width, (int)$height, 1).'" alt="'.__('Watch video', 'pk_text_domain_front').'" /></a>';
		
	} else {
		
		$cover_no_player = '<a href="http://www.vimeo.com/'.$video_id.'" title="'.__('Watch video', 'pk_text_domain_front').'">'.__('Watch video', 'pk_text_domain_front').'</a>';
		
	}
	
	($autoplay == 'true') ? $autoplay = '1' : $autoplay = '0';
	
	return '
<!-- pk start Vimeo player -->
<div class="pk_video'.(($align != '') ? ' pk_align'.strtolower($align) : '').'"'.((($width == '' || $width == '0') && ($height == '' || $height == '0')) ? '' : ' style="width:'.($width + (int)$padding).'px; height:'.($height + $hp).'px;"').'>
	<div class="pk_video_wrapper'.(((int)$padding == 0) ? '_no_padding' : '').'"'.((($width == '' || $width == '0') && ($height == '' || $height == '0')) ? '' : ' style="width:'.$width.'px; height:'.$height.'px;"').'>
		<div id="pk_vimeo_'.$pk_vimeo_counter.'" class="pk_fit">'.$cover_no_player.'</div>
	</div>
	<script type="text/javascript">
		/*<![CDATA[*/
		var flashvars = {};
		var params = {
			allowfullscreen:"true",
			allowscriptaccess:"always",
			wmode:"transparent"
		};
		var attributes = {};
		swfobject.embedSWF("http://www.vimeo.com/moogaloop.swf?clip_id='.$video_id.'&amp;autoplay='.$autoplay.'&amp;title=0&amp;byline=0&amp;portrait=0", "pk_vimeo_'.$pk_vimeo_counter.'", "100%", "100%", "9.0.0", null, flashvars, params, attributes);
		/*]]>*/
	</script>
</div>
<!-- pk end Vimeo player -->
';
	
}

add_shortcode('pk_vimeo_player', 'pk_scp_vimeo_player');

/*
 * Html5 video player
*/

static $pk_html5_counter = 0;

function pk_scp_html5_player($atts, $content = null) {
	
	global $pk_skin_profile;
	
	$pk_player_options = pk_get_options('pk_skin_options', '', $pk_skin_profile);
	
	extract(shortcode_atts(array(
		'padding' => '12',
		'width' => '',
		'height' => '',
		'align' => 'none',
		'autoplay' => 'false',
		'cover' => '',
		'mp4' => '',
		'webm' => '',
		'ogg' => ''
	), $atts));
	
	$hp = 0;
	
	if ($width != '' && $width != '0' && $height != '' && $height != '0') $hp = floor((int)$padding * ((int)$height / (int)$width));
	
	if ($width != '' && $width != '0') (int)$width -= (int)$padding;
	if ($height != '' && $height != '0') (int)$height -= $hp;
	
	global $pk_html5_counter;
	
	$pk_html5_counter++;
	
	($autoplay == 'true') ? $autoplay_string = 'autoplay controls preload="auto"' : $autoplay_string = 'controls preload="auto"';
	
	return '
<!-- pk start html5 player -->
<div class="pk_video'.(($align != '') ? ' pk_align'.strtolower($align) : '').'"'.((($width == '' || $width == '0') && ($height == '' || $height == '0')) ? '' : ' style="width:'.($width + (int)$padding).'px; height:'.($height + $hp).'px;"').'>
	<div class="pk_video_wrapper'.(((int)$padding == 0) ? '_no_padding' : '').'"'.((($width == '' || $width == '0') && ($height == '' || $height == '0')) ? '' : ' style="width:'.$width.'px; height:'.$height.'px;"').'>
		<div id="pk_html5_'.$pk_html5_counter.'" class="pk_fit">
			<video width="'.(($width == '') ? '100%' : $width).'" height="'.(($height == '') ? '100%' : $height).'"'.(($cover != '') ? ' poster="'.pk_build_image($cover, (int)$width, (int)$height, 1).'"' : '').' '.$autoplay_string.'>
				<source src="'.esc_url($mp4).'" type="video/mp4" />
				<source src="'.esc_url($webm).'" type="video/webm" />
				<source src="'.esc_url($ogg).'" type="video/ogg" />
			</video>
		</div>
	</div>
	<script type="text/javascript">
		/*<![CDATA[*/
		var v = document.createElement("video");
		if (!v.play) {
			var flashvars = {
				file_url:"'.esc_url($mp4).'",
				auto_play:"'.$autoplay.'",
				cover_url:"'.esc_url($cover).'",
				small_cover_url:"'.urlencode(pk_build_image($cover, (int)$width, (int)$height, 1)).'",
				background_color:"'.$pk_player_options['custom_player_c1'].'",
				buttons_color:"'.$pk_player_options['custom_player_c2'].'",
				time_label_color:"'.$pk_player_options['custom_player_c3'].'",
				controls_background_color:"'.$pk_player_options['custom_player_c4'].'",
				progress_bar_color:"'.$pk_player_options['custom_player_c5'].'",
				progress_bar_background_color:"'.$pk_player_options['custom_player_c6'].'",
				loading_bar_color:"'.$pk_player_options['custom_player_c7'].'",
				volume_bar_color:"'.$pk_player_options['custom_player_c8'].'",
				volume_bar_background_color:"'.$pk_player_options['custom_player_c9'].'",
				spectrum_color:"'.$pk_player_options['custom_player_c10'].'"};
			var params = {
				scale:"noScale",
				salign:"lt",
				menu:"false",
				allowScriptAccess:"always",
				allowFullScreen:"true",
				wmode:"transparent"};
			var attributes = {};
			swfobject.embedSWF("'.PK_THEME_DIR.'/parkerandkent2011/flash/theme/itis_video_player.swf", "pk_html5_'.$pk_html5_counter.'", "100%", "100%", "9.0.0", null, flashvars, params, attributes);
		}
		/*]]>*/
	</script>
</div>
<!-- pk end html5 player -->
';
	
}

add_shortcode('pk_html5_player', 'pk_scp_html5_player');

/*
 * YouTube custom player
*/

static $pk_youtube_custom_counter = 0;

function pk_scp_youtube_custom_player($atts, $content = null) {
	
	global $pk_skin_profile;
	
	$pk_player_options = pk_get_options('pk_skin_options', '', $pk_skin_profile);
	
	extract(shortcode_atts(array(
		'padding' => '12',
		'width' => '',
		'height' => '',
		'align' => 'none',
		'autoplay' => 'false',
		'cover' => '',
		'video_id' => ''
	), $atts));
	
	$hp = 0;
	
	if ($width != '' && $width != '0' && $height != '' && $height != '0') $hp = floor((int)$padding * ((int)$height / (int)$width));
	
	if ($width != '' && $width != '0') (int)$width -= (int)$padding;
	if ($height != '' && $height != '0') (int)$height -= $hp;
	
	global $pk_youtube_custom_counter;
	
	$pk_youtube_custom_counter++;
	
	if ($cover != '') {
		
		$cover_no_player = '<a href="http://www.youtube.com/watch?v='.$video_id.'" title="'.__('Watch video', 'pk_text_domain_front').'"><img src="'.pk_build_image($cover, (int)$width, (int)$height, 1).'" alt="'.__('Watch video', 'pk_text_domain_front').'" /></a>';
		
	} else {
		
		$cover_no_player = '<a href="http://www.youtube.com/watch?v='.$video_id.'" title="'.__('Watch video', 'pk_text_domain_front').'">'.__('Watch video', 'pk_text_domain_front').'</a>';
		
	}
	
	return '
<!-- pk start YouTube custom player -->
<div class="pk_video'.(($align != '') ? ' pk_align'.strtolower($align) : '').'"'.((($width == '' || $width == '0') && ($height == '' || $height == '0')) ? '' : ' style="width:'.($width + (int)$padding).'px; height:'.($height + $hp).'px;"').'>
	<div class="pk_video_wrapper'.(((int)$padding == 0) ? '_no_padding' : '').'"'.((($width == '' || $width == '0') && ($height == '' || $height == '0')) ? '' : ' style="width:'.$width.'px; height:'.$height.'px;"').'>
		<div id="pk_youtube_custom_'.$pk_youtube_custom_counter.'" class="pk_fit">'.$cover_no_player.'</div>
	</div>
	<script type="text/javascript">
		/*<![CDATA[*/
		var flashvars = {
			file_url:"'.$video_id.'",
			auto_play:"'.$autoplay.'",
			cover_url:"'.esc_url($cover).'",
			small_cover_url:"'.urlencode(pk_build_image($cover, (int)$width, (int)$height, 1)).'",
			background_color:"'.$pk_player_options['custom_player_c1'].'",
			buttons_color:"'.$pk_player_options['custom_player_c2'].'",
			time_label_color:"'.$pk_player_options['custom_player_c3'].'",
			controls_background_color:"'.$pk_player_options['custom_player_c4'].'",
			progress_bar_color:"'.$pk_player_options['custom_player_c5'].'",
			progress_bar_background_color:"'.$pk_player_options['custom_player_c6'].'",
			loading_bar_color:"'.$pk_player_options['custom_player_c7'].'",
			volume_bar_color:"'.$pk_player_options['custom_player_c8'].'",
			volume_bar_background_color:"'.$pk_player_options['custom_player_c9'].'",
			spectrum_color:"'.$pk_player_options['custom_player_c10'].'"};
		var params = {
			scale:"noScale",
			salign:"lt",
			menu:"false",
			allowScriptAccess:"always",
			allowFullScreen:"true",
			wmode:"transparent"};
		var attributes = {};
		swfobject.embedSWF("'.PK_THEME_DIR.'/parkerandkent2011/flash/theme/itis_youtube_player.swf", "pk_youtube_custom_'.$pk_youtube_custom_counter.'", "100%", "100%", "9.0.0", null, flashvars, params, attributes);
		/*]]>*/
	</script>
</div>
<!-- pk end YouTube custom player -->
';
	
}

add_shortcode('pk_youtube_custom_player', 'pk_scp_youtube_custom_player');

/*
 * Video player
*/

static $pk_video_counter = 0;

function pk_scp_video_player($atts, $content = null) {
	
	global $pk_skin_profile;
	
	$pk_player_options = pk_get_options('pk_skin_options', '', $pk_skin_profile);
	
	extract(shortcode_atts(array(
		'padding' => '12',
		'width' => '',
		'height' => '',
		'align' => 'none',
		'autoplay' => 'false',
		'cover' => '',
		'video_url' => ''
	), $atts));
	
	$hp = 0;
	
	if ($width != '' && $width != '0' && $height != '' && $height != '0') $hp = floor((int)$padding * ((int)$height / (int)$width));
	
	if ($width != '' && $width != '0') (int)$width -= (int)$padding;
	if ($height != '' && $height != '0') (int)$height -= $hp;
	
	global $pk_video_counter;
	
	$pk_video_counter++;
	
	if ($cover != '') {
		
		$cover_no_player = '<a href="'.$video_url.'" title="'.__('Download video', 'pk_text_domain_front').'"><img src="'.pk_build_image($cover, (int)$width, (int)$height, 1).'" alt="'.__('Download video', 'pk_text_domain_front').'" /></a>';
		
	} else {
		
		$cover_no_player = '<a href="'.$video_url.'" title="'.__('Download video', 'pk_text_domain_front').'">'.__('Download video', 'pk_text_domain_front').'</a>';
		
	}
	
	return '
<!-- pk start as3 flash video player -->
<div class="pk_video'.(($align != '') ? ' pk_align'.strtolower($align) : '').'"'.((($width == '' || $width == '0') && ($height == '' || $height == '0')) ? '' : ' style="width:'.($width + (int)$padding).'px; height:'.($height + $hp).'px;"').'>
	<div class="pk_video_wrapper'.(((int)$padding == 0) ? '_no_padding' : '').'"'.((($width == '' || $width == '0') && ($height == '' || $height == '0')) ? '' : ' style="width:'.$width.'px; height:'.$height.'px;"').'>
		<div id="pk_video_'.$pk_video_counter.'" class="pk_fit">'.$cover_no_player.'</div>
	</div>
	<script type="text/javascript">
		/*<![CDATA[*/
		var flashvars = {
			file_url:"'.esc_url($video_url).'",
			auto_play:"'.$autoplay.'",
			cover_url:"'.esc_url($cover).'",
			small_cover_url:"'.urlencode(pk_build_image($cover, (int)$width, (int)$height, 1)).'",
			background_color:"'.$pk_player_options['custom_player_c1'].'",
			buttons_color:"'.$pk_player_options['custom_player_c2'].'",
			time_label_color:"'.$pk_player_options['custom_player_c3'].'",
			controls_background_color:"'.$pk_player_options['custom_player_c4'].'",
			progress_bar_color:"'.$pk_player_options['custom_player_c5'].'",
			progress_bar_background_color:"'.$pk_player_options['custom_player_c6'].'",
			loading_bar_color:"'.$pk_player_options['custom_player_c7'].'",
			volume_bar_color:"'.$pk_player_options['custom_player_c8'].'",
			volume_bar_background_color:"'.$pk_player_options['custom_player_c9'].'",
			spectrum_color:"'.$pk_player_options['custom_player_c10'].'"};
		var params = {
			scale:"noScale",
			salign:"lt",
			menu:"false",
			allowScriptAccess:"always",
			allowFullScreen:"true",
			wmode:"transparent"};
		var attributes = {};
		swfobject.embedSWF("'.PK_THEME_DIR.'/parkerandkent2011/flash/theme/itis_video_player.swf", "pk_video_'.$pk_video_counter.'", "100%", "100%", "9.0.0", null, flashvars, params, attributes);
		/*]]>*/
	</script>
</div>
<!-- pk end as3 flash video player -->
';
	
}

add_shortcode('pk_video_player', 'pk_scp_video_player');

/*
 * Audio player
*/

static $pk_audio_counter = 0;

function pk_scp_audio_player($atts, $content = null) {
	
	global $pk_skin_profile;
	
	$pk_player_options = pk_get_options('pk_skin_options', '', $pk_skin_profile);
	
	extract(shortcode_atts(array(
		'padding' => '12',
		'width' => '',
		'height' => '',
		'align' => 'none',
		'autoplay' => 'false',
		'cover' => '',
		'audio_url' => ''
	), $atts));
	
	$hp = 0;
	
	if ($width != '' && $width != '0' && $height != '' && $height != '0') $hp = floor((int)$padding * ((int)$height / (int)$width));
	
	if ($width != '' && $width != '0') (int)$width -= (int)$padding;
	if ($height != '' && $height != '0') (int)$height -= $hp;
	
	global $pk_audio_counter;
	
	$pk_audio_counter++;
	
	if ($cover != '') {
		
		$cover_no_player = '<a href="'.$audio_url.'" title="'.__('Download audio', 'pk_text_domain_front').'"><img src="'.pk_build_image($cover, (int)$width, (int)$height, 1).'" alt="'.__('Download audio', 'pk_text_domain_front').'" /></a>';
		
	} else {
		
		$cover_no_player = '<a href="'.$audio_url.'" title="'.__('Download audio', 'pk_text_domain_front').'">'.__('Download audio', 'pk_text_domain_front').'</a>';
		
	}
	
	return '
<!-- pk start as3 flash audio player -->
<div class="pk_video'.(($align != '') ? ' pk_align'.strtolower($align) : '').'"'.((($width == '' || $width == '0') && ($height == '' || $height == '0')) ? '' : ' style="width:'.($width + (int)$padding).'px; height:'.($height + $hp).'px;"').'>
	<div class="pk_video_wrapper'.(((int)$padding == 0) ? '_no_padding' : '').'"'.((($width == '' || $width == '0') && ($height == '' || $height == '0')) ? '' : ' style="width:'.$width.'px; height:'.$height.'px;"').'>
		<div id="pk_audio_'.$pk_audio_counter.'" class="pk_fit">'.$cover_no_player.'</div>
	</div>
	<script type="text/javascript">
		/*<![CDATA[*/
		var flashvars = {
			file_url:"'.esc_url($audio_url).'",
			auto_play:"'.$autoplay.'",
			cover_url:"'.esc_url($cover).'",
			small_cover_url:"'.urlencode(pk_build_image($cover, (int)$width, (int)$height, 1)).'",
			background_color:"'.$pk_player_options['custom_player_c1'].'",
			buttons_color:"'.$pk_player_options['custom_player_c2'].'",
			time_label_color:"'.$pk_player_options['custom_player_c3'].'",
			controls_background_color:"'.$pk_player_options['custom_player_c4'].'",
			progress_bar_color:"'.$pk_player_options['custom_player_c5'].'",
			progress_bar_background_color:"'.$pk_player_options['custom_player_c6'].'",
			loading_bar_color:"'.$pk_player_options['custom_player_c7'].'",
			volume_bar_color:"'.$pk_player_options['custom_player_c8'].'",
			volume_bar_background_color:"'.$pk_player_options['custom_player_c9'].'",
			spectrum_color:"'.$pk_player_options['custom_player_c10'].'"};
		var params = {
			scale:"noScale",
			salign:"lt",
			menu:"false",
			allowScriptAccess:"always",
			allowFullScreen:"true",
			wmode:"transparent"};
		var attributes = {};
		swfobject.embedSWF("'.PK_THEME_DIR.'/parkerandkent2011/flash/theme/itis_audio_player.swf", "pk_audio_'.$pk_audio_counter.'", "100%", "100%", "9.0.0", null, flashvars, params, attributes);
		/*]]>*/
	</script>
</div>
<!-- pk end as3 flash audio player -->
';
	
}

add_shortcode('pk_audio_player', 'pk_scp_audio_player');

/*
 * Swf object
*/

static $pk_swf_object_counter = 0;

function pk_scp_swf_object($atts, $content = null) {
	
	extract(shortcode_atts(array(
		'padding' => '12',
		'width' => '',
		'height' => '',
		'align' => 'none',
		'flashvars' => '{}',
		'params' => '{}',
		'fp_version' => '9.0.0',
		'swf_url' => ''
	), $atts));
	
	$hp = 0;
	
	if ($width != '' && $width != '0' && $height != '' && $height != '0') $hp = floor((int)$padding * ((int)$height / (int)$width));
	
	if ($width != '' && $width != '0') (int)$width -= (int)$padding;
	if ($height != '' && $height != '0') (int)$height -= $hp;
	
	global $pk_swf_object_counter;
	
	$pk_swf_object_counter++;
	
	return '
<!-- pk start flash swf object -->
<div class="pk_video'.(($align != '') ? ' pk_align'.strtolower($align) : '').'"'.((($width == '' || $width == '0') && ($height == '' || $height == '0')) ? '' : ' style="width:'.($width + (int)$padding).'px; height:'.($height + $hp).'px;"').'>
	<div class="pk_video_wrapper'.(((int)$padding == 0) ? '_no_padding' : '').'"'.((($width == '' || $width == '0') && ($height == '' || $height == '0')) ? '' : ' style="width:'.$width.'px; height:'.$height.'px;"').'>
		<div id="pk_swf_object_'.$pk_swf_object_counter.'" class="pk_fit"><p>'.__('You need Adobe Flash Player to display this swf!', 'pk_text_domain_front').'</p></div>
	</div>
	<script type="text/javascript">
		/*<![CDATA[*/
		var flashvars = '.$flashvars.';
		var params = '.$params.';
		var attributes = {};
		swfobject.embedSWF("'.esc_url($swf_url).'", "pk_swf_object_'.$pk_swf_object_counter.'", "100%", "100%", "'.$fp_version.'", null, flashvars, params, attributes);
		/*]]>*/
	</script>
</div>
<!-- pk end flash swf object -->
';
	
}

add_shortcode('pk_swf_object', 'pk_scp_swf_object');

?>