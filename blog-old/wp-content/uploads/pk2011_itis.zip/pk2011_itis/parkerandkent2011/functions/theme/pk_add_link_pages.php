<?php

function pk_add_link_pages(){
	
	wp_link_pages(array('echo' => 1, 'before' => '<p class="pk_posts_link_pages">'.__('Pages:', 'pk_text_domain_front')));
	
}

?>