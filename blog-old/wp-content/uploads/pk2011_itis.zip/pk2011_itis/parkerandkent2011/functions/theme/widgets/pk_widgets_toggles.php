<?php

class PK_Widget_Toggles extends WP_Widget {
	
	function PK_Widget_Toggles() {
		
		$widget_ops = array('classname' => 'widget_toggles', 'description' => __('Displays content toggles', 'pk_text_domain'));	
		$this -> WP_Widget('pk-toggles', __('Toggles', 'pk_text_domain'), $widget_ops);
		
	}
	
	function widget($args, $instance) {
		
		extract($args);
		
		$title = apply_filters('widget_title', $instance['title']);
		
		if (empty($title)) $title = false;
		
		$number = absint($instance['number']);
		$toggles_type = (isset($instance['toggles_type']) && !empty($instance['toggles_type'])) ? $instance['toggles_type'] : 'minimal';
		$instance_toggles_title = array();
		$instance_toggles_content = array();
		
		for ($i = 1; $i <= $number; $i++) {
			
			$toggles_title = 'toggles_'.$i.'_title';
			$instance_toggles_title[$i] = isset($instance[$toggles_title]) ? $instance[$toggles_title] : '';
			$toggles_content = 'toggles_'.$i.'_content';
			$instance_toggles_content[$i] = isset($instance[$toggles_content]) ? $instance[$toggles_content] : '';
			
		}
		
		echo '<!-- pk start pk-toggles widget -->
'.$before_widget.'
	';
		
		if ($title) {
			
			echo $before_title;
			echo $title;
			echo $after_title;
			
		}
?>
<?php
		if ($toggles_type == 'minimal') : 
?>

	<div class="pk_minimal_toggles" style="width:100%;">
<?php
		else : 
?>
	<div class="pk_boxed_toggles" style="width:100%;">
<?php
		endif;

		for ($i = 1; $i <= $number; $i++) : 
			
			if ($toggles_type == 'minimal') : 
?>
		<div class="pk_toggle pk_toggle_border">
			<p class="pk_toggle_button"><?php echo $instance_toggles_title[$i]; ?></p>
			<div class="pk_toggle_content_wrapper">
				<div class="pk_toggle_content">
					<?php echo $instance_toggles_content[$i];
?>

				</div>
			</div>
		</div>
<?php
			else : 
?>
		<div class="pk_toggle pk_rounded">
			<p class="pk_toggle_button"><?php echo $instance_toggles_title[$i]; ?></p>
			<div class="pk_toggle_content_wrapper">
				<div class="pk_toggle_content">
					<?php echo $instance_toggles_content[$i];
?>

				</div>
			</div>
		</div>
<?php
			endif;
			
		endfor;
?>
	</div>
<?php

		echo $after_widget.'
<!-- pk end pk-toggles widget -->

';
		
	}
	
	function update($new_instance, $old_instance) {
		
		$instance = $old_instance;
		
		$instance['title'] = strip_tags($new_instance['title']);
		$instance['number'] = $new_instance['number'];
		$instance['toggles_type'] = $new_instance['toggles_type'];
		for ($i = 1; $i <= absint($instance['number']); $i++) {
			
			$instance['toggles_'.$i.'_title'] = $new_instance['toggles_'.$i.'_title'];
			$instance['toggles_'.$i.'_content'] = $new_instance['toggles_'.$i.'_content'];
			
		}
		
		return $instance;
		
	}
	
	function form($instance) {
		
		$title = isset($instance['title']) ? esc_attr($instance['title']) : '';
		$number = isset($instance['number']) ? absint($instance['number']) : 1;
		$toggles_type = (isset($instance['toggles_type']) && !empty($instance['toggles_type'])) ? $instance['toggles_type'] : 'minimal';
		$instance_toggles_title = array();
		$instance_toggles_content = array();
		
		for ($i = 1; $i <= $number; $i++) {
			
			$toggles_title = 'toggles_'.$i.'_title';
			$instance_toggles_title[$i] = isset($instance[$toggles_title]) ? $instance[$toggles_title] : '';
			$toggles_content = 'toggles_'.$i.'_content';
			$instance_toggles_content[$i] = isset($instance[$toggles_content]) ? $instance[$toggles_content] : '';
			
		}
?>
		<p><label for="<?php echo $this -> get_field_id('title'); ?>"><?php _e('Title:', 'pk_text_domain'); ?></label>
		<input class="widefat" id="<?php echo $this -> get_field_id('title'); ?>" name="<?php echo $this -> get_field_name('title'); ?>" type="text" value="<?php echo $title; ?>" /></p>
		
		<p><label for="<?php echo $this -> get_field_id('number'); ?>"><?php _e('Number of toggles to show:', 'pk_text_domain'); ?></label>
		<input class="widefat" id="<?php echo $this -> get_field_id('number'); ?>" name="<?php echo $this -> get_field_name('number'); ?>" type="text" value="<?php echo $number; ?>" /></p>
		
		<p>
		<label for="<?php echo $this -> get_field_id('toggles_type'); ?>"><?php _e('Style:', 'pk_text_domain'); ?></label>
		<select class="widefat" id="<?php echo $this -> get_field_id('toggles_type'); ?>" name="<?php echo $this -> get_field_name('toggles_type'); ?>">
			<option value="minimal"<?php if ($toggles_type == 'minimal') echo ' selected="selected"';?>><?php _e('Minimal', 'pk_text_domain'); ?></option>
			<option value="boxed"<?php if ($toggles_type == 'boxed') echo ' selected="selected"';?>><?php _e('Boxed', 'pk_text_domain'); ?></option>
		</select>
		</p>
		
		<div>
<?php for ($i = 1; $i <= $number; $i++) : $toggles_title = 'toggles_'.$i.'_title'; $toggles_content = 'toggles_'.$i.'_content'; ?>
			<div>
				<p><strong><?php _e('Toggle', 'pk_text_domain'); ?> <?php echo $i; ?>:</strong></p>
				<p><label for="<?php echo $this -> get_field_id($toggles_title); ?>"><?php _e('Title:', 'pk_text_domain'); ?></label>
				<input class="widefat" id="<?php echo $this -> get_field_id($toggles_title); ?>" name="<?php echo $this -> get_field_name($toggles_title); ?>" type="text" value="<?php echo $instance_toggles_title[$i]; ?>" /></p>
				<p><label for="<?php echo $this -> get_field_id($toggles_content); ?>"><?php _e('Content:', 'pk_text_domain'); ?></label>
				<textarea class="widefat" rows="10" cols="10" id="<?php echo $this -> get_field_id($toggles_content); ?>" name="<?php echo $this -> get_field_name($toggles_content); ?>"><?php echo $instance_toggles_content[$i]; ?></textarea></p>
			</div>
<?php endfor;?>
		</div>
<?php
	}
	
}

function pk_widgets_toggles() {
	
	register_widget('PK_Widget_Toggles');
	
}

add_action('widgets_init', 'pk_widgets_toggles');

?>