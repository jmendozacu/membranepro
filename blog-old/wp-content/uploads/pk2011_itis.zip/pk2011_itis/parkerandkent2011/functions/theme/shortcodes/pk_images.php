<?php

/*
 * Image
*/

function pk_scp_image($atts, $content = null) {
	
	global $post;
	
	extract(shortcode_atts(array(
		'image' => '',
		'title' => '',
		'w' => '',
		'image_style' => '',
		'h' => '',
		'align' => 'none',
		'icon' => '',
		'action' => '',
		'link' => '',
		'link_target' => '_self',
		'lightbox_gallery_id' => (isset($post -> ID)) ? $post -> ID : 'lightbox_gallery'
	), $atts));
	
	$w = (int)$w;
	$h = (int)$h;
	
	$hp = 0;
	
	switch ($image_style) {
		
		case '16/9' :
			
			$h = floor(($w / 16) * 9);
			break;
			
		case '4/3' :
			
			$h = floor(($w / 4) * 3);
			break;
			
		case 'portrait' :
			
			$h = floor(($w / 3) * 4);
			break;
			
		case 'square' :
			
			$h = $w;
			break;
			
		case 'auto' :
			
			$h = 0;
			break;
			
		case 'custom' :
			
			$h = $h;
			break;
		
	}
	
	if ($w != 0 && $h != 0) $hp = floor(12 * ($h / $w));
	
	$output = '';
			
	if ($image != '') {
		
		$output .= '
<!-- pk start image -->
<div class="pk_image pk_align'.$align.'"';
		
		if ($w != 0) {
			
			$output .= ' style="'.(($w != 0) ? 'width:'.$w.'px;' : '').(($h != 0) ? ' height:'.$h.'px;' : '').'"';
			
		}
		
		$output .= '>
	<div class="pk_image_wrapper">';
			
		if ($action != '') {
				
			$output .= '
		<a href="'.esc_url($link).'" title="'.$title.'"';
				
			if ($link_target != '_self' && $action == 'link') {
					
				$output .= ' target="'.$link_target.'"';
					
			}
				
			$output .= (($icon != '') ? ' class="pk_'.$icon.'_icon"' : '').(($action == 'lightbox') ? ' rel="prettyPhoto['.$lightbox_gallery_id.']"' : '').'>
			<img src="'.pk_build_image($image, $w - 12, ($h > 0) ? $h - $hp : 0, 1).'" />
			<span class="pk_image_button_overlay"></span>
		</a>';
				
		} else {
				
			$output .='
		<img src="'.pk_build_image($image, $w - 12, ($h > 0) ? $h - $hp : 0, 1).'" alt="'.$title.'" />';
					
		}
			
		$output .= '
	</div>
</div>
<!-- pk end image -->
';
	
	}
	
	return $output;
	
}

add_shortcode('pk_image', 'pk_scp_image');

/*
 * Gallery shortcode filter
*/

function pk_scp_gallery($attr) {
	
	global $post, $wp_locale;
	
	static $instance = 0;
	
	$instance++;
	
	$output = apply_filters('post_gallery', '', $attr);
	
	if ($output != '') return $output;

	if (isset($attr['orderby'])) {
		
		$attr['orderby'] = sanitize_sql_orderby($attr['orderby']);
		
		if (!$attr['orderby']) unset($attr['orderby']);
		
	}
	
	extract(shortcode_atts(array(
		'order' => 'ASC',
		'orderby' => 'menu_order ID',
		'id' => $post -> ID,
		'itemtag' => 'dl',
		'icontag' => 'dt',
		'captiontag' => 'dd',
		'columns' => 3,
		'size' => 'thumbnail',
		'include' => '',
		'exclude' => ''
	), $attr));
	
	$id = intval($id);
	
	if ('RAND' == $order) $orderby = 'none';
	
	if (!empty($include)) {
		
		$include = preg_replace('/[^0-9,]+/', '', $include);
		
		$_attachments = get_posts(array('include' => $include, 'post_status' => 'inherit', 'post_type' => 'attachment', 'post_mime_type' => 'image', 'order' => $order, 'orderby' => $orderby));
		
		$attachments = array();
		
		foreach ($_attachments as $key => $val) {
			
			$attachments[$val -> ID] = $_attachments[$key];
			
		}
		
	} elseif (!empty($exclude)) {
		
		$exclude = preg_replace('/[^0-9,]+/', '', $exclude);
		
		$attachments = get_children(array('post_parent' => $id, 'exclude' => $exclude, 'post_status' => 'inherit', 'post_type' => 'attachment', 'post_mime_type' => 'image', 'order' => $order, 'orderby' => $orderby));
		
	} else {
		
		$attachments = get_children(array('post_parent' => $id, 'post_status' => 'inherit', 'post_type' => 'attachment', 'post_mime_type' => 'image', 'order' => $order, 'orderby' => $orderby));
		
	}
	
	if (empty($attachments)) return '';
	
	if (is_feed()) {
		
		$output = "\n";
		
		foreach ($attachments as $att_id => $attachment) $output .= wp_get_attachment_link($att_id, $size, true)."\n";
		
		return $output;
		
	}
	
	$itemtag = tag_escape($itemtag);
	$captiontag = tag_escape($captiontag);
	$columns = intval($columns);
	$itemwidth = $columns > 0 ? floor(100/$columns) : 100;
	$float = is_rtl() ? 'right' : 'left';
	
	$selector = "gallery-{$instance}";
	
	$gallery_style = $gallery_div = '';
	
	if (apply_filters('use_default_gallery_style', true))
		
		$gallery_style = "<style type='text/css'>
	
	#{$selector} {
		margin:auto;
	}
	
	#{$selector} .gallery-item {
		float:{$float};
		margin-top:10px;
		text-align:center;
		width:{$itemwidth}%;
	}
	
	#{$selector} img {
		padding:5px;
		border:1px dotted #c9c9c9;
	}
	
	#{$selector} .gallery-caption {
		margin-left:0;
	}
	
</style>";
	
	$size_class = sanitize_html_class($size);
	
	$gallery_div = "<div id=\"$selector\" class=\"gallery galleryid-{$id} gallery-columns-{$columns} gallery-size-{$size_class}\">";
	
	$output = apply_filters('gallery_style', $gallery_style."\n\n".$gallery_div);
	
	$i = 0;
	
	foreach ($attachments as $id => $attachment) {
		
		$link = isset($attr['link']) && 'file' == $attr['link'] ? wp_get_attachment_link($id, $size, false, false) : wp_get_attachment_link($id, $size, true, false);
		
		if (isset($attr['link']) && 'file' == $attr['link']) $link = str_replace('<a', '<a rel="prettyPhoto[gallery_lightbox]" ', $link);
		
		$output .= "
<{$itemtag} class=\"gallery-item\">";
		$output .= "
<{$icontag} class=\"gallery-icon\">
	$link
</{$icontag}>";
		
		if ($captiontag && trim($attachment -> post_excerpt)) {
			
			$output .= "
<{$captiontag} class=\"wp-caption-text gallery-caption\">
".wptexturize($attachment -> post_excerpt)."
</{$captiontag}>";
			
		}
		
		$output .= "\n</{$itemtag}>";
		
		if ($columns > 0 && ++$i % $columns == 0) $output .= '
<br style="clear:both" />';
		
	}
	
	$output .= "
<br style=\"clear:both\" />
</div>";
	
	return $output;
	
}

remove_shortcode('gallery');

add_shortcode('gallery', 'pk_scp_gallery');

?>