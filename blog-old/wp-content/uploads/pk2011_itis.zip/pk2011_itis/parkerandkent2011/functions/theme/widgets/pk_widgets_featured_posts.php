<?php

class PK_Widget_Featured_Posts extends WP_Widget {
	
	function PK_Widget_Featured_Posts() {
		
		$widget_ops = array('classname' => 'widget_featured_posts', 'description' => __('Displays the featured posts', 'pk_text_domain'));
		$this -> WP_Widget('pk-featured-posts', __('Featured Posts', 'pk_text_domain'), $widget_ops);
		$this -> alt_option_name = 'widget_featured_posts';

		add_action('save_post', array(&$this, 'flush_widget_cache'));
		add_action('deleted_post', array(&$this, 'flush_widget_cache'));
		add_action('switch_theme', array(&$this, 'flush_widget_cache'));
		
	}
	
	function widget($args, $instance) {
		
		$cache = wp_cache_get('widget_featured_posts', 'widget');
		
		$title = apply_filters('widget_title', $instance['title']);
		
		if (empty($title)) $title = false;
		
		$selected_posts = (isset($instance['selected_posts']) && !empty($instance['selected_posts'])) ? $instance['selected_posts'] : array();
		$selected_order_by = (isset($instance['selected_order_by']) && !empty($instance['selected_order_by'])) ? $instance['selected_order_by'] : 'date';
		$display_excerpt = (isset($instance['display_excerpt']) && $instance['display_excerpt']) ? 1 : 0;
		$display_thumb = (isset($instance['display_thumb']) && $instance['display_thumb']) ? 1 : 0;
		$list_icon = (isset($instance['list_icon']) && !empty($instance['list_icon'])) ? $instance['list_icon'] : '';
		$thumb_icon = (isset($instance['thumb_icon']) && !empty($instance['thumb_icon'])) ? $instance['thumb_icon'] : '';
		$thumb_width = (isset($instance['thumb_width']) && $instance['thumb_width']) ? absint($instance['thumb_width']) : 70;
		$thumb_height = (isset($instance['thumb_height']) && $instance['thumb_height']) ? absint($instance['thumb_height']) : 70;

		if (!is_array($cache)) {
			
			$cache = array();
			
		}

		if (isset($cache[$args['widget_id']])) {
			
			echo $cache[$args['widget_id']];
			return;
			
		}
		
		ob_start();
		extract($args);
		
		$r = new WP_Query(array('post_type' => 'post', 'posts_per_page' => count($selected_posts), 'post__in' => $selected_posts, 'nopaging' => 0, 'post_status' => 'publish', 'ignore_sticky_posts' => 1, 'orderby' => $selected_order_by, 'order' => 'DESC'));
		
		if ($r -> have_posts()) : 
			
			echo '<!-- pk start pk-featured-posts widget -->
'.$before_widget.'
	';
			
			if ($title) echo $before_title.$title.$after_title;
?>

	<ul class="<?php if (!$display_thumb && !$display_excerpt) : ?>pk_underline_list pk_clear_list<?php else : ?>pk_thumbnail_list<?php endif; if (!$display_thumb) : echo ' '.$list_icon; endif; ?>">
<?php
				while ($r -> have_posts()) : 
					
					$r -> the_post();
					
					if ($display_thumb) : 
						
						$image = pk_get_featured_image();
?>
		<li>
<?php
						if ($image) : 
?>
			<div class="pk_image pk_alignleft" style="width:<?php echo $thumb_width; ?>px; height:<?php echo $thumb_height; ?>px;">
				<div class="pk_image_wrapper">
					<a href="<?php the_permalink(); ?>" title="<?php _e('Read more &raquo;', 'pk_text_domain_front'); ?>" <?php if ($thumb_icon != '') : ?>class="<?php echo $thumb_icon; ?>"<?php endif; ?>>
						<img src="<?php echo pk_build_image($image[0], $thumb_width - 12, $thumb_height - 12, 1); ?>" />
						<span class="pk_image_button_overlay"></span>
					</a>
				</div>
			</div>
<?php
						endif;
?>
			<a href="<?php the_permalink(); ?>" title="<?php echo esc_attr(get_the_title() ? get_the_title() : get_the_ID()); ?>"><?php if (get_the_title() && !$display_excerpt) : the_title(); ?></a><?php else : ?><h6><?php the_title(); ?></h6></a><?php add_filter('excerpt_length', 'pk_widgets_excerpt_filter'); add_filter('excerpt_more', 'pk_excerpt_more'); the_excerpt(); endif; ?>
			<p class="pk_post_meta"><?php comments_popup_link(__('No Comments', 'pk_text_domain_front'), __('1 Comment', 'pk_text_domain_front'), __('% Comments', 'pk_text_domain_front'), 'pk_meta_tot_comments', __('Comments Off', 'pk_text_domain_front')); ?></p>
		</li>
<?php
					else : 
?>
		<li>
<?php
						if (get_the_title() && !$display_excerpt) : 
?>
			<a href="<?php the_permalink(); ?>" title="<?php echo esc_attr(get_the_title() ? get_the_title() : get_the_ID()); ?>"><?php the_title(); ?></a>
<?php
						else : 
?>
			<a href="<?php the_permalink(); ?>" title="<?php echo esc_attr(get_the_title() ? get_the_title() : get_the_ID()); ?>"><h6><?php the_title(); ?></h6></a>	
			<?php			
							add_filter('excerpt_length', 'pk_widgets_excerpt_filter');
							add_filter('excerpt_more', 'pk_excerpt_more');
							the_excerpt();
							
						endif;
?>
		</li>
<?php
					endif;
					
				endwhile;
?>
	</ul>
<?php
			echo $after_widget.'
<!-- pk end pk-featured-posts widget -->

';
		
		endif;
		
		wp_reset_postdata();
		
		$cache[$args['widget_id']] = ob_get_flush();
		
		wp_cache_set('widget_featured_posts', $cache, 'widget');
		
	}
	
	function update($new_instance, $old_instance) {
		
		$instance = $old_instance;
		$instance['title'] = strip_tags($new_instance['title']);
		$instance['selected_posts'] = $new_instance['selected_posts'];
		$instance['selected_order_by'] = $new_instance['selected_order_by'];
		$instance['display_excerpt'] = $new_instance['display_excerpt'] ? 1 : 0;
		$instance['display_thumb'] = $new_instance['display_thumb'] ? 1 : 0;
		$instance['list_icon'] = $new_instance['list_icon'];
		$instance['thumb_icon'] = $new_instance['thumb_icon'];
		$instance['thumb_width'] = (int) $new_instance['thumb_width'];
		$instance['thumb_height'] = (int) $new_instance['thumb_height'];
		
		$this -> flush_widget_cache();

		$alloptions = wp_cache_get('alloptions', 'options');
		
		if (isset($alloptions['widget_featured_posts'])) {
			
			delete_option('widget_featured_posts');
			
		}
		
		return $instance;
		
	}
	
	function flush_widget_cache() {
		
		wp_cache_delete('widget_featured_posts', 'widget');
		
	}
	
	function form($instance) {
		
		$title = isset($instance['title']) ? esc_attr($instance['title']) : '';
		$selected_posts = (isset($instance['selected_posts']) && !empty($instance['selected_posts'])) ? $instance['selected_posts'] : array();
		$selected_order_by = (isset($instance['selected_order_by']) && !empty($instance['selected_order_by'])) ? $instance['selected_order_by'] : 'date';
		$display_excerpt = (isset($instance['display_excerpt']) && !empty($instance['display_excerpt'])) ? 'checked="checked"' : '';
		$display_thumb = (isset($instance['display_thumb']) && !empty($instance['display_thumb'])) ? 'checked="checked"' : '';
		$list_icon = (isset($instance['list_icon']) && !empty($instance['list_icon'])) ? $instance['list_icon'] : '';
		$thumb_icon = (isset($instance['thumb_icon']) && !empty($instance['thumb_icon'])) ? $instance['thumb_icon'] : '';
		$thumb_width = isset($instance['thumb_width']) ? absint($instance['thumb_width']) : 70;
		$thumb_height = isset($instance['thumb_height']) ? absint($instance['thumb_height']) : 70;
?>
		<p><label for="<?php echo $this -> get_field_id('title'); ?>"><?php _e('Title:', 'pk_text_domain'); ?></label>
		<input class="widefat" id="<?php echo $this -> get_field_id('title'); ?>" name="<?php echo $this -> get_field_name('title'); ?>" type="text" value="<?php echo $title; ?>" /></p>
		
		<p>
		<label for="<?php echo $this -> get_field_id('selected_posts'); ?>"><?php _e('Select posts:', 'pk_text_domain'); ?></label>
		<select class="widefat" id="<?php echo $this -> get_field_id('selected_posts'); ?>" name="<?php echo $this -> get_field_name('selected_posts'); ?>[]" multiple="multiple" style="height:auto"><?php
			
			$all_posts = get_posts(array('post_type' => 'post', 'posts_per_page' => -1, 'orderby' => 'title', 'order' => 'ASC'));
			
			if ($all_posts) {
			
				foreach ($all_posts as $current_post) {
					
					if (in_array($current_post -> ID, $selected_posts)) {
						
						$selected_string = ' selected="selected"';
						
					} else {
						
						$selected_string = '';
						
					}
					
					echo '
				<option value="'.$current_post -> ID.'"'.$selected_string.'>'.$current_post -> post_title.'</option>';
					
				}
				
			}
				
		?></select>
		</p>
		
		<p>
		<label for="<?php echo $this -> get_field_id('selected_order_by'); ?>"><?php _e('Order posts by:', 'pk_text_domain'); ?></label>
		<select class="widefat" id="<?php echo $this -> get_field_id('selected_order_by'); ?>" name="<?php echo $this -> get_field_name('selected_order_by'); ?>">
			<option value="date"<?php if ($selected_order_by == 'date') echo ' selected="selected"';?>><?php _e('Date', 'pk_text_domain'); ?></option>
			<option value="comment_count"<?php if ($selected_order_by == 'comment_count') echo ' selected="selected"';?>><?php _e('Comments Count', 'pk_text_domain'); ?></option>
			<option value="title"<?php if ($selected_order_by == 'title') echo ' selected="selected"';?>><?php _e('Title', 'pk_text_domain'); ?></option>
			<option value="author"<?php if ($selected_order_by == 'author') echo ' selected="selected"';?>><?php _e('Author', 'pk_text_domain'); ?></option>
			<option value="rand"<?php if ($selected_order_by == 'rand') echo ' selected="selected"';?>><?php _e('Random', 'pk_text_domain'); ?></option>
		</select>
		</p>
		
		<p><input class="checkbox" type="checkbox" <?php echo $display_excerpt; ?> id="<?php echo $this -> get_field_id('display_excerpt'); ?>" name="<?php echo $this -> get_field_name('display_excerpt'); ?>" />
		<label for="<?php echo $this -> get_field_id('display_excerpt'); ?>"><?php _e('Display excerpt', 'pk_text_domain'); ?></label><br />
		<input class="checkbox" type="checkbox" <?php echo $display_thumb; ?> id="<?php echo $this -> get_field_id('display_thumb'); ?>" name="<?php echo $this -> get_field_name('display_thumb'); ?>" />
		<label for="<?php echo $this -> get_field_id('display_thumb'); ?>"><?php _e('Display thumbnails', 'pk_text_domain'); ?></label></p>
		
		<p>
		<label for="<?php echo $this -> get_field_id('thumb_icon'); ?>"><?php _e('Select thumbnails icon type:', 'pk_text_domain'); ?></label>
		<select class="widefat" id="<?php echo $this -> get_field_id('thumb_icon'); ?>" name="<?php echo $this -> get_field_name('thumb_icon'); ?>">
			<option value=""<?php if ($thumb_icon == '') echo ' selected="selected"';?>><?php _e('No Icon', 'pk_text_domain'); ?></option>
			<option value="pk_page_icon"<?php if ($thumb_icon == 'pk_page_icon') echo ' selected="selected"';?>><?php _e('Page Icon', 'pk_text_domain'); ?></option>
			<option value="pk_link_icon"<?php if ($thumb_icon == 'pk_link_icon') echo ' selected="selected"';?>><?php _e('Link Icon', 'pk_text_domain'); ?></option>
			<option value="pk_play_icon"<?php if ($thumb_icon == 'pk_play_icon') echo ' selected="selected"';?>><?php _e('Play Icon', 'pk_text_domain'); ?></option>
			<option value="pk_zoom_icon"<?php if ($thumb_icon == 'pk_zoom_icon') echo ' selected="selected"';?>><?php _e('Zoom Icon', 'pk_text_domain'); ?></option>
		</select>
		</p>
		
		<p>
		<label for="<?php echo $this -> get_field_id('list_icon'); ?>"><?php _e('Select list icon type:', 'pk_text_domain'); ?></label>
		<select class="widefat" id="<?php echo $this -> get_field_id('list_icon'); ?>" name="<?php echo $this -> get_field_name('list_icon'); ?>">
			<option value="pk_clear_list"<?php if ($list_icon == 'pk_clear_list') echo ' selected="selected"';?>><?php _e('No Icon', 'pk_text_domain'); ?></option>
			<option value="pk_arrow_list"<?php if ($list_icon == 'pk_arrow_list') echo ' selected="selected"';?>><?php _e('Arrow Icon', 'pk_text_domain'); ?></option>
			<option value="pk_check_list"<?php if ($list_icon == 'pk_check_list') echo ' selected="selected"';?>><?php _e('Check Icon', 'pk_text_domain'); ?></option>
			<option value="pk_posts_list"<?php if ($list_icon == 'pk_posts_list') echo ' selected="selected"';?>><?php _e('Post Icon', 'pk_text_domain'); ?></option>
			<option value="pk_circle_list"<?php if ($list_icon == 'pk_circle_list') echo ' selected="selected"';?>><?php _e('Circle Icon', 'pk_text_domain'); ?></option>
		</select>
		</p>
		
		<p><label for="<?php echo $this -> get_field_id('thumb_width'); ?>"><?php _e('Thumbnails width:', 'pk_text_domain'); ?></label>
		<input class="widefat" id="<?php echo $this -> get_field_id('thumb_width'); ?>" name="<?php echo $this -> get_field_name('thumb_width'); ?>" type="text" value="<?php echo $thumb_width; ?>" /></p>
		
		<p><label for="<?php echo $this -> get_field_id('thumb_height'); ?>"><?php _e('Thumbnails height:', 'pk_text_domain'); ?></label>
		<input class="widefat" id="<?php echo $this -> get_field_id('thumb_height'); ?>" name="<?php echo $this -> get_field_name('thumb_height'); ?>" type="text" value="<?php echo $thumb_height; ?>" /></p>
<?php
	}
	
}

function pk_widgets_featured_posts() {
	
	register_widget('PK_Widget_Featured_Posts');
	
}

add_action('widgets_init', 'pk_widgets_featured_posts');

?>