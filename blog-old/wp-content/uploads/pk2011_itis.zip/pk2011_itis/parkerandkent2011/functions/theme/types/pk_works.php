<?php

function pk_register_works() {
	
	$labels = array(
		'name' => _x('Works', 'post type general name', 'pk_text_domain'),
		'singular_name' => _x('Work', 'post type singular name', 'pk_text_domain'),
		'add_new' => _x('Add New', 'release', 'pk_text_domain'),
		'add_new_item' => __('Add New Work', 'pk_text_domain'),
		'edit_item' => __('Edit Work', 'pk_text_domain'),
		'new_item' => __('New Work', 'pk_text_domain'),
		'view_item' => __('View Work', 'pk_text_domain'),
		'search_items' => __('Search Works', 'pk_text_domain'),
		'not_found' => __('No works found', 'pk_text_domain'),
		'not_found_in_trash' => __('No works found in Trash', 'pk_text_domain')
	);
	
	$args = array(
		'labels' => $labels,
		'public' => true,
		'menu_position' => 5,
		'capability_type' => 'post',
		'hierarchical' => false,
		'supports' => array('title', 'editor', 'excerpt', 'comments', 'revisions', 'thumbnail'),
		'query_var' => true,
		'rewrite' => false,
		'show_in_nav_menus' => true,
		'has_archive' => true
	);
	
	$taxonomy_labels = array(
		'name' => _x('Works Categories', 'taxonomy general name', 'pk_text_domain'),
		'singular_name' => _x('Works Category', 'taxonomy singular name', 'pk_text_domain'),
		'search_items' => __('Search Works Category', 'pk_text_domain'),
		'popular_items' => __('Popular Works Categories', 'pk_text_domain'),
		'all_items' => __('All Works Categories', 'pk_text_domain'),
		'parent_item' => __('Parent Works Category', 'pk_text_domain'),
		'parent_item_colon' => __('Parent Works Category:', 'pk_text_domain'),
		'edit_item' => __('Edit Works Category', 'pk_text_domain'),
		'add_new_item' => __('Add New Works Category', 'pk_text_domain'),
		'new_item_name' => __('New Works Category Name', 'pk_text_domain')
	);
	
	$taxonomy_args = array(
		'labels' => $taxonomy_labels,
		'public' => true,
		'show_in_nav_menus' => true,
		'show_ui' => true,
		'hierarchical' => true,
		'rewrite' => array('slug' => 'works_category', 'with_front' => false),
		'query_var' => true
	);
	
	register_post_type('works', $args);
	
	register_taxonomy('taxonomy_works', 'works', $taxonomy_args);
	
	flush_rewrite_rules();
	
}

add_action('init', 'pk_register_works');
 
function pk_works_edit_columns($columns){
	
	$columns = array(
		'cb' => '<input type="checkbox" />',
		'title' => __('Work Title', 'pk_text_domain'),
		'works_thumb' => __('Featured Image', 'pk_text_domain'),
		'author' => __('Author', 'pk_text_domain'),
		'taxonomy_works' => __('Works Categories', 'pk_text_domain'),
		'comments' => $columns['comments'],
		'date' => $columns['date']
	);
	
	return $columns;
	
}

add_filter('manage_edit-works_columns', 'pk_works_edit_columns');

function pk_works_custom_columns($column){
	
	global $post;
	
	switch ($column) {
		
		case 'works_thumb':
			
			if (function_exists('the_post_thumbnail') && has_post_thumbnail()) {
				
				the_post_thumbnail(array(80, 80));
				
			}
			
   			break;
			
		case 'taxonomy_works':
			
			echo get_the_term_list($post -> ID, 'taxonomy_works', '', ', ', '');
			
   			break;
			
	}
	
}

add_action('manage_posts_custom_column', 'pk_works_custom_columns');

function pk_save_works_sort() {
	
	global $wpdb;
	
	$order = explode(',', $_POST['order']);
	
	$counter = 0;
 
	foreach ($order as $works_id) {
		
		$wpdb -> update($wpdb -> posts, array('menu_order' => $counter), array('ID' => $works_id));
		$counter++;
		
	}
	
	do_action('pk_ah_posts_sorted');
	
	die();
	
}

add_action('wp_ajax_works_sort', 'pk_save_works_sort');

function pk_add_sort_works_page() {
	
	add_submenu_page('edit.php?post_type=works', 'Sort Works', 'Sort Works', 'edit_posts', basename(__FILE__), 'pk_create_sort_works_page');
	
}

add_action('admin_menu', 'pk_add_sort_works_page'); 

function pk_create_sort_works_page() {
	
	$works = new WP_Query('post_type=works&posts_per_page=-1&orderby=menu_order&order=ASC');
	
?>

<!-- pk sort works page - start -->
<div class="wrap">
	<div id="icon-options-general" class="icon32">
		<br />
	</div>
	<h2><?php _e('Sort Works', 'pk_text_domain'); ?> <a href="<?php echo admin_url('post-new.php').'?post_type=works'; ?>" class="button add-new-h2"><?php _e('Add New', 'pk_text_domain'); ?></a></h2>
	<br />
	<div id="pk_admin_saving_sorting" class="updated">
		<p><strong><?php _e('Saving the works order...', 'pk_text_domain'); ?></strong></p>
	</div>
	<div id="pk_admin_success_sorting" class="updated">
		<p><strong><?php _e('Works order saved!', 'pk_text_domain'); ?></strong></p>
	</div>
	<div id="pk_admin_error_sorting" class="updated">
		<p><strong><?php _e('Error saving the works order, please try again.', 'pk_text_domain'); ?></strong></p>
	</div>
	<div>
		<ul id="pk_admin_sortable_list">
<?php if ($works -> have_posts()) : while ($works -> have_posts()) : $works -> the_post(); ?>
			<li id="<?php the_id(); ?>" class="pk_admin_sortable_default">
				<?php if (function_exists('the_post_thumbnail') && has_post_thumbnail()) { the_post_thumbnail(array(80, 80), array('class' => 'pk_admin_sort_thumb')); } else { echo '<span class="pk_admin_sort_no_img"></span>'; } ?>
				
				<strong><a class="pk_admin_sort_titles" href="<?php echo admin_url('post.php').'?post='; the_id(); echo '&action=edit'; ?>"><?php the_title(); ?></a></strong>
				<p class="pk_admin_class_taxonomies"><?php the_taxonomies(); ?></p>
			</li>
<?php endwhile; ?>
		</ul>
<?php else :?>
		<p><?php _e('No works found', 'pk_text_domain'); ?></p>
<?php endif; ?>
	</div>
</div>
<!-- pk sort works page - end -->
<?php

}