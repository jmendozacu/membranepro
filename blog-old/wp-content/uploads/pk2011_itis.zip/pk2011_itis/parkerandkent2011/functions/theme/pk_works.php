<?php

function pk_works_grid_categories_filter() {
	
	global $pk_show_categories_filter;
	global $pk_filter_categories;
	
	if ($pk_show_categories_filter == 'true') : 
?>
<!-- pk start categories filter -->
<div class="pk_categories_filter">
	<div class="pk_dropdown_categories">
		<p class="pk_button_categories"><?php _e('Categories:', 'pk_text_domain_front'); ?></p>
		<ul class="pk_categories_list">
			<li><a href="<?php echo home_url().'/?post_type=works'; ?>" title="<?php _e('View all', 'pk_text_domain_front'); ?>"><?php _e('All', 'pk_text_domain_front'); ?></a></li>
<?php
		foreach ($pk_filter_categories as $filter_category) : 
?>
			<li><a href="<?php $term = get_term_by('id', $filter_category, 'taxonomy_works'); echo get_term_link($term -> slug, $term -> taxonomy); ?>" title="<?php echo $term -> name; ?>"><?php echo $term -> name; ?></a></li>
<?php
		endforeach;
?>
		</ul>
	</div>
</div>
<!-- pk end categories filter -->

<?php
	endif;
	
}

function pk_works_grid_item() {
	
	global $pk_count;
	global $pk_sidebar;
	global $pk_columns;
	global $pk_show_read_more;
	
	if ($pk_count == $pk_columns + 1) $pk_count = 1;
	
	$excerpt_length = ($pk_sidebar == 'none' || $pk_columns < 3) ? ($pk_columns == 1) ? 'very_long' : 'long' : 'short';
	
	add_filter('excerpt_more', 'pk_excerpt_more');
	add_filter('excerpt_length', 'pk_works_'.$excerpt_length.'_excerpt_filter');
	
	switch ($pk_columns) :
		
		case 6 :
?>
<!-- ################## -->
<!-- pk start grid item -->
<!-- ################## -->
<div id="post-<?php the_ID(); ?>" <?php post_class('pk_one_sixth pk_entry_grid'.(($pk_count == $pk_columns) ? ' pk_last' : '')); ?>>
<?php
	do_action('pk_ah_pre_'.((is_tax('taxonomy_works')) ? 'works_taxonomy' : 'works').'_grid_item');
	
	pk_works_grid_item_thumb((($pk_sidebar == 'none') ? 125 : 92));
	
	do_action('pk_ah_after_'.((is_tax('taxonomy_works')) ? 'works_taxonomy' : 'works').'_grid_item');
?>

</div>
<!-- ################ -->
<!-- pk end grid item -->
<!-- ################ -->

<?php
		break;
		
		case 5 :
?>
<!-- ################## -->
<!-- pk start grid item -->
<!-- ################## -->
<div id="post-<?php the_ID(); ?>" <?php post_class('pk_one_fifth pk_entry_grid'.(($pk_count == $pk_columns) ? ' pk_last' : '')); ?>>
<?php
	do_action('pk_ah_pre_'.((is_tax('taxonomy_works')) ? 'works_taxonomy' : 'works').'_grid_item');
	
	pk_works_grid_item_thumb((($pk_sidebar == 'none') ? 157 : 115));
	
	do_action('pk_ah_after_'.((is_tax('taxonomy_works')) ? 'works_taxonomy' : 'works').'_grid_item');
?>

</div>
<!-- ################ -->
<!-- pk end grid item -->
<!-- ################ -->

<?php
		break;
		
		case 4 :
?>
<!-- ################## -->
<!-- pk start grid item -->
<!-- ################## -->
<div id="post-<?php the_ID(); ?>" <?php post_class('pk_one_fourth pk_entry_grid'.(($pk_count == $pk_columns) ? ' pk_last' : '')); ?>>
<?php
	do_action('pk_ah_pre_'.((is_tax('taxonomy_works')) ? 'works_taxonomy' : 'works').'_grid_item');
	
	pk_works_grid_item_thumb((($pk_sidebar == 'none') ? 207 : 152));
?>

<!-- pk start grid item title -->
<h4 class="pk_entry_title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
<!-- pk end grid item title -->

<!-- pk start grid item description -->
<?php
	the_excerpt();
	
	if ($pk_show_read_more != 'false') pk_works_grid_item_read_more();
?>
<!-- pk end grid item description -->
<?php
	do_action('pk_ah_after_'.((is_tax('taxonomy_works')) ? 'works_taxonomy' : 'works').'_grid_item');
?>

</div>
<!-- ################ -->
<!-- pk end grid item -->
<!-- ################ -->

<?php
		break;
		
		case 3 :
?>
<!-- ################## -->
<!-- pk start grid item -->
<!-- ################## -->
<div id="post-<?php the_ID(); ?>" <?php post_class('pk_one_third pk_entry_grid'.(($pk_count == $pk_columns) ? ' pk_last' : '')); ?>>
<?php
	do_action('pk_ah_pre_'.((is_tax('taxonomy_works')) ? 'works_taxonomy' : 'works').'_grid_item');
	
	pk_works_grid_item_thumb((($pk_sidebar == 'none') ? 288 : 211));
?>

<!-- pk start grid item title -->
<h4 class="pk_entry_title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
<!-- pk end grid item title -->

<!-- pk start grid item description -->
<?php
	the_excerpt();
	
	if ($pk_show_read_more != 'false') pk_works_grid_item_read_more();
?>
<!-- pk end grid item description -->
<?php
	do_action('pk_ah_after_'.((is_tax('taxonomy_works')) ? 'works_taxonomy' : 'works').'_grid_item');
?>

</div>
<!-- ################ -->
<!-- pk end grid item -->
<!-- ################ -->

<?php
		break;
		
		case 2 :
?>
<!-- ################## -->
<!-- pk start grid item -->
<!-- ################## -->
<div id="post-<?php the_ID(); ?>" <?php post_class('pk_one_half pk_entry_grid'.(($pk_count == $pk_columns) ? ' pk_last' : '')); ?>>
<?php
	do_action('pk_ah_pre_'.((is_tax('taxonomy_works')) ? 'works_taxonomy' : 'works').'_grid_item');
	
	pk_works_grid_item_thumb((($pk_sidebar == 'none') ? 451 : 331));
?>

<!-- pk start grid item title -->
<h4 class="pk_entry_title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
<!-- pk end grid item title -->

<!-- pk start grid item description -->
<?php
	the_excerpt();
	
	if ($pk_show_read_more != 'false') pk_works_grid_item_read_more();
?>
<!-- pk end grid item description -->
<?php
	do_action('pk_ah_after_'.((is_tax('taxonomy_works')) ? 'works_taxonomy' : 'works').'_grid_item');
?>

</div>
<!-- ################ -->
<!-- pk end grid item -->
<!-- ################ -->

<?php
		break;
		
		case 1 :
?>
<!-- ################## -->
<!-- pk start grid item -->
<!-- ################## -->
<div id="post-<?php the_ID(); ?>" <?php post_class('pk_entry_grid pk_entry pk_entry_standard'); ?>>
<?php do_action('pk_ah_pre_'.((is_tax('taxonomy_works')) ? 'works_taxonomy' : 'works').'_grid_item'); ?>

<div class="pk_two_third">
<?php pk_works_grid_item_thumb((($pk_sidebar == 'none') ? 614 : 451)); ?>

</div>

<div class="pk_one_third pk_last">

<!-- pk start grid item title -->
<h4 class="pk_entry_title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
<!-- pk end grid item title -->

<!-- pk start grid item description -->
<?php
	the_excerpt();
	
	if ($pk_show_read_more != 'false') pk_works_grid_item_read_more();
?>
<!-- pk end grid item description -->

</div>

<?php do_action('pk_ah_after_'.((is_tax('taxonomy_works')) ? 'works_taxonomy' : 'works').'_grid_item'); ?>
</div>
<!-- ################ -->
<!-- pk end grid item -->
<!-- ################ -->

<?php
		
		break;
		
	endswitch;
	
	if ($pk_count == $pk_columns) : 
?>
<span class="pk_clear_both"></span>

<?php
	endif;
	
	$pk_count++;
	
}

function pk_works_grid_item_thumb($w) {
	
	global $post;
	
	$work_meta = pk_get_meta();
	
	$use_featured_image = (isset($work_meta['use_featured_image'])) ? $work_meta['use_featured_image'] : 'true';
	$use_custom_players = (isset($work_meta['use_custom_players'])) ? $work_meta['use_custom_players'] : 'true';
	$auto_play = (isset($work_meta['auto_play'])) ? $work_meta['auto_play'] : 'false';
	$thumb_icon = (isset($work_meta['thumb_icon'])) ? $work_meta['thumb_icon'] : '';
	$thumb_style = (isset($work_meta['thumb_style'])) ? $work_meta['thumb_style'] : '16/9';
	$thumb_height = (isset($work_meta['thumb_height'])) ? (int)$work_meta['thumb_height'] : 0;
	$thumb_action = (isset($work_meta['thumb_action'])) ? $work_meta['thumb_action'] : '';
	$thumb_type = (isset($work_meta['thumb_type'])) ? $work_meta['thumb_type'] : '';
	$lightbox_gallery = (isset($work_meta['lightbox_gallery'])) ? $work_meta['lightbox_gallery'] : '';
	
	$lightbox_gallery = explode('[pk_data_sep]', $lightbox_gallery);
		
	$lightbox_gallery_data = explode('[pk_sep]', $lightbox_gallery[0]);
	
	if (isset($lightbox_gallery[1]) && $lightbox_gallery[1] && $thumb_action == 'lightbox') {
		
		$lightbox_gallery_items = explode('[pk_items_sep]', $lightbox_gallery[1]);
		
	} else {
		
		$lightbox_gallery_items = '';
		
	}
	
	$thumb_type = explode(',', $thumb_type);
	$thumb_type = (isset($thumb_type[1])) ? $thumb_type[1] : '';
	
	if ($use_featured_image == 'true' || $thumb_type == '') {
		
		if ($thumb_type == '') $thumb_type = 'image';
		$image = pk_get_featured_image();
		if ($image) $image = $image[0];
		
	}
		
	if ($use_featured_image == 'false' && $thumb_type == 'image') {
		
		$image = $work_meta['image'];
		
	}
		
	if ($thumb_type == 'audio') {
		
		$audio = explode(',', $work_meta['audio']);
		if ($use_featured_image == 'false') $image = $audio[0];
		
	}
	
	if ($thumb_type == 'video') {
		
		$video = explode(',', $work_meta['video']);
		if ($use_featured_image == 'false') $image = $video[1];
		
		if ((int)$video[0] == 1) $thumb_type = 'html5';
		if ((int)$video[0] == 2) $thumb_type = 'video';
		if ((int)$video[0] == 3) $thumb_type = 'youtube';
		if ((int)$video[0] == 3 && $use_custom_players == 'true') $thumb_type = 'youtube_custom';
		if ((int)$video[0] == 4) $thumb_type = 'vimeo';
		
	}
	
	if ($thumb_type == 'swf') {
		
		$swf = $work_meta['swf'];
		
	}
	
	switch ($thumb_style) {
		
		case '16/9' :
			
			$h = floor(($w / 16) * 9);
			break;
			
		case '4/3' :
			
			$h = floor(($w / 4) * 3);
			break;
			
		case 'portrait' :
			
			$h = floor(($w / 3) * 4);
			break;
			
		case 'square' :
			
			$h = $w;
			break;
			
		case 'auto' :
			
			$h = 0;
			break;
			
		case 'custom' :
			
			$h = $thumb_height;
			break;
		
	}
	
	$hp = floor(12 * ($h / $w));
	
	switch ($thumb_type) {
		
		case 'image':
			
			if ($image) : 
				
?>

<!-- pk start image -->
<div class="pk_image" style="<?php echo (($w > 0) ? 'width:'.$w.'px;' : ''); echo (($h > 0) ? ' height:'.$h.'px;' : ''); ?>">
	<div class="pk_image_wrapper">
<?php
	if ($thumb_action != '') : 
		
		if (is_array($lightbox_gallery_items)) {
			
			$first_image = explode('[pk_sep]', $lightbox_gallery_items[0]);
			$first_image = $first_image[1];
			
		}
?>
		<a href="<?php echo (is_array($lightbox_gallery_items)) ? esc_url($first_image) : get_permalink($post -> ID); ?>" title="<?php the_title(); ?>" class="<?php echo $thumb_icon; ?>"<?php echo (is_array($lightbox_gallery_items)) ? ' rel="prettyPhoto['.$lightbox_gallery_data[4].']"' : ''; ?>>
			<img src="<?php echo pk_build_image($image, $w - 12, ($h > 0) ? $h - $hp : 0, 1); ?>" />
			<span class="pk_image_button_overlay"></span>
		</a>
<?php
		if (is_array($lightbox_gallery_items)) : 
			
			for ($i = 0; $i < count($lightbox_gallery_items); $i++) : 
				
				if ($i == 0) continue;
				
				$item = explode('[pk_sep]', $lightbox_gallery_items[$i]);
?>
		<a href="<?php echo esc_url($item[1]); ?>" title="<?php echo strip_tags($item[0]); ?>" rel="prettyPhoto[<?php echo $lightbox_gallery_data[4]; ?>]"></a>
<?php
			endfor;
			
		endif;
		
	else : 
?>
		<img src="<?php echo pk_build_image($image, $w - 12, ($h > 0) ? $h - $hp : 0, 1); ?>" />
<?php
	endif;
?>
	</div>
<?php
	if (is_array($lightbox_gallery_items)) : 
?>
	<script type="text/javascript">
		/*<![CDATA[*/
		jQuery(document).ready(function() {
			jQuery("a[rel^='prettyPhoto[<?php echo $lightbox_gallery_data[4]; ?>]']").prettyPhoto({
				default_width:<?php echo $lightbox_gallery_data[0]; ?>,
				default_height:<?php echo $lightbox_gallery_data[1]; ?>,
				autoplay_slideshow:<?php echo ($lightbox_gallery_data[2] != 'false') ? 'true' : 'false'; ?>,
				slideshow:<?php echo (int)$lightbox_gallery_data[3] * 1000; ?>
			});
		});
		/*]]>*/
	</script>
<?php
	endif;
?>
</div>
<!-- pk end image -->
<?php

			endif;
			
			break;
			
		case 'audio' :
			
			echo do_shortcode('[pk_audio_player width="'.$w.'" height="'.(($h == 0) ?  floor(($w / 16) * 9) : $h).'" autoplay="'.$auto_play.'" cover="'.$image.'" audio_url="'.$audio[1].'"]');
			
			break;
			
		case 'html5' :
			
			echo do_shortcode('[pk_html5_player width="'.$w.'" height="'.(($h == 0) ?  floor(($w / 16) * 9) : $h).'" autoplay="'.$auto_play.'" cover="'.$image.'" mp4="'.$video[2].'" webm="'.$video[3].'" ogg="'.$video[4].'"]');
			
			break;
			
			
		case 'video' :
			
			echo do_shortcode('[pk_video_player width="'.$w.'" height="'.(($h == 0) ?  floor(($w / 16) * 9) : $h).'" autoplay="'.$auto_play.'" cover="'.$image.'" video_url="'.$video[2].'"]');
			
			break;
			
		case 'youtube_custom' :
			
			echo do_shortcode('[pk_youtube_custom_player width="'.$w.'" height="'.(($h == 0) ?  floor(($w / 16) * 9) : $h).'" autoplay="'.$auto_play.'" cover="'.$image.'" video_id="'.$video[2].'"]');
			
			break;
			
		case 'youtube' :
			
			echo do_shortcode('[pk_youtube_player width="'.$w.'" height="'.(($h == 0) ?  floor(($w / 16) * 9) : $h).'" autoplay="'.$auto_play.'" cover="'.$image.'" video_id="'.$video[2].'"]');
			
			break;
			
		case 'vimeo' :
			
			echo do_shortcode('[pk_vimeo_player width="'.$w.'" height="'.(($h == 0) ?  floor(($w / 16) * 9) : $h).'" autoplay="'.$auto_play.'" cover="'.$image.'" video_id="'.$video[2].'"]');
			
			break;
			
		case 'swf' :
			
			echo do_shortcode('[pk_swf_object width="'.$w.'" height="'.(($h == 0) ?  floor(($w / 16) * 9) : $h).'" flashvars="'.str_replace('"', '\'', $work_meta['swf_flashvars']).'" params="'.str_replace('"', '\'', $work_meta['swf_params']).'" swf_url="'.$swf.'" fp_version="'.$work_meta['swf_fp_version'].'"]');
			
			break;
	
	}
	
}

function pk_works_grid_item_read_more() {
	
?>
<a href="<?php the_permalink(); ?>" title="<?php _e('Read more &raquo;', 'pk_text_domain_front'); ?>" class="pk_button_small"><span><?php _e('Read more &raquo;', 'pk_text_domain_front'); ?></span></a>
<?php
	
}

function pk_works_grid_pagination() {
	
	global $pk_sidebar;
	global $pk_paged;
	global $wp_query;
	
?>
<span class="pk_clear_both"></span>

<!-- pk start pagination -->
<div class="pk_pagination pk_pagination_<?php echo ($pk_sidebar == 'none') ? 'full' : 'sidebar'; ?>">
	<?php pk_pagination($wp_query -> max_num_pages, $pk_paged, 2); ?>
</div>
<!-- pk end pagination -->
<?php
	
}

?>