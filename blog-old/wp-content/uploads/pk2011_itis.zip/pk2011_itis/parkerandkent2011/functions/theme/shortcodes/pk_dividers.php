<?php

/*
 * Clear both
*/

function pk_sc_clear_both($atts, $content = null) {
	
	return '<span class="pk_clear_both"></span>';
	
}

/*
 * Empty space
*/

function pk_sc_empty_space($atts, $content = null) {
	
	extract(shortcode_atts(array(
		'height' => ''
	), $atts));
	
	$style = '';
	
	if ($height != '' && $height != '0') {
		
		$style = ' style="height:'.$height.'px;"';
		
	}
	
	return '<div class="pk_empty_space"'.$style.'></div>';
	
}

/*
 * Divider
*/

function pk_sc_divider($atts, $content = null) {
	
	return '<div class="pk_divider"><hr /></div>';
	
}

/*
 * Divider top
*/

function pk_sc_divider_top($atts, $content = null) {
	
	return '<div class="pk_divider pk_top"><hr /><a href="#" title="">Top</a></div>';
	
}

add_shortcode('pk_clear_both', 'pk_sc_clear_both');
add_shortcode('pk_empty_space', 'pk_sc_empty_space');
add_shortcode('pk_divider', 'pk_sc_divider');
add_shortcode('pk_divider_top', 'pk_sc_divider_top');

?>