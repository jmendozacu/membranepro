<?php

function pk_blog_list_item_standard() {
	
	global $pk_sidebar;
	global $pk_show_posts_meta;
	global $pk_show_author_meta;
	global $pk_show_date_meta;
	global $pk_show_date_meta_links;
	global $pk_show_categories_meta;
	global $pk_show_tags_meta;
	global $pk_show_comments_meta;
	global $pk_show_full_posts;
	global $pk_show_read_more;
	global $pk_image_style;
	global $pk_image_icon;
	
	$image = pk_get_featured_image();
	
?>
<!-- ############# -->
<!-- pk start post -->
<!-- ############# -->
<div id="post-<?php the_ID(); ?>" <?php post_class('pk_entry pk_entry_full'); ?>>
<?php do_action('pk_ah_pre_'.((is_archive()) ? 'blog_archive' : ((is_search()) ? 'search' : 'blog')).'_list_item'); ?>

<!-- pk start post title -->
<h3 class="pk_entry_title"><a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" rel="bookmark"><?php the_title(); ?></a></h3>
<!-- pk end post title -->

<?php
	if ($pk_show_posts_meta == 'true') (get_post_type() == 'post') ? pk_blog_list_item_meta($pk_show_author_meta, $pk_show_date_meta, $pk_show_date_meta_links, $pk_show_categories_meta, $pk_show_tags_meta, $pk_show_comments_meta) : pk_custom_posts_list_item_meta($pk_show_author_meta, $pk_show_date_meta, $pk_show_categories_meta, $pk_show_tags_meta, $pk_show_comments_meta); 
	
	if ($image) pk_blog_list_item_featuered_image((($pk_sidebar == 'none') ? 940 : 690), $pk_image_style, $pk_image_icon, $image, false);
?>

<!-- pk start post entry content -->
<div class="pk_entry_content">
<?php
	if ($pk_show_full_posts == 'true') : 
		
		the_content(__('Read more &raquo;', 'pk_text_domain_front'), false);
		
	else : 
		
		add_filter('excerpt_length', 'pk_blog_excerpt_filter');
		add_filter('excerpt_more', 'pk_excerpt_more');
		
		the_excerpt();
		
		if ($pk_show_read_more == 'true') : 
?>
<a href="<?php the_permalink(); ?>" title="<?php _e('Read more &raquo;', 'pk_text_domain_front'); ?>" class="pk_button_small"><span><?php _e('Read more &raquo;', 'pk_text_domain_front'); ?></span></a>
<?php
		endif;
		
	endif;
?>
</div>
<!-- pk end post entry content -->

<?php do_action('pk_ah_after_'.((is_archive()) ? 'blog_archive' : ((is_search()) ? 'search' : 'blog')).'_list_item'); ?>
</div>
<!-- ########### -->
<!-- pk end post -->
<!-- ########### -->

<?php
	
}

function pk_blog_list_item_alternative() {
	
	global $pk_sidebar;
	global $pk_show_posts_meta;
	global $pk_show_author_meta;
	global $pk_show_date_meta;
	global $pk_show_date_meta_links;
	global $pk_show_categories_meta;
	global $pk_show_tags_meta;
	global $pk_show_comments_meta;
	global $pk_show_full_posts;
	global $pk_show_read_more;
	global $pk_image_style;
	global $pk_image_icon;
	
	$image = pk_get_featured_image();
	
	if (!$image) {
		
		pk_blog_list_item_standard();
		return;
		
	}
	
?>
<!-- ############# -->
<!-- pk start post -->
<!-- ############# -->
<div id="post-<?php the_ID(); ?>" <?php post_class('pk_entry pk_entry_full'); ?>>
<?php do_action('pk_ah_pre_'.((is_archive()) ? 'blog_archive' : ((is_search()) ? 'search' : 'blog')).'_list_item'); ?>

<div class="pk_one_third">
<?php
	if ($image) pk_blog_list_item_featuered_image((($pk_sidebar == 'none') ? 288 : 211), $pk_image_style, $pk_image_icon, $image, false);
?>

</div>

<div class="pk_two_third pk_last">

<!-- pk start post title -->
<h3 class="pk_entry_title"><a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" rel="bookmark"><?php the_title(); ?></a></h3>
<!-- pk end post title -->

<?php
	if ($pk_show_posts_meta == 'true') (get_post_type() == 'post') ? pk_blog_list_item_meta($pk_show_author_meta, $pk_show_date_meta, $pk_show_date_meta_links, $pk_show_categories_meta, $pk_show_tags_meta, $pk_show_comments_meta) : pk_custom_posts_list_item_meta($pk_show_author_meta, $pk_show_date_meta, $pk_show_categories_meta, $pk_show_tags_meta, $pk_show_comments_meta);
?>

<!-- pk start post entry content -->
<div class="pk_entry_content">
<?php
	if ($pk_show_full_posts == 'true') : 
		
		the_content(__('Read more &raquo;', 'pk_text_domain_front'), false);
		
	else : 
		
		add_filter('excerpt_length', 'pk_blog_excerpt_filter');
		add_filter('excerpt_more', 'pk_excerpt_more');
		
		the_excerpt();
		
		if ($pk_show_read_more == 'true') : 
?>
<a href="<?php the_permalink(); ?>" title="<?php _e('Read more &raquo;', 'pk_text_domain_front'); ?>" class="pk_button_small"><span><?php _e('Read more &raquo;', 'pk_text_domain_front'); ?></span></a>
<?php
		endif;
		
	endif;
?>
</div>
<!-- pk end post entry content -->

</div>

<?php do_action('pk_ah_after_'.((is_archive()) ? 'blog_archive' : ((is_search()) ? 'search' : 'blog')).'_list_item'); ?>
</div>
<!-- ########### -->
<!-- pk end post -->
<!-- ########### -->

<?php
	
}

function pk_blog_list_item_meta($show_author_meta, $show_date_meta, $show_date_meta_links, $show_categories_meta, $show_tags_meta, $show_comments_meta) {
	
	if ($show_comments_meta == 'true') : $s = 0;
?>
<!-- pk start post meta -->
<div class="pk_entry_meta">
	<div class="pk_four_fifth">
		<p><?php if ($show_author_meta == 'true') : ?><?php _e('By:', 'pk_text_domain_front'); ?> <?php the_author_posts_link(); ?><?php $s++; endif; ?><?php if ($show_date_meta == 'true') : ?><?php if ($s > 0) : ?><span class="pk_meta_divider">|</span><?php endif; ?><?php if ($show_date_meta_links == 'false') : echo get_the_date('d F, Y'); else : ?><a href="<?php echo get_day_link(get_the_time('Y'), get_the_time('m'), get_the_time('d')); ?>"><?php echo get_the_date('d'); ?></a> <a href="<?php echo get_month_link(get_the_time('Y'), get_the_time('m')); ?>"><?php echo get_the_date('F'); ?></a>, <a href="<?php echo get_year_link(get_the_time('Y')); ?>"><?php echo get_the_date('Y'); ?></a><?php $s++; endif; endif; ?><?php if ($show_categories_meta == 'true') : ?><?php if ($s > 0) : ?><span class="pk_meta_divider">|</span><?php $s++; endif; ?><?php _e('Categories: ', 'pk_text_domain_front'); the_category(' . '); ?><?php $s++; endif; ?><?php if ($show_tags_meta == 'true') : ?><?php the_tags((($s > 0) ? '<span class="pk_meta_divider">|</span>' : '').__('Tags: ', 'pk_text_domain_front'), ' . '); ?><?php endif; ?></p>
	</div>
	<div class="pk_one_fifth pk_last">
		<p><?php comments_popup_link(__('No comments', 'pk_text_domain_front'), __('1 Comment', 'pk_text_domain_front'), __('% Comments', 'pk_text_domain_front'), 'pk_meta_tot_comments', __('Comments closed', 'pk_text_domain_front')); ?></p>
	</div>
</div>
<!-- pk end post meta -->
<?php else : $s = 0; ?>
<!-- pk start post meta -->
<div class="pk_entry_meta">
	<p><?php if ($show_author_meta == 'true') : ?><?php _e('By:', 'pk_text_domain_front'); ?> <?php the_author_posts_link(); ?><?php $s++; endif; ?><?php if ($show_date_meta == 'true') : ?><?php if ($s > 0) : ?><span class="pk_meta_divider">|</span><?php endif; ?><?php if ($show_date_meta_links == 'false') : echo get_the_date('d F, Y'); else : ?><a href="<?php echo get_day_link(get_the_time('Y'), get_the_time('m'), get_the_time('d')); ?>"><?php echo get_the_date('d'); ?></a> <a href="<?php echo get_month_link(get_the_time('Y'), get_the_time('m')); ?>"><?php echo get_the_date('F'); ?></a>, <a href="<?php echo get_year_link(get_the_time('Y')); ?>"><?php echo get_the_date('Y'); ?></a><?php $s++; endif; endif; ?><?php if ($show_categories_meta == 'true') : ?><?php if ($s > 0) : ?><span class="pk_meta_divider">|</span><?php $s++; endif; ?><?php _e('Categories: ', 'pk_text_domain_front'); the_category(' . '); ?><?php $s++; endif; ?><?php if ($show_tags_meta == 'true') : ?><?php the_tags((($s > 0) ? '<span class="pk_meta_divider">|</span>' : '').__('Tags: ', 'pk_text_domain_front'), ' . '); ?><?php endif; ?></p>
</div>
<!-- pk end post meta -->
<?php
	endif;
	
}

function pk_custom_posts_list_item_meta($show_author_meta, $show_date_meta, $show_categories_meta, $show_tags_meta, $show_comments_meta) {
	
	switch (get_post_type()) {
			
		case 'works' :
		
			$post_taxonomy = 'taxonomy_works';
			break;
			
		default:
		
			$post_taxonomy = false;
		
	}
	
	if ($show_comments_meta == 'true') : $s = 0;
?>
<!-- pk start post meta -->
<div class="pk_entry_meta">
	<div class="pk_four_fifth">
		<p><?php if ($show_author_meta == 'true') : ?><?php _e('By:', 'pk_text_domain_front'); ?> <?php the_author_posts_link(); ?><?php $s++; endif; ?><?php if ($show_date_meta == 'true') : ?><?php if ($s > 0) : ?><span class="pk_meta_divider">|</span><?php endif; ?><?php echo get_the_date('d F, Y'); ?><?php $s++; endif; ?><?php if ($show_categories_meta == 'true') : ?><?php if ($post_taxonomy) : ?><?php if ($s > 0) : ?><span class="pk_meta_divider">|</span><?php endif; ?><?php _e('Categories: ', 'pk_text_domain_front'); the_terms(get_the_ID(), $post_taxonomy, '', ' . ', ''); ?><?php endif; endif; ?></p>
	</div>
	<div class="pk_one_fifth pk_last">
		<p><?php comments_popup_link(__('0', 'pk_text_domain_front'), __('1', 'pk_text_domain_front'), __('%', 'pk_text_domain_front'), 'pk_meta_tot_comments', __('Off', 'pk_text_domain_front')); ?></p>
	</div>
</div>
<!-- pk end post meta -->
<?php else : $s = 0; ?>
<!-- pk start post meta -->
<div class="pk_entry_meta">
	<p><?php if ($show_author_meta == 'true') : ?><?php _e('By:', 'pk_text_domain_front'); ?> <?php the_author_posts_link(); ?><?php $s++; endif; ?><?php if ($show_date_meta == 'true') : ?><?php if ($s > 0) : ?><span class="pk_meta_divider">|</span><?php endif; ?><?php echo get_the_date('d F, Y'); ?><?php $s++; endif; ?><?php if ($show_categories_meta == 'true') : ?><?php if ($post_taxonomy) : ?><?php if ($s > 0) : ?><span class="pk_meta_divider">|</span><?php endif; ?><?php _e('Categories: ', 'pk_text_domain_front'); the_terms(get_the_ID(), $post_taxonomy, '', ' . ', ''); ?><?php endif; endif; ?></p>
</div>
<!-- pk end post meta -->
<?php
	endif;
	
}

function pk_blog_list_item_featuered_image($w, $image_style, $image_icon, $image, $alternative_layout = false) {
	
	switch ($image_style) {
		
		case '16/9' :
			
			$h = floor(($w / 16) * 9);
			break;
			
		case '4/3' :
			
			$h = floor(($w / 4) * 3);
			break;
			
		case 'portrait' :
			
			$h = floor(($w / 3) * 4);
			break;
			
		case 'square' :
			
			$h = $w;
			break;
			
		case 'auto' :
			
			$h = 0;
			break;
		
	}
	
	$hp = floor(12 * ($h / $w));
			
	if ($image) :
		
?>

<!-- pk start post featured image -->
<div class="pk_image<?php if ($alternative_layout) : ?> pk_alignleft<?php endif; ?>" style="<?php echo (($w > 0) ? 'width:'.$w.'px;' : ''); echo (($h > 0) ? ' height:'.$h.'px;' : ''); ?>">
	<div class="pk_image_wrapper">
		<a href="<?php the_permalink(); ?>" title="<?php _e('Read more &raquo;', 'pk_text_domain_front'); ?>"<?php if ($image_icon != '') : ?> class="<?php echo $image_icon; ?>"<?php endif; ?>>
			<img src="<?php echo pk_build_image($image[0], $w - 12, ($h > 0) ? $h - $hp : 0, 1); ?>" />
			<span class="pk_image_button_overlay"></span>
		</a>
	</div>
</div>
<!-- pk end post featured image -->
<?php
			
	endif;
	
}

function pk_blog_pagination() {
	
	global $pk_sidebar;
	global $pk_paged;
	global $wp_query;
	
?>
<!-- pk start pagination -->
<div class="pk_pagination pk_pagination_<?php echo ($pk_sidebar == 'none') ? 'full' : 'sidebar'; ?>">
	<?php pk_pagination($wp_query -> max_num_pages, $pk_paged, 2); ?>
</div>
<!-- pk end pagination -->
<?php
	
}

?>