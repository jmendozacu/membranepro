<?php

/*
 * Get size
*/

function pk_sc_get_size($atts, $content = null) {
	
	return '<div class="pk_get_size">Size: 0px</div>';
	
}

add_shortcode('pk_get_size', 'pk_sc_get_size');

/*
 * AddThis
*/

function pk_scp_add_this($atts, $content = null) {
	
	return '
<!-- pk start share buttons -->
<span class="pk_clear_both"></span>
<div class="pk_add_this">
	<div class="addthis_toolbox addthis_default_style ">
		<a class="addthis_counter addthis_pill_style"></a>
		<a class="addthis_button_tweet" style="margin-left:15px;"></a>
		<a class="addthis_button_facebook_like"></a>
	</div>
	<script type="text/javascript">var addthis_config = {"data_track_clickback":true};</script>
	<script type="text/javascript" src="http://s7.addthis.com/js/250/addthis_widget.js#pubid='.pk_get_options('pk_general_options', 'general_add_this_username').'"></script>
</div>
<!-- pk end share buttons -->
';
	
}

add_shortcode('pk_add_this', 'pk_scp_add_this');

?>