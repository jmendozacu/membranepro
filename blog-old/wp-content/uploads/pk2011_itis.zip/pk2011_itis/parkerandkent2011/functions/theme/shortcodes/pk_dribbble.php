<?php

/*
 * Dribbble
*/

static $pk_dribble_feeds_counter = 0;

function pk_scp_dribbble_feed($atts, $content = null) {
	
	extract(shortcode_atts(array(
		'title' => '',
		'username' => '',
		'number' => '3'
	), $atts));
	
	global $pk_dribble_feeds_counter;
	
	$pk_dribble_feeds_counter++;
	
	$id = md5($pk_dribble_feeds_counter.$title.$username.$number);
	
	$output = '';
	
	include_once(ABSPATH.WPINC.'/feed.php');
	
	$feed = "http://dribbble.com/$username/shots.rss";
	
	$transients = get_option('pk_dribbble_transients');
	$transients[] = $id;
	update_option('pk_dribbble_transients', array_unique($transients));
	
	$cache = get_transient($id);
	
	if ($cache) {
		
		return $cache;
		
	} else {
		
		$feed = fetch_feed($feed);
		
	}
	
	if ($feed != '' && !is_wp_error($feed)) {
		
		$items = $feed -> get_items(0, $number);
		
		$output = '
<!-- pk start Dribbble widgets -->
<div class="pk_scp_dribbble pk_widget">';
	
	if ($title != '') $output .= '
	<h4>'.$title.'</h4>';
	
	$output .= '
	<ul class="pk_thumbnail_list">';
		
		foreach ($items as $item) {
			
			$author = $item -> get_author();
			$text = $item -> get_title();
			$link = $item -> get_permalink();
			$time = $item -> get_date('d F, Y');
			$description = $item -> get_description();
			
			preg_match("/src=\"(http.*(jpg|jpeg|gif|png))/", $description, $image_url);
			$image = $image_url[1];
			
			if ($image) {
				
				$output .= '
			<li>
				<h6>'.$text.'</h6>
				<div class="pk_image pk_alignleft" style="width:100%;">
					<div class="pk_image_wrapper">
						<a href="'.esc_url($link).'" title="'.$text.'" rel="external nofollow">
							<img src="'.$image.'" style="width:100%;" />
						</a>
					</div>
				</div>
				<small>'.__('By:', 'pk_text_domain_front').' '.$username.' . '.$time.'</small>
			</li>';
				
			}
		
		}
		
		$output .= '
	</ul>
</div>
<!-- pk end Dribbble widgets -->
';
		
	} else {
		
		$output .= '
<p>'.__('The Dribbble feed is either empty or unavailable. Please check back later.', 'pk_text_domain_front').'</p>';
		
	}
	
	set_transient($id, $output, 3600);
	
	return $output;
	
}

add_shortcode('pk_dribbble_feed', 'pk_scp_dribbble_feed');

/*
 * Cache management
*/

add_option('pk_dribbble_transients', array());

function pk_delete_dribbble_transients() {
	
	$transients = get_option('pk_dribbble_transients');
	
	foreach ($transients as $transient) {
		
		delete_transient($transient);
		
	}
	
}
	
add_action('publish_post', 'pk_delete_dribbble_transients');
add_action('save_post', 'pk_delete_dribbble_transients');
add_action('edit_post', 'pk_delete_dribbble_transients');
add_action('delete_post', 'pk_delete_dribbble_transients');
add_action('pk_ah_save_text_widget', 'pk_delete_dribbble_transients');
add_action('pk_ah_options_updated', 'pk_delete_dribbble_transients');
add_action('pk_ah_posts_sorted', 'pk_delete_dribbble_transients');

?>