<?php

function pk_intro() {
	
	global $pk_intro;
	global $query_string;
	
	if (is_search()) {
		
		parse_str($query_string, $temp_query_args);
		
		$temp_query_args['s'] = esc_html(get_search_query());
		$temp_query_args['posts_per_page'] = -1;
		$temp_query_args['category__not_in'] = explode(',', pk_get_options('pk_blog_options', 'blog_exclude_categories'));
		
		$temp_search = new WP_Query($temp_query_args);
		$search_result_count = $temp_search -> post_count;
	
?>
<h2 id="pk_page_title"><?php printf(__('Results for: %s', 'pk_text_domain_front'), get_search_query()); ?></h2>
<div id="pk_slogan"><?php printf(__('Found %s entries matching your search.', 'pk_text_domain_front'), $search_result_count); ?></div>	
<?php
		
		return;
		
	}
	
	if (!is_tax('taxonomy_works') && function_exists('is_post_type_archive') && is_post_type_archive('works')) {
	
?>
<h2 id="pk_page_title"><?php _e('Works Archive', 'pk_text_domain_front'); ?></h2>
<div id="pk_slogan"><?php _e('Below are listed all our latest works.', 'pk_text_domain_front'); ?></div>
<?php
		
		return;
		
	}
	
	if (is_tax('taxonomy_works')) {
		
		$term = get_term_by('slug', get_query_var('term'), get_query_var('taxonomy'));
		
?>
<h2 id="pk_page_title"><?php echo $term -> name; ?></h2>
<?php if ($term -> description) echo '<div id="pk_slogan">'.$term -> description.'</div>
';
		
		return;
		
	} 
	
	if (!is_tax() && !is_post_type_archive() && is_archive()) { 
		
?>
<h2 id="pk_page_title"><?php _e('Blog Archive', 'pk_text_domain_front'); ?></h2>
<div id="pk_slogan"><?php
		if (is_day()) :
			
			printf(__('You are viewing the daily archive for: %s', 'pk_text_domain_front'), get_the_date('d F, Y'));
			
		elseif (is_month()) :
			
			printf(__('You are viewing the monthly archive for: %s', 'pk_text_domain_front'), get_the_date('F, Y'));
			
		elseif (is_year()) : 
			
			printf(__('You are viewing the yearly archive for: %s', 'pk_text_domain_front'), get_the_date('Y'));
			
		elseif (is_category()) : 
			
			printf(__('You are viewing the category archive for: %s', 'pk_text_domain_front'), single_cat_title('', false));
			
		elseif (is_tag()) : 
			
			printf(__('You are viewing the tag archive for: %s', 'pk_text_domain_front'), single_tag_title('', false));
			
		elseif (is_author()) : 
			
			printf(__('You are viewing the author archive for: %s', 'pk_text_domain_front'), get_userdata(get_query_var('author')) -> display_name);
			
		else : 
			
			printf(__('You are viewing the archives for: %s', 'pk_text_domain_front'), get_bloginfo('name'));
			
		endif;
?></div>
<?php
		
		return;
		
	}
	
	if (is_home()) {
	
?>
<h2 id="pk_page_title"><?php _e('Blog', 'pk_text_domain_front'); ?></h2>
<div id="pk_slogan"><?php echo stripslashes($pk_intro); ?></div>
<?php
		
		return;
		
	}
	
	global $post;
	
	if ($post && $pk_intro != '') echo '<h2 id="pk_page_title">'.$post -> post_title.'</h2>
<div id="pk_slogan">'.stripslashes($pk_intro).'</div>
';
	
}

function pk_print_intro() {
	
	global $pk_intro;
	global $pk_sidebar;
	
	$show_intro_text = pk_get_options('pk_general_options', 'general_show_intro_text');
	
	if ($show_intro_text == 'false' || (isset($pk_intro) && $pk_intro == '')) {
		
		return;
		
	}
	
?>

<!-- pk start intro -->
<div id="pk_intro">

<!-- pk start intro contents -->
<div class="pk_center_box">
<?php
do_action('pk_ah_intro');
?>
</div>
<!-- pk end intro contents -->

</div>
<!-- pk end intro -->

<?php
	
}

?>