<?php

/*
 * Featured posts
*/
	
static $pk_featured_posts_counter = 0;

function pk_scp_featured_posts($atts, $content = null, $class) {
	
	extract(shortcode_atts(array(
		'title' => '',
		'posts' => '',
		'order_by' => 'date',
		'display_excerpt' => 'true',
		'display_thumb' => 'true',
		'list_icon' => 'arrow',
		'thumb_icon' => 'link',
		'thumb_width' => '160',
		'thumb_height' => '90'
	), $atts));
	
	global $pk_featured_posts_counter;
	
	$pk_featured_posts_counter++;
	
	$id = md5($pk_featured_posts_counter.$class.$title.$posts.$order_by.$display_excerpt.$display_thumb.$list_icon.$thumb_icon.$thumb_width.$thumb_height);
	
	$transients = get_option('pk_blog_sc_transients');
	$transients[] = $id;
	update_option('pk_blog_sc_transients', array_unique($transients));
	
	$cache = get_transient($id);
	
	if ($cache) {
		
		return $cache;
		
	}
	
	$display_excerpt = ($display_excerpt == 'true') ? 1 : 0;
	$display_thumb = ($display_thumb == 'true') ? 1 : 0;
	
	$thumb_width = (int)$thumb_width;
	$thumb_height = (int)$thumb_height;
	
	$posts = explode(',', $posts);
	
	$output = '';
	
	$r = new WP_Query(array('post_type' => 'post', 'posts_per_page' => count($posts), 'post__in' => $posts, 'nopaging' => 0, 'post_status' => 'publish', 'ignore_sticky_posts' => 1, 'orderby' => $order_by, 'order' => 'DESC'));
	
	if ($r -> have_posts()) : 
	
	$output = '
<!-- pk start featured posts -->
<div class="pk_scp_featured_posts">';
	
	if ($title != '') $output .= '
	<h4>'.$title.'</h4>';
	
	$output .= '
	<ul class="'.((!$display_thumb && !$display_excerpt) ? 'pk_underline_list pk_clear_list' : 'pk_thumbnail_list').((!$display_thumb && $list_icon != '') ? ' pk_'.$list_icon.'_list' : '').'">';
	
	while ($r -> have_posts()) : $r -> the_post();
		
		if ($display_thumb) : 
			
			$image = pk_get_featured_image();
			
			$output .= '
			<li>';
			
			if ($image) : 
			$output .= '
			<div class="pk_image pk_alignleft" style="width:'.$thumb_width.'px; height:'.$thumb_height.'px;">
				<div class="pk_image_wrapper">
					<a href="'.get_permalink().'" title="'.__('Read more &raquo;', 'pk_text_domain_front').'"'.(($thumb_icon != '') ? ' class="pk_'.$thumb_icon.'_icon"' : '').'>
						<img src="'.pk_build_image($image[0], $thumb_width - 12, $thumb_height - 12, 1).'" />
						<span class="pk_image_button_overlay"></span>
					</a>
				</div>
			</div>';
			endif;
			$output .= '
			<a href="'.get_permalink().'" title="'.esc_attr(get_the_title() ? get_the_title() : get_the_ID()).'">';
			
			if (get_the_title() && !$display_excerpt) : 
				
				$output .= get_the_title().'</h5></a>';
				
			else : 
				
				$output .= '<h5>'.get_the_title().'</h5></a>';
				
				add_filter('excerpt_length', 'pk_shortcodes_excerpt_filter');
				add_filter('excerpt_more', 'pk_excerpt_more');
				
				$output .= get_the_excerpt();
				
			endif;
			
			$output .= '
			</li>';
			
		else : 
			
			$output .= '
			<li><a href="'.get_permalink().'" title="'.esc_attr(get_the_title() ? get_the_title() : get_the_ID()).'">';
			
			if (get_the_title() && !$display_excerpt) : 
				
				$output .= get_the_title().'</h5></a>';
				
			else : 
				
				$output .= '<h5>'.get_the_title().'</h5></a>';
				
				add_filter('excerpt_length', 'pk_shortcodes_excerpt_filter');
				add_filter('excerpt_more', 'pk_excerpt_more');
				
				$output .= get_the_excerpt();
				
			endif;
			
			$output .= '</li>';
			
		endif;
		
	endwhile;
	
	$output .= '
	</ul>
</div>
<!-- pk end featured posts -->
';
	
	set_transient($id, $output, 3600);
	
	endif;
	
	wp_reset_postdata();
	
	return $output;
	
}

add_shortcode('pk_featured_posts', 'pk_scp_featured_posts');

/*
 * Popular posts
*/

static $pk_popular_posts_counter = 0;

function pk_scp_popular_posts($atts, $content = null, $class) {
	
	extract(shortcode_atts(array(
		'title' => '',
		'number' => 5,
		'display_excerpt' => 'true',
		'display_thumb' => 'true',
		'list_icon' => 'arrow',
		'thumb_icon' => 'link',
		'thumb_width' => '160',
		'thumb_height' => '90'
	), $atts));
	
	global $pk_popular_posts_counter;
	
	$pk_popular_posts_counter++;
	
	$id = md5($pk_popular_posts_counter.$class.$title.$number.$display_excerpt.$display_thumb.$list_icon.$thumb_icon.$thumb_width.$thumb_height);
	
	$transients = get_option('pk_blog_sc_transients');
	$transients[] = $id;
	update_option('pk_blog_sc_transients', array_unique($transients));
	
	$cache = get_transient($id);
	
	if ($cache) {
		
		return $cache;
		
	}
	
	$display_excerpt = ($display_excerpt == 'true') ? 1 : 0;
	$display_thumb = ($display_thumb == 'true') ? 1 : 0;
	
	$thumb_width = (int)$thumb_width;
	$thumb_height = (int)$thumb_height;
	
	$output = '';
	
	$r = new WP_Query(array('posts_per_page' => $number, 'category__not_in' => explode(',', pk_get_options('pk_blog_options', 'blog_exclude_categories')), 'nopaging' => 0, 'post_status' => 'publish', 'ignore_sticky_posts' => 1, 'orderby' => 'comment_count', 'order' => 'DESC'));
	
	if ($r -> have_posts()) : 
	
	$output = '
<!-- pk start popular posts -->
<div class="pk_scp_popular_posts">';
	
	if ($title != '') $output .= '
	<h4>'.$title.'</h4>';
	
	$output .= '
	<ul class="'.((!$display_thumb && !$display_excerpt) ? 'pk_underline_list pk_clear_list' : 'pk_thumbnail_list').((!$display_thumb) ? ' pk_'.$list_icon.'_list' : '').'">';
	
	while ($r -> have_posts()) : $r -> the_post();
		
		if ($display_thumb) : 
			
			$image = pk_get_featured_image();
			
			$output .= '
			<li>';
			
			if ($image) : 
			$output .= '
			<div class="pk_image pk_alignleft" style="width:'.$thumb_width.'px; height:'.$thumb_height.'px;">
				<div class="pk_image_wrapper">
					<a href="'.get_permalink().'" title="'.__('Read more &raquo;', 'pk_text_domain_front').'"'.(($thumb_icon != '') ? ' class="pk_'.$thumb_icon.'_icon"' : '').'>
						<img src="'.pk_build_image($image[0], $thumb_width - 12, $thumb_height - 12, 1).'" />
						<span class="pk_image_button_overlay"></span>
					</a>
				</div>
			</div>';
			endif;
			$output .= '
			<a href="'.get_permalink().'" title="'.esc_attr(get_the_title() ? get_the_title() : get_the_ID()).'">';
			
			if (get_the_title() && !$display_excerpt) : 
				
				$output .= get_the_title().'</h5></a>';
				
			else : 
				
				$output .= '<h5>'.get_the_title().'</h5></a>';
				
				add_filter('excerpt_length', 'pk_shortcodes_excerpt_filter');
				add_filter('excerpt_more', 'pk_excerpt_more');
				
				$output .= get_the_excerpt();
				
			endif;
			
			$output .= '
			</li>';
			
		else : 
			
			$output .= '
			<li><a href="'.get_permalink().'" title="'.esc_attr(get_the_title() ? get_the_title() : get_the_ID()).'">';
			
			if (get_the_title() && !$display_excerpt) : 
				
				$output .= get_the_title().'</h5></a>';
				
			else : 
				
				$output .= '<h5>'.get_the_title().'</h5></a>';
				
				add_filter('excerpt_length', 'pk_shortcodes_excerpt_filter');
				add_filter('excerpt_more', 'pk_excerpt_more');
				
				$output .= get_the_excerpt();
				
			endif;
			
			$output .= '</li>';
			
		endif;
		
	endwhile;
	
	$output .= '
	</ul>
</div>
<!-- pk end popular posts -->
';
	
	set_transient($id, $output, 3600);
	
	endif;
	
	wp_reset_postdata();
	
	return $output;
	
}

add_shortcode('pk_popular_posts', 'pk_scp_popular_posts');

/*
 * Recent posts
*/

static $pk_recent_posts_counter = 0;

function pk_scp_recent_posts($atts, $content = null, $class) {
	
	extract(shortcode_atts(array(
		'title' => '',
		'number' => 5,
		'display_excerpt' => 'true',
		'display_thumb' => 'true',
		'list_icon' => 'arrow',
		'thumb_icon' => 'link',
		'thumb_width' => '160',
		'thumb_height' => '90'
	), $atts));
	
	global $pk_recent_posts_counter;
	
	$pk_recent_posts_counter++;
	
	$id = md5($pk_recent_posts_counter.$class.$title.$number.$display_excerpt.$display_thumb.$list_icon.$thumb_icon.$thumb_width.$thumb_height);
	
	$transients = get_option('pk_blog_sc_transients');
	$transients[] = $id;
	update_option('pk_blog_sc_transients', array_unique($transients));
	
	$cache = get_transient($id);
	
	if ($cache) {
		
		return $cache;
		
	}
	
	$display_excerpt = ($display_excerpt == 'true') ? 1 : 0;
	$display_thumb = ($display_thumb == 'true') ? 1 : 0;
	
	$thumb_width = (int)$thumb_width;
	$thumb_height = (int)$thumb_height;
	
	$output = '';
	
	$r = new WP_Query(array('posts_per_page' => $number, 'category__not_in' => explode(',', pk_get_options('pk_blog_options', 'blog_exclude_categories')), 'nopaging' => 0, 'post_status' => 'publish', 'ignore_sticky_posts' => 1));
	
	if ($r -> have_posts()) : 
	
	$output = '
<!-- pk start recent posts -->
<div class="pk_scp_recent_posts">';
	
	if ($title != '') $output .= '
	<h4>'.$title.'</h4>';
	
	$output .= '
	<ul class="'.((!$display_thumb && !$display_excerpt) ? 'pk_underline_list pk_clear_list' : 'pk_thumbnail_list').((!$display_thumb) ? ' pk_'.$list_icon.'_list' : '').'">';
	
	while ($r -> have_posts()) : $r -> the_post();
		
		if ($display_thumb) : 
			
			$image = pk_get_featured_image();
			
			$output .= '
			<li>';
			
			if ($image) : 
			$output .= '
			<div class="pk_image pk_alignleft" style="width:'.$thumb_width.'px; height:'.$thumb_height.'px;">
				<div class="pk_image_wrapper">
					<a href="'.get_permalink().'" title="'.__('Read more &raquo;', 'pk_text_domain_front').'"'.(($thumb_icon != '') ? ' class="pk_'.$thumb_icon.'_icon"' : '').'>
						<img src="'.pk_build_image($image[0], $thumb_width - 12, $thumb_height - 12, 1).'" />
						<span class="pk_image_button_overlay"></span>
					</a>
				</div>
			</div>';
			endif;
			$output .= '
			<a href="'.get_permalink().'" title="'.esc_attr(get_the_title() ? get_the_title() : get_the_ID()).'">';
			
			if (get_the_title() && !$display_excerpt) : 
				
				$output .= get_the_title().'</h5></a>';
				
			else : 
				
				$output .= '<h5>'.get_the_title().'</h5></a>';
				
				add_filter('excerpt_length', 'pk_shortcodes_excerpt_filter');
				add_filter('excerpt_more', 'pk_excerpt_more');
				
				$output .= get_the_excerpt();
				
			endif;
			
			$output .= '
			</li>';
			
		else : 
			
			$output .= '
			<li><a href="'.get_permalink().'" title="'.esc_attr(get_the_title() ? get_the_title() : get_the_ID()).'">';
			
			if (get_the_title() && !$display_excerpt) : 
				
				$output .= get_the_title().'</h5></a>';
				
			else : 
				
				$output .= '<h5>'.get_the_title().'</h5></a>';
				
				add_filter('excerpt_length', 'pk_shortcodes_excerpt_filter');
				add_filter('excerpt_more', 'pk_excerpt_more');
				
				$output .= get_the_excerpt();
				
			endif;
			
			$output .= '</li>';
			
		endif;
		
	endwhile;
	
	$output .= '
	</ul>
</div>
<!-- pk end recent posts -->
';
	
	set_transient($id, $output, 3600);
	
	endif;
	
	wp_reset_postdata();
	
	return $output;
	
}

add_shortcode('pk_recent_posts', 'pk_scp_recent_posts');

/*
 * Related posts
*/

static $pk_related_posts_counter = 0;

function pk_scp_related_posts($atts, $content = null, $class) {
	
	extract(shortcode_atts(array(
		'title' => '',
		'number' => 5,
		'display_excerpt' => 'true',
		'display_thumb' => 'true',
		'list_icon' => 'arrow',
		'thumb_icon' => 'link',
		'thumb_width' => '160',
		'thumb_height' => '90'
	), $atts));
	
	global $post;
	
	if (isset($post) && $post -> post_type == 'post') {
		
		global $pk_related_posts_counter;
		
		$pk_related_posts_counter++;
		
		$id = md5($pk_related_posts_counter.$class.$title.$number.$display_excerpt.$display_thumb.$list_icon.$thumb_icon.$thumb_width.$thumb_height);
		
		$transients = get_option('pk_blog_sc_transients');
		$transients[] = $id;
		update_option('pk_blog_sc_transients', array_unique($transients));
		
		$cache = get_transient($id);
		
		if ($cache) {
			
			return $cache;
			
		}
		
		$display_excerpt = ($display_excerpt == 'true') ? 1 : 0;
		$display_thumb = ($display_thumb == 'true') ? 1 : 0;
		
		$thumb_width = (int)$thumb_width;
		$thumb_height = (int)$thumb_height;
		
		$output = '';
		
		$tags = wp_get_post_tags($post -> ID);
		$tag_ids = array();
		
	}
	
	if (isset($tags) && $tags) {
		
		$tagcount = count($tags);
		
		for ($i = 0; $i < $tagcount; $i++) {
			
			$tag_ids[$i] = $tags[$i] -> term_id;
			
		}
		
		$r = new WP_Query(array('post_type' => $post -> post_type, 'posts_per_page' => $number, 'category__not_in' => explode(',', pk_get_options('pk_blog_options', 'blog_exclude_categories')), 'tag__in' => $tag_ids, 'post__not_in' => array($post -> ID), 'nopaging' => 0, 'post_status' => 'publish', 'ignore_sticky_posts' => 1, 'orderby' => 'comment_count', 'order' => 'DESC'));
		
		if ($r -> have_posts()) : 
		
		$output = '
<!-- pk start related posts -->
<div class="pk_scp_related_posts">';
		
		if ($title != '') $output .= '
	<h4>'.$title.'</h4>';
		
		$output .= '
	<ul class="'.((!$display_thumb && !$display_excerpt) ? 'pk_underline_list pk_clear_list' : 'pk_thumbnail_list').((!$display_thumb) ? ' pk_'.$list_icon.'_list' : '').'">';
		
		while ($r -> have_posts()) : $r -> the_post();
			
			if ($display_thumb) : 
				
				$image = pk_get_featured_image();
				
				$output .= '
			<li>';
				
				if ($image) : 
				$output .= '
			<div class="pk_image pk_alignleft" style="width:'.$thumb_width.'px; height:'.$thumb_height.'px;">
				<div class="pk_image_wrapper">
					<a href="'.get_permalink().'" title="'.__('Read more &raquo;', 'pk_text_domain_front').'"'.(($thumb_icon != '') ? ' class="pk_'.$thumb_icon.'_icon"' : '').'>
						<img src="'.pk_build_image($image[0], $thumb_width - 12, $thumb_height - 12, 1).'" />
						<span class="pk_image_button_overlay"></span>
					</a>
				</div>
			</div>';
				endif;
				$output .= '
			<a href="'.get_permalink().'" title="'.esc_attr(get_the_title() ? get_the_title() : get_the_ID()).'">';
				
				if (get_the_title() && !$display_excerpt) : 
					
					$output .= get_the_title().'</h5></a>';
					
				else : 
					
					$output .= '<h5>'.get_the_title().'</h5></a>';
					
					add_filter('excerpt_length', 'pk_shortcodes_excerpt_filter');
					add_filter('excerpt_more', 'pk_excerpt_more');
					
					$output .= get_the_excerpt();
					
				endif;
				
				$output .= '
			</li>';
			
			else : 
				
				$output .= '
			<li><a href="'.get_permalink().'" title="'.esc_attr(get_the_title() ? get_the_title() : get_the_ID()).'">';
				
				if (get_the_title() && !$display_excerpt) : 
					
					$output .= get_the_title().'</h5></a>';
					
				else : 
					
					$output .= '<h5>'.get_the_title().'</h5></a>';
					
					add_filter('excerpt_length', 'pk_shortcodes_excerpt_filter');
					add_filter('excerpt_more', 'pk_excerpt_more');
					
					$output .= get_the_excerpt();
					
				endif;
				
				$output .= '</li>';
				
			endif;
			
		endwhile;
		
		$output .= '
	</ul>
</div>
<!-- pk end related posts -->
';
		
		set_transient($id, $output, 3600);
		
		endif;
		
		wp_reset_postdata();
		
		return $output;
		
	}
	
}

add_shortcode('pk_related_posts', 'pk_scp_related_posts');

/*
 * Cache management
*/

add_option('pk_blog_sc_transients', array());

function pk_delete_blog_sc_transients() {
	
	$transients = get_option('pk_blog_sc_transients');
	
	foreach ($transients as $transient) {
		
		delete_transient($transient);
		
	}
	
}
	
add_action('publish_post', 'pk_delete_blog_sc_transients');
add_action('save_post', 'pk_delete_blog_sc_transients');
add_action('edit_post', 'pk_delete_blog_sc_transients');
add_action('delete_post', 'pk_delete_blog_sc_transients');
add_action('pk_ah_save_text_widget', 'pk_delete_blog_sc_transients');
add_action('pk_ah_options_updated', 'pk_delete_blog_sc_transients');
add_action('pk_ah_posts_sorted', 'pk_delete_blog_sc_transients');

?>