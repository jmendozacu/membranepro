<?php

function pk_comments_navigation($navigation) {
	
	if (!$navigation) return;
	
	$button_prev = (get_previous_comments_link(__('Previous comments', 'pk_text_domain_front'))) ? str_replace('<a', '<a class="pk_button_prev pk_light_icon"', get_previous_comments_link(__('Previous comments', 'pk_text_domain_front'))) : '<span class="pk_button_prev pk_light_icon"></span>';
	$button_next = (get_next_comments_link(__('Next comments', 'pk_text_domain_front'))) ? str_replace('<a', '<a class="pk_button_next pk_light_icon"', get_next_comments_link(__('Next comments', 'pk_text_domain_front'))) : '<span class="pk_button_next pk_light_icon"></span>';
	
?>

<!-- pk start comments pagination -->
<div class="pk_pagination pk_pagination_comments">
	<?php echo $button_prev;
?>

	<div class="pk_pages"><?php
	
	for ($i = 0; $i < count($navigation); $i++) {
		
		if ($i > 0) {
			
			echo '<span> / </span>';
			
		}
		
		echo str_replace('current', 'pk_current_page', $navigation[$i]);
		
	}
	
?></div>
	<?php echo $button_next;
?>

</div>
<!-- pk end comments pagination -->
<?php
	
}

function pk_comments_list($comment, $args, $depth) {
	
	$GLOBALS['comment'] = $comment;
	
	if (get_comment_type() != 'comment') :
		
		pk_trackbacks_list($comment, $args, $depth);
		
	else :
	
?>

<!-- pk start comment -->
<li id="li-comment-<?php comment_ID(); ?>" <?php comment_class('pk_comment'); ?>>
	<div id="comment-<?php comment_ID(); ?>" class="pk_message">
<?php
		if (get_avatar($comment, '52')) : 
?>
		<div class="pk_image pk_alignleft">
			<div class="pk_image_wrapper">
				<?php
			echo get_avatar($comment, '52');
?>

			</div>
		</div>
		<span class="pk_arrow"></span>
		<div class="pk_comment_text">
<?php
			if ($comment -> comment_approved == 0) : 
?>
			<p><em><?php _e('Your comment is awaiting moderation.', 'pk_text_domain_front'); ?></em></p>
<?php
			endif;
?>
			<?php comment_text();
?>
			<p class="pk_comment_meta"><?php _e('By: ', 'pk_text_domain_front'); comment_author_link(); ?> . <?php printf(__('%s', 'pk_text_domain_front'), get_comment_date()); ?> . <?php printf(__('%s', 'pk_text_domain_front'), get_comment_time()); edit_comment_link(__('Edit', 'pk_text_domain_front'), ' . '); ?></p>
			<?php comment_reply_link(array_merge($args, array('reply_text' => 'Reply', 'depth' => $depth, 'max_depth' => $args['max_depth']))); ?>
		</div>
<?php
		else : 
		
			if ($comment -> comment_approved == 0) : 
?>
		<p><em><?php _e('Your comment is awaiting moderation.', 'pk_text_domain_front'); ?></em></p>
<?php
			endif;
?>
		<?php comment_text();
?>
		<p class="pk_comment_meta"><?php _e('By: ', 'pk_text_domain_front'); comment_author_link(); ?> . <?php printf(__('%s', 'pk_text_domain_front'), get_comment_date()); ?> . <?php printf(__('%s', 'pk_text_domain_front'), get_comment_time()); edit_comment_link(__('Edit', 'pk_text_domain_front'), ' . '); ?></p>
		<?php comment_reply_link(array_merge($args, array('reply_text' => 'Reply', 'depth' => $depth, 'max_depth' => $args['max_depth']))); ?>
<?php
		endif;
?>
	</div>
<?php	
	endif;
	
}

function pk_trackbacks_list($comment, $args, $depth) {
	
	$GLOBALS['comment'] = $comment;
	
?>
<!-- pk start trackback comment -->
<li id="li-trackback-comment-<?php comment_ID(); ?>" <?php comment_class('pk_comment'); ?>>
	<div id="trackback-comment-<?php comment_ID(); ?>" class="pk_message">
		<p class="pk_comment_meta"><?php _e('Pingback: ', 'pk_text_domain_front'); comment_author_link(); ?> . <?php printf(__('%s', 'pk_text_domain_front'), get_comment_date()); ?> . <?php printf(__('%s', 'pk_text_domain_front'), get_comment_time()); ?></p>
	</div>
<?php
	
}

function pk_check_referrer() {
	
	if (!isset($_SERVER['HTTP_REFERER']) || $_SERVER['HTTP_REFERER'] == '') {
		
		wp_die('Please enable referrers in your browser!');
		
	}
	
}
 
add_action('check_comment_flood', 'pk_check_referrer');

?>