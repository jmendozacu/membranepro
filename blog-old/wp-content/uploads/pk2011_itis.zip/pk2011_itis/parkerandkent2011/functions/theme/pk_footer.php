<?php

function pk_footer_widgets_area() {
	
	global $pk_footer_profile;
	
	$pk_footer_profiles =  get_option('pk_footer_options_profiles');
	
	if (!$pk_footer_profile || $pk_footer_profile == '' || !in_array($pk_footer_profile, $pk_footer_profiles)) {
			
			$pk_footer_profile = get_option('pk_footer_options_active_profile');
			
	}

	$footer_layout = pk_get_options('pk_footer_options', 'footer_widget_area_layout', $pk_footer_profile);
	
	if ($footer_layout != '' && pk_get_options('pk_footer_options', 'footer_show_widget_area', $pk_footer_profile) == 'true') {
		
		echo '
<!-- pk start extra content -->
<div id="pk_extra_content">

<!-- pk start extra content inner -->
<div class="pk_inner">
';
		
		do_action('pk_ah_pre_footer_widgets_area');

		if (pk_get_options('pk_footer_options', 'footer_widget_area_heading', $pk_footer_profile) != '') {
			
			echo '
<h3 class="pk_heading_underline">'.pk_get_options('pk_footer_options', 'footer_widget_area_heading', $pk_footer_profile).'</h3>
<span class="pk_empty_space"></span>
';
			
		}
		
		$footer_layout_columns = explode('[pk_data_sep]', $footer_layout);
		$footer_layout_columns = explode(',', $footer_layout_columns[0]);
		
		for ($i = 1; $i <= count($footer_layout_columns); $i++) {
			
			echo '
<!-- pk start extra content column -->
<div class="'.$footer_layout_columns[$i - 1].(($i == count($footer_layout_columns)) ? ' pk_last' : '').'">

';
			
			if (function_exists('dynamic_sidebar') && dynamic_sidebar('footer_column_'.$i.'_'.md5($pk_footer_profile))) : endif; 
			
			echo '</div>
<!-- pk end extra content column -->
';
			
		}
		
		do_action('pk_ah_after_footer_widgets_area');
		
		echo '
</div>
<!-- pk end extra content inner -->

</div>
<!-- pk end extra content -->
';
		
	}
	
}

function pk_footer_navigation() {
	
	$separator = pk_get_options('pk_navigation_options', 'footer_navigation_separator');
	
	if ($separator == '') {
		
		$separator = '|';
		
	}
	
	if (pk_get_options('pk_navigation_options', 'footer_show_navigation') != 'false') {
		
		$output = wp_nav_menu(array('echo' => false, 'theme_location' => 'pk_footer_menu', 'container' => '', 'menu_class' => 'pk_footer_menu', 'after' => ' '.$separator, 'depth' => 1, 'fallback_cb' => 'pk_page_menu_footer'));
		
		echo str_replace('</ul>', '<li class="pk_last"><a href="#" title="top" class="pk_button_circle pk_button_top">top</a></li></ul>', $output);
		
	}
	
}

function pk_page_menu_footer() {
	
	$footer_navigation_exclude_pages = pk_get_options('pk_navigation_options', 'footer_navigation_exclude_pages');
	
	$separator = pk_get_options('pk_navigation_options', 'footer_navigation_separator');
	
	if ($separator == '') {
		
		$separator = '|';
		
	}
	
	echo str_replace(array('</li>', '<div class="menu"><ul>', '<li >', '</ul></div>'), array(' '.$separator.'</li>', '<ul class="pk_footer_menu">', '<li>', '<li class="pk_last"><a href="#" title="top" class="pk_button_circle pk_button_top">top</a></li></ul>'), wp_page_menu(array('echo' => false, 'depth' => 1, 'show_home' => false, 'exclude' => $footer_navigation_exclude_pages)));
	
}

function pk_footer_social_networks() {
	
	global $pk_footer_profile;
	
	$social_networks = pk_get_options('pk_footer_options', 'footer_social_networks', $pk_footer_profile);
	
	if ($social_networks == '') return;
	
	$social_networks = explode('[pk_data_sep]', $social_networks);
	
?>
<ul class="pk_footer_sn">
<?php
	
	foreach ($social_networks as $social_network) {
		
		$social_network = explode(',', $social_network);
		 
?>
<li><a href="<?php echo esc_url($social_network[2]); ?>" title="<?php echo $social_network[0]; ?>"><img src="<?php echo esc_url($social_network[1]); ?>" alt="<?php echo $social_network[0]; ?>" /></a></li>
<?php
		
	}
	
?>
</ul>
<?php
	
}

function pk_footer_copyright() {
	
	global $pk_footer_profile;
	
	$footer_copyright_text = stripslashes(pk_get_options('pk_footer_options', 'footer_copyright_text', $pk_footer_profile));
	
	if ($footer_copyright_text == '') {
		
		return;
		
	}
	
	echo '<p class="pk_copyright">'.esc_attr($footer_copyright_text).'</p>
';
	
}

?>