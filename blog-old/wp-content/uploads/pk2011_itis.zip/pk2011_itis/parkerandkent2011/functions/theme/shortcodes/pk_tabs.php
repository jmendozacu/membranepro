<?php

/*
 * Tabs
*/

function pk_sc_tabs($atts, $content = null, $class) {
	
	extract(shortcode_atts(array(
		'title' => '',
		'width' => '',
		'align' => 'none'
	), $atts));
	
	global $tabs;
	global $tabs_counter;
	
	$tabs = array();
	$tabs_counter = 0;
	
	($width != '' && $width != '0') ? $width = ' style="width:'.$width.'px;"' : $width = ' style="width:100%;"';
	
	do_shortcode($content);
	
	foreach($tabs as $tab) {
		
		$l[] = '<li><a title="'.$tab['title'].'" href="#">'.$tab['title'].'</a></li>';
		$t[] = '<div class="pk_tab">'.do_shortcode($tab['content']).'</div>';
		
	}
	
	return '<div class="'.$class.' pk_align'.strtolower($align).'"'.$width.'>'.(($title != '') ? '<h4 class="pk_tabs_label">'.$title.'</h4>' : '').'<ul class="pk_tabs_navigation">'.implode('', $l).'</ul><div class="pk_tabs">'.implode('', $t).'</div></div>';
	
}

add_shortcode('pk_minimal_tabs', 'pk_sc_tabs');
add_shortcode('pk_boxed_tabs', 'pk_sc_tabs');

/*
 * Tab
*/

function pk_sc_tab($atts, $content = null) {
	
	extract(shortcode_atts(array(
		'title' => ''
	), $atts));
	
	global $tabs;
	global $tabs_counter;
	
	$tabs[$tabs_counter] = array('title' => $title, 'content' => $content);
	
	$tabs_counter++;
	
}

add_shortcode('pk_tab', 'pk_sc_tab');

?>