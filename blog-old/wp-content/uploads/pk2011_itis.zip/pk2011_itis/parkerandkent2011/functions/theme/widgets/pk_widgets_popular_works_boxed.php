<?php

class PK_Widget_Popular_Works_Boxed extends WP_Widget {
	
	function PK_Widget_Popular_Works_Boxed() {
		
		$widget_ops = array('classname' => 'widget_popular_works_boxed', 'description' => __('Displays the most popular works.', 'pk_text_domain'));
		$this -> WP_Widget('pk-popular-works-boxed', __('Popular Works Boxed', 'pk_text_domain'), $widget_ops);
		$this -> alt_option_name = 'widget_popular_works_boxed';

		add_action('save_post', array(&$this, 'flush_widget_cache'));
		add_action('deleted_post', array(&$this, 'flush_widget_cache'));
		add_action('switch_theme', array(&$this, 'flush_widget_cache'));
		
	}

	function widget($args, $instance) {
		
		$cache = wp_cache_get('widget_popular_works_boxed', 'widget');
		
		$title = apply_filters('widget_title', $instance['title']);
		
		if (empty($title)) $title = false;
		
		$number = absint($instance['number']);
		
		$display_excerpt = (isset($instance['display_excerpt']) && $instance['display_excerpt']) ? 1 : 0;
		$display_thumb = (isset($instance['display_thumb']) && $instance['display_thumb']) ? 1 : 0;
		$thumb_icon = (isset($instance['thumb_icon']) && !empty($instance['thumb_icon'])) ? $instance['thumb_icon'] : '';

		if (!is_array($cache)) {
			
			$cache = array();
			
		}

		if (isset($cache[$args['widget_id']])) {
			
			echo $cache[$args['widget_id']];
			return;
			
		}
		
		ob_start();
		extract($args);
		
		remove_filter('pre_get_posts', 'pk_pre_get_posts');
		
		$r = new WP_Query(array('post_type' => 'works', 'posts_per_page' => $number, 'nopaging' => 0, 'post_status' => 'publish', 'ignore_sticky_posts' => 1, 'orderby' => 'comment_count', 'order' => 'DESC'));
		
		if ($r -> have_posts()) : 
			
			echo '<!-- pk start pk-popular-works-boxed widget -->
'.$before_widget.'
	<div class="pk_titled_widget">
		<div class="pk_widget_title">
			<span class="pk_left_corner"></span>
			<span class="pk_right_corner"></span>
			';
			
			if ($title) echo $before_title.$title.$after_title.'
		</div>';
?>

		<div class="pk_widget_content">
			<ul>
<?php
				while ($r -> have_posts()) : 
					
					$r -> the_post();
					
					if ($display_thumb) : 
						
						$image = pk_get_featured_image();
?>
				<li>
<?php
						if ($image) : 
?>
					<div class="pk_image">
						<div class="pk_image_wrapper">
							<a href="<?php the_permalink(); ?>" title="<?php _e('Read more &raquo;', 'pk_text_domain_front'); ?>" <?php if ($thumb_icon != '') : ?>class="<?php echo $thumb_icon; ?>"<?php endif; ?>>
								<img src="<?php echo $image[0]; ?>" />
								<span class="pk_image_button_overlay"></span>
							</a>
						</div>
					</div>
<?php
						endif;
?>
					<a href="<?php the_permalink(); ?>" title="<?php echo esc_attr(get_the_title() ? get_the_title() : get_the_ID()); ?>"><?php if (get_the_title() && !$display_excerpt) : the_title(); ?></a><?php else : ?><h6><?php the_title(); ?></h6></a><?php add_filter('excerpt_length', 'pk_widgets_excerpt_filter'); add_filter('excerpt_more', 'pk_excerpt_more'); the_excerpt(); endif; ?>
					<p class="pk_post_meta"><?php comments_popup_link(__('No Comments', 'pk_text_domain_front'), __('1 Comment', 'pk_text_domain_front'), __('% Comments', 'pk_text_domain_front'), 'pk_meta_tot_comments', __('Comments Off', 'pk_text_domain_front')); ?></p>
				</li>
<?php
					else : 
?>
				<li>
<?php
						if (get_the_title() && !$display_excerpt) : 
?>
					<a href="<?php the_permalink(); ?>" title="<?php echo esc_attr(get_the_title() ? get_the_title() : get_the_ID()); ?>"><?php the_title(); ?></a>
<?php
						else : 
?>
					<a href="<?php the_permalink(); ?>" title="<?php echo esc_attr(get_the_title() ? get_the_title() : get_the_ID()); ?>"><h6><?php the_title(); ?></h6></a>	
			<?php			
							add_filter('excerpt_length', 'pk_widgets_excerpt_filter');
							add_filter('excerpt_more', 'pk_excerpt_more');
							the_excerpt();
							
						endif;
?>
				</li>
<?php
					endif;
					
				endwhile;
?>
			</ul>
		</div>
		<div class="pk_widget_navigation">
			<span class="pk_call_to_action"><?php _e('Back to first', 'pk_text_domain_front'); ?></span>
			<span class="pk_button_circle pk_button_next"><?php _e('next', 'pk_text_domain_front'); ?></span>
			<span class="pk_button_circle pk_button_prev"><?php _e('prev', 'pk_text_domain_front'); ?></span>
		</div>
	</div>
<?php
			echo $after_widget.'
<!-- pk end pk-popular-works-boxed widget -->

';
		
		endif;
		
		add_filter('pre_get_posts', 'pk_pre_get_posts');
		
		wp_reset_postdata();
		
		$cache[$args['widget_id']] = ob_get_flush();
		
		wp_cache_set('widget_popular_works_boxed', $cache, 'widget');
		
	}

	function update($new_instance, $old_instance) {
		
		$instance = $old_instance;
		
		$instance['title'] = strip_tags($new_instance['title']);
		$instance['number'] = (int) $new_instance['number'];
		$instance['display_excerpt'] = $new_instance['display_excerpt'] ? 1 : 0;
		$instance['display_thumb'] = $new_instance['display_thumb'] ? 1 : 0;
		$instance['thumb_icon'] = $new_instance['thumb_icon'];
		
		$this -> flush_widget_cache();

		$alloptions = wp_cache_get('alloptions', 'options');
		
		if (isset($alloptions['widget_popular_works_boxed'])) {
			
			delete_option('widget_popular_works_boxed');
			
		}
		
		return $instance;
		
	}

	function flush_widget_cache() {
		
		wp_cache_delete('widget_popular_works_boxed', 'widget');
		
	}
	
	function form($instance) {
		
		$title = isset($instance['title']) ? esc_attr($instance['title']) : '';
		$number = isset($instance['number']) ? absint($instance['number']) : 5;
		$display_excerpt = (isset($instance['display_excerpt']) && !empty($instance['display_excerpt'])) ? 'checked="checked"' : '';
		$display_thumb = (isset($instance['display_thumb']) && !empty($instance['display_thumb'])) ? 'checked="checked"' : '';
		$thumb_icon = (isset($instance['thumb_icon']) && !empty($instance['thumb_icon'])) ? $instance['thumb_icon'] : '';
?>
		<p><label for="<?php echo $this -> get_field_id('title'); ?>"><?php _e('Title:', 'pk_text_domain'); ?></label>
		<input class="widefat" id="<?php echo $this -> get_field_id('title'); ?>" name="<?php echo $this -> get_field_name('title'); ?>" type="text" value="<?php echo $title; ?>" /></p>
		
		<p><label for="<?php echo $this -> get_field_id('number'); ?>"><?php _e('Number of works to show:', 'pk_text_domain'); ?></label>
		<input class="widefat" id="<?php echo $this -> get_field_id('number'); ?>" name="<?php echo $this -> get_field_name('number'); ?>" type="text" value="<?php echo $number; ?>" size="3" /></p>
		
		<p><input class="checkbox" type="checkbox" <?php echo $display_excerpt; ?> id="<?php echo $this -> get_field_id('display_excerpt'); ?>" name="<?php echo $this -> get_field_name('display_excerpt'); ?>" />
		<label for="<?php echo $this -> get_field_id('display_excerpt'); ?>"><?php _e('Display excerpt', 'pk_text_domain'); ?></label><br />
		<input class="checkbox" type="checkbox" <?php echo $display_thumb; ?> id="<?php echo $this -> get_field_id('display_thumb'); ?>" name="<?php echo $this -> get_field_name('display_thumb'); ?>" />
		<label for="<?php echo $this -> get_field_id('display_thumb'); ?>"><?php _e('Display thumbnails', 'pk_text_domain'); ?></label></p>
		
		<p>
		<label for="<?php echo $this -> get_field_id('thumb_icon'); ?>"><?php _e('Select thumbnails icon type:', 'pk_text_domain'); ?></label>
		<select class="widefat" id="<?php echo $this -> get_field_id('thumb_icon'); ?>" name="<?php echo $this -> get_field_name('thumb_icon'); ?>">
			<option value=""<?php if ($thumb_icon == '') echo ' selected="selected"';?>><?php _e('No Icon', 'pk_text_domain'); ?></option>
			<option value="pk_page_icon"<?php if ($thumb_icon == 'pk_page_icon') echo ' selected="selected"';?>><?php _e('Page Icon', 'pk_text_domain'); ?></option>
			<option value="pk_link_icon"<?php if ($thumb_icon == 'pk_link_icon') echo ' selected="selected"';?>><?php _e('Link Icon', 'pk_text_domain'); ?></option>
			<option value="pk_play_icon"<?php if ($thumb_icon == 'pk_play_icon') echo ' selected="selected"';?>><?php _e('Play Icon', 'pk_text_domain'); ?></option>
			<option value="pk_zoom_icon"<?php if ($thumb_icon == 'pk_zoom_icon') echo ' selected="selected"';?>><?php _e('Zoom Icon', 'pk_text_domain'); ?></option>
		</select>
		</p>
<?php
	}
	
}

function pk_widgets_popular_works_boxed() {
	
	register_widget('PK_Widget_Popular_Works_Boxed');
	
}

add_action('widgets_init', 'pk_widgets_popular_works_boxed');

?>