<?php

class PK_Widget_Twitter_Boxed extends WP_Widget {
	
	function PK_Widget_Twitter_Boxed(){
		
		$widget_ops = array('classname' => 'widget_twitter_boxed', 'description' => __('Display your Twitter updates', 'pk_text_domain'));
		$this -> WP_Widget('pk-twitter-boxed', __('Twitter Boxed', 'pk_text_domain'), $widget_ops);
		
	}
	
	function widget($args, $instance) {
		
		extract($args);
		
		$title = apply_filters('widget_title', $instance['title']);
		
		if (empty($title)) $title = false;
		
		$username = (isset($instance['username'])) ? urlencode($instance['username']) : '';
		
		if (empty($username)) return;
		
		$number = (isset($instance['number'])) ? absint($instance['number']) : 5;
		
		$total = 0;
		
		echo '<!-- pk start pk-twitter-boxed widget -->
'.$before_widget.'
	<div class="pk_titled_widget pk_twitter">
		<div class="pk_widget_title">
			<span class="pk_left_corner"></span>
			<span class="pk_right_corner"></span>
			';
		
		if ($title) {
			
			echo $before_title;
			echo $title;
			echo $after_title.'
		</div>';
			
		}
		
		include_once(ABSPATH.WPINC.'/feed.php');
		
		$twitter_feed_url = "http://twitter.com/statuses/user_timeline/$username.rss";
		
		$transients = get_option('pk_twitter_transients');
		$transients[] = $args['widget_id'];
		update_option('pk_twitter_transients', array_unique($transients));
		
		$cache = get_transient($args['widget_id']);
		
		if ($cache) {
			
			echo $cache;
			return;
			
		} else {
			
			$feed = fetch_feed($twitter_feed_url);
			
		}
		
		if (!is_wp_error($feed)) {
			
			$total = $feed -> get_item_quantity($number);
			$items = $feed -> get_items(0, $total);
			
		}
		
		ob_start();
		
		if ($total == 0) : 
			
			echo '
		<div class="pk_widget_content">
			<ul class="pk_twitter_list">
				<li><p>'.__('The Twitter feed is either empty or unavailable. Please check back later.', 'pk_text_domain_front').'</p></li>
			</ul>
		</div>
		<div class="pk_widget_navigation">
			<a class="pk_call_to_action" href="http://twitter.com/'.$username.'">'.__('Follow on Twitter', 'pk_text_domain_front').'</a>
			<span class="pk_button_circle pk_button_next">'.__('next', 'pk_text_domain_front').'</span>
			<span class="pk_button_circle pk_button_prev">'.__('prev', 'pk_text_domain_front').'</span>
		</div>';
			
		else:
?>

		<div class="pk_widget_content">
			<ul class="pk_twitter_list">
<?php
			foreach ($items as $item) : 
				
				$text = $item -> get_title();
				$link = $item -> get_permalink();
				$time = $item -> get_date();
				
				$text = strstr($text, ': ');
				$text = substr($text, 2);
				$text = make_clickable($text);
				$text = preg_replace_callback('/(^|\s)@(\w+)/', array($this, '_widget_twitter_boxed_username'), $text);
				$text = preg_replace_callback('/(^|\s)#(\w+)/', array($this, '_widget_twitter_boxed_hashtag'), $text);
				
				$time = str_replace(' ', '&nbsp;', $time);
?>
				<li><p><?php echo $text; ?><small><a href="<?php echo $link; ?>" rel="external nofollow"><?php echo $time; ?></a></small></p></li>
<?php
			endforeach;
?>
			</ul>
		</div>
		<div class="pk_widget_navigation">
			<a class="pk_call_to_action" href="http://twitter.com/<?php echo $username ?>"><?php _e('Follow on Twitter', 'pk_text_domain_front'); ?></a>
			<span class="pk_button_circle pk_button_next"><?php _e('next', 'pk_text_domain_front'); ?></span>
			<span class="pk_button_circle pk_button_prev"><?php _e('prev', 'pk_text_domain_front'); ?></span>
		</div><?php
		endif;
		
		echo '
	</div>
'.$after_widget.'
<!-- pk end pk-twitter-boxed widget -->

';
		
		set_transient($args['widget_id'], ob_get_flush(), 3600);
		
	}
	
	function update($new_instance, $old_instance) {
		
		$instance = $old_instance;
		
		$instance['title'] = strip_tags($new_instance['title']);
		$instance['username'] = $new_instance['username'];
		$instance['number'] = $new_instance['number'];
		
		$transients = get_option('pk_twitter_transients');
		
		foreach ($transients as $transient) {
			
			delete_transient($transient);
			
		}
		
		return $instance;
		
	}
	
	function _widget_twitter_boxed_username($matches) {
		
		return "$matches[1]@<a href='".esc_url('http://twitter.com/'.urlencode($matches[2]))."'>$matches[2]</a>";
		
	}
	
	function _widget_twitter_boxed_hashtag($matches) {
		
		return "$matches[1]<a href='".esc_url('http://search.twitter.com/search?q=%23'.urlencode($matches[2]))."'>#$matches[2]</a>";
		
	}
	
	function form($instance) {
		
		$title = isset($instance['title']) ? esc_attr($instance['title']) : '';
		$username = (isset($instance['username'])) ? $instance['username'] : '';
		$number = (isset($instance['number'])) ? absint($instance['number']) : 5;
?>
		<p><label for="<?php echo $this -> get_field_id('title'); ?>"><?php _e('Title:', 'pk_text_domain'); ?></label>
		<input class="widefat" id="<?php echo $this -> get_field_id('title'); ?>" name="<?php echo $this -> get_field_name('title'); ?>" type="text" value="<?php echo $title; ?>" /></p>
		
		<p><label for="<?php echo $this -> get_field_id('username'); ?>"><?php _e('Twitter username:', 'pk_text_domain'); ?></label>
		<input class="widefat" id="<?php echo $this -> get_field_id('username'); ?>" name="<?php echo $this -> get_field_name('username'); ?>" type="text" value="<?php echo $username; ?>" /></p>
		
		<p><label for="<?php echo $this -> get_field_id('number'); ?>"><?php _e('Number of tweets to show:', 'pk_text_domain'); ?></label>
		<input class="widefat" id="<?php echo $this -> get_field_id('number'); ?>" name="<?php echo $this -> get_field_name('number'); ?>" type="text" value="<?php echo $number; ?>" /></p>
<?php
	}
	
}

function pk_widgets_twitter_boxed() {
	
	register_widget('PK_Widget_Twitter_Boxed');
	
}

add_action('widgets_init', 'pk_widgets_twitter_boxed');

?>