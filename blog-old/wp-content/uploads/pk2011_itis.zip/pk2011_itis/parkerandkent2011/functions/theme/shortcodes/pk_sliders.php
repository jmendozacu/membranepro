<?php

/*
 * Standard slider
*/

static $pk_standard_sliders_counter = 0;

function pk_scp_standard_slider($atts, $content = null) {
	
	extract(shortcode_atts(array(
		'width' => '',
		'height' => '',
		'slides_categories' => '',
		'slides_ids' => '',
		'info_text_align' => 'left',
		'info_back_ground_alpha' => '0.7',
		'slideshow' => 'true',
		'slideshow_auto_start' => 'false',
		'slideshow_interval' => '5',
		'open_info_label' => __('info', 'pk_text_domain_front'),
		'close_info_label' => __('close info', 'pk_text_domain_front')
	), $atts));
	
	global $pk_standard_sliders_counter;
	
	$pk_standard_sliders_counter++;
	
	$id = md5($pk_standard_sliders_counter.$slides_categories.$slides_ids.$width.$height.$open_info_label.$close_info_label.$info_text_align.$info_back_ground_alpha.$slideshow.$slideshow_auto_start.$slideshow_interval);
	
	$transients = get_option('pk_sliders_sc_transients');
	$transients[] = $id;
	update_option('pk_sliders_sc_transients', array_unique($transients));
	
	$cache = get_transient($id);
	
	if ($cache) {
		
		return $cache;
		
	}
	
	$posts_to_query = get_objects_in_term(explode(',', $slides_categories), 'taxonomy_slides');
	$posts_to_query = array_unique(array_merge($posts_to_query, explode(',', $slides_ids)));
	
	$query_args = array(
		'post_type' => 'slides',
		'post_status' => 'publish',
		'posts_per_page' => -1,
		'post__in' => $posts_to_query,
		'orderby' => 'menu_order',
		'order' => 'ASC'
	);
	
	$r = new WP_Query($query_args);
	
	add_filter('excerpt_more', 'pk_excerpt_more');
	add_filter('excerpt_length', 'pk_sliders_info_filter');
	
	$hp = 0;
	
	if ($width != '' && $height != '') $hp = floor(12 * ((int)$height / (int)$width));
	
	$output = '
<!-- pk start slider -->
<div id="pk_slider_'.$pk_standard_sliders_counter.'" class="pk_slider" style="width:'.$width.'px; height:'.$height.'px;">
<div class="pk_slider_content" style="width:'.($width - 12).'px; height:'.($height - $hp).'px;">';
	
	if ($r -> have_posts()) : 
		
		while ($r -> have_posts()) : $r -> the_post();
			
			$output .= '

<!-- #################### -->
<!-- pk start slider item -->
<!-- #################### -->
<div class="pk_slider_item">

<!-- pk start slider item media -->
<div class="pk_slider_item_media">
'.pk_standard_slider_item((int)$width, (int)$height, 'pk_slider_'.$pk_standard_sliders_counter.'_lightbox').'
</div>
<!-- pk end slider item media -->
';
			
			if (get_the_excerpt() != '') {
				
				$output .= '
<!-- pk start slider item info-->
<div class="pk_slider_item_info">
	<div class="pk_slider_item_info_background"></div>
	<div class="pk_slider_item_info_content">
		'.get_the_excerpt().'
	</div>
</div>
<!-- pk end slider item info-->
';
				
			}
			
			$output .= '
</div>
<!-- ################## -->
<!-- pk end slider item -->
<!-- ################## -->
';
		
		endwhile;
		
	endif;
	
	$output .= '
</div>
</div>
<script type="text/javascript">
	/*<![CDATA[*/
	jQuery(document).ready(function() {
		jQuery("#pk_slider_'.$pk_standard_sliders_counter.'").pk_slider({
			sliderWidth:'.$width.',
			sliderHeight:'.($height - $hp).',
			buttonInfoOpenLabel:"'.$open_info_label.'",
			buttonInfoCloseLabel:"'.$close_info_label.'",
			infoTextAlign:"'.$info_text_align.'",
			infoBackgroundAlpha:'.$info_back_ground_alpha.',
			slideshow:'.$slideshow.',
			slideshowAutoStart:'.$slideshow_auto_start.',
			slideshowInterval:'.$slideshow_interval.',
			easing: "easeOutExpo",
			speedIn:400,
			speedOut:400
		});
	});
	/*]]>*/
</script>
<!-- pk end slider -->
';
	
	wp_reset_postdata();
	
	set_transient($id, $output, 3600);
	
	return $output;
	
}

add_shortcode('pk_standard_slider', 'pk_scp_standard_slider');

/*
 * Cache management
*/

add_option('pk_sliders_sc_transients', array());

function pk_delete_sliders_sc_transients() {
	
	$transients = get_option('pk_sliders_sc_transients');
	
	foreach ($transients as $transient) {
		
		delete_transient($transient);
		
	}
	
}

add_action('publish_post', 'pk_delete_sliders_sc_transients');
add_action('save_post', 'pk_delete_sliders_sc_transients');
add_action('edit_post', 'pk_delete_sliders_sc_transients');
add_action('delete_post', 'pk_delete_sliders_sc_transients');
add_action('pk_ah_save_text_widget', 'pk_delete_sliders_sc_transients');
add_action('pk_ah_options_updated', 'pk_delete_sliders_sc_transients');
add_action('pk_ah_posts_sorted', 'pk_delete_sliders_sc_transients');

?>