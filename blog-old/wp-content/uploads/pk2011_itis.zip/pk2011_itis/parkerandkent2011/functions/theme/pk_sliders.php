<?php

function pk_standard_slider_item($w, $h, $lightbox_gallery_id) {
	
	global $post;
	
	$slide_meta = pk_get_meta();
	
	$use_featured_image = (isset($slide_meta['use_featured_image'])) ? $slide_meta['use_featured_image'] : 'true';
	$image_action = (isset($slide_meta['image_action'])) ? $slide_meta['image_action'] : '';
	$image_link_url = (isset($slide_meta['image_link_url'])) ? $slide_meta['image_link_url'] : '';
	$use_custom_players = (isset($slide_meta['use_custom_players'])) ? $slide_meta['use_custom_players'] : 'true';
	$auto_play = (isset($slide_meta['auto_play'])) ? $slide_meta['auto_play'] : 'false';
	$file_type = (isset($slide_meta['file_type'])) ? $slide_meta['file_type'] : '';
	
	$file_type = explode(',', $file_type);
	$file_type = (isset($file_type[1])) ? $file_type[1] : '';
	
	if ($use_featured_image == 'true' || $file_type == '') {
		
		if ($file_type == '') $file_type = 'image';
		$image = pk_get_featured_image();
		if ($image) $image = $image[0];
		
	}
	
	if ($use_featured_image == 'false' && $file_type == 'image') {
		
		$image = $slide_meta['image'];
		
	}
	
	if ($file_type == 'audio') {
		
		$audio = explode(',', $slide_meta['audio']);
		if ($use_featured_image == 'false') $image = $audio[0];
		
	}
	
	if ($file_type == 'video') {
		
		$video = explode(',', $slide_meta['video']);
		if ($use_featured_image == 'false') $image = $video[1];
		
		if ((int)$video[0] == 1) $file_type = 'html5';
		if ((int)$video[0] == 2) $file_type = 'video';
		if ((int)$video[0] == 3) $file_type = 'youtube';
		if ((int)$video[0] == 3 && $use_custom_players == 'true') $file_type = 'youtube_custom';
		if ((int)$video[0] == 4) $file_type = 'vimeo';
		
	}
	
	if ($file_type == 'swf') {
		
		$swf = $slide_meta['swf'];
		
	}
	
	switch ($file_type) {
		
		case 'image' :
			
			$hp = floor(12 * ((int)$h / (int)$w));
			
			if ($image && $image_action != '') : 
				
				return '
<!-- pk start image -->
<div class="pk_image" style="'.(($w > 0) ? 'width:'.$w.'px;' : '').(($h > 0) ? ' height:'.$h.'px;' : '').'">
	<div class="pk_image_wrapper">
		<a href="'.(($image_action == 'link') ? esc_url($image_link_url) : esc_url($image)).'" title="'.get_the_title().'"'.(($image_action == 'lightbox') ? ' rel="prettyPhoto['.$lightbox_gallery_id.']" class="pk_zoom_icon"' : ' class="pk_link_icon"').'>
			<img src="'.pk_build_image($image, $w - 12, $h - $hp, 1).'" />
			<span class="pk_image_button_overlay"></span>
		</a>
	</div>
</div>
<!-- pk end image -->
';
				
			endif;
			
			if ($image && $image_action == '') : 
				
				return '
<!-- pk start image -->
<div class="pk_image" style="'.(($w > 0) ? 'width:'.$w.'px;' : '').(($h > 0) ? ' height:'.$h.'px;' : '').'">
	<div class="pk_image_wrapper">
		<img src="'.pk_build_image($image, $w - 12, $h - $hp, 1).'" />
	</div>
</div>
<!-- pk end image -->
';
				
			endif;
			
			break;
			
		case 'audio' :
			
			return do_shortcode('[pk_audio_player width="'.$w.'" height="'.$h.'" autoplay="'.$auto_play.'" cover="'.$image.'" audio_url="'.$audio[1].'"]');
			
			break;
			
		case 'html5' :
			
			return do_shortcode('[pk_html5_player width="'.$w.'" height="'.$h.'" autoplay="'.$auto_play.'" cover="'.$image.'" mp4="'.$video[2].'" webm="'.$video[3].'" ogg="'.$video[4].'"]');
			
			break;
			
			
		case 'video' :
			
			return do_shortcode('[pk_video_player width="'.$w.'" height="'.$h.'" autoplay="'.$auto_play.'" cover="'.$image.'" video_url="'.$video[2].'"]');
			
			break;
			
		case 'youtube_custom' :
			
			return do_shortcode('[pk_youtube_custom_player width="'.$w.'" height="'.$h.'" autoplay="'.$auto_play.'" cover="'.$image.'" video_id="'.$video[2].'"]');
			
			break;
			
		case 'youtube' :
			
			return do_shortcode('[pk_youtube_player width="'.$w.'" height="'.$h.'" autoplay="'.$auto_play.'" cover="'.$image.'" video_id="'.$video[2].'"]');
			
			break;
			
		case 'vimeo' :
			
			return do_shortcode('[pk_vimeo_player width="'.$w.'" height="'.$h.'" autoplay="'.$auto_play.'" cover="'.$image.'" video_id="'.$video[2].'"]');
			
			break;
			
		case 'swf' :
			
			return do_shortcode('[pk_swf_object width="'.$w.'" height="'.$h.'" flashvars="'.str_replace('"', '\'', $slide_meta['swf_flashvars']).'" params="'.str_replace('"', '\'', $slide_meta['swf_params']).'" swf_url="'.$swf.'" fp_version="'.$slide_meta['swf_fp_version'].'"]');
			
			break;
		
	}
	
}

?>