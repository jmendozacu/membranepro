<?php

$pk_test_count = 0;
$pk_temp_query = $wp_query;
$pk_check_paged = (is_front_page() && !is_home()) ? 'page' : 'paged';

if (is_home()) {
	
	$pk_test_count++;
	
	$pk_page_options = pk_get_options('pk_blog_options');
	
	$pk_layout = (isset($pk_page_options['blog_layout'])) ? $pk_page_options['blog_layout'] : 'standard';
	$pk_show_posts_meta = (isset($pk_page_options['blog_show_posts_meta'])) ? $pk_page_options['blog_show_posts_meta'] : 'true';
	$pk_show_author_meta = (isset($pk_page_options['blog_show_author_meta'])) ? $pk_page_options['blog_show_author_meta'] : 'true';
	$pk_show_date_meta = (isset($pk_page_options['blog_show_date_meta'])) ? $pk_page_options['blog_show_date_meta'] : 'true';
	$pk_show_date_meta_links = (isset($pk_page_options['blog_show_date_meta_links'])) ? $pk_page_options['blog_show_date_meta_links'] : 'true';
	$pk_show_categories_meta = (isset($pk_page_options['blog_show_categories_meta'])) ? $pk_page_options['blog_show_categories_meta'] : 'true';
	$pk_show_tags_meta = (isset($pk_page_options['blog_show_tags_meta'])) ? $pk_page_options['blog_show_tags_meta'] : 'true';
	$pk_show_comments_meta = (isset($pk_page_options['blog_show_comments_meta'])) ? $pk_page_options['blog_show_comments_meta'] : 'true';
	$pk_show_full_posts = (isset($pk_page_options['blog_show_full_posts'])) ? $pk_page_options['blog_show_full_posts'] : 'false';
	$pk_show_read_more = (isset($pk_page_options['blog_show_read_more'])) ? $pk_page_options['blog_show_read_more'] : 'true';
	$pk_sidebar = (isset($pk_page_options['blog_sidebar'])) ? $pk_page_options['blog_sidebar'] : 'right';
	$pk_intro = (isset($pk_page_options['blog_intro'])) ? $pk_page_options['blog_intro'] : '';
	$pk_image_style = (isset($pk_page_options['blog_image_style'])) ? $pk_page_options['blog_image_style'] : '16/9';
	$pk_image_icon = (isset($pk_page_options['blog_image_icon'])) ? $pk_page_options['blog_image_icon'] : 'pk_page_icon';
	$pk_footer_profile = (isset($pk_page_options['blog_footer_profile'])) ? $pk_page_options['blog_footer_profile'] : '';
	
	pk_print_intro();
	
	$pk_paged = (get_query_var($pk_check_paged)) ? get_query_var($pk_check_paged) : 1;
	parse_str($query_string, $pk_query_args);
	
	$pk_query_args['paged'] = (int)$pk_paged;
	$pk_query_args['category__not_in'] = array_unique(array_merge(explode(',', pk_get_options('pk_blog_options', 'blog_soft_exclude_categories')), explode(',', pk_get_options('pk_blog_options', 'blog_exclude_categories'))));
	
	query_posts($pk_query_args);
	
}

if (!is_tax() && (function_exists('is_post_type_archive') && !is_post_type_archive()) && is_archive()) {
	
	$pk_test_count++;
	
	if (is_category()) {
		
		$pk_blog_archive_options_profile = (in_array(base64_encode(get_query_var('category_name')), get_option('pk_blog_archive_options_profiles'))) ? base64_encode(get_query_var('category_name')) : '';
		
		$pk_page_options = pk_get_options('pk_blog_archive_options', '', $pk_blog_archive_options_profile);
		
	}
	
	if (is_tag()) {
		
		$pk_blog_archive_options_profile = (in_array(base64_encode(get_query_var('tag')), get_option('pk_blog_archive_options_profiles'))) ? base64_encode(get_query_var('tag')) : '';
		
		$pk_page_options = pk_get_options('pk_blog_archive_options', '', $pk_blog_archive_options_profile);
		
	}
	
	$pk_layout = (isset($pk_page_options['blog_archive_layout'])) ? $pk_page_options['blog_archive_layout'] : 'standard';
	$pk_show_posts_meta = (isset($pk_page_options['blog_archive_show_posts_meta'])) ? $pk_page_options['blog_archive_show_posts_meta'] : 'true';
	$pk_show_author_meta = (isset($pk_page_options['blog_archive_show_author_meta'])) ? $pk_page_options['blog_archive_show_author_meta'] : 'true';
	$pk_show_date_meta = (isset($pk_page_options['blog_archive_show_date_meta'])) ? $pk_page_options['blog_archive_show_date_meta'] : 'true';
	$pk_show_date_meta_links = (isset($pk_page_options['blog_archive_show_date_meta_links'])) ? $pk_page_options['blog_archive_show_date_meta_links'] : 'true';
	$pk_show_categories_meta = (isset($pk_page_options['blog_archive_show_categories_meta'])) ? $pk_page_options['blog_archive_show_categories_meta'] : 'true';
	$pk_show_tags_meta = (isset($pk_page_options['blog_archive_show_tags_meta'])) ? $pk_page_options['blog_archive_show_tags_meta'] : 'true';
	$pk_show_comments_meta = (isset($pk_page_options['blog_archive_show_comments_meta'])) ? $pk_page_options['blog_archive_show_comments_meta'] : 'true';
	$pk_show_full_posts = (isset($pk_page_options['blog_archive_show_full_posts'])) ? $pk_page_options['blog_archive_show_full_posts'] : 'false';
	$pk_show_read_more = (isset($pk_page_options['blog_archive_show_read_more'])) ? $pk_page_options['blog_archive_show_read_more'] : 'true';
	$pk_sidebar = (isset($pk_page_options['blog_archive_sidebar'])) ? $pk_page_options['blog_archive_sidebar'] : 'right';
	$pk_image_style = (isset($pk_page_options['blog_archive_image_style'])) ? $pk_page_options['blog_archive_image_style'] : '16/9';
	$pk_image_icon = (isset($pk_page_options['blog_archive_image_icon'])) ? $pk_page_options['blog_archive_image_icon'] : 'pk_page_icon';
	$pk_footer_profile = (isset($pk_page_options['blog_archive_footer_profile'])) ? $pk_page_options['blog_archive_footer_profile'] : '';
	
	pk_print_intro();
	
	$pk_paged = (get_query_var($pk_check_paged)) ? get_query_var($pk_check_paged) : 1;
	parse_str($query_string, $pk_query_args);
	
	$pk_query_args['paged'] = (int)$pk_paged;
	$pk_query_args['category__not_in'] = explode(',', pk_get_options('pk_blog_options', 'blog_exclude_categories'));
	
	query_posts($pk_query_args);
	
}

if (!is_tax() && function_exists('is_post_type_archive') && is_post_type_archive('works')) {
	
	$pk_test_count++;
	
	$pk_page_options = pk_get_options('pk_works_archive_options');
	
	$pk_sidebar = (isset($pk_page_options['works_archive_sidebar'])) ? $pk_page_options['works_archive_sidebar'] : 'none';
	$pk_columns = (isset($pk_page_options['works_archive_layout'])) ? $pk_page_options['works_archive_layout'] : '4';
	$pk_show_categories_filter = (isset($pk_page_options['works_archive_show_categories_filter'])) ? $pk_page_options['works_archive_show_categories_filter'] : 'true';
	$pk_show_read_more = (isset($pk_page_options['works_archive_show_read_more'])) ? $pk_page_options['works_archive_show_read_more'] : 'true';
	$pk_posts_per_page = (isset($pk_page_options['works_archive_posts_per_page'])) ? $pk_page_options['works_archive_posts_per_page'] : (int)$pk_columns * 3;
	$pk_footer_profile = (isset($pk_page_options['works_archive_footer_profile'])) ? $pk_page_options['works_archive_footer_profile'] : '';
	
	pk_print_intro();
	
	$pk_filter_categories = array();
	
	$pk_terms = get_terms('taxonomy_works', 'hide_empty=1&hierarchical=0');
	
	if(count($pk_terms) > 0) {
		
		foreach ($pk_terms as $pk_term) {
			
			$pk_filter_categories[] = $pk_term -> term_id;
			
		}
		
	}
	
	$pk_count = 1;
	
	$pk_paged = (get_query_var($pk_check_paged)) ? get_query_var($pk_check_paged) : 1;
	parse_str($query_string, $pk_query_args);
	
	$pk_query_args['post_status'] = 'publish';
	$pk_query_args['posts_per_page'] = (int)$pk_posts_per_page;
	$pk_query_args['paged'] = (int)$pk_paged;
	
	query_posts($pk_query_args);
	
}

if (is_search()) {
	
	$pk_test_count++;
	
	$pk_page_options = pk_get_options('pk_search_options');
	
	$pk_layout = (isset($pk_page_options['search_layout'])) ? $pk_page_options['search_layout'] : 'standard';
	$pk_show_posts_meta = (isset($pk_page_options['search_show_posts_meta'])) ? $pk_page_options['search_show_posts_meta'] : 'true';
	$pk_show_author_meta = (isset($pk_page_options['search_show_author_meta'])) ? $pk_page_options['search_show_author_meta'] : 'true';
	$pk_show_date_meta = (isset($pk_page_options['search_show_date_meta'])) ? $pk_page_options['search_show_date_meta'] : 'true';
	$pk_show_date_meta_links = (isset($pk_page_options['search_show_date_meta_links'])) ? $pk_page_options['search_show_date_meta_links'] : 'true';
	$pk_show_categories_meta = (isset($pk_page_options['search_show_categories_meta'])) ? $pk_page_options['search_show_categories_meta'] : 'true';
	$pk_show_tags_meta = (isset($pk_page_options['search_show_tags_meta'])) ? $pk_page_options['search_show_tags_meta'] : 'true';
	$pk_show_comments_meta = (isset($pk_page_options['search_show_comments_meta'])) ? $pk_page_options['search_show_comments_meta'] : 'true';
	$pk_show_full_posts = (isset($pk_page_options['search_show_full_posts'])) ? $pk_page_options['search_show_full_posts'] : 'false';
	$pk_show_read_more = (isset($pk_page_options['search_show_read_more'])) ? $pk_page_options['search_show_read_more'] : 'true';
	$pk_sidebar = (isset($pk_page_options['search_sidebar'])) ? $pk_page_options['search_sidebar'] : 'right';
	$pk_image_style = (isset($pk_page_options['search_image_style'])) ? $pk_page_options['search_image_style'] : '16/9';
	$pk_image_icon = (isset($pk_page_options['search_archive_image_icon'])) ? $pk_page_options['search_archive_image_icon'] : 'pk_page_icon';
	$pk_footer_profile = (isset($pk_page_options['search_footer_profile'])) ? $pk_page_options['search_footer_profile'] : '';
	
	pk_print_intro();
	
	$pk_paged = (get_query_var($pk_check_paged)) ? get_query_var($pk_check_paged) : 1;
	parse_str($query_string, $pk_query_args);
	
	$pk_query_args['paged'] = (int)$pk_paged;
	$pk_query_args['category__not_in'] = explode(',', pk_get_options('pk_blog_options', 'blog_exclude_categories'));
	
	query_posts($pk_query_args);
	
}

if (is_404()) {
	
	$pk_test_count++;
	
	$pk_page_options = pk_get_options('pk_general_options');
	
	$pk_404_page_id = (isset($pk_page_options['general_404_page_id'])) ?(int)$pk_page_options['general_404_page_id'] : '';
	
	if ($pk_404_page_id == '') : 
		
		$pk_intro = '<div class="pk_warning_box"><div class="pk_message_box_content"><p>'.__('Please, select a static page to use for the "404 page not found" error in the "General Options" of the theme.', 'pk_text_domain_front').'</p></div></div>';
		pk_print_intro();
	
	else : 
		
		global $post;
		
		$post = get_post($pk_404_page_id);
		
		$pk_page_meta = pk_get_meta();
		
		$pk_sidebar = (isset($pk_page_meta['sidebar'])) ? $pk_page_meta['sidebar'] : 'right';
		$pk_show_comments_sidebar = (isset($pk_page_meta['show_comments_sidebar'])) ? $pk_page_meta['show_comments_sidebar'] : 'true';
		$pk_show_author_info = (isset($pk_page_meta['show_author_info'])) ? $pk_page_meta['show_author_info'] : 'true';
		$pk_intro = (isset($pk_page_meta['intro'])) ? $pk_page_meta['intro'] : '';
		$pk_footer_profile = get_post_meta($post -> ID, '_pk_footer_profile', true);
		
		pk_print_intro();
		
		$pk_query_args = array(
			'post_type' => 'page',
			'post__in' => array($pk_404_page_id)
		);
		
		$wp_query = new WP_Query($pk_query_args);
		
	endif;
	
}

if (is_attachment()) {
	
	$pk_test_count++;
	
	$pk_sidebar = 'none';
	$pk_show_comments_sidebar = 'true';
	
}

if (is_singular(array('page'))) {
	
	$pk_test_count++;
	
	$pk_page_meta = pk_get_meta();
	
	$pk_sidebar = (isset($pk_page_meta['sidebar'])) ? $pk_page_meta['sidebar'] : 'right';
	$pk_show_comments_sidebar = (isset($pk_page_meta['show_comments_sidebar'])) ? $pk_page_meta['show_comments_sidebar'] : 'true';
	$pk_show_author_info = (isset($pk_page_meta['show_author_info'])) ? $pk_page_meta['show_author_info'] : 'false';
	$pk_intro = (isset($pk_page_meta['intro'])) ? $pk_page_meta['intro'] : '';
	$pk_footer_profile = get_post_meta($post -> ID, '_pk_footer_profile', true);
	
}

if (is_singular(array('post', 'works'))) {
	
	$pk_test_count++;
	
	$pk_page_meta = pk_get_meta();
	
	$pk_sidebar = (isset($pk_page_meta['sidebar'])) ? $pk_page_meta['sidebar'] : 'right';
	$pk_show_comments_sidebar = (isset($pk_page_meta['show_comments_sidebar'])) ? $pk_page_meta['show_comments_sidebar'] : 'true';
	$pk_show_author_info = (isset($pk_page_meta['show_author_info'])) ? $pk_page_meta['show_author_info'] : 'false';
	$pk_intro = (isset($pk_page_meta['intro'])) ? $pk_page_meta['intro'] : '';
	$pk_footer_profile = get_post_meta($post -> ID, '_pk_footer_profile', true);
	
	pk_print_intro();
	
}

if (is_page_template('default')) {
	
	pk_print_intro();
	
}

if (is_page_template('workspage_1.php') || is_page_template('workspage_2.php') || is_page_template('workspage_3.php') || is_page_template('workspage_4.php') || is_page_template('workspage_5.php') || is_page_template('workspage_6.php')) {
	
	$pk_test_count++;
	
	$pk_page_template = split('_', get_post_meta($wp_query -> post -> ID, '_wp_page_template', true));
	$pk_page_template = substr($pk_page_template[1], 0, 1);
	
	$pk_columns = $pk_page_template;
	
	$pk_order_by = (isset($pk_page_meta['wo_order_by'])) ? $pk_page_meta['wo_order_by'] : 'menu_order';
	$pk_posts_per_page = (isset($pk_page_meta['wo_posts_per_page'])) ? $pk_page_meta['wo_posts_per_page'] : (int)$pk_columns * 3;
	$pk_include_ids = (isset($pk_page_meta['wo_include_ids'])) ? $pk_page_meta['wo_include_ids'] : '';
	$pk_include_categories = (isset($pk_page_meta['wo_include_categories'])) ? $pk_page_meta['wo_include_categories'] : '';
	$pk_show_categories_filter = (isset($pk_page_meta['wo_show_categories_filter'])) ? $pk_page_meta['wo_show_categories_filter'] : 'true';
	$pk_show_read_more = (isset($pk_page_meta['wo_show_read_more'])) ? $pk_page_meta['wo_show_read_more'] : 'true';
	
	pk_print_intro();
	
	/*$pk_include_ids_categories = array();
	
	if ($pk_include_ids != '') {
		
		foreach (explode(',', $pk_include_ids) as $pk_included_id) {
			
			$pk_works_terms = wp_get_post_terms($pk_included_id, 'taxonomy_works');
			
			foreach ($pk_works_terms as $pk_filter_category) {
				
				$pk_include_ids_categories[] = $pk_filter_category -> term_id;
				
			}
			
		}
		
	}
	
	if ($pk_include_categories != '') {
	
		$pk_filter_categories = array_unique(array_merge($pk_include_ids_categories, explode(',', $pk_include_categories)));
	
	} else {
		
		$pk_filter_categories = array_unique($pk_include_ids_categories);
		
	}
	
	sort($pk_filter_categories);*/
	
	$pk_filter_categories = array();
	
	$pk_terms = get_terms('taxonomy_works', 'hide_empty=1&hierarchical=0');
	
	if(count($pk_terms) > 0) {
		
		foreach ($pk_terms as $pk_term) {
			
			$pk_filter_categories[] = $pk_term -> term_id;
			
		}
		
	}
	
	$pk_count = 1;
	
	$pk_posts_to_query = get_objects_in_term(explode(',', $pk_include_categories), 'taxonomy_works');
	$pk_posts_to_query = array_unique(array_merge($pk_posts_to_query, explode(',', $pk_include_ids)));
	
	$pk_paged = (get_query_var($pk_check_paged)) ? get_query_var($pk_check_paged) : 1;
	
	if ($pk_order_by != 'menu_order') {
	
		$pk_query_args = array(
			'post_type' => 'works',
			'post_status' => 'publish',
			'posts_per_page' => (int)$pk_posts_per_page,
			'post__in' => $pk_posts_to_query,
			'orderby' => $pk_order_by,
			'order' => 'DESC',
			'paged' => (int)$pk_paged
		);
	
	} else {
		
		$pk_query_args = array(
			'post_type' => 'works',
			'post_status' => 'publish',
			'posts_per_page' => (int)$pk_posts_per_page,
			'post__in' => $pk_posts_to_query,
			'orderby' => $pk_order_by,
			'order' => 'ASC',
			'paged' => (int)$pk_paged
		);	
		
	}
	
	$wp_query = new WP_Query($pk_query_args);
	
}

if (is_page_template('flickr-grid-gallery-page.php')) {
	
	$pk_test_count++;
	
	global $pk_flickr_user_id;
	global $pk_flickr_group_id;
	global $pk_flickr_user_tags;
	global $pk_flickr_per_page;
	global $pk_flickr_page;
	global $pk_flickr_photoset_id;
	global $pk_flickr_gallery_id;
	
	$pk_columns = (isset($pk_page_meta['fgg_layout'])) ? (int)$pk_page_meta['fgg_layout'] : 3;
	$pk_load_photos_from = (isset($pk_page_meta['fgg_load_photos_from'])) ? $pk_page_meta['fgg_load_photos_from'] : 'recent';
	$pk_user_id = (isset($pk_page_meta['fgg_flickr_user_id'])) ? $pk_page_meta['fgg_flickr_user_id'] : pk_get_options('pk_general_options', 'general_flickr_user_id');
	$pk_group_id = (isset($pk_page_meta['fgg_flickr_group_id'])) ? $pk_page_meta['fgg_flickr_group_id'] : '';
	$pk_user_tags = (isset($pk_page_meta['fgg_flickr_user_tags'])) ? $pk_page_meta['fgg_flickr_user_tags'] : '';
	$pk_select_set = (isset($pk_page_meta['fgg_select_set'])) ? $pk_page_meta['fgg_select_set'] : '';
	$pk_select_galleries = (isset($pk_page_meta['fgg_select_galleries'])) ? $pk_page_meta['fgg_select_galleries'] : '';
	$pk_total_images = (isset($pk_page_meta['fgg_total_images'])) ? $pk_page_meta['fgg_total_images'] : '9';
	$pk_image_style = (isset($pk_page_meta['fgg_thumbs_style'])) ? $pk_page_meta['fgg_thumbs_style'] : '16/9';
	$pk_image_height = (isset($pk_page_meta['fgg_thumbs_height'])) ? (int)$pk_page_meta['fgg_thumbs_height'] : 0;
	$pk_image_icon = (isset($pk_page_meta['fgg_thumbs_icon'])) ? $pk_page_meta['fgg_thumbs_icon'] : '';
	$pk_image_action = (isset($pk_page_meta['fgg_thumbs_action'])) ? $pk_page_meta['fgg_thumbs_action'] : 'lightbox';
	$pk_title_action = (isset($pk_page_meta['fgg_title_action'])) ? $pk_page_meta['fgg_title_action'] : 'link';
	$pk_show_image_title = (isset($pk_page_meta['fgg_show_photo_title'])) ? $pk_page_meta['fgg_show_photo_title'] : 'true';
	$pk_show_image_description = (isset($pk_page_meta['fgg_show_photo_description'])) ? $pk_page_meta['fgg_show_photo_description'] : 'false';
	$pk_slideshow_auto_start = (isset($pk_page_meta['fgg_slideshow_auto_start'])) ? $pk_page_meta['fgg_slideshow_auto_start'] : 'false';
	$pk_slideshow_interval = (isset($pk_page_meta['fgg_slideshow_interval'])) ? (int)$pk_page_meta['fgg_slideshow_interval'] * 1000 : 5000;
	
	pk_print_intro();
	
	$pk_count = 1;
	
	pk_flickr_init();
	
	$pk_flickr_user_id = $pk_user_id;
	$pk_flickr_group_id = $pk_group_id;
	$pk_flickr_user_tags = $pk_user_tags;
	$pk_flickr_per_page = $pk_total_images;
	$pk_flickr_page = (get_query_var($pk_check_paged)) ? get_query_var($pk_check_paged) : 1;
	$pk_flickr_photoset_id = $pk_select_set;
	$pk_flickr_gallery_id = $pk_select_galleries;
	
	$pk_flickr_transient_id = md5('pk_flickr_grid_gallery_page_'.$post -> ID.'_'.$pk_flickr_page);
	$pk_flickr_transient_total_pages_id = md5('pk_flickr_grid_gallery_page_total_pages_'.$post -> ID.'_'.$pk_flickr_page);
	
	$transients = get_option('pk_flickr_grid_gallery_page_transients');
	$transients[] = $pk_flickr_transient_id;
	$transients[] = $pk_flickr_transient_total_pages_id;
	
	update_option('pk_flickr_grid_gallery_page_transients', array_unique($transients));
	
	$pk_flickr_cache = get_transient($pk_flickr_transient_id);
	
	if (is_array($pk_flickr_cache)) {
		
		$pk_gallery_items = $pk_flickr_cache;
		$pk_flickr_total_pages = (int)get_transient($pk_flickr_transient_total_pages_id);
		
	} else {
		
		switch ($pk_load_photos_from) {
			
			case 'recent':
				
				$pk_flickr_gallery_query = pk_flickr_get_recent_photos();
				
				$pk_gallery_items = $pk_flickr_gallery_query['photo'];
				$pk_flickr_total_pages = (int)$pk_flickr_gallery_query['pages'];
				
				break;
			
			case 'favorites':
				
				$pk_flickr_gallery_query = pk_flickr_get_favorites_photos();
				
				$pk_gallery_items = $pk_flickr_gallery_query['photos']['photo'];
				$pk_flickr_total_pages = (int)$pk_flickr_gallery_query['photos']['pages'];
				
				break;
				
			case 'tags':
				
				$pk_flickr_gallery_query = pk_flickr_get_tagged_photos();
				
				$pk_gallery_items = $pk_flickr_gallery_query['photo'];
				$pk_flickr_total_pages = (int)$pk_flickr_gallery_query['pages'];
				
				break;
			
			case 'photoset':
				
				$pk_flickr_gallery_query = pk_flickr_get_photosets_photos();
				
				$pk_gallery_items = $pk_flickr_gallery_query['photoset']['photo'];
				$pk_flickr_total_pages = (int)$pk_flickr_gallery_query['photoset']['pages'];
				
				break;
			
			case 'galleries':
				
				$pk_flickr_gallery_query = pk_flickr_get_galleries_photos();
				
				$pk_gallery_items = $pk_flickr_gallery_query['photos']['photo'];
				$pk_flickr_total_pages = (int)$pk_flickr_gallery_query['photos']['pages'];
				
				break;
			
		}
		
		if (!is_array($pk_gallery_items)) $pk_gallery_items = array();
		
		set_transient($pk_flickr_transient_id, $pk_gallery_items, 3600);
		set_transient($pk_flickr_transient_total_pages_id, $pk_flickr_total_pages, 3600);
		
	}
	
}

if (is_tax('taxonomy_works')) {
	
	$pk_test_count++;
	
	$pk_works_archive_options_profile = (in_array(base64_encode(get_query_var('term')), get_option('pk_works_archive_options_profiles'))) ? base64_encode(get_query_var('term')) : '';
	
	$pk_page_options = pk_get_options('pk_works_archive_options', '', $pk_works_archive_options_profile);
	
	$pk_sidebar = (isset($pk_page_options['works_archive_sidebar'])) ? $pk_page_options['works_archive_sidebar'] : 'none';
	$pk_columns = (isset($pk_page_options['works_archive_layout'])) ? $pk_page_options['works_archive_layout'] : '4';
	$pk_order_by = (isset($pk_page_options['works_archive_order_by'])) ? $pk_page_options['works_archive_order_by'] : 'date';
	$pk_show_categories_filter = (isset($pk_page_options['works_archive_show_categories_filter'])) ? $pk_page_options['works_archive_show_categories_filter'] : 'true';
	$pk_show_read_more = (isset($pk_page_options['works_archive_show_read_more'])) ? $pk_page_options['works_archive_show_read_more'] : 'true';
	$pk_posts_per_page = (isset($pk_page_options['works_archive_posts_per_page'])) ? $pk_page_options['works_archive_posts_per_page'] : (int)$pk_columns * 3;
	$pk_footer_profile = (isset($pk_page_options['works_archive_footer_profile'])) ? $pk_page_options['works_archive_footer_profile'] : '';
	
	pk_print_intro();
	
	/*$pk_filter_categories = array();
	
	$pk_current_term = get_term_by('slug', get_query_var('term'), 'taxonomy_works');
	
	if ($pk_current_term -> parent) $pk_filter_categories[] = $pk_current_term -> parent;
	
	$pk_terms = get_terms('taxonomy_works', 'hide_empty=1&hierarchical=0&parent='.$pk_current_term -> term_id.'');
	
	if(count($pk_terms) > 0) {
		
		foreach ($pk_terms as $pk_term) {
			
			$pk_filter_categories[] = $pk_term -> term_id;
			
		}
		
	}*/
	
	$pk_filter_categories = array();
	
	$pk_terms = get_terms('taxonomy_works', 'hide_empty=1&hierarchical=0');
	
	if(count($pk_terms) > 0) {
		
		foreach ($pk_terms as $pk_term) {
			
			$pk_filter_categories[] = $pk_term -> term_id;
			
		}
		
	}
	
	$pk_count = 1;
	
	$pk_paged = (get_query_var($pk_check_paged)) ? get_query_var($pk_check_paged) : 1;
	parse_str($query_string, $pk_query_args);
	
	$pk_query_args['orderby'] = $pk_order_by;
	$pk_query_args['order'] = ($pk_order_by != 'menu_order') ? 'DESC' : 'ASC';
	$pk_query_args['post_status'] = 'publish';
	$pk_query_args['posts_per_page'] = (int)$pk_posts_per_page;
	$pk_query_args['paged'] = (int)$pk_paged;
	
	query_posts($pk_query_args);
	
}

switch ($pk_sidebar) {
	
	case 'none':
	
		add_filter('embed_defaults', 'pk_full_embed_defaults');
		break;
		
	default:
	
		add_filter('embed_defaults', 'pk_sidebar_embed_defaults');
	
}

?>