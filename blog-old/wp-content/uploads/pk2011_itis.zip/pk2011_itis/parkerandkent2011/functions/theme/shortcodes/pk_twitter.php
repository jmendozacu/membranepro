<?php

/*
 * Twitter
*/

static $pk_twitter_feeds_counter = 0;

function pk_scp_twitter_feed($atts, $content = null) {
	
	extract(shortcode_atts(array(
		'title' => '',
		'username' => '',
		'number' => '5',
		'show_follow_link' => 'false'
	), $atts));
	
	global $pk_twitter_feeds_counter;
	
	$pk_twitter_feeds_counter++;
	
	$id = md5($pk_twitter_feeds_counter.$title.$username.$number.$show_follow_link);
	
	if ($username == '') return;
	
	$total = 0;
	
	$output = '';
	
	include_once(ABSPATH.WPINC.'/feed.php');
	
	$twitter_feed_url = "http://twitter.com/statuses/user_timeline/$username.rss";
	
	$transients = get_option('pk_twitter_transients');
	$transients[] = $id;
	update_option('pk_twitter_transients', array_unique($transients));
	
	$cache = get_transient($id);
	
	if ($cache) {
		
		return $cache;
		
	} else {
		
		$feed = fetch_feed($twitter_feed_url);
		
	}
	
	if (!is_wp_error($feed)) {
		
		$total = $feed -> get_item_quantity((int)$number);
		$items = $feed -> get_items(0, $total);
		
	}
	
	if ($total == 0) {
		
		$output = '<p>'.__('The Twitter feed is either empty or unavailable. Please check back later.', 'pk_text_domain_front').'</p>';
		
	} else {
		
		$output = '
<!-- pk start Twitter widget -->
<div class="pk_scp_twitter pk_widget">';
	
	if ($title != '') $output .= '
	<h4>'.$title.'</h4>';
	
	$output .= '
	<ul class="pk_twitter_list">';
		
		foreach ($items as $item) {
			
			$text = $item -> get_title();
			$link = $item -> get_permalink();
			$time = $item -> get_date();
			
			$text = strstr($text, ': ');
			$text = substr($text, 2);
			$text = make_clickable($text);
			$text = preg_replace_callback('/(^|\s)@(\w+)/', 'pk_scp_twitter_feed_username', $text);
			$text = preg_replace_callback('/(^|\s)#(\w+)/', 'pk_scp_twitter_feed_hashtag', $text);
			
			$time = str_replace(' ', '&nbsp;', $time);
			
			$output .= '
		<li>
			'.$text.'
			<small><a href="'.$link.'" rel="external nofollow">'.$time.'</a></small>
		</li>';
			
		}
		
		if ($show_follow_link == 'true') {
			
			$output .= '
		<li>
			<a class="follow" href="http://twitter.com/$username">
				'.sprintf(__('Follow @%s on Twitter', 'pk_text_domain_front'), $username).'
			</a>
		</li>';
			
		}
		
		$output .= '
	</ul>
</div>
<!-- pk end Twitter widget -->
';
		
	}
	
	set_transient($id, $output, 3600);
	
	return $output;
	
}

add_shortcode('pk_twitter_feed', 'pk_scp_twitter_feed');

function pk_scp_twitter_feed_username($matches) {
	
	return "$matches[1]@<a href='".esc_url('http://twitter.com/'.urlencode($matches[2]))."'>$matches[2]</a>";
	
}

function pk_scp_twitter_feed_hashtag($matches) {
	
	return "$matches[1]<a href='".esc_url('http://search.twitter.com/search?q=%23'.urlencode($matches[2]))."'>#$matches[2]</a>";
	
}

/*
 * Cache management
*/

add_option('pk_twitter_transients', array());

function pk_delete_twitter_transients() {
	
	$transients = get_option('pk_twitter_transients');
	
	foreach ($transients as $transient) {
		
		delete_transient($transient);
		
	}
	
}
	
add_action('publish_post', 'pk_delete_twitter_transients');
add_action('save_post', 'pk_delete_twitter_transients');
add_action('edit_post', 'pk_delete_twitter_transients');
add_action('delete_post', 'pk_delete_twitter_transients');
add_action('pk_ah_save_text_widget', 'pk_delete_twitter_transients');
add_action('pk_ah_options_updated', 'pk_delete_twitter_transients');
add_action('pk_ah_posts_sorted', 'pk_delete_twitter_transients');

?>