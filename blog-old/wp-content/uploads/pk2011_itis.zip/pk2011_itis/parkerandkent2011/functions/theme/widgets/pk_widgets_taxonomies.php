<?php

class PK_Widget_Taxonomies extends WP_Widget {
	
	function PK_Widget_Taxonomies() {
		
		$widget_ops = array('classname' => 'widget_taxonomies', 'description' => __('A list or dropdown of works categories', 'pk_text_domain'));
		$this -> WP_Widget('pk-taxonomies', __('Works Categories', 'pk_text_domain'), $widget_ops);
		
	}
	
	function widget($args, $instance) {
		
		extract($args);
		
		$title = apply_filters('widget_title', $instance['title']);
		$c = $instance['count'] ? '1' : '0';
		$h = $instance['hierarchical'] ? '1' : '0';
		$d = $instance['dropdown'] ? '1' : '0';
		
		echo '<!-- pk start pk-taxonomies widget -->
'.$before_widget.'
	';
		
		if ($title) {
			
			echo $before_title;
			echo $title;
			echo $after_title;
			
		}
		
		$taxonomies_args = array('orderby' => 'name', 'show_count' => $c, 'hierarchical' => $h, 'taxonomy' => 'taxonomy_works', 'echo' => 0);
		
		if ($d) {
			
			$terms = get_terms('taxonomy_works', $taxonomies_args);
			
			echo '
	<select id="taxonomy_select_'.$widget_id.'" name="taxonomy_select_'.$widget_id.'" class="postform">';
				echo '
		<option value="">'.__('Select Category', 'pk_text_domain_front').'</option>';
				
			foreach ($terms as $term) {
				
				echo '
		<option value="'.get_term_link($term -> slug, 'taxonomy_works').'">'.$term -> name.'</option>';
				
			}
			
			echo '
	</select>
';
?>
	<script type='text/javascript'>
	/* <![CDATA[ */
		document.getElementById("taxonomy_select_<?php echo $widget_id; ?>").onchange = function() {
			location.href = this.options[this.selectedIndex].value;
		}
	/* ]]> */
	</script>
<?php
		} else {
?>

	<ul class="<?php if ($taxonomies_args['show_count'] == 0) echo 'pk_underline_list '; ?>pk_arrow_list">
<?php
$taxonomies_args['title_li'] = '';
echo str_replace(array("\n</a>", "\n</li>", "<li"), array("</a>", "</li>", "\t<li"), wp_list_categories(apply_filters('widget_categories_args', $taxonomies_args)));
?>
	</ul>
<?php
		}
		
		echo $after_widget.'
<!-- pk end pk-taxonomies widget -->

';
		
	}
	
	function update($new_instance, $old_instance) {
		
		$instance = $old_instance;
		
		$instance['title'] = strip_tags($new_instance['title']);
		$instance['count'] = !empty($new_instance['count']) ? 1 : 0;
		$instance['hierarchical'] = !empty($new_instance['hierarchical']) ? 1 : 0;
		$instance['dropdown'] = !empty($new_instance['dropdown']) ? 1 : 0;
		
		return $instance;
		
	}
	
	function form($instance) {
		
		$instance = wp_parse_args((array) $instance, array('title' => ''));
		$title = esc_attr($instance['title']);
		$count = isset($instance['count']) ? (bool) $instance['count'] : false;
		$hierarchical = isset($instance['hierarchical']) ? (bool) $instance['hierarchical'] : false;
		$dropdown = isset($instance['dropdown']) ? (bool) $instance['dropdown'] : false;
?>
		<p><label for="<?php echo $this -> get_field_id('title'); ?>"><?php _e('Title:', 'pk_text_domain'); ?></label>
		<input class="widefat" id="<?php echo $this -> get_field_id('title'); ?>" name="<?php echo $this -> get_field_name('title'); ?>" type="text" value="<?php echo $title; ?>" /></p>
		
		<p><input type="checkbox" class="checkbox" id="<?php echo $this -> get_field_id('dropdown'); ?>" name="<?php echo $this -> get_field_name('dropdown'); ?>"<?php checked($dropdown); ?> />
		<label for="<?php echo $this -> get_field_id('dropdown'); ?>"><?php _e('Display as dropdown', 'pk_text_domain'); ?></label><br />
		<input type="checkbox" class="checkbox" id="<?php echo $this -> get_field_id('count'); ?>" name="<?php echo $this -> get_field_name('count'); ?>"<?php checked($count); ?> />
		<label for="<?php echo $this -> get_field_id('count'); ?>"><?php _e('Show post counts', 'pk_text_domain'); ?></label><br />
		<input type="checkbox" class="checkbox" id="<?php echo $this -> get_field_id('hierarchical', 'pk_text_domain'); ?>" name="<?php echo $this -> get_field_name('hierarchical'); ?>"<?php checked($hierarchical); ?> />
		<label for="<?php echo $this -> get_field_id('hierarchical'); ?>"><?php _e('Show hierarchy', 'pk_text_domain'); ?></label></p>
<?php
	}
	
}

function pk_widgets_taxonomies() {
	
	register_widget('PK_Widget_Taxonomies');
	
}

add_action('widgets_init', 'pk_widgets_taxonomies');

?>