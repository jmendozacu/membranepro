<?php

function pk_register_slides() {
	
	$labels = array(
		'name' => _x('Slides', 'post type general name', 'pk_text_domain'),
		'singular_name' => _x('Slide', 'post type singular name', 'pk_text_domain'),
		'add_new' => _x('Add New', 'release', 'pk_text_domain'),
		'add_new_item' => __('Add New Slide', 'pk_text_domain'),
		'edit_item' => __('Edit Slide', 'pk_text_domain'),
		'new_item' => __('New Slide', 'pk_text_domain'),
		'view_item' => __('View Slide', 'pk_text_domain'),
		'search_items' => __('Search Slides', 'pk_text_domain'),
		'not_found' => __('No slides found', 'pk_text_domain'),
		'not_found_in_trash' => __('No slides found in Trash', 'pk_text_domain')
	);
	
	$args = array(
		'labels' => $labels,
		'public' => true,
		'menu_position' => 5,
		'capability_type' => 'post',
		'hierarchical' => false,
		'supports' => array('title', 'editor', 'excerpt', 'thumbnail'),
		'query_var' => true,
		'rewrite' => false,
		'show_in_nav_menus' => false,
		'exclude_from_search' => true
	);
	
	$taxonomy_labels = array(
		'name' => _x('Slides Categories', 'taxonomy general name', 'pk_text_domain'),
		'singular_name' => _x('Slides Category', 'taxonomy singular name', 'pk_text_domain'),
		'search_items' => __('Search Slides Category', 'pk_text_domain'),
		'popular_items' => __('Popular Slides Categories', 'pk_text_domain'),
		'all_items' => __('All Slides Categories', 'pk_text_domain'),
		'parent_item' => __('Parent Slides Category', 'pk_text_domain'),
		'parent_item_colon' => __('Parent Slides Category:', 'pk_text_domain'),
		'edit_item' => __('Edit Slides Category', 'pk_text_domain'),
		'add_new_item' => __('Add New Slides Category', 'pk_text_domain'),
		'new_item_name' => __('New Slides Category Name', 'pk_text_domain')
	);
	
	$taxonomy_args = array(
		'labels' => $taxonomy_labels,
		'public' => true,
		'show_in_nav_menus' => false,
		'show_ui' => true,
		'hierarchical' => true,
		'rewrite' => array('slug' => 'slides_category', 'with_front' => false),
		'query_var' => true
	);
	
	register_post_type('slides', $args);
	
	register_taxonomy('taxonomy_slides', 'slides', $taxonomy_args);
	
	flush_rewrite_rules();
	
}

add_action('init', 'pk_register_slides');
 
function pk_slides_edit_columns($columns){
	
	$columns = array(
		'cb' => '<input type="checkbox" />',
		'title' => __('Slide Title', 'pk_text_domain'),
		'slides_thumb' => __('Featured Image', 'pk_text_domain'),
		'author' => __('Author', 'pk_text_domain'),
		'taxonomy_slides' => __('Slides Categories', 'pk_text_domain'),
		'date' => $columns['date']
	);
	
	return $columns;
	
}

add_filter('manage_edit-slides_columns', 'pk_slides_edit_columns');

function pk_slides_custom_columns($column){
	
	global $post;
	
	switch ($column) {
		
		case 'slides_thumb':
			
			if (function_exists('the_post_thumbnail') && has_post_thumbnail()) {
				
				the_post_thumbnail(array(80, 80));
				
			}
			
   			break;
			
		case 'taxonomy_slides':
			
			echo get_the_term_list($post -> ID, 'taxonomy_slides', '', ', ', '');
			
   			break;
			
	}
	
}

add_action('manage_posts_custom_column', 'pk_slides_custom_columns');

function pk_save_slides_sort() {
	
	global $wpdb;
	
	$order = explode(',', $_POST['order']);
	
	$counter = 0;
 
	foreach ($order as $slides_id) {
		
		$wpdb -> update($wpdb -> posts, array('menu_order' => $counter), array('ID' => $slides_id));
		$counter++;
		
	}
	
	do_action('pk_ah_posts_sorted');
	
	die();
	
}

add_action('wp_ajax_slides_sort', 'pk_save_slides_sort');

function pk_add_sort_slides_page() {
	
	add_submenu_page('edit.php?post_type=slides', 'Sort Slides', 'Sort Slides', 'edit_posts', basename(__FILE__), 'pk_create_sort_slides_page');
	
}

add_action('admin_menu', 'pk_add_sort_slides_page'); 

function pk_create_sort_slides_page() {
	
	$slides = new WP_Query('post_type=slides&posts_per_page=-1&orderby=menu_order&order=ASC');
	
?>

<!-- pk sort slides page - start -->
<div class="wrap">
	<div id="icon-options-general" class="icon32">
		<br />
	</div>
	<h2><?php _e('Sort Slides', 'pk_text_domain'); ?> <a href="<?php echo admin_url('post-new.php').'?post_type=slides'; ?>" class="button add-new-h2"><?php _e('Add New', 'pk_text_domain'); ?></a></h2>
	<br />
	<div id="pk_admin_saving_sorting" class="updated">
		<p><strong><?php _e('Saving the slides order...', 'pk_text_domain'); ?></strong></p>
	</div>
	<div id="pk_admin_success_sorting" class="updated">
		<p><strong><?php _e('Slides order saved!', 'pk_text_domain'); ?></strong></p>
	</div>
	<div id="pk_admin_error_sorting" class="updated">
		<p><strong><?php _e('Error saving the slides order, please try again.', 'pk_text_domain'); ?></strong></p>
	</div>
	<div>
		<ul id="pk_admin_sortable_list">
<?php if ($slides -> have_posts()) : while ($slides -> have_posts()) : $slides -> the_post(); ?>
			<li id="<?php the_id(); ?>" class="pk_admin_sortable_default">
				<?php if (function_exists('the_post_thumbnail') && has_post_thumbnail()) { the_post_thumbnail(array(80, 80), array('class' => 'pk_admin_sort_thumb')); } else { echo '<span class="pk_admin_sort_no_img"></span>'; } ?>
				
				<strong><a class="pk_admin_sort_titles" href="<?php echo admin_url('post.php').'?post='; the_id(); echo '&action=edit'; ?>"><?php the_title(); ?></a></strong>
				<p class="pk_admin_class_taxonomies"><?php the_taxonomies(); ?></p>
			</li>
<?php endwhile; ?>
		</ul>
<?php else :?>
		<p><?php _e('No slides found', 'pk_text_domain'); ?></p>
<?php endif; ?>
	</div>
</div>
<!-- pk sort slides page - end -->
<?php

}