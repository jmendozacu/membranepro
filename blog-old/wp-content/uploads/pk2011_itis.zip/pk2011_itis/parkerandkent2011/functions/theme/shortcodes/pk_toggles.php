<?php

/*
 * Toggles
*/

function pk_sc_toggles($atts, $content = null, $class) {
	
	extract(shortcode_atts(array(
		'width' => '',
		'align' => 'none'
	), $atts));
	
	($width != '' && $width != '0') ? $width = ' style="width:'.$width.'px;"' : $width = ' style="width:100%;"';
	
	return '<div class="'.$class.' pk_align'.strtolower($align).'"'.$width.'>'.do_shortcode($content).'</div>';
	
}

add_shortcode('pk_minimal_toggles', 'pk_sc_toggles');
add_shortcode('pk_boxed_toggles', 'pk_sc_toggles');

/*
 * Toggle
*/

function pk_sc_toggle($atts, $content = null, $class) {
	
	extract(shortcode_atts(array(
		'title' => ''
	), $atts));
	
	if ($class == 'pk_minimal_toggle') {
		
		return '<div class="pk_toggle pk_toggle_border"><p class="pk_toggle_button">'.$title.'</p><div class="pk_toggle_content_wrapper"><div class="pk_toggle_content">'.do_shortcode($content).'</div></div></div>';
		
	}
	
	if ($class == 'pk_boxed_toggle') {
		
		return '<div class="pk_toggle pk_rounded"><p class="pk_toggle_button">'.$title.'</p><div class="pk_toggle_content_wrapper"><div class="pk_toggle_content">'.do_shortcode($content).'</div></div></div>';
		
	}
	
}

add_shortcode('pk_minimal_toggle', 'pk_sc_toggle');
add_shortcode('pk_boxed_toggle', 'pk_sc_toggle');

?>