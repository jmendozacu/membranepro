<?php

function pk_add_previous_next_post_links(){
	
?>
<p class="pk_previous_next_post_links">
<?php
	previous_post_link();
	next_post_link();
?>
</p>
<?php
	
}

?>