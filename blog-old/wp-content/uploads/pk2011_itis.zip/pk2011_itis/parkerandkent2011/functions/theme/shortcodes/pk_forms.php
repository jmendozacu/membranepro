<?php

/*
 * Contact form
*/

static $pk_forms_counter = 0;

function pk_scp_contact_form($atts, $content = null) {
	
	extract(shortcode_atts(array(
		'send_to' => get_option('admin_email'),
		'name_label' => __('Name', 'pk_text_domain_front'),
		'email_label' => __('Email', 'pk_text_domain_front'),
		'message_label' => __('Message', 'pk_text_domain_front'),
		'subject' => '%sitename%: email from %name%'
	), $atts));
	
	global $pk_forms_counter;
	
	$pk_forms_counter++;
	
	$output = '
<!-- pk start contact form -->
<div class="pk_contact_form">
	<form id="pk_contact_form_'.$pk_forms_counter.'" action="pk_ajax_contact_form" method="POST">
		<input type="hidden" value="pk_ajax_contact_form" name="action" />
		<input type="hidden" value="'.str_replace('@', '[at]', $send_to).'" name="send_to" />
		<input type="hidden" value="'.$subject.'" name="subject" />
		<input type="text" id="contact_name_'.$pk_forms_counter.'" name="contact_name" tabindex="'.(1 + (($pk_forms_counter - 1) * 4)).'" /><label for="contact_name_'.$pk_forms_counter.'">'.$name_label.'</label>
		<input type="email" id="contact_email_'.$pk_forms_counter.'" name="contact_email" tabindex="'.(2 + (($pk_forms_counter - 1) * 4)).'" /><label for="contact_email_'.$pk_forms_counter.'">'.$email_label.'</label>
		<div class="pk_contact_form_textarea_wrapper">
			<textarea id="contact_message'.$pk_forms_counter.'" name="contact_message" rows="10" cols="10" tabindex="'.(3 + (($pk_forms_counter - 1) * 4)).'">'.$message_label.'</textarea>
		</div>
		<input type="submit" name="submit" value="Send" tabindex="'.(4 + (($pk_forms_counter - 1) * 4)).'" />
	</form>
	<script type="text/javascript">
		/*<![CDATA[*/
		jQuery("#pk_contact_form_'.$pk_forms_counter.'").pk_contact_form();
		/*]]>*/
	</script>
</div>
<!-- pk end contact form -->
';
	
	return $output;
		
}

add_shortcode('pk_contact_form', 'pk_scp_contact_form');

/*
 * Search form
*/

function pk_scp_search_form($atts, $content = null) {
	
	extract(shortcode_atts(array(
		'title' => ''
	), $atts));
	
	$output = '
<!-- pk start search form -->
<div class="pk_scp_search_form">';
	
	if ($title != '') $output .= '
	<h4>'.$title.'</h4>';
	
	$output .= '
	<form role="search" method="get" id="searchform" action="'.home_url().'">
		<div>
			<label class="screen-reader-text" for="s">Search for:</label>
			<input type="text" value="" name="s" id="s" />
			<input type="submit" id="searchsubmit" value="Search" />
		</div>
	</form>';
	
	$output .= '
</div>
<!-- pk end search form form -->
';
	
	return $output;
	
}

add_shortcode('pk_search_form', 'pk_scp_search_form');

?>