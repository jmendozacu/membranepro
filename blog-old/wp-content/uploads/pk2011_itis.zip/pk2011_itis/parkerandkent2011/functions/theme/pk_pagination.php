<?php

function pk_pagination($pages = '', $paged = 1, $range = 2) {
	
	$showitems = ($range * 2) + 1;
	
	if ($pages == '') {
		
		global $wp_query;
		
		$pages = $wp_query -> max_num_pages;
		
		if(!$pages) {
			
			$pages = 1;
			
		}
		
	}
	
	if (1 != $pages) {
		
		if ($paged > 1) {
			
			echo '<a href="'.esc_url(get_pagenum_link($paged - 1)).'" title="'.__('Previous page', 'pk_text_domain_front').'">'.__('&laquo;', 'pk_text_domain_front').'</a>';
			
		} else {
			
			echo '<a>'.__('&laquo;', 'pk_text_domain_front').'</a>';
			
		}
		
		$c = 1;
		
		for ($i = 1; $i <= $pages; $i++) {
			
			if (1 != $pages && (!($i >= $paged + $range + 1 || $i <= $paged - $range - 1) || $pages <= $showitems)) {
				
				echo ($paged == $i) ? '<a class="pk_current_page">'.$i.'</a>' : '<a href="'.esc_url(get_pagenum_link($i)).'">'.$i.'</a>';
				
				$c++;
				
			}
			
		}
		
		if ($paged < $pages) {
			
			echo '<a href="'.esc_url(get_pagenum_link($paged + 1)).'" title="'.__('Next page', 'pk_text_domain_front').'">'.__('&raquo;', 'pk_text_domain_front').'</a>
';
			
		} else {
			
			echo '<a>'.__('&raquo', 'pk_text_domain_front').'</a>
';
			
		}
		
	}
	
}

?>