<?php

function pk_get_options($type = '', $option = '', $profile = '') {
	
	if ($profile == '') {
		
		$profile = get_option($type.'_active_profile');
		
	}
	
	$options = get_option($type.(($profile == '') ? '' : '_'.$profile));
	
	if ($option == '') {
		
		$decoded_options = array();
		
		if (isset($options) && is_array($options)) foreach ($options as $k => $v) {
			
			$decoded_options[$k] = urldecode($v);
			
		}
		
		return $decoded_options;
		
	} else {
		
		return (isset($options[$option])) ? urldecode($options[$option]) : '';	
		
	}
	
}

?>