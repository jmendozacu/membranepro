<?php
	
	do_action('pk_ah_pre_'.((is_tax('taxonomy_works')) ? 'works_taxonomy' : 'works').'_grid_categories_filter');
	do_action('pk_ah_'.((is_tax('taxonomy_works')) ? 'works_taxonomy' : 'works').'_print_grid_categories_filter');
	do_action('pk_ah_pre_'.((is_tax('taxonomy_works')) ? 'works_taxonomy' : 'works').'_grid_loop');
	
	if (have_posts()) : 
		
		while (have_posts()) : 
			
			the_post();
			
			do_action('pk_ah_'.((is_tax('taxonomy_works')) ? 'works_taxonomy' : 'works').'_print_grid_item');
			
		endwhile;
		
	endif;
	
	do_action('pk_ah_after_'.((is_tax('taxonomy_works')) ? 'works_taxonomy' : 'works').'_grid_loop');
	
	if ($wp_query -> max_num_pages > 1) : 
		
		do_action('pk_ah_pre_'.((is_tax('taxonomy_works')) ? 'works_taxonomy' : 'works').'_grid_pagination');
		do_action('pk_ah_'.((is_tax('taxonomy_works')) ? 'works_taxonomy' : 'works').'_grid_pagination');
		do_action('pk_ah_after_'.((is_tax('taxonomy_works')) ? 'works_taxonomy' : 'works').'_grid_pagination');
		
	endif;
	
?>