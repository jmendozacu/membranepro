<?php
	
	do_action('pk_ah_pre_'.((is_archive()) ? 'blog_archive' : ((is_search()) ? 'search' : 'blog')).'_loop');
	
	if (have_posts()) : 
		
		while (have_posts()) : 
			
			the_post();
			
			if ($pk_layout == 'standard') {
				
				do_action('pk_ah_'.((is_archive()) ? 'blog_archive' : ((is_search()) ? 'search' : 'blog')).'_print_list_item_standard');
				
			} else {
				
				do_action('pk_ah_'.((is_archive()) ? 'blog_archive' : ((is_search()) ? 'search' : 'blog')).'_print_list_item_alternative');
				
			}
			
		endwhile;
		
		do_action('pk_ah_after_'.((is_archive()) ? 'blog_archive' : ((is_search()) ? 'search' : 'blog')).'_loop');
		
		if ($wp_query -> max_num_pages > 1) : 
			
			do_action('pk_ah_pre_'.((is_archive()) ? 'blog_archive' : ((is_search()) ? 'search' : 'blog')).'_pagination');
			do_action('pk_ah_'.((is_archive()) ? 'blog_archive' : ((is_search()) ? 'search' : 'blog')).'_pagination');
			do_action('pk_ah_after_'.((is_archive()) ? 'blog_archive' : ((is_search()) ? 'search' : 'blog')).'_pagination');
			
		endif;
		
	else : 
	
		do_action('pk_ah_'.((is_archive()) ? 'blog_archive' : ((is_search()) ? 'search' : 'blog')).'_no_posts_available');
		
	endif;
	
?>