<?php

function pk_google_analytics() {
	
	$google_analytics_code = pk_get_options('pk_general_options', 'general_google_analytics_code');
	
	if ($google_analytics_code) {
		
		echo '<!-- pk start analytics -->
<div class="pk_invisible">
'.stripslashes($google_analytics_code).'
</div>
<!-- pk end analytics -->

';
		
	}
	
}

add_action('wp_footer', 'pk_google_analytics');

?>