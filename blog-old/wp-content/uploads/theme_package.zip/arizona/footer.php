<!-- BEGIN FOOTER -->
   
   	<div id="footer">
    	 <div id="footer-wrapper">
        	<?php
        		$al_options = get_option('al_general_settings'); 
        		 $footer_widget_count = isset($al_options['al_footer_widgets_count']) ? $al_options['al_footer_widgets_count']:4;
        			$width = floor((960 - $footer_widget_count * 80 + 20)  / $footer_widget_count).'px';
				   for($i = 1; $i<= $footer_widget_count; $i++)
				   {
					   if($i<$footer_widget_count)
					   {
				   	  		echo '<div class="footer-block" style="width:'.$width.' ">';
					   }
					   else
					   {
						  echo  '<div class="footer-block" style="width:'.$width.'; padding-right:0">';
					   }
						if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar("Footer Widget ".$i) ) :endif;
				    	echo '</div>';
				    
				   }
        	?>
            <div class="clear"></div>
      	</div>
     </div>
    <div id="footer-bottom">
        <div id="footer-bottom-wrapper">
            <div id="copyright">
                <?php  
                    $al_options = get_option('al_general_settings'); 
                    echo $al_options['al_copyright'];
                ?>
            </div>
            <div id="footer-right">
            	<a href="http://www.wpmeta.com">Premium WordPress Themes</a>
            </div>
            <div class="clear"></div>
        </div>
     	
   </div> 
    <!-- END FOOTER -->
    <?php echo $al_options['al_ganalytics'];?>
    <?php wp_footer() ?> 
</body>
</html>