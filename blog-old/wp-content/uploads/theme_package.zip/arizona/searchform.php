<form action="/" method="get" id="search-form">   
   	<div>
		<input type="text" name="s" id="search" class="txt" value="<?php the_search_query(); ?>" />
   	</div>
   	<div>
		<button type="submit" name="search" id="search-submit" class="button small blue"><?php _e('Search', 'arizona');?></button>
	</div>
</form>
