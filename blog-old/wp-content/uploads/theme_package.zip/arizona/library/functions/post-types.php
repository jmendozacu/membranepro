<?php
/*************** SLIDER POST-TYPES  ****************/
add_action('init', 'slider_items_register');

function slider_items_register() 
{	
	register_post_type( 'slider' , 
						array(
							'label' => 'Slider Items',
							'singular_label' => 'Slider Item',
							'public' => true,
							'show_ui' => true,
							'capability_type' => 'post',
							'hierarchical' => false,
							'rewrite' => true,
							'supports' => array('title', 'thumbnail', 'editor')
						)
					);
	
	//add_filter('manage_edit-slider_columns', 'slider_edit_columns');
	//add_action('manage_posts_custom_column',  'slider_custom_columns');	
	
}

add_action("admin_init", "add_slide");
add_action('save_post', 'update_slide_url');

function add_slide()
{
	add_meta_box("slider_details", "Slider Options", "slider_options", "slider", "normal", "low");
}
	
function slider_options()
{
	global $post;
	$custom = get_post_custom($post->ID);
	$slide_url = isset($custom["slide_url"][0]) ? $custom["slide_url"][0] : '';
	?>
	<div class="al_input">
		<label for="slideurl">Slide URL:</label>
		<input name="slide_url" id="slideurl" value="<?php echo $slide_url; ?>" />
		<small>Url the slide refers to. Leave blank if you don't want it to be a link.</small><div class="clearfix"></div>		
	</div>   
	<?php
}

function update_slide_url()
{
	global $post;
	if(isset($_POST["slide_url"]))
	update_post_meta($post->ID, "slide_url", $_POST["slide_url"]);
}


add_filter("manage_edit-slider_columns", "slider_edit_columns");
add_action("manage_posts_custom_column",  "slider_columns_display");
 
function slider_edit_columns($portfolio_columns){
	$slider_columns = array(
		"cb" => "<input type=\"checkbox\" />",
		"title" => "Slide Title",
		"description" => "Description",
		"slide_url" => "Slide url"
		//'slider_image' => 'Image',
	);
	return $slider_columns;
}
 
function slider_columns_display($slider_columns){
	switch ($slider_columns)
	{
		case "description":
			the_excerpt();
			break;
		//case 'slider_image':
		//	the_post_thumbnail( 'gallery' );
		//	break;
		case 'slide_url':  
			$custom = get_post_custom();  
			echo $custom['slide_url'][0];  
			break;  				
	}
}


/*************** POSTFOLIO POST-TYPES  ****************/
add_action('init', 'portfolio_register');

function portfolio_register() {	

	register_post_type( 'portfolio' , 
						array(
							'label' => 'Portfolio',
							'singular_label' => 'Portfolio',
							'exclude_from_search' => true,
							'publicly_queryable' => true,
							'rewrite' => array('with_front' => false, 'slug'=>'projects'),
							'show_ui' => true, 
							'query_var' => true,
							'capability_type' => 'post',
							'hierarchical' => false,
							'edit_item' => __( 'Edit Work' ),
							'supports' => array('title', 'editor', 'thumbnail', 'excerpt', 'custom-fields', 'comments', 'revisions')
						)
					);
	
	add_filter('manage_edit-portfolio_columns', 'portfolio_edit_columns');
	add_action('manage_posts_custom_column',  'portfolio_custom_columns');
	
	function portfolio_edit_columns($columns){
		$columns = array(
			'cb' => '<input type="checkbox" />',
			'title' => 'Title',
			'portfolio_description' => 'Description'
		);
	
		return $columns;
	}
	
	function portfolio_custom_columns($column){
		global $post;
		switch ($column)
		{
			case 'portfolio_description':
				the_excerpt();  
				break;  

			case 'portfolio_image':
				the_post_thumbnail( 'portfolio1' );
				break;
		}
	}
}
?>