<?php
/* ***************************************************** 
 * File Description: Contains all theme's shortcodes
 * Author: Weblusive
 * Author URI: http://www.weblusive.com
 * ************************************************** */


/*********** ENABLE RAW CONTENT ************/
function my_formatter($content) 
{
       $new_content = '';
       $pattern_full = '{(\[raw\].*?\[/raw\])}is';
       $pattern_contents = '{\[raw\](.*?)\[/raw\]}is';
       $pieces = preg_split($pattern_full, $content, -1, PREG_SPLIT_DELIM_CAPTURE);

       foreach ($pieces as $piece) 
       {
               if (preg_match($pattern_contents, $piece, $matches)) 
               {
                       $new_content .= $matches[1];
               } else 
               {
                       $new_content .= wptexturize(wpautop($piece));
               }
       }

       return $new_content;
}

remove_filter('the_content', 'wpautop');
remove_filter('the_content', 'wptexturize');

add_filter('the_content', 'my_formatter', 99);

/**********************************************/


/***************** BUTTONS ********************/

function al_button($atts, $content = null) {

	extract(shortcode_atts(array(
		"id"			=> '',
		"class"			=> '',
		"href" 			=> '#', 
		"bg" 			=> 'white',
		"color"			=> '',
		"size"		 	=> 'medium',
		"type"			=> '',		
	
	), $atts));
	
	$withicon = '';
	
	$color = isset($color) && $color != '' ? 'style="color:'.$color.'"' : '';
	$id = isset($id) && $id != '' ? 'id="'.$id.'"' : '';
	
	return '<a href="'.$href.'" '.$id.' class="button '.$bg.' '.$size.' '.$class.' '.$type.'" '.$color.'><span>'.$content.'</span></a>';
}
add_shortcode('button', 'al_button');

/************************************************/


/************** Top / Inner Titles  *************/

function al_top_title( $atts, $content = null ) {
	extract(shortcode_atts(array(
		'class'	=> '',
		'icon'	=> ''
	), $atts));
	
	
	if($icon != '') $icon = 'with-icon '.$icon;
	$out = "<h2 class=\"top-title {$icon} {$class}\" >".$content."</h2>";
	
	return $out; 
}
add_shortcode('top-title', 'al_top_title');

/************************************************/


/*************** ORDERED LISTS ******************/

function al_olist($atts, $content = null) {
	extract(shortcode_atts(array(
		'style'	=> '',
	), $atts));
	return '<ol class="ordered-list '.$style.'">'.do_shortcode($content).'</ol>';
}
add_shortcode('olist', 'al_olist');

function al_olitem($atts, $content = null) {
	extract(shortcode_atts(array(
		'style'	=> '',
	), $atts));
	return '<li><p>'.$content.'</p></li>';
}
add_shortcode('olitem', 'al_olitem');

/************************************************/


/************** TEXT HIGLIGHTING ****************/

function al_highlight($atts, $content = null) {

	extract(shortcode_atts(array(
		"type"			=> '',
		"color"			=> '',
		"bg" 	=> '',
		
	), $atts));	
	
	$style = false;
	$params1 = isset($color) ? 'color:'.$color.'; ' : '';
	$params2 = isset($bg) ? 'background-color:'.$bg.'; ' : '';
	if($params1 !='' || $params2!='')
	{
		$style = ' style="'.$params1.$params2.'"';
	}
	
	return '<span class="highlight '.$type.'"'.$style.'>'.$content.'</span>';
}
add_shortcode('highlight', 'al_highlight');

/************************************************/


/*************** VARIOUS BOXES ******************/

function al_box($atts, $content = null) {

	extract(shortcode_atts(array(
		"type"	=> '',
		"title"	=> '',
		"bg"	=> 'grey',
		"color" => ''
		
	), $atts));	
	
	$color = isset($color) && $color!='' ? ' style="color:'.$color.'"' : '';
	$title = isset($title) && $title !='' ? '<div class="box-title '.$bg.'"><h2'.$color.'>'.$title.'</h2></div>' : '';
	
	if(isset($type) && $type != '')
	{
		return '<div class="box '.$type.'"><div class="box-content '.$bg.' '.$type.'">'.$title.' '.do_shortcode($content).'</div></div>';	
	}
	else
	{
		return '<div class="box '.$type.'">'.$title.'<div class="box-content '.$bg.' '.$type.'">'.do_shortcode($content).'</div></div>';	
	}
}
add_shortcode('box', 'al_box');
 
/************************************************/


/**** BANNER ADS (ALMOST ALL STANDARD SIZES) ****/

function al_ad( $atts, $content=null ) {
    extract(shortcode_atts(array(
        'size' => '125x125',
        'source' => '',
        'title' => 'Banner Ad',
        'link'  => '#',
        'class' => '',
        'id'	=> ''
    ), $atts));
 	
    $theId = ($id !='' ? ' id="'.$id.'"' : '');
    
    $fsize = explode('x', $size);
 	return "<div class = \"banner banner-{$size}{$class}\"{$theId}>
 				<a href=\"{$link}\"><img src=\"{$source}\" alt=\"{$title}\" /></a>{$content}</div>";
 
}
add_shortcode('ad', 'al_ad');

/************************************************/


/*************** DIVIDER LINE ******************/

function al_divider($atts, $content = null) {
	  extract(shortcode_atts(array(
        'type' => '',
		'mode' => '',
        
    ), $atts));
   return '<div class="divider'.$mode.' '.$type.'"></div>';
}
add_shortcode('divider', 'al_divider');

/************************************************/


/****************** SPACING ********************/

function al_spacing($atts, $content = null) {
  extract(shortcode_atts(array(
        'type' => 'top',
        'amount' => '10',
   ), $atts));
   return '<div class="'.$type.$amount.'"></div>';
}
add_shortcode('spacing', 'al_spacing');

/************************************************/


/************** FEATURED BLOCKS *****************/

function al_fblock($atts, $content = null) {
  extract(shortcode_atts(array(
        'icon' => '',
        'title' => '',
   ), $atts));
   
   if($icon !='') $icon = '<img src="'.$icon.'" alt="'.$title.'" />';
   if($title!='') $title = '<h3>'.$title.'</h3>';
   
   return '<div class="featured-block">'.$icon.$title.'
	   		   <p>'.do_shortcode($content).'</p>
	   		   <div class="clear"></div>
   		   </div>';
}
add_shortcode('fblock', 'al_fblock');

/************************************************/


/************* VIMEO EMBED (VIA ID) *************/

function al_vimeo($atts, $content=null) {
	
	   extract(shortcode_atts(array(
            "id" => '',
            "width" => '600',
            "height" => '400'
        ), $atts));
    
    $data = '<object width="'.$width.'" height="'.$height.'" data="http://vimeo.com/moogaloop.swf?clip_id='.$id.'&amp;server=vimeo.com" type="application/x-shockwave-flash">
            <param name="wmode" value="transparent" />
			<param name="allowfullscreen" value="true" />
            <param name="allowscriptaccess" value="always" />
            <param name="movie" value="http://vimeo.com/moogaloop.swf?clip_id='.$id.'&amp;server=vimeo.com" />
        </object>';
    return $data;
}
add_shortcode('vimeo', 'al_vimeo');

/************************************************/


/************** YOUTUBE EMBED (VIA ID) **********/

$youtube_nr = 0;
function al_youtube($atts, $content=null) {
	 extract(shortcode_atts(array(
			'id'  => '',
			'width'  => '600',
			'height' => '400'
			), $atts));

		return '<div class="youtube_video">
				<object type="application/x-shockwave-flash" style="width:'.$width.'px; height:'.$height.'px;" data="http://www.youtube.com/v/'.$id.'&amp;hl=en_US&amp;fs=1&amp;" wmode="transparent">
					<param name="movie" value="http://www.youtube.com/v/'.$id.'&amp;hl=en_US&amp;fs=1&amp;" />
					<param name="wmode" value="transparent" />
				</object>
				</div>';

}
add_shortcode('youtube', 'al_youtube');
/************************************************/


/***************** DROPCAPS *********************/

function al_dropcap( $atts, $content = null ) {
	extract(shortcode_atts(array(
	'color'	=> ''
	), $atts));
	
	$color = isset($color) && !empty($color) ? 'style="color:'.$color.'"'  : '';
	
   	return '<span class="dropcap" '.$color.'>' . $content . '</span>';

}
add_shortcode('dropcap', 'al_dropcap');

/************************************************/


/********* PDF LINK WITH GOOGLE VIEWER **********/

function pdflink($attr, $content) {
	if ($attr['href']) {
		return '<a class="link" href="http://docs.google.com/viewer?url=' . $attr['href'] . '">'.$content.'</a>';
	} else {
		$src = str_replace("=", "", $attr[0]);
		return '<a class="pdf" href="http://docs.google.com/viewer?url=' . $src . '">'.$content.'</a>';
	}
}
add_shortcode('pdf', 'pdflink');

/************************************************/


/***************** CHECKLISTS *******************/

function al_checklist($atts, $content = null) {
	extract(shortcode_atts(array(
		'type' 	=> '',
	
	), $atts));
	if($type !='') $type = 'checklist-'.$type;
	return '
<div class="checklist '.$type.'">'.$content.'</div>
';
}
add_shortcode('checklist', 'al_checklist');

/************************************************/


/***************** CLEAR *******************/

function al_clear($atts, $content = null) {	
	return '<div class="clear"></div>';
}
add_shortcode('clear', 'al_clear');

/************************************************/


/********* STANDARD UNORDERED LISTS *************/

function al_list($atts, $content = null) {
	extract(shortcode_atts(array(
		'type' 	=> '',
	
	), $atts));
	if($type !='') $type = 'list-'.$type;
	return '
<div class="list '.$type.'">'.$content.'</div>
';
}
add_shortcode('list', 'al_list');

/************************************************/


/****************** COLUMNS *********************/

// COLUMN 1/2
function one_half( $atts, $content = null ) {
   return '<div class="one_half">' . do_shortcode($content) . '</div>'; }
add_shortcode('one_half', 'one_half');

// COLUMN 1/2 Last
function one_half_last( $atts, $content = null ) {
   return '<div class="one_half last">' . do_shortcode($content) . '</div><div class="clear"></div>'; }
add_shortcode('one_half_last', 'one_half_last');

// COLUMN 1/3 
function one_third( $atts, $content = null ) {
   return '<div class="one_third">' . do_shortcode($content) . '</div>'; }
add_shortcode('one_third', 'one_third');

// COLUMN 1/3 Last
function one_third_last( $atts, $content = null ) {
   return '<div class="one_third last">' . do_shortcode($content) . '</div><div class="clear"></div>'; }
add_shortcode('one_third_last', 'one_third_last');

// COLUMN 2/3
function two_third( $atts, $content = null ) {
   return '<div class="two_third">' . do_shortcode($content) . '</div>'; }
add_shortcode('two_third', 'two_third');

// COLUMN 2/3 Last
function two_third_last( $atts, $content = null ) {
   return '<div class="two_third last">' . do_shortcode($content) . '</div><div class="clear"></div>'; }
add_shortcode('two_third_last', 'two_third_last');

// COLUMN 1/4
function one_fourth( $atts, $content = null ) {
   return '<div class="one_fourth">' . do_shortcode($content) . '</div>'; }
add_shortcode('one_fourth', 'one_fourth');

// COLUMN 1/4 Last
function one_fourth_last( $atts, $content = null ) {
   return '<div class="one_fourth last">' . do_shortcode($content) . '</div><div class="clear"></div>'; }
add_shortcode('one_fourth_last', 'one_fourth_last');

// COLUMN 1/5
function one_fifth( $atts, $content = null ) {
   return '<div class="one_fifth">' . do_shortcode($content) . '</div>'; }
add_shortcode('one_fifth', 'one_fifth');

// COLUMN 1/5 Last
function one_fifth_last( $atts, $content = null ) {
   return '<div class="one_fifth last">' . do_shortcode($content) . '</div><div class="clear"></div>'; }
add_shortcode('one_fifth_last', 'one_fifth_last');

// COLUMN 3/4
function three_fourth( $atts, $content = null ) {
   return '<div class="three_fourth">' . do_shortcode($content) . '</div>'; }
add_shortcode('three_fourth', 'three_fourth');

// COLUMN 3/4 Last
function three_fourth_last( $atts, $content = null ) {
   return '<div class="three_fourth last">' . do_shortcode($content) . '</div><div class="clear"></div>'; }
add_shortcode('three_fourth_last', 'three_fourth_last');

// COLUMN 4/5
function four_fifth( $atts, $content = null ) {
   return '<div class="four_fifth">' . do_shortcode($content) . '</div>'; }
add_shortcode('four_fifth', 'four_fifth');

// COLUMN 4/5 Last
function four_fifth_last( $atts, $content = null ) {
   return '<div class="four_fifth last">' . do_shortcode($content) . '</div><div class="clear"></div>'; }
add_shortcode('four_fifth_last', 'four_fifth_last');

/************************************************/


/******************* QUOTES *********************/

function al_quote( $atts, $content = null ) {
	extract(shortcode_atts(array(
		'author' => '',
		'align'	 => 'center',
		'class' => ''
	), $atts));
	$out = "<blockquote class=\"{$align} {$class}\"><p>" .do_shortcode($content). "</p><div class=\"author\">" .$author. "</div></blockquote>";
	return $out; }
add_shortcode('quote', 'al_quote');

/************************************************/


/***************** BASIC TABS *******************/

add_shortcode( 'tabgroup', 'al_tab_group' );
function al_tab_group( $atts, $content ){
	$GLOBALS['tab_count'] = 0;
	
	do_shortcode( $content );
	
	if( is_array( $GLOBALS['tabs'] ) ){
	foreach( $GLOBALS['tabs'] as $tab ){
	$tabs[] = '<li><a class="" href="#">'.$tab['title'].'</a></li>';
	$panes[] = '<div class="pane">'.do_shortcode($tab['content']).'</div>';
	}
	$return = "\n".'<!-- the tabs --><ul class="tabs">'.implode( "\n", $tabs ).'</ul>'."\n".'<!-- tab "panes" --><div class="panes">'.implode( "\n", $panes ).'</div>'."\n";
	}
	return $return;
}

add_shortcode( 'tab', 'al_tab' );

function al_tab( $atts, $content ){
	extract(shortcode_atts(array(
	'title' => 'Tab %d'
	), $atts));
	
	$x = $GLOBALS['tab_count'];
	$GLOBALS['tabs'][$x] = array( 'title' => sprintf( $title, $GLOBALS['tab_count'] ), 'content' =>  $content );
	
	$GLOBALS['tab_count']++;
}

/************************************************/


/***************** TOGGLES **********************/

function al_toggle($atts, $content = null ) {
	extract(shortcode_atts(array(
		'bg'	=> 'toggle',
		'class'	=> '',
		'title'	=> '',
	
	), $atts));
		
	return '<div class="toggle-trigger '.$bg.'-back rounded"><a href="#" class="tr'.$class.'">'.$title.'</a></div> 
			<div class="toggle-container"> 
				<div class="block"> 
					'.do_shortcode($content).'
				</div> 
			</div> 
			'; 
}
add_shortcode('toggle', 'al_toggle');

/************************************************/


/**************** ALIGNMENTS ****************/

function al_align( $atts, $content = null)
{
   extract(shortcode_atts(array(
		'pos'	=> 'left',
		'width'	=> '',
		'class' => ''
	), $atts));	
	
	$width = isset($width) && $width !='' ? 'style="width:'.$width.'px"' : '';
	
   return '<div class="align'.$pos.' '.$class.'" '.$width.'>'. do_shortcode($content) .'</div>';
}
add_shortcode('align', 'al_align');

/************************************************/


/*************** GOOGLE MAPS ********************/

/*
Plugin Name: Google Maps v3 Shortcode
Plugin URI: http://gis.yohman.com
Description: This plugin allows you to add one or more maps to your page/post using shortcodes.  Features include:  multiple maps on the same page, specify location by address or lat/lon combo, add kml, show traffic, add your own custom image icon, set map size.
Version: 1.02
Author: yohda
Author URI: http://gis.yohman.com/
*/

// Add the google maps api to header

// Main function to generate google map
function mapme($attr) {

	// default atts
	$attr = shortcode_atts(array(	
		'lat'   => '0', 
		'lon'    => '0',
		'id' => 'map',
		'z' => '1',
		'w' => '260',
		'h' => '260',
		'maptype' => 'ROADMAP',
		'address' => '',
		'kml' => '',
		'marker' => '',
		'markerimage' => '',
		'traffic' => 'no',
		'infowindow' => ''
		
		), $attr);
									
$returnme = '<div id="' .$attr['id'] . '" style="width:' . $attr['w'] . 'px;height:' . $attr['h'] . 'px;"></div>
    <script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false"></script>
	<script type="text/javascript">
    	var latlng = new google.maps.LatLng(' . $attr['lat'] . ', ' . $attr['lon'] . ');
		var myOptions = {
			zoom: ' . $attr['z'] . ',
			center: latlng,
			mapTypeId: google.maps.MapTypeId.' . $attr['maptype'] . '
		};
		var ' . $attr['id'] . ' = new google.maps.Map(document.getElementById("' . $attr['id'] . '"),
		myOptions);
		';
				
		//kml
		if($attr['kml'] != '') 
		{
			//Wordpress converts "&" into "&#038;", so converting those back
			$thiskml = str_replace("&#038;","&",$attr['kml']);		
			$returnme .= '
			var kmllayer = new google.maps.KmlLayer(\'' . $thiskml . '\');
			kmllayer.setMap(' . $attr['id'] . ');
			';
		}
		
		//traffic
		if($attr['traffic'] == 'yes')
		{
			$returnme .= '
			var trafficLayer = new google.maps.TrafficLayer();
			trafficLayer.setMap(' . $attr['id'] . ');
			';
		}
	
		//address
		if($attr['address'] != '')
		{
			$returnme .= '
		    var geocoder_' . $attr['id'] . ' = new google.maps.Geocoder();
			var address = \'' . $attr['address'] . '\';
			geocoder_' . $attr['id'] . '.geocode( { \'address\': address}, function(results, status) {
				if (status == google.maps.GeocoderStatus.OK) {
					' . $attr['id'] . '.setCenter(results[0].geometry.location);
					';
					
					if ($attr['marker'] !='')
					{
						//add custom image
						if ($attr['markerimage'] !='')
						{
							$returnme .= 'var image = "'. $attr['markerimage'] .'";';
						}
						$returnme .= '
						var marker = new google.maps.Marker({
							map: ' . $attr['id'] . ', 
							';
							if ($attr['markerimage'] !='')
							{
								$returnme .= 'icon: image,';
							}
						$returnme .= '
							position: ' . $attr['id'] . '.getCenter()
						});
						';

						//infowindow
						if($attr['infowindow'] != '') 
						{
							//first convert and decode html chars
							$thiscontent = htmlspecialchars_decode($attr['infowindow']);
							$returnme .= 'var contentString = \'' . $thiscontent . '\'
								var infowindow = new google.maps.InfoWindow({
								content: contentString
							});
										
							google.maps.event.addListener(marker, \'click\', function() {
							  infowindow.open(' . $attr['id'] . ',marker);
							});
				
							';
						}


					}
			$returnme .= '
				} else {
				alert("Geocode was not successful for the following reason: " + status);
			}
			});
			';
		}

		//marker: show if address is not specified
		if ($attr['marker'] != '' && $attr['address'] == '')
		{
			//add custom image
			if ($attr['markerimage'] !='')
			{
				$returnme .= 'var image = "'. $attr['markerimage'] .'";';
			}

			$returnme .= '
				var marker = new google.maps.Marker({
				map: ' . $attr['id'] . ', 
				';
				if ($attr['markerimage'] !='')
				{
					$returnme .= 'icon: image,';
				}
			$returnme .= '
				position: ' . $attr['id'] . '.getCenter()
			});
			';

			//infowindow
			if($attr['infowindow'] != '') 
			{
				$returnme .= '
				var contentString = \'' . $attr['infowindow'] . '\';
				var infowindow = new google.maps.InfoWindow({
					content: contentString
				});
							
				google.maps.event.addListener(marker, \'click\', function() {
				  infowindow.open(' . $attr['id'] . ',marker);
				});
	
				';
			}


		}

		$returnme .= '</script>';
		return $returnme;
	?>
    

	<?php
}
add_shortcode('map', 'mapme');

/************************************************/


/******** EMBED WIDGETS VIA SHORTCODE **********/

function widget($atts) {
    
    global $wp_widget_factory;
    
    extract(shortcode_atts(array(
        'widget_name' => FALSE
    ), $atts));
    
    $widget_name = esc_html($widget_name);
    
    if (!is_a($wp_widget_factory->widgets[$widget_name], 'WP_Widget')):
        $wp_class = 'WP_Widget_'.ucwords(strtolower($class));
        
        if (!is_a($wp_widget_factory->widgets[$wp_class], 'WP_Widget')):
            return '<p>'.sprintf(__("%s: Widget class not found. Make sure this widget exists and the class name is correct"),'<strong>'.$class.'</strong>').'</p>';
        else:
            $class = $wp_class;
        endif;
    endif;
    
    ob_start();
    the_widget($widget_name, $instance, array('widget_id'=>'arbitrary-instance-'.$id,
        'before_widget' => '',
        'after_widget' => '',
        'before_title' => '',
        'after_title' => ''
    ));
    $output = ob_get_contents();
    ob_end_clean();
    return $output;
    
}
add_shortcode('widget','widget'); 

/************************************************/


/******** SHORTCODE SUPPORT FOR WIDGETS *********/

if (function_exists ('shortcode_unautop')) {
	add_filter ('widget_text', 'shortcode_unautop');
}
add_filter ('widget_text', 'do_shortcode');

/************************************************/


/************* LIST PORTFOLIO ITEMS *************/

function al_list_portfolio($atts, $content = null) {
    extract(shortcode_atts(array(
            "limit" => '3',
    		"cols"  => '3'
    ), $atts));
 	global $post;
    $counter = 1; 
   	$query = new WP_Query(array('post_type' => 'portfolio', 'showposts' => $limit, 'posts_per_page' => 9));
	
   	$return = '<ul id="portfolio-list" class="cols-'.$cols.'">';
	   	
	while ($query->have_posts()) : $query->the_post(); 
		$custom = get_post_custom($post->ID);  	
		
		if($counter>0 && $counter%$limit==0)
		{
		$return.= '<li class="edge">';
		}
		else
		{
			$return.= '<li>'; 
		}
		$full_image = wp_get_attachment_image_src(get_post_thumbnail_id($post->ID), 'full', false);
	   
	    $return.= '<div>'.get_the_post_thumbnail($post->ID, 'portfolio-thumb-3cols', array('class' => 'portfolio')).'</div>';
	   	$return.='<h4><a href="'.get_permalink($post->ID).'">'.get_the_title().'</a></h4>';
		$return.= '<p>'.limit_words(get_the_excerpt(), '11').'</p>';
	    $return.= '<span class="poverlay"></span>';
	   	$return.= '<a href="'.$full_image[0].'" class="zoom-icon" title="'.get_the_title().'" rel="prettyPhoto[portfolio]"></a>';
		$return.='<a href="'.get_permalink($post->ID).'" class="button gray small read-more"><span>Read More</span></a>';
	    $return.= '<div class="clear"></div></li>';               
	   
		$counter++;  
	endwhile; wp_reset_query();
	
	$return.='</ul><div class="clear"></div>';
	
	return $return;
	
}
add_shortcode("list_portfolio", "al_list_portfolio"); 

/************************************************/

/*************** SOCIAL BUTTONS *****************/

function al_socialbutton($atts, $content = null) {

	extract(shortcode_atts(array(
		"name"	=> '',
		"link" 	=> '#', 
		"icon"	=> '',
		"title"	=> '',
	), $atts));
	
	$alt = isset($alt) && $alt != '' ? $alt : $name;
	$predefined = array('facebook', 'twitter', 'vimeo');
	$icon = in_array($name, $predefined) ? get_template_directory_uri().'/img/icons/'.$name.'.png' : $icon.'' ;
	
	return '<a href="'.$link.'" class="social-button"><img src="'.$icon.'" alt="'.$title.'" /></a>';
}
add_shortcode('social_button', 'al_socialbutton');

/************************************************/
?>