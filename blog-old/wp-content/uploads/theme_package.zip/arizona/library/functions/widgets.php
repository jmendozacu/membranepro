<?php

/**** WIDGETS AREA ****/


/* ***************************************************** 
 * Plugin Name: Arizona Flickr
 * Description: Retrieve and display photos from Flickr.
 * Version: 1.0
 * Author: Weblusive
 * Author URI: http://www.weblusive.com
 * ************************************************** */
class al_flickr_widget extends WP_Widget {

	// Widget setup.
	function al_flickr_widget() {

		// Widget settings.
		$widget_ops = array(
			'classname' => 'widget_al_flickr',
			'description' => __('Display images from flickr', 'arizona')
		);

		// Widget control settings.
		$control_ops = array(
			'width' => 50,
			'height' => 50,
			'id_base' => 'al-flickr-widget'
		);

		// Create the widget.
		$this->WP_Widget('al-flickr-widget', __('Arizona Flickr', 'al_flickr') , $widget_ops, $control_ops);
	}

	// Display the widget on the screen.
	function widget($args, $instance) {
		extract($args);
		$title = apply_filters('widget_title', $instance['title']);
		$id = $instance['flickr_id'];
		$nr = ($instance['flickr_nr'] != '') ? $nr = $instance['flickr_nr'] : $nr = 6;
		echo $before_widget;
		if ($title) echo $before_title . $title . $after_title;
		echo '<script type="text/javascript" src="http://www.flickr.com/badge_code_v2.gne?count=' . $nr . '&amp;display=latest&amp;size=s&amp;layout=x&amp;source=user&amp;user=' . $id . '"></script>';
		echo '<div class="clear"></div>'.$after_widget;
	}

	function update($new_instance, $old_instance) {
		$instance = $old_instance;
		$instance['title'] = strip_tags($new_instance['title']);
		$instance['flickr_id'] = strip_tags($new_instance['flickr_id']);
		$instance['flickr_nr'] = strip_tags($new_instance['flickr_nr']);
		return $instance;
	}

	function form($instance) {
		$defaults = array(
		'title' => 'Latest From Flickr',
		'flickr_nr' => '9',
		'flickr_id' => '12285897@N00'
		);
		
		$instance = wp_parse_args((array)$instance, $defaults); ?>
		<p>
			<label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title:', 'hybrid'); ?></label>
			<input id="<?php echo $this->get_field_id('title'); ?>" type="text" name="<?php echo $this->get_field_name('title'); ?>" value="<?php echo $instance['title']; ?>" class="widefat" />
		</p>
        
		<p>
			<label for="<?php echo $this->get_field_id('flickr_id'); ?>">Flickr ID</label> 
			<input id="<?php echo $this->get_field_id('flickr_id'); ?>" type="text" name="<?php echo $this->get_field_name('flickr_id'); ?>" value="<?php echo $instance['flickr_id']; ?>" class="widefat" />
            <small style="line-height:12px;"><a href="http://www.idgettr.com">Find your Flickr user or group id</a></small>
		</p>
        <p>
			<label for="<?php echo $this->get_field_id('flickr_nr'); ?>">Number of photos</label> 
			<input id="<?php echo $this->get_field_id('flickr_nr'); ?>" type="text" name="<?php echo $this->get_field_name('flickr_nr'); ?>" value="<?php echo $instance['flickr_nr']; ?>" class="widefat" />
		</p>
	<?php
	}
}

register_widget('al_flickr_widget');


/* ***************************************************** 
 * Plugin Name: Last Tweets
 * Description: Displays Latest Tweets.
 * Version: 1.1
 * Author: Weblusive
 * Author URI: http://www.weblusive.com
 * ************************************************** */

add_action( 'widgets_init', 'es_tweets_widgets' );

function es_tweets_widgets() {
	register_widget( 'ES_Tweet_Widget' );
}
class es_tweet_widget extends WP_Widget {

	function ES_Tweet_Widget() {
	
		$widget_ops = array( 'classname' => 'es_tweet_widget', 'description' => __('A custom widget for displaying your latest tweets.', 'arizona') );
		$this->WP_Widget( 'es_tweet_widget', __('Arizona Latest Tweets','arizona'), $widget_ops);
	}

	function widget( $args, $instance ) {
		extract( $args );

		$title = apply_filters('widget_title', $instance['title'] );
		$username = $instance['username'];
		$postcount = $instance['postcount'];
	
		echo $before_widget;

		if ( $title )
			echo $before_title . $title . '<span class="twitbird">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>'.$after_title;
		
		 ?>
        	<ul id="twitter_update_list" class="twitter">
                <li><p></p></li>
            </ul>
            <a href="http://twitter.com/<?php echo $username ?>" class="twitter-link"></a>
			<script type="text/javascript" src="<?php echo get_template_directory_uri() ?>/js/twitter.js"></script>
			<script type="text/javascript" src="http://twitter.com/statuses/user_timeline/<?php echo $username ?>.json?callback=twitterCallback2&amp;count=<?php echo $postcount ?>"></script>
                            
        
		
		<?php 

		echo $after_widget;
	}

	function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		$instance['title'] = strip_tags( $new_instance['title'] );
		$instance['username'] = strip_tags( $new_instance['username'] );
		$instance['postcount'] = strip_tags( $new_instance['postcount'] );
		
		return $instance;
	}
	
	function form( $instance ) {

		$defaults = array(
		'title' => 'Latest Tweets',
		'username' => 'wpmeta',
		'postcount' => '5',
		'tweettext' => 'Follow on Twitter',
		);
		$instance = wp_parse_args( (array) $instance, $defaults ); ?>

		<div>
			<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e('Title:', 'arizona') ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo $instance['title']; ?>" />
		</div>

		<div>
			<label for="<?php echo $this->get_field_id( 'username' ); ?>"><?php _e('Twitter Username (e.g., weblusive)', 'arizona') ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id( 'username' ); ?>" name="<?php echo $this->get_field_name( 'username' ); ?>" value="<?php echo $instance['username']; ?>" />
		</div>
		
		<div>
			<label for="<?php echo $this->get_field_id( 'postcount' ); ?>"><?php _e('Number of tweets (Keep < 20)', 'arizona') ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id( 'postcount' ); ?>" name="<?php echo $this->get_field_name( 'postcount' ); ?>" value="<?php echo $instance['postcount']; ?>" />
		</div>
		
	<?php
	}
}
?>