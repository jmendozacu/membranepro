jQuery.noConflict();

jQuery(document).ready(function () {
	jQuery(".toggle-container").hide();
	jQuery("#al_body_font, #al_headings_font, #al_menu_font").after('<div class="font-preview"></div>');
    if (jQuery('.color-picker').size() > 0) {
        jQuery('.color-picker').ColorPicker({
            onSubmit: function (hsb, hex, rgb, el) {
                jQuery(el).val('#' + hex);
                jQuery(el).ColorPickerHide();
            },
            onBeforeShow: function () {
                jQuery(this).ColorPickerSetColor(this.value);
            }
        }).bind('keyup', function () {
            jQuery(this).ColorPickerSetColor(this.value);
        });
    }
	
	jQuery("#al_body_font, #al_headings_font, #al_menu_font").change(function() {
		var font = jQuery(this).val();
		if(font != '' && font != 'off' && font != 'none')
		{
			var preview = '/wp-content/themes/arizona/library/admin/font-preview.php?font='+font;
			jQuery(this).next().html('<a href="'+preview+'" target="_blank">Click to Preview</a>');
			//window.open(preview);			
		} 
		else 
		{
			jQuery(this).next().html('Default font will be set.');
		} 
	});
    
}) 