<?php

/**** ADMIN PANEL MODULE ****/

$panelPath = TEMPLATEPATH . '/library/admin/admin-panel/';
require_once ($panelPath . 'general-settings.php');
?>
