<?php
/**
 * The Template for displaying all single posts.
 */

get_header(); ?>
<?php $al_options = get_option('al_general_settings'); ?>	
<div id="content">
	<div id="content-top"></div>
    <div id="content-inner">
        <div id="title-container">
            <h1 class="top-title"><?php _e('Blog', 'arizona'); ?></h1>	
            <?php if(class_exists('the_breadcrumb') && $al_options['al_allow_breadcrumbs']){ $bc = new the_breadcrumb; } ?>
        </div>
		<div class="two_third">
			<?php if ( have_posts() ) while ( have_posts() ) : the_post(); ?>
		
				<div id="post-<?php the_ID(); ?>" class="post-block inner">
                	<h2 class="post-title inner bottom10"><?php the_title(); ?></h2>
                	<div class="post-block-inner">
                        <div class="blog-stripe">
							<?php
                                    printf( __( ' <div class="date-label">%1$s</div> <div class="author-inner">by %2$s</div>', 'arizona' ),
                                    sprintf( '%2$s',esc_attr( get_the_time() ),get_the_date()),
                                    sprintf( '<a class="url fn n" href="%1$s" title="%2$s">%3$s</a>',
                                        get_author_posts_url( get_the_author_meta( 'ID' ) ),
                                        sprintf( esc_attr__( 'View all posts by %s', 'arizona' ), get_the_author() ),
                                        get_the_author())
                                   );
                               
                            ?>
                            <?php if ( count( get_the_category() ) ) : ?>
                            <div class="post-categories"><?php the_category(', '); ?></div>
                            <?php endif; ?>
                          
                            <div class="clear"></div>
                        </div>
                        <div class="top20 bottom10">
                        	<?php if(function_exists('woo_tumblog_content')){ woo_tumblog_content();} ?> 
                            <?php the_content(); ?>
                        </div>
                         <?php
                            $tags_list = get_the_tag_list( '', ', ' );
                            if ( $tags_list ) : ?>
                            <span class="post-tags"><?php printf( __( 'Tagged: %s', 'arizona' ), $tags_list ); ?></span>
                        <?php endif; ?>
                    </div>
                </div>
                   
				<?php if ( get_the_author_meta( 'description' ) ) : // If a user has filled out their description, show a bio on their entries  ?>
					<h3 id="author-title"><?php printf( esc_attr__( 'About %s', 'arizona' ), get_the_author() ); ?></h3>
					<div id="author-info" class="rounded-all">	
						<div id="author-avatar">
							<?php echo get_avatar( get_the_author_meta( 'user_email' ), 60 ); ?>
						</div>
						<div id="author-description">
							<?php the_author_meta( 'description' ); ?>
	                        <a href="<?php echo get_author_posts_url( get_the_author_meta( 'ID' ) ); ?>">
								<?php printf( __( 'View all posts by %s', 'arizona' ), get_the_author() ); ?>
							</a>
						</div>
	
					</div>
	                
	                <div class="clearfix"></div>
	                
					<div class="hr"><hr /></div>
				<?php endif; ?>	
				<?php comments_template( '', true ); ?>	
			<?php endwhile; ?>
		</div>		
		
		<div class="one_third last">
			<?php dynamic_sidebar("Global Sidebar") ?>
        </div>    
		<div class="clear"></div>
        
	</div>
    <div id="footer-top"></div>
</div>

<?php get_footer(); ?>