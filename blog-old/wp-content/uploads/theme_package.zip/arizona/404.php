<?php
/**
 * The template for displaying 404 pages (Not Found).
 *
 */

get_header(); ?>

<div id="content">
	
	<div id="content-inner" style="min-height:400px">
		<div class="one_third">
        	 <h1 style="font-size:96px">404</h1>
       		 <h4 ><?php _e('Page Not Found.', 'arizona')?></h4>
        </div>
    	<div class="two_third last">
       
        	<h2 class="sorry404">
            	<?php _e('Sorry, the page or file you requested may have been moved or deleted.', 'arizona')?>
            </h2>
            <div class="error-descr-block">
                <h4 class="inner-title"><?php _e('Here are some recommendations to follow:', 'arizona')?></h4>
                <ul class="features-list" id="error-page-list">
                    <li>
                    	<?php _e('Go to ', 'arizona')?><a href="<?php  echo home_url()  ?>" title="<?php bloginfo( 'name' ); ?>"><?php _e('Home Page', 'arizona')?></a> 
                    	<?php _e('and start browsing again.', 'arizona')?>
                    </li>
                    <li><?php _e('Use the search box below.', 'arizona')?></li>
                </ul>
                <?php get_search_form(); ?>
              
            </div>
        </div>
        
        <div class="clear"></div>
	</div>
    <div id="footer-top"></div>
</div>
<?php get_footer(); ?>