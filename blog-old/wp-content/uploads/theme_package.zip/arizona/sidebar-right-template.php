<?php
/* Template Name: With Sidebar (Right) */
?>
<?php get_header(); ?>
<div id="content">
	<div id="content-top"></div>
    <div id="content-inner">
        <div id="title-container">
            <h1 class="top-title bottom20"><?php the_title(); ?></h1>	
            <?php if(class_exists('the_breadcrumb') && $al_options['al_allow_breadcrumbs']){ $bc = new the_breadcrumb; } ?>
        </div>
        <div class="two_third">
		 	<?php if ( have_posts() ) while ( have_posts() ) : the_post(); ?>
				<?php the_content(); ?>
			<?php endwhile; ?>	
		</div>
		<div class="one_third last">
			<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar("Global Sidebar") ) : ?> <?php   endif;?>
		</div>
	   	<div class="clear"></div>
  	</div>
</div>
<?php get_footer(); ?>