<?php
/**
 * Portfolio Single Posts template.
 */

get_header(); ?>
	<?php  $al_options = get_option('al_general_settings'); ?>
   
	<div id="content">
    	<div id="content-top"></div>
		<div id="content-inner">
        <div id="title-container">
            <h1 class="top-title">Portfolio</h1>
            <?php if(class_exists('the_breadcrumb') && $al_options['al_allow_breadcrumbs']){ $albc = new the_breadcrumb; } ?>	
        </div>
			<h2 class="top-title"><?php the_title()?></h2>
			<div class="two_third">
				<?php 
					$id = 0;
					if ( have_posts() ) while ( have_posts() ) : the_post(); 
						the_content(); 
					endwhile; 
				?>
            </div>
            <div class="one_third last top10">
            	<?php dynamic_sidebar("Portfolio Single Sidebar") ?>
            </div>
            <div class="clear"></div>
           
		</div>
        
	</div>
	
<?php get_footer(); ?>