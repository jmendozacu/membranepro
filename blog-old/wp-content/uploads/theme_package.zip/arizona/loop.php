<?php /*** The loop that displays posts.***/ ?>

<?php 

$al_options = get_option('al_general_settings');
?>
<?php if ( ! have_posts() ) : ?>
	<div id="post-0" class="post error404 not-found">
		<h1 class="entry-title"><?php _e( 'Not Found', 'arizona' ); ?></h1>
		<div class="entry-content">
			<p><?php _e( 'Apologies, but no results were found for the requested archive. Perhaps searching will help find a related post.', 'arizona' ); ?></p>
			<?php get_search_form(); ?>
		</div><!-- .entry-content -->
	</div><!-- #post-0 -->
<?php endif; ?>


<?php while ( have_posts() ) : the_post(); ?>
	<div class="post-block" id="post-<?php the_ID();?>">
        <h2 class="post-title bottom5">
        	<a href="<?php the_permalink(); ?>" title="<?php printf( esc_attr__( 'Permalink to %1$s', 'arizona' ), the_title_attribute( 'echo=0' ) ); ?>" rel="bookmark">
			<?php the_title(); ?></a>
        </h2>
    	<div class="date-label">
            <?php the_time('F j, Y'); ?>
        </div>
       	<?php if ( count( get_the_category() ) ) : ?>
             <div class="post-categories">
                <?php printf( __( '<span>Posted in</span> %1$s', 'essence' ), get_the_category_list( ', ' ) ); ?>
            </div>
        <?php endif; ?>
        
        <?php if( 'open' == $post->comment_status) : ?>
            <?php comments_popup_link( __( 'No Comments', 'essence' ), __( '1 Comment', 'essence' ), __( '% Comments', 'essence' ), 'post-comm' ); ?>
        <?php endif; ?>
        
        <div class="clear"></div>
      
        <p class="top10" style="border-top:dotted 1px #ccc">
            <a href="<?php the_permalink(); ?>" class="post-thumb" title="<?php the_title(); ?>">
                <?php the_post_thumbnail('blog-list'); ?>
            </a>
        </p>
        <div class="post-desc">
        	<?php the_excerpt(); ?>
        </div>
        <div class="clear"></div>
  </div>

<?php endwhile; // End the loop. Whew. ?>

<?php /* Display navigation to next/previous pages when applicable */ ?>

<div class="navigation">
<?php if ( $wp_query->max_num_pages > 1 ) :
   include(arizona_PLUGINS . '/wp-pagenavi.php' );
   if(function_exists('wp_pagenavi')) { wp_pagenavi(); }
?>
<?php endif; ?>
</div>