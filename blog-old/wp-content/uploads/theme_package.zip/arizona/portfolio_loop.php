<?php 
	$page_template_name = get_post_meta($post->ID,'_wp_page_template',true); 
	$al_options = get_option('al_general_settings');
	$cols = 3;
	// Check which layout was selected
	switch($page_template_name)
	{
		case 'portfolio-template-3columns.php':
		$cols = 3;	
		break;
	}
?>

<div id="content">
	<div id="content-top"></div>
    <div id="content-inner">
        <div id="title-container">
            <h1 class="top-title"><?php the_title(); ?></h1>	
            <?php if(class_exists('the_breadcrumb') && $al_options['al_allow_breadcrumbs']){ $bc = new the_breadcrumb; } ?>
        </div>
		<?php
			$loop = new WP_Query(array('post_type' => 'portfolio', 'posts_per_page' => 10)); 
			// If the number of items per page has been set
			if( get_post_meta($post->ID, "_page_portfolio_num_items_page", $single = true) != '' ) { 
				$items_per_page = get_post_meta($post->ID, "_page_portfolio_num_items_page", $single = false);
				
			} else { // else don't paginate
				$items_per_page = 777;
			}
				
			$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
			
			$wp_query = new WP_Query( array('post_type' => 'portfolio', 'paged' => $paged, 'showposts' => $items_per_page[0] ) ); 
			
			$counter = 1;
		?>
        <ul id="portfolio-list" class="cols-<?php echo $cols?>"><?php
			while ($wp_query->have_posts()) : $wp_query->the_post();
				$custom = get_post_custom($post->ID);
			   	?>
				<li <?php if($counter>0 && $counter%$cols==0):?>class="edge"<?php endif?>>
					<div>
						<?php the_post_thumbnail('portfolio-thumb-'.$cols.'cols', array('class' => 'portfolio')); ?>
					</div>
					<div>
						<h4>       
							<a href="<?php the_permalink(); ?>">
								<?php the_title(); ?>
							</a>
						</h4>
						<p><?php echo  limit_words(get_the_excerpt(), '11'); ?></p>
					 
						<span class="poverlay"></span>
						<a href="<?php $full_image = wp_get_attachment_image_src(get_post_thumbnail_id($post->ID), 'full', false); echo $full_image[0]; ?>" class="zoom-icon" title="<?php the_title(); ?>" rel="prettyPhoto"></a>     
						<a href="<?php the_permalink(); ?>" class="read-more button small gray"><span>Read More</span></a>
						<div class="clear"></div>
                    </div>						
				</li>
			
		<?php $counter++; endwhile; ?>
		</ul> 
		<div class="clear"></div>
		<?php
			// If the user has set a number of items per page, then display pagination
			if( $items_per_page != 777 ) {
				include(arizona_PLUGINS . '/wp-pagenavi.php' );
				if(function_exists('wp_pagenavi')) { wp_pagenavi(); }
			} 
		?>
		<div class="clear"></div>
	</div>
</div>

