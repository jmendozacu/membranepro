<?php


//If the form is submitted
if(isset($_POST['send'])) 
{
	$email= '';
	$message = '';
	$contactName = stripslashes(trim($_POST['contactName']));
	$company = stripslashes(trim($_POST['company']));
	if (empty($company)) $company = _e('Not Specified', 'arizona');
	$website = trim($_POST['website']);
	if (empty($website)) $website = _e('Not Specified', 'arizona');
	$name = "";
	
	$al_options = explode(',', $_POST['options']);
	
	//If there is no error, send the email
	if(!isset($hasError)) 
	{
		if(trim($_POST['contactName']) === '') 
		{
			$nameError = _e('You forgot to enter your name.', 'arizona');
			$hasError = true;
		} 
		else 
		{
			$name = trim($_POST['contactName']);
		}
		
		//Check to make sure sure that a valid email address is submitted
		if(trim($_POST['email']) === '')  
		{
			$emailError = _e('You forgot to enter your email address.', 'arizona');
			$hasError = true;
		} 
		else if (!eregi("^[A-Z0-9._%-]+@[A-Z0-9._%-]+.[A-Z]{2,4}$", trim($_POST['email']))) 
		{
			$emailError = 'You entered an invalid email address.';
			$hasError = true;
		}
		else 
		{
			$email = trim($_POST['email']);
		}
		 
		//Check to make sure comments were entered 
		if(trim($_POST['message']) === '') 
		{
			$messageError = _e('You forgot to enter your message.', 'arizona');
			$hasError = true;
		} 
		else 
		{
			if(function_exists('stripslashes')) 
			{
		  		$message = stripslashes(trim($_POST['message']));
		 	} 
		 	else 
			{
		  		$message = trim($_POST['message']);
			}
		}
	}
	if(!isset($hasError)) 
	{		
		$status = "";
		
		$to .= $al_options[3];
		
		// subject
		$subject = $al_options[2];
		
		// message
		$fullmessage = '
		<html>
		<head>
		  <title>E-mail from website</title>
		</head>
		<body>
		  <table>
			<tr>
			  <th>Company</th>
			  <th>Website</th>
			</tr>
			<tr>
			  <td>'.$company.'</td><td>'.$website.'</td>
			</tr>
			<tr>
				<th>Message</th>
			</tr>
			<tr>
				<td>'.$message.'</td>
			</tr>
		  </table>
		</body>
		</html>
		';
		
		// To send HTML mail, the Content-type header must be set
		$headers  = 'MIME-Version: 1.0' . "\r\n";
		$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
		
		// Additional headers
		$headers .= 'To:  <'.$al_options[3].'>' . "\r\n";
		$headers .= 'From: '.$contactName.' <'.$email.'>' . "\r\n";
	
		
		// Mail it
		if(!mail($to, $subject, $fullmessage, $headers)){
			$status =  $al_options[0];
		}
		else
		{
			$status =  $al_options[1];
		}
		
		echo $status; die();	
	}
}
?>