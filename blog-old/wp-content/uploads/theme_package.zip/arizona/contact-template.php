<?php /* Template Name: Contact Form */ ?>

<?php get_header(); ?>
	<div id="content">
    	<div id="content-top"></div>
    	<div id="content-inner">
            <div id="title-container">
                <h1 class="top-title"><?php the_title(); ?></h1>	
                <?php if(class_exists('the_breadcrumb') && $al_options['al_allow_breadcrumbs']){ $bc = new the_breadcrumb; } ?>
            </div>
       		<div class="two_third">
			   <?php if (have_posts()) : ?>
 
  					<?php while (have_posts()) : the_post(); ?>
   						
	   					<?php if(isset($hasError) || isset($captchaError)): ?>
	    					<p class="error"><?php _e('There was an error submitting the form.', 'arizona')?><p>
	   					<?php endif ?>
 						
		   				<form action="" id="contact-form" method="post">
		            		<div id="status"></div>
			                <div class="floated">
			                    <label for="contactName"><?php _e( 'Name', 'arizona' ); ?>*:</label>
			                   	<input type="text" name="contactName" id="contactName" value="<?php if(isset($_POST['contactName'])) echo $_POST['contactName'];?>" class="requiredField txt" />
								<?php if(isset($nameError) && $nameError != ''): ?><span class="error"><?php echo $nameError;?></span><?php endif;?>
                                <div class="clear"></div>
						    </div>
			                <div class="floated">
			                    <label for="email"><?php _e( 'E-mail', 'arizona' ); ?>*:</label>
			                    <input type="text" name="email" id="email" value="<?php if(isset($_POST['email'])) echo $_POST['email'];?>" class="requiredField email txt" />
								<?php if(isset($emailError) && $emailError != ''): ?><span class="error"><?php echo $emailError;?></span><?php endif;?>
						    	<div class="clear"></div>
			                </div>
			                <div class="floated">
			                    <label for="company"><?php _e( 'Company', 'arizona' ); ?>:</label>
			                    <input type="text" name="company" value="<?php if(isset($_POST['company'])) echo $_POST['company'];?>" class="txt" id="company" />
			                    <?php if(isset($company) && !$company = ''): ?><span class="error"><?php echo $companyError;?></span><?php endif;?>
			                	<div class="clear"></div>
                            </div>
			                <div class="floated">
			                    <label for="website"><?php _e( 'Website', 'arizona' ); ?>:</label>
			                    <input type="text" name="website" class="txt" id="website"  value="<?php if(isset($_POST['website'])) echo $_POST['website'];?>"  />
			                    <?php if(isset($websiteError) && $websiteError != ''): ?><span class="error"><?php echo $websiteError;?></span><?php endif;?>
			                	<div class="clear"></div>
                            </div>
			                <div class="floated">
			                    <label for="message"><?php _e( 'Message', 'arizona' ); ?>*:</label>
			                    <textarea name="message" cols="100" rows="200" id="message" class="txt requiredField"><?php echo isset($_POST['message']) && $_POST['message']!='' ?  stripslashes($_POST['message'])  : ''?></textarea>
								<?php if(isset($messageError) && $messageError != '') { ?>
									<span class="error"><?php echo $messageError;?></span> 
								<?php } ?>
                                <div class="clear"></div>
			                </div>
			                <div>
			                	<?php 
			                		$al_options = get_option('al_general_settings'); 
			                		$options = array(
			                						$al_options['al_contact_error_message'], 
			                						$al_options['al_contact_success_message'],
			                						$al_options['al_subject'],
			                						$al_options['al_email_address'],
			                						);
			                	?>
			                	<input type="hidden" name = "options" value="<?php echo implode(',', $options) ?>" />
			                	<input type="hidden" name="siteurl" value="<?php echo get_option('blogname')?>" />
			                
			                    <button type="submit" id="send" name="send" class="button small blue"><span><?php _e( 'Send Message', 'arizona' ); ?></span></button>
                            </div>
		                </form>
                        <div class="clear"></div>
		            </div>
		      
                   	<div class="one_third last">
                    	<?php the_content(); ?>
                   	</div> 	
                   	<div class="clear"></div>
                   
                 </div>
               
		   </div>
    <!-- END CONTENT -->
    <?php endwhile; ?>
 <?php endif; ?>
<script type="text/javascript">

jQuery(document).ready(function(){
  jQuery("#contact-form").validate({
	submitHandler: function() {
	
		var postvalues =  jQuery("#contact-form").serialize();
		
		
		jQuery.ajax
		 ({
		   type: "POST",
		   url: "<?php echo get_template_directory_uri()  ?>/contact-form.php",
		   data: postvalues,
		   success: function(response)
		   {
		 	 jQuery("#status").addClass('success-message').html(response).show('normal');
		     jQuery('#contact-form :input.not("#send")').val("");
		   }
		 });
		return false;
		
    },
	focusInvalid: true,
	focusCleanup: false,
  	rules: 
	{
		contactName: {required: true},
		email: {required: true, minlength: 6,maxlength: 50, email:true},
		message: {required: true}
	},
	
	messages: 
	{
		contactName: {required: "<?php _e( 'This field is required', 'arizona' ); ?>"},
		email: {required: "<?php _e( 'This field is required', 'arizona' ); ?>", email: "<?php _e( 'Please provide a valid e-mail', 'arizona' ); ?>"},
		message: {required: "<?php _e( 'This field is required', 'arizona' ); ?>"}
		
	},
	
	errorPlacement: function(error, element) 
	{
		error.insertAfter(element);
	},
	invalidHandler: function()
	{
		jQuery("body").animate({ scrollTop: 0 }, "slow");
	}
});
});


</script>
 
<?php get_footer(); ?>   

