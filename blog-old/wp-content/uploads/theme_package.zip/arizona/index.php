<?php
/*** The template for displaying Tag Archive pages. ***/

get_header(); ?>
	<div id="content">
    	<div id="content-top"></div>
		<div id="content-inner">		
			<div class="two_third">
				<?php
                /* Run the loop for the tag archive to output the posts */
                 get_template_part( 'loop', 'index' );
                ?>
            </div>
            <div class="one_third last">
            	<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar("Global Sidebar") ) : ?> <?php   endif;?>
            </div> 
            <div class="clear"></div>
            
		</div><!-- #content-iiner -->
	</div><!-- #content -->
<?php get_footer(); ?>
