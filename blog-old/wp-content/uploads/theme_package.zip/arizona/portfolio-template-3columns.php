<?php 
/* Template Name: Portfolio */
get_header(); 

include('portfolio_loop.php');

get_footer(); 

?>