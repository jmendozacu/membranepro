<?php /** Functions file for Arizona theme. **/

/********************* DEFINE MAIN PATHS ********************/

define('arizona_PLUGINS', TEMPLATEPATH . '/plugins' ); // Shortcut to the /plugins/ directory

$adminPath 	= TEMPLATEPATH . '/library/admin/';
$funcPath 	= TEMPLATEPATH . '/library/functions/';
$incPath 	= TEMPLATEPATH . '/library/includes/';

global $al_options;
$al_options = isset($_POST['options']) ? $_POST['options'] : get_option('al_general_settings');


/************************************************************/

/** REMOVE UNNECESSARY STUFF THE WORDPRESS LOADS BY DEFAULT**/

remove_action('wp_head', 'rsd_link');
remove_action('wp_head', 'wlwmanifest_link');
remove_action('wp_head', 'index_rel_link');
remove_action('wp_head', 'wp_generator');

/*********** LOAD ALL REQUIRED SCRIPTS AND STYLES ***********/
function loadScripts()
{
	if( !is_admin())
	{
		wp_deregister_script('jquery'); 
	   	wp_register_script('jquery', get_template_directory_uri().'/js/jquery-1.5.1.min.js', false, '1.5.1'); 
	   	wp_enqueue_script('jquery');
	  	wp_enqueue_script('jquery-tools', get_template_directory_uri(). '/js/jquery.tools.min.js', array('jquery'), '1.2.5' );
	 	wp_enqueue_script('prettyphoto', get_template_directory_uri(). '/js/jquery.prettyPhoto.js', array('jquery'), '3.0.1' );
	  	wp_enqueue_style('slider-styles',get_template_directory_uri().'/sliders/accordion/styles.css');
	  	wp_enqueue_style('pretty-photo', get_template_directory_uri().'/css/prettyPhoto.css',false,'3.0.1','all');
		wp_enqueue_script('top-menu', get_template_directory_uri(). '/js/menu.js');
		wp_enqueue_script('my-custom-scripts', get_template_directory_uri(). '/js/custom.js', array('jquery'), '1.0' );
		wp_enqueue_script('top-menu', get_template_directory_uri(). '/js/menu.js');
		wp_enqueue_script('accordion-slider', get_template_directory_uri(). '/sliders/accordion/jquery.easyAccordion.js');
	}
}
add_action( 'init', 'loadScripts' ); //Load All Scripts

function loadValidation(){
	if( !is_admin())
	{
		if (is_page_template('contact-template.php')){
			 wp_enqueue_script('Validate', get_template_directory_uri().'/js/validate.js',array('jquery'));
		}
	}
}
add_action( 'wp_print_scripts', 'loadValidation' ); 
/************************************************************/


/********************* DEFINE MAIN PATHS ********************/

require_once ($incPath . 'the_breadcrumb.php');
require_once ($funcPath . 'options.php');
require_once ($funcPath . 'post-types.php');
require_once ($funcPath . 'widgets.php');
require_once ($funcPath . 'shortcodes.php');


require_once ($adminPath . 'custom-fields.php');
require_once ($adminPath . 'scripts.php');
require_once ($adminPath . 'admin-panel/admin-panel.php');

// Redirect To Theme Options Page on Activation
if (is_admin() && isset($_GET['activated'])){
	wp_redirect(admin_url('admin.php?page=adminpanel'));
}

/************** ADD SUPPORT FOR LOCALIZATION ***************/

load_theme_textdomain( 'arizona', TEMPLATEPATH . '/languages' );

	$locale = get_locale();

	$locale_file = TEMPLATEPATH . "/languages/$locale.php";
	if ( is_readable( $locale_file ) )
		require_once( $locale_file );

/************************************************************/


/**************** ADD SUPPORT FOR POST THUMBS ***************/

add_theme_support( 'post-thumbnails');
add_theme_support( 'automatic-feed-links');

// Define various thumbnail sizes
add_image_size('portfolio-thumb-3cols', 250, 140, true); 
add_image_size('blog-list', 260, 130, true);

/************************************************************/


/******************** CONTENT WIDTH *************************/
if ( ! isset( $content_width ) ) $content_width = 960;
/************************************************************/


/************* ADD SUPPORT FOR WORDPRESS 3 MENUS ************/

add_theme_support( 'nav-menus' );
if(function_exists('register_nav_menu')):
	register_nav_menu( 'primary_nav', 'Primary Navigation');
endif;

/************************************************************/


/************* COMMENTS HOOK *************/

function arizona_comment($comment, $args, $depth) {
	$GLOBALS['comment'] = $comment; ?>
	
    <li <?php comment_class(); ?> id="li-comment-<?php comment_ID() ?>">
        <div id="comment-<?php comment_ID(); ?>">
            <div class="comment-author vcard">
            <?php echo get_avatar($comment,$size='42',$default='<path_to_url>' ); ?>
             
            <?php printf(__('<cite class="fn">%s</cite>'), get_comment_author_link()) ?>
            </div>
            <?php if ($comment->comment_approved == '0') : ?>
            <em><?php _e('Your comment is awaiting moderation.') ?></em>
            <br />
            <?php endif; ?>
         
            <div class="comment-meta commentmetadata">
                <a href="<?php echo htmlspecialchars(get_comment_link( $comment->comment_ID )) ?>"></a>
            </div>
            <p>	<a class="comment-date"><?php printf(__('%1$s at %2$s'), get_comment_date(),get_comment_time()) ?></a>
                <?php edit_comment_link(__('(Edit)'),'  ','') ?>
            </p>
         
            <?php comment_text() ?>
            <?php if($args['max_depth']!=$depth) { ?>
            <div class="reply button gray small">
            <?php comment_reply_link(array_merge($args, array('depth' => $depth, 'max_depth' => $args['max_depth']))) ?>
            
            <?php } ?>
            </div>
         </div>	
	<?php	
}

/*****************************************/


/************** FOOTER WIDGETS ************/

$al_options = get_option('al_general_settings'); 
$footer_widget_count = isset($al_options['al_footer_widgets_count']) ? $al_options['al_footer_widgets_count']:3;

for($i = 1; $i<= $footer_widget_count; $i++)
{
  if ( function_exists('register_sidebar') )
	register_sidebar(array(
	  	'name' => 'Footer Widget '.$i,
		'before_widget' => '<div class="block-'.$i.' ">',
		'after_widget' => '</div></div>',
		'before_title' => '	<h3>',
		'after_title' => '</h3><div class="hr"></div><div class="widget_footer_content">',
	));
}

/*******************************************/


/******* PORTFOLIO/GLOBAL SIDEBARS *********/

if ( function_exists('register_sidebar') )
{	
	register_sidebar(array(
		'name' => 'Global Sidebar',
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget' => '</div>',
        'before_title' => '<h3>',
        'after_title' => '</h3>',
    ));
}

if ( function_exists('register_sidebar') )
{	
	register_sidebar(array(
		'name' => 'Portfolio Single Sidebar',
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget' => '</div>',
        'before_title' => '<h3>',
        'after_title' => '</h3>',
    ));
}

/*******************************************/


/********* STRING MANIPULATIONS ************/

function al_trim($text, $length, $end = '[...]') {
	$text = preg_replace('`\[[^\]]*\]`', '', $text);
	$text = strip_tags($text);
	$text = substr($text, 0, $length);
	$text = substr($text, 0, last_pos($text, " "));
	$text = $text . $end;
	return $text;
}

function last_pos($string, $needle){
   $len=strlen($string);
   for ($i=$len-1; $i>-1;$i--){
       if (substr($string, $i, 1)==$needle) return ($i);
   }
   return FALSE;
}

function limit_words($string, $word_limit) {
 
	// creates an array of words from $string (this will be our excerpt)
	// explode divides the excerpt up by using a space character
 
	$words = explode(' ', $string);
 
	// this next bit chops the $words array and sticks it back together
	// starting at the first word '0' and ending at the $word_limit
	// the $word_limit which is passed in the function will be the number
	// of words we want to use
	// implode glues the chopped up array back together using a space character
 
	return implode(' ', array_slice($words, 0, $word_limit)).'...';
}

function excerpt_ellipse($text) {
   return str_replace('[...]', '<a href="'.get_permalink().'" class="button white small read-more top20"><span>Read more</span></a>', $text); }
add_filter('the_excerpt', 'excerpt_ellipse');

/*******************************************/


/**************  GOOGLE FONTS ***************/

function font_name($string){
		
	$check = strpos($string, ':');
			
	if($check == false){
		
		return $string;
		
	} else { 
		preg_match("/([\w].*):/i", $string, $matches);
		
		return $matches[1];
	} 
	
} 

/********************************************/
?>