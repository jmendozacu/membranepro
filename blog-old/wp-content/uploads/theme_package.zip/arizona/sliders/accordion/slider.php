<?php
$al_options = get_option('al_general_settings'); 
$loop = new WP_Query(array('post_type' => 'slider', 'posts_per_page' => 10));

?>

<script type="text/javascript">
jQuery(document).ready(function(){ 	
	jQuery('#accordion-1').easyAccordion({ 
		autoStart: <?php echo isset($al_options['accordion_autostart']) ? $al_options['accordion_autostart'] : 'true' ?>,
		slideInterval:  <?php echo isset($al_options['accordion_slide_interval']) ? $al_options['accordion_slide_interval'] : '3000' ?>,
		slideNum: <?php echo isset($al_options['accordion_slide_numbers']) ? $al_options['accordion_slide_numbers'] : 'true' ?>
	}); 	
}); 
</script>


<div id="accordion-1">
	<dl>
		<?php while ( $loop->have_posts() ) : $loop->the_post(); ?>
			<?php $custom = get_post_custom($post->ID);?>
			<dt><?php the_title() ?></dt>
			<dd><?php the_content() ?></dd>
	 	<?php endwhile; ?> 
  	</dl> 
</div>
