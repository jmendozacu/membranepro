<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html <?php language_attributes( ) ?>>
<head>
    <meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=UTF-8" /> 
	
	<title><?php bloginfo('name'); ?><?php wp_title(); ?></title>
    
	<link rel="alternate" type="application/rss+xml" title="RSS2.0" href="<?php bloginfo('rss2_url'); ?>" />
	<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
	<link rel="stylesheet" type="text/css"  media="all" href="<?php bloginfo( 'stylesheet_url' ); ?>" />

	<?php  $al_options = get_option('al_general_settings'); ?>
	
   	<?php if(!empty($al_options['al_favicon'])):?>
	<link rel="shortcut icon" href="<?php echo $al_options['al_favicon'] ?>" /> 
 	<?php endif?>
   	<?php if ( is_singular() ) wp_enqueue_script( 'comment-reply' ); ?>
   	<?php wp_head(); ?>
   
    <!--[if lte IE 6]><script src="<?php  get_template_directory_uri() ?>/js/ie6/warning.js"></script><script>window.onload=function(){e("<?php get_template_directory_uri()  ?>/js/ie6/")}</script><![endif]-->
  	<?php  if(isset($al_options['al_custom_js']) && !empty($al_options['al_custom_js'])) echo $al_options['al_custom_js'];?>
  	
   <?php 
   
   		$bodyFont = isset($al_options['al_body_font']) ? $al_options['al_body_font'] : 'off';
		$headingsFont =isset($al_options['al_headings_font']) ? $al_options['al_headings_font'] : 'Allan';
		$menuFont = isset($al_options['al_menu_font']) ? $al_options['al_menu_font'] : 'Allan';
	
		$fonts['body'] = $bodyFont;
		$fonts['h1, h2, h3, h4, h5, h6'] = $headingsFont;
		$fonts['.sf-menu a'] = $menuFont;
		
		foreach ($fonts as $value => $key)
		{
			if($key != 'off' && $key != ''){ 
				$api_font = str_replace(" ", '+', $key);
				$font_name = font_name($key);
				
				echo '<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family='.$api_font.'" />';
				echo "<style type=\"text/css\">".$value."{ font-family: '".$key."' !important; }</style>";			
			}
		}
	?>
</head>

<body <?php body_class(); ?>>
	
	<!-- BEGIN HEADER -->
	    
        <div id="header" <?php if(is_front_page()):?>class="header-home"<?php endif?>>
	        <div id="header-inner">
	            <div id="logo-container">
	               <a href="<?php echo site_url()?>">
                        <?php if(!empty($al_options['al_logo'])):?>
                            <img src="<?php echo $al_options['al_logo']?>" alt="<?php echo $al_options['al_logotext']?>" id="logo-image" />
                        <?php else:?>
                        	Arizona
                        <?php endif?>
                    </a>
	            </div>
              	<div id="header-right">
                	<?php if(!empty($al_options['al_hr_content'])) echo do_shortcode($al_options['al_hr_content'])?>
                </div>
		        <div class="clear"></div>
                
                <div id="menu-container">
					<?php 
                        if(function_exists('wp_nav_menu')):
                            wp_nav_menu( 
                            array( 
                                'menu' =>'primary_nav', 
                                'container'=>'div', 
                                'depth' => 3, 
                                'container_id' => 'menu',
                                'menu_class' => 'sf-menu'
                                )  
                            ); 
                        else:
                            ?>
                            <div id="menu">
                                <ul class="sf-menu top-level-menu"><?php wp_list_pages('title_li=&depth=3'); ?></ul> 
                            </div>
                            <?php
                        endif; 
                    ?>
                    <div class="clear"></div>
		   		</div>
		    </div>
	       	<?php if(is_front_page()):?>
                <div id="slider-mainwrap">
                    <?php include('sliders/accordion/slider.php');?>
                    <div class="clear"></div>
                </div>
            <?php endif?>
            
         </div>
	    <!-- END HEADER -->
    	