<?php /** The default template for pages. **/ ?>

<?php get_header(); ?>
<?php $al_options = get_option('al_general_settings');?>
  <div id="content">	
    	<div id="content-top"></div>
        <div id="content-inner">
            <div id="title-container">
                <h1 class="top-title"><?php the_title(); ?></h1>	
                <?php if(class_exists('the_breadcrumb') && $al_options['al_allow_breadcrumbs']){ $bc = new the_breadcrumb; } ?>
            </div>
            <?php if ( have_posts() ) while ( have_posts() ) : the_post(); ?>
                <?php the_content(); ?>
               
            <?php endwhile; ?>	
            <div class="clear"></div>
       </div>
	</div>
<?php get_footer(); ?>
