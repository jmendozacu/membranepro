<?php
/**
* The Header widget areas.
*
*/
?>

<div id="header-widget-area">
<ul class="xoxo">

<?php if ( ! dynamic_sidebar( 'header-widget-area' ) ) : ?>

			
<?php endif; // end primary widget area ?>
</ul>
</div><!-- #primary .widget-area -->
