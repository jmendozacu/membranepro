=== Plugin Name ===
Contributors: gn_themes
Donate link: http://ilovecode.ru/
Tags: shortcode, shortcodes, form, post, plugin, admin, front-end
Requires at least: 3.0
Tested up to: 3.2
Stable tag: 1.0.2

Front-end posting form for guests.
 Usage: <code>[wp_insert_post]</code>


== Description ==

Front-end posting form for guests.
 Usage: <code>[wp_insert_post]</code>

Bug report / contact author: http://ilovecode.ru/
My twitter: http://twitter.com/gn_themes


== Installation ==

1. Unzip plugin files and upload them under your '/wp-content/plugins/' directory. Resulted names will be:
   './wp-content/plugins/wp-insert-post/*'

2. Activate plugin at "Plugins" administration page.


== Upgrade Notice ==

Upgrade normally via your Wordpress admin -> Plugins panel.


== Screenshots ==

1. Post form.


== Frequently Asked Questions ==


== Changelog ==

= 1.0.0 =
* Initial release

