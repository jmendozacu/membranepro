<?php $strings = "tinyMCE.addI18n({en:{
meteor_shortcodes:{desc : 'Add a Custom Shortcode'},}});";
?>