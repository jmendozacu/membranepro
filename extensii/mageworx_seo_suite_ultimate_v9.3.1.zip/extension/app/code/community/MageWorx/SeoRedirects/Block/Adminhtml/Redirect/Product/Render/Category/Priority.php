<?php
/**
 * MageWorx
 * MageWorx_SeoRedirects Extension
 *
 * @category   MageWorx
 * @package    MageWorx_SeoRedirects
 * @copyright  Copyright (c) 2017 MageWorx (http://www.mageworx.com/)
 */
class MageWorx_SeoRedirects_Block_Adminhtml_Redirect_Product_Render_Category_Priority extends MageWorx_SeoRedirects_Block_Adminhtml_Redirect_Product_Render_Category
{
    protected $_fieldName = 'priority_category_id';
}