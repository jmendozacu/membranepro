<?php
/**
 * MageWorx
 * MageWorx SeoSuite Ultimate Extension
 * 
 * @category   MageWorx
 * @package    MageWorx_SeoSuiteUltimate
 * @copyright  Copyright (c) 2017 MageWorx (http://www.mageworx.com/)
 */


class MageWorx_SeoSuiteUltimate_Helper_Data extends Mage_Core_Helper_Abstract
{
    
}