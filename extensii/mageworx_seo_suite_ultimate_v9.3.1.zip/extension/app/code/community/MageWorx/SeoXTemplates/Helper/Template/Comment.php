<?php
/**
 * MageWorx
 * MageWorx SeoXTemplates Extension
 *
 * @category   MageWorx
 * @package    MageWorx_SeoXTemplates
 * @copyright  Copyright (c) 2017 MageWorx (http://www.mageworx.com/)
 */

abstract class MageWorx_SeoXTemplates_Helper_Template_Comment extends Mage_Core_Helper_Abstract
{
    abstract public function getComment($typeId);
}