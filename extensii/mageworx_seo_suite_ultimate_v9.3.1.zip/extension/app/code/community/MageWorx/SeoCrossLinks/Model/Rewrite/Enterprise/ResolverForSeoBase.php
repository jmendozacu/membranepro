<?php
/**
 * MageWorx
 * MageWorx SeoCrossLinks Extension
 *
 * @category   MageWorx
 * @package    MageWorx_SeoCrossLinks
 * @copyright  Copyright (c) 2017 MageWorx (http://www.mageworx.com/)
 */

class MageWorx_SeoCrossLinks_Model_Rewrite_Enterprise_CmsConfigResolver extends Enterprise_Cms_Model_Config
{
}