<?php
/**
 * @category    Mana
 * @package     ManaPro_FilterPositioning
 * @copyright   Copyright (c) http://www.manadev.com
 * @license     http://www.manadev.com/license  Proprietary License
 */
/**
 * @author Mana Team
 *
 */
class ManaPro_FilterPositioning_Model_Source_Position_Aboveproducts extends ManaPro_FilterPositioning_Model_Source_Position {
    protected $_position = 'above_products';
}