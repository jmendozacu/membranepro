<?php
/**
 * @category    Mana
 * @package     ManaPro_FilterAdvanced
 * @copyright   Copyright (c) http://www.manadev.com
 * @license     http://www.manadev.com/license  Proprietary License
 */
/**
 * Generic helper functions for ManaPro_FilterAdvanced module. This class is a must for any module even if empty.
 * @author Mana Team
 */
class ManaPro_FilterAdvanced_Helper_Data extends Mage_Core_Helper_Abstract {
}