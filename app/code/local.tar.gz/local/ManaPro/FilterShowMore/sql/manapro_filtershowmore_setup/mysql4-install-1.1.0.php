<?php
/**
 * @category    Mana
 * @package     ManaPro_FilterShowMore
 * @copyright   Copyright (c) http://www.manadev.com
 * @license     http://www.manadev.com/license  Proprietary License
 */
/* BASED ON SNIPPET: Resources/Install/upgrade script */
/* @var $installer ManaPro_FilterShowMore_Resource_Setup */
$installer = $this;

$installer->startSetup();

$installer->installEntities();

$installer->endSetup();