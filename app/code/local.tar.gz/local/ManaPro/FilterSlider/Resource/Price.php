<?php
/**
 * @category    Mana
 * @package     ManaPro_FilterSlider
 * @copyright   Copyright (c) http://www.manadev.com
 * @license     http://www.manadev.com/license  Proprietary License
 */

/**
 * Changes interpretation of applied price filter value
 * @author Mana Team
 *
 */
class ManaPro_FilterSlider_Resource_Price extends Mana_Filters_Resource_Filter_Price {
}