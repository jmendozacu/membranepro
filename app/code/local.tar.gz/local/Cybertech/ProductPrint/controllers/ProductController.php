<?php

require_once 'Mage/Catalog/controllers/ProductController.php';

class Cybertech_ProductPrint_ProductController extends Mage_Catalog_ProductController
{
	
}