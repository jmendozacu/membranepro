<?php

class Cybertech_ProductPrint_IndexController extends Mage_Core_Controller_Front_Action 
{

} 