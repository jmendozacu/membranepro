<?php
require_once 'Mage/Catalog/Model/Product.php';

class Cybertech_ProductPrint_Model_Product extends Mage_Catalog_Model_Product
{
    
}
