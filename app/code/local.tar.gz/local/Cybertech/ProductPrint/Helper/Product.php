<?php
require_once 'Mage/Catalog/Helper/Product.php';

class Cybertech_ProductPrint_Helper_Product extends Mage_Catalog_Helper_Product
{

}
