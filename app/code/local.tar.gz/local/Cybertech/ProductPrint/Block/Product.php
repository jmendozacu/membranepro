<?php
require_once 'Mage/Catalog/Block/Product.php';

class Cybertech_ProductPrint_Block_Product extends Mage_Catalog_Block_Product
{

}
