<?php  
 
class Cybertech_Newsletterdownload_Helper_Data extends Mage_Core_Helper_Data {
    
} 