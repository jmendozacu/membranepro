<?php

class TM_FireCheckout_Block_Checkout extends Mage_Checkout_Block_Onepage_Abstract
{}
