<?php
class Amasty_Shopby_Block_Catalog_Layer_View_Top extends Amasty_Shopby_Block_Catalog_Layer_View
{
    protected $_blockPos = 'top';
}