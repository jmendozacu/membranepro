<?php
class Amasty_Shopby_Block_Search_Layer_Right extends Amasty_Shopby_Block_Search_Layer
{
    protected $_blockPos = 'right'; 
}