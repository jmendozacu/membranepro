<?php

class Openstream_CustomListing_Helper_Data extends Mage_Core_Helper_Abstract
{

}