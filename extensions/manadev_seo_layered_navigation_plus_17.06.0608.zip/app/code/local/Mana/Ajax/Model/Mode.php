<?php
/**
 * @category    Mana
 * @package     Mana_Ajax
 * @copyright   Copyright (c) http://www.manadev.com
 * @license     http://www.manadev.com/license  Proprietary License
 */

class Mana_Ajax_Model_Mode {
	const OFF = 0;
	const ON_FOR_ALL = 1;
	const ON_FOR_USERS = 2;
}