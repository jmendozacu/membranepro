<?php
/**
 * @category    Mana
 * @package     Mana_Ajax
 * @copyright   Copyright (c) http://www.manadev.com
 * @license     http://www.manadev.com/license  Proprietary License
 */

class Mana_Ajax_Model_Method {
	const MARK_WITH_CSS_CLASS = 1;
	const WRAP_INTO_CONTAINER = 2;
}